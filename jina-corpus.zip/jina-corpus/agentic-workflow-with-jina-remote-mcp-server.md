---
title: "Agentic Workflow with Jina Remote MCP Server"
slug: agentic-workflow-with-jina-remote-mcp-server
url: https://cms.jina.ai/agentic-workflow-with-jina-remote-mcp-server/
published_at: 2025-08-29T03:46:41.000+02:00
updated_at: 2025-08-29T20:12:20.000+02:00
reading_time: 9
authors: "Alex C-G"
tags: "Tech Blog"
excerpt: "Jina MCP streamlines agent development by connecting our APIs to any LLM, reducing custom code and improving reliability of the workflow."
---

# Agentic Workflow with Jina Remote MCP Server

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/MCP" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/MCP: Official Jina AI Remote MCP Server
</div>
<div class="kg-bookmark-description">
Official Jina AI Remote MCP Server. Contribute to jina-ai/MCP development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-16.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/f9d9963e-0363-496c-bdec-fa5863f46b9f" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

We showed you, in a [previous post](https://jina.ai/news/using-deepseek-r1-reasoning-model-in-deepsearch/), how to integrate Jina AI’s [search and reader APIs](https://jina.ai/reader) with DeepSeek R1 to build a deep research agent, but it took a lot of custom code and prompt engineering to make it work. In this post we’ll do the same thing using the [Model Context Protocol (MCP)](https://www.anthropic.com/news/model-context-protocol), which uses a lot less custom code and is portable to different LLMs, but is still subject to a few pitfalls along the way.

To build our agent, we'll work with our recently released [MCP server](https://github.com/jina-ai/MCP), which provides access to Jina Reader, Embeddings and Reranker APIs along with URL-to-markdown, web search, image search, and embeddings/reranker tools.

## Agents and Model Context Protocol

There’s been a lot of [digital ink](https://techcrunch.com/2025/05/12/even-a16z-vcs-say-no-one-really-knows-what-an-ai-agent-is/) spilled about agents and agentic AI of late, often either hyping them up (like Gartner, who expect by 2028 about [15 percent of daily work decisions will be made autonomously by AI agents](https://techcrunch.com/2025/05/12/even-a16z-vcs-say-no-one-really-knows-what-an-ai-agent-is/)) or tearing them down (like Vortex who claim [most agentic AI propositions lack significant value or return on investment](https://techcrunch.com/2025/05/12/even-a16z-vcs-say-no-one-really-knows-what-an-ai-agent-is/)).

But what even are agents? One of the better definitions (from [Chip Huyen](https://huyenchip.com/2025/01/07/agents.html) via [Simon Willison](https://simonwillison.net/2025/Jan/11/agents/)) is:

> \[Agents are\] LLM systems that plan an approach and then run tools in a loop until a goal is achieved

That’s the definition we’re going with for this blog post. And those tools that the agent uses? They’re connected with Model Context Protocol. That protocol, originally developed by Anthropic, is becoming the lingua franca for connecting LLMs to external tools and data sources. This means that agents can chain together multiple tools in a single workflow. The result is agents that can plan, reason, and act by orchestrating a suite of APIs.

<figure class="kg-card kg-bookmark-card">
<a href="https://www.anthropic.com/news/model-context-protocol" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Introducing the Model Context Protocol
</div>
<div class="kg-bookmark-description">
The Model Context Protocol (MCP) is an open standard for connecting AI assistants to the systems where data lives, including content repositories, business tools, and development environments. Its aim is to help frontier models produce better, more relevant responses.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-45.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/1aef864f9b246c740fe3cef6e1068f2220995d5e-2400x1260-1.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

For example, we could build a price optimization agent that collects competitor product pricing for comparison and price optimization. Then we could outfit the agent with Jina AI’s MCP server, a prompt, and a list of competitor products, letting it generate an actionable report with scraped data and links to sources. By using additional MCP servers, the agent could export that report to PDF format, email it to stakeholders, store it in an internal knowledge base, and [more](https://mcp.so/).

In this post, we’ll build three example agents with our MCP server, which provides the following tools:

- **`primer`** - Get current contextual information for localized, time-aware responses
- **`read_url`** - Extract clean, structured content from web pages as Markdown via [Reader API](https://jina.ai/reader) (also available as a parallel version)
- **`capture_screenshot_url`** - Capture high-quality screenshots of web pages via Reader API
- **`guess_datetime_url`** - Analyze web pages for last update/publish datetime with confidence scores
- **`search_web`** - Search the entire web for current information and news via Reader API (also available as a parallel version)
- **`search_arxiv`** - Search academic papers and preprints on the [arXiv repository](https://arxiv.org) via Reader API (also available as a parallel version)
- **`search_images`** - Search for images across the web (similar to Google Images) via Reader API
- **`expand_query`** - Expand and rewrite web search queries based on the query expansion model via Reader API
- **`sort_by_relevance`** - Rerank documents by relevance to a query via [Reranker API](https://jina.ai/reranker)
- **`deduplicate_strings`** - Get top-k semantically unique strings via [Embeddings API](https://jina.ai/embeddings) and [submodular optimization](https://jina.ai/news/submodular-optimization-for-diverse-query-generation-in-deepresearch)
- **`deduplicate_images`** - Get top-k semantically unique images via Embeddings API and submodular optimization

We’ll also need an MCP client ([VS Code](https://code.visualstudio.com/) with Copilot, since it's free and widely used), and an LLM ([Claude Sonnet 4](https://www.anthropic.com/claude/sonnet), since it gave the best results in our testing).

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Moving forward, we'll refer to the combination of MCP client + LLM + MCP server(s) as "our agent" for the sake of brevity.

</div>

</div>

## Using the Jina AI MCP Server

MCP has been described as a [universal plugin system](https://worksonmymachine.ai/p/mcp-an-accidentally-universal-plugin), supporting multiple programs like Claude Code, VS Code, Google Gemini CLI, and the desktop front-ends for Claude and ChatGPT. Connecting up an MCP server is typically just a matter of editing your settings file to include the following:

``` json
{
  "mcpServers": {
    "jina-mcp-server": {
      "url": "https://mcp.jina.ai/sse",
      "headers": {
        "Authorization": "Bearer ${JINA_API_KEY}" // optional
      }
    }
  }
}
```

To test that the MCP server works, let’s use a simple prompt:

``` text
Give me a summary of the latest post on jina.ai news in the
form of a single verse sea shanty
```

Our agent does the following:

- Call `read_url` to scrape <https://jina.ai/news>
- Call `search_web` with the query `"site:jina.ai \\"Optimizing GGUFs for Decoder-Only Embedding Models\\" August 2025"`
- Call `read_url` to scrape the [blog post](https://jina.ai/news/optimizing-ggufs-for-decoder-only-embedding-models)
- Generate a one-verse sea shanty from the scraped data:

``` text
🎵 *To the tune of a traditional sea shanty* 🎵

**"The GGUF Sailor's Tale"**

*Oh, they sailed with their embeddings, three billion strong and true,*  
*Through quantized waters deep and blue,*  
*With L4 GPU winds at their back,*  
*Four thousand tokens per second on their track!*  
*Heave away, me hearties, strip the vision tower down,*  
*For GGUF optimizations are the finest ports in town!*
```

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Our agent typically produces very long outputs. Instead of including them all in the post, we’ll link to a GitHub gist for the rest of them.

</div>

</div>

Now that we’ve seen that it works in practice, let’s really put it through its paces by building some useful real-world examples.

## Example 1: Daily arXiv Paper Summaries

Reading the latest academic papers is part of our jobs at Jina AI. But filtering out the truly relevant ones and extracting the most important information from each can be a real chore. So, for our first experiment, we automated that task by creating a daily digest of the most relevant recent papers. Here’s the prompt we used:

``` text
Using only Jina tools, scrape arxiv for the papers about
LLMs, reranking, and embeddings published in the past 24
hours, then deduplicate and rerank for relevance, outputting
the top 10. For each one, scrape the PDF and extract the
abstract. Then summarize it and organize the information you
gathered into a "daily update". Include a link and publication
date for each paper.
```

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

We specify "Use only Jina tools" since VS Code has its own search and scraping functionality built in. This phrasing could be omitted on models that lack that functionality.

</div>

</div>

Our agent:

- Searches for relevant [arxiv.org](http://arxiv.org/) papers (using the `parallel_search_arxiv` tool) with the query strings `large language models LLM`, `reranking information retrieval`, `embeddings vector representations`, `transformer neural networks` and `natural language processing NLP`
- Removes duplicates (using the `deduplicate_strings` tool)
- Reranks the results (using `sort_by_relevance` tool), outputting only the ten most relevant results.
- Retrieves the URLs to the PDFs for the reranked results (using `parallel_read_url`), split into two batches of five.
- Reads each URL (using the `read_url` tool, called ten times)
- Generates a detailed [report](https://gist.github.com/alexcg1/9bec8b86849d48d45a56add8a55061d0), including abstracts, summaries, trends, and insights, implications for future research, research gaps, and conclusions.

<figure class="kg-card kg-bookmark-card">
<a href="https://gist.github.com/alexcg1/9bec8b86849d48d45a56add8a55061d0" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Arxiv Daily Update, generated with Jina MCP server tools
</div>
<div class="kg-bookmark-description">
Arxiv Daily Update, generated with Jina MCP server tools - arxiv_daily_update.md
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-17.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Gist</span><span class="kg-bookmark-publisher">262588213843476</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/gist-og-image-54fd7dc0713e-1.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

We occasionally ran into the problem that the agent didn’t limit its results to the past 24 hours. Prompting it one more time to follow that instruction resulted in the report above.

## Example 2: Market Research Agent

For our next experiment, we'll have our agent write a competitive intelligence report about a notable video game company (name redacted). Here's our prompt:

``` text
Create a comprehensive competitive intelligence report for
$GAME_COMPANY focusing on their recent activities in retro
indie games. Use Jina tools to search for the latest news,
press releases, and announcements, then extract clean content
from their official communications. Rank all findings by
business relevance and remove any duplicate information.
Present insights on their strategic direction, product
launches, and market positioning changes over the past
quarter
```

Our agent:

- Runs several loops of `search_web` and `read_url` to gather research.
- Reranks its findings using `sort_by_relevance`, outputting the top ten results.
- Generates a [market intelligence report](https://gist.github.com/alexcg1/6215f99e66e869b1a2eb5db7809cea21), including executive summary, critical business developments (ranked by strategic importance), strategic decision analysis, and many other sections.

<figure class="kg-card kg-bookmark-card">
<a href="https://gist.github.com/alexcg1/6215f99e66e869b1a2eb5db7809cea21" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GAME_COMPANY Competitive Intelligence Report: Retro Indie Games (Q3 2025)
</div>
<div class="kg-bookmark-description">
GAME_COMPANY Competitive Intelligence Report: Retro Indie Games (Q3 2025) - game_company_intelligence_report.md
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-18.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Gist</span><span class="kg-bookmark-publisher">262588213843476</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/gist-og-image-54fd7dc0713e-2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Example 3: Legal Compliance Research

As we said earlier, one of the useful aspects of MCP is that we can use multiple servers to get more complex outputs. In this case, we’re using the [PDF Reader MCP Server](https://github.com/sylphxltd/pdf-reader-mcp) in addition to our own to create a research report on the current state of AI legal compliance in the EU and the USA. We used the prompt:

``` text
Develop a knowledge base section focused on AI legal
compliance news and common pitfalls in the EU and USA as of
this moment. Report should be aimed at AI startups in EU.
Apply Jina MCP tools extensively: perform parallel web
searches and URL reads to efficiently extract detailed
content, deduplicate semantic overlaps, and rerank to surface
the most authoritative information. Cite all sources with
URLs and publication or update dates. Organize content
clearly and produce a formatted PDF document ready for
immediate use.
```

Our agent:

- Performs a parallel search operation for general information (using `parallel_search`) with the queries `EU AI Act 2024 compliance requirements startups legal obligations August 2025`, `USA AI regulation Biden executive order compliance requirements 2024 2025`, `AI startup legal pitfalls Europe GDPR data protection compliance 2025`, `AI liability insurance compliance requirements EU USA startups 2024 2025` and `AI ethics governance framework startups EU USA regulatory updates 2025`, returning 25 results for each query.
- Deduplicates the returned URLs (using `deduplicate_strings`)
- Reads the contents of four URLs (using `parallel_read_url`)
- Performs a further `parallel_search` for more specific information, with the queries `AI startup common compliance pitfalls mistakes EU USA 2025`, `AI liability insurance cybersecurity startup requirements 2025`, `AI bias discrimination testing requirements EU AI Act compliance startups`, `AI data protection GDPR violations penalties startups 2025`
- Uses `parallel_read_url` to read through a further four URLs
- Generates a [report](https://gist.github.com/alexcg1/0dd0b46f5a29564e65142cd1adea3664) in Markdown format and converts it to an 18-page PDF

<figure class="kg-card kg-bookmark-card">
<a href="https://gist.github.com/alexcg1/0dd0b46f5a29564e65142cd1adea3664" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
AI Legal Compliance Report - Jina MCP demo
</div>
<div class="kg-bookmark-description">
AI Legal Compliance Report - Jina MCP demo. GitHub Gist: instantly share code, notes, and snippets.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-19.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Gist</span><span class="kg-bookmark-publisher">262588213843476</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/gist-og-image-54fd7dc0713e-3.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

We also had to do a little further prompting to improve PDF metadata and formatting, as well as to make it more of a report instead of a very long bulleted list, but that’s something we would integrate into the prompt for future reports.

## Alternative Approaches

Before going with Claude Sonnet 4, we tried a range of [Ollama](https://www.notion.so/ollama.com/) models that supported tools, including [Qwen3](https://qwenlm.github.io/blog/qwen3/):30b, [Qwen2.5](https://qwenlm.github.io/blog/qwen2.5/):7b, and [llama3.3](https://www.llama.com/docs/model-cards-and-prompt-formats/llama3_3/):70b. For the MCP client, we initially used [ollmcp](https://github.com/jonigl/mcp-client-for-ollama) before jumping to VS Code. All of the above models failed in the same way, no matter how explicitly we prompted them with the tools and how to use them: When asked to perform even a simple task, like retrieve the latest blog post from Jina AI, each model (no matter the size or vendor) would consistently:

- Go into a lengthy reasoning loop, constantly second-guessing themselves (and using up tokens) until they finally resolve to just do as they were told
- Call `read_url` for <https://jina.ai/news>
- Inspect the blog post titles and excerpts
- Completely hallucinate that they scraped the latest post (without even calling `read_url` for that page)
- Present a summary based on the excerpt from the top search result (not the actual page content)
- When questioned, claim they followed the instructions exactly and scraped the page as requested

Models in the Claude, GPT and Gemini families provided acceptable output, though we pretty quickly landed on Claude Sonnet 4 as it made extensive use of tools (often reaching for parallel tooling options rather than the serial approach favored by GPT-4.1) and generated longer, better-structured output.

## Conclusion

There's still a lot of fuzziness around the term "agentic AI", but MCP represents a step towards making it something solid and practical. In our experience, agents aren't *quite* ready for prime time just yet, with the LLM generally being the weak link, but with a little hand-holding and experimentation, it's possible to get good results. That said, when you *do* get the right combination of prompt, LLM, and MCP servers, you can see agents reliably execute multi-step tasks with no custom code needed — something that was much harder with previous models like DeepSeek (that don't support tools), which required more manual engineering and resulted in brittle integration.

Despite these current limitations, the trajectory is promising. The MCP ecosystem is growing rapidly, bringing more integrations and tools that make it easier to mix and match APIs, such as Jina's, or to swap in new LLMs as they become available. As both the underlying models improve and the tooling ecosystem matures, the gap between experimental agents and production-ready agentic AI continues to narrow, making robust implementations increasingly accessible for real-world applications.
