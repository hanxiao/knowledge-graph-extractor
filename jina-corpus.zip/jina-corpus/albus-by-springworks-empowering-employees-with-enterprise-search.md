---
title: "Albus by Springworks: Empowering Employees with Enterprise Search"
slug: albus-by-springworks-empowering-employees-with-enterprise-search
url: https://cms.jina.ai/albus-by-springworks-empowering-employees-with-enterprise-search/
published_at: 2024-05-13T11:00:14.000+02:00
updated_at: 2024-07-08T21:10:05.000+02:00
reading_time: 5
authors: "Francesco Kruk, Saahil Ognawala"
tags: "Tech Blog"
excerpt: "Learn how a leading HR-tech startup uses Jina AI’s models to talk with structured and unstructured data."
---

# Albus by Springworks: Empowering Employees with Enterprise Search

The advent of Large Language Models (LLMs) and Retrieval Augmented Generation (RAG) has opened up many avenues for companies to leverage their data, but also poses the problem of connecting different sources to a single communication interface. HR-tech innovator [<u>Springworks</u>](https://www.springworks.in/) has set out to solve this problem in deep collaboration with Jina AI. 

This case study explores how [<u>Albus</u>](https://www.springworks.in/albus/), Springworks’ workplace productivity tool, uses <a href="https://jina.ai/embeddings" rel="noreferrer">Jina Embeddings</a> and <a href="https://jina.ai/reranker" rel="noreferrer">Reranker</a> to let you talk with data from different apps.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Start with 1M free tokens. Top-performing, 8192 context length bilingual embeddings for your search and RAG systems.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/reranker" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Reranker API
</div>
<div class="kg-bookmark-description">
Maximize the search relevancy and RAG accuracy at ease.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-reranker-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://www.springworks.in/albus/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Albus - AI Slack Search &amp; Web Assistant
</div>
<div class="kg-bookmark-description">
Seamlessly access workplace search and enhance collaboration. Albus is also your intelligent web assistant for rapid answers and browsing.
</div>
<div class="kg-bookmark-metadata">
<img src="https://assets-global.website-files.com/639b1128ea2a944b3451c51a/6409832b8f17ec9c5c877def_favicon%20albus.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">AI Slack Search &amp; Web Assistant</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://assets-global.website-files.com/639b1128ea2a944b3451c51a/644bb7a2cbe59be25235e1e2_Albus%20OG%20image.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Connecting All Your Apps to a Single Tool

Today’s digitalization has brought about an explosion in workplace collaboration tools, creating an environment where information is scattered across multiple, isolated platforms. Employees often have to search endlessly for information they remember reading somewhere, but cannot find again, such as results from a past brainstorming session or minutes of a sprint planning from the previous week. This fragmentation of information creates barriers that decrease productivity and add to frustration. Generative AI promises to address this issue, creating question-answering systems with access to multi-source data, so employees have a single source for answers. To do this, we need an AI application that can access all these information silos and integrate them.

## Springworks Albus to the Rescue

Albus integrates with [<u>100+ commonly used workplace applications</u>](https://www.springworks.in/albus/integrations/), including CRMs, ticketing systems, human resource management systems, and knowledge management tools. By leveraging Jina AI’s state-of-the-art Embedding and Reranker models with an LLM for generating answers, Albus answers employees' questions after analyzing all connected sources and using the most relevant and up-to-date information. Employees no longer need to search in multiple apps or remember specific file names and locations.

> “*We’ve evaluated almost all state-of-the-art embeddings and reranker models on our hand-crafted company-internal benchmarks, and Jina’s models truly stand out. Their technology not only meets but exceeds expectations.*”  
>   
> — *Kartik* Mandaville, *founder* and *CEO* of Springworks

## The Backbone of Springworks’ Solution

Springworks is collaborating with Jina AI to develop and iteratively improve Albus’s advanced RAG system. Albus retrieves both structured and unstructured data. An AI classifier decides whether a user's request should be resolved by querying a relational database or using <a href="https://jina.ai/news/what-is-colbert-and-late-interaction-and-why-they-matter-in-search/" rel="noreferrer"><code>jina-colbert-v1-en</code></a> to query unstructured data in a vector database. Regardless of the source, the retrieved results are then re-ranked using <a href="https://jina.ai/news/maximizing-search-relevancy-and-rag-accuracy-with-jina-reranker/" rel="noreferrer"><code>jina-reranker-v1-base-en</code></a> to find the most relevant information to answer any user question. 

> “*Jina AI’s customer success team has played a crucial role in optimizing our use of these models. With their prompt responses and thorough walkthroughs, they've simplified our implementation process and greatly improved our results.*"  
>   
> — *Kartik* Mandaville, *founder* and *CEO* of Springworks

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Blog-images--37-.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Blog-images--37-.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Blog-images--37-.jpg 1000w, https://cms.jina.ai/content/images/2024/05/Blog-images--37-.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="900" alt="Flowchart illustrating a search engine system with components like Query Classifier, Relational Database, and various data pr" />
</figure>

As an example, let's imagine that the user wants to use Albus to query a <a href="https://www.atlassian.com/software/jira" rel="noreferrer">Jira ticket database</a>, and asks it the following:

``` Text
Which tickets were created since March about updating the Dockerfile
to use the latest Ubuntu version?
```

The *Query Classifier* decides that this query is best suited for structured search ("`since March`" implies a traditional filter query), and generates an equivalent in <a href="https://support.atlassian.com/jira-service-management-cloud/docs/use-advanced-search-with-jira-query-language-jql/" rel="noreferrer">Jira Query Language</a>, an SQL-variant used in Jira:

``` SQL
project = "BACKEND_API"
  AND created >= "2023-03-01"
  AND text ~ "dockerfile"
  AND text ~ "Ubuntu"
```

This returns a set of tickets, and their textual contents are sent to `jina-reranker-v1-base-en`, along with the original natural language query. The Jina Reranker re-orders them, and the top-ranked tickets' texts are compiled with a template into a prompt for an LLM. This creates a natural language text response transmitted to the user.

Now, let's imagine the request was something less well-suited to a structured search:

``` Text
How does the company's ESOP policy differ between senior management
and associate-level employees?
```

The *Query Classifier* recognizes this as better suited to an embeddings-based vector search and uses `jina-colbert-v1-base-en` to generate an embedding, which the vector database matches with tickets. These results are passed to `jina-reranker-v1-base-en` with the original query, just like in the structured search case, and yield a natural language response via the same procedure.

## Immediate Deployment and One-Click Integration

Albus is engineered to be as user-friendly as possible. You can integrate your work apps with a single click:

<figure class="kg-card kg-image-card">
<img src="https://lh7-us.googleusercontent.com/VT_y3XHv6Cod9E1cuODg29L_autNlUxi7qZx_44Z3iLCZ6fMUB_4zoJJ937Gy7BMhDs-oGvQRDbY4PdwGDCrmyedZCpxf_oIJ1WAvk4PoNeBBhQMOGCCunWhj5pZaPDS-LsdX5fDVR2OrOZAVzznC3c" class="kg-image" loading="lazy" width="1506" height="927" alt="Flatstudio app interface showing options to add team connections with Slack, Google Drive, Trello, Notion, and HubSpot." />
</figure>

Albus will be up and running within minutes, transforming your entire workplace into a single chat environment where your team can find any information just by asking.

## A New Frontier in Knowledge-Sharing

Springworks has created a new way for companies to access their data and is set to become a trusted office tool. By providing a centralized, AI-powered solution for information retrieval, Albus reduces the time and effort employees spend searching for what they need. Thanks to Jina AI and the tool's ability to integrate with existing systems and provide accurate, context-aware answers, Albus makes company knowledge more accessible than ever.

Jina AI is committed to bringing the highest quality models to enterprises at competitive prices. Contact us via our [<u>website</u>](https://jina.ai/) if you’d also like to benefit from our implementation expertise and enterprise offerings. Talk to us directly through our [<u>Discord channel</u>](https://discord.jina.ai/) to share your feedback and stay up-to-date with our latest models. We're refining our products every day, and your input is crucial to our development process.
