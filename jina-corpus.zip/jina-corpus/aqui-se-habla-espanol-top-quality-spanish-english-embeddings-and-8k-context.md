---
title: "Aquí Se Habla Español: Top-Quality Spanish-English Embeddings and 8k Context"
slug: aqui-se-habla-espanol-top-quality-spanish-english-embeddings-and-8k-context
url: https://cms.jina.ai/aqui-se-habla-espanol-top-quality-spanish-english-embeddings-and-8k-context/
published_at: 2024-02-14T16:30:36.000+01:00
updated_at: 2024-11-27T06:00:25.000+01:00
reading_time: 4
authors: "Jina AI"
tags: "Press"
excerpt: "Jina AI's new bilingual Spanish-English embedding model brings the state-of-the-art in AI to half a billion Spanish speakers."
---

# Aquí Se Habla Español: Top-Quality Spanish-English Embeddings and 8k Context

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings v3: A Frontier Multilingual Embedding Model
</div>
<div class="kg-bookmark-description">
jina-embeddings-v3 is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-13.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/v3banner-3.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v3</code></span><span style="white-space: pre-wrap;"> has been released on Sept. 18, 2024. The best &lt;1B multilingual embedding model.</span></p></figcaption>
</figure>

Jina AI is <a href="https://jina.ai/news/8k-token-length-bilingual-embeddings-break-language-barriers-in-chinese-and-english/" rel="noreferrer">once</a> <a href="https://jina.ai/news/ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length/" rel="noreferrer">again</a> <a href="https://jina.ai/news/elevate-your-code-search-with-new-jina-code-embeddings/" rel="noreferrer">demonstrating</a> its commitment to high-quality multilingual AI models by releasing its **Spanish-English bilingual model**.

This model provides embedding vectors for texts of up to 8k tokens in Spanish or English, designed so that if texts in the two languages mean the same thing, their embeddings will be geometrically close together. Jina Embeddings v2 for Spanish and English is ideally suited for cross-language information retrieval, bilingual semantic analysis, and bilingual RAG applications.

This new model, `jina-embeddings-v2-base-es`, brings to Spanish the same state-of-the-art performance and ground-breaking feature set of Jina AI’s `v2` models for <a href="https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai/" rel="noreferrer">English</a>, <a href="https://jina.ai/news/ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length/" rel="noreferrer">German</a>, <a href="https://jina.ai/news/8k-token-length-bilingual-embeddings-break-language-barriers-in-chinese-and-english/" rel="noreferrer">Chinese</a>, and <a href="https://jina.ai/news/elevate-your-code-search-with-new-jina-code-embeddings/" rel="noreferrer">programming languages</a>:

- 8,192 tokens of input context, a leader among open-source embedding models.
- Real bilingualism instead of uneven multilingualism. Jina AI’s bilingual models are trained to give balanced support to both languages, avoiding the [biases of “multilingual” models](https://arxiv.org/abs/2210.05619) trained on uncurated Internet scrapes.
- `jina-embeddings-v2-base-es` is compact compared to open-source models of comparable performance. The embeddings themselves are 768 dimensions, saving space and run-time in production.
- Jina Embeddings v2 models are fully integrated into major vector databases, RAG frameworks, and AI development libraries:
  - [MongoDB](https://www.mongodb.com/developer/products/atlas/jina-ai-semantic-search/?ref=jina-ai-gmbh.ghost.io)
  - [Qdrant](https://qdrant.tech/documentation/embeddings/jina-embeddings/?ref=jina-ai-gmbh.ghost.io)
  - [Weaviate](https://weaviate.io/developers/weaviate/modules/retriever-vectorizer-modules/text2vec-jinaai?ref=jina-ai-gmbh.ghost.io)
  - [Haystack](https://haystack.deepset.ai/integrations/jina?ref=jina-ai-gmbh.ghost.io)
  - [LlamaIndex](https://docs.llamaindex.ai/en/stable/examples/embeddings/jinaai_embeddings.html?ref=jina-ai-gmbh.ghost.io).

Jina Embeddings v2 for Spanish and English is accessible via the Jina <a href="https://jina.ai/embeddings" rel="noreferrer">Embeddings API</a> right now, with one million free tokens, so you pay nothing to try it out.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Start with 1M free tokens. Top-performing, 8192 context length bilingual embeddings for your search and RAG systems.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Benchmarks

On Spanish benchmarks, Jina v2 for Spanish and English outperforms the <a href="https://huggingface.co/intfloat/multilingual-e5-base" rel="noreferrer">Multilingual E5 base model</a> and the <a href="https://huggingface.co/BAAI/bge-m3" rel="noreferrer">BGE M3 model</a>, the only comparable open-source models with Spanish support. The tests below (<a href="https://github.com/jina-ai/mteb-es" rel="noreferrer">MTEB-es</a>) are adapted from the <a href="https://github.com/embeddings-benchmark/mteb" rel="noreferrer">Massive Text Embeddings Benchmark</a>. You can view and run them from this <a href="https://github.com/jina-ai/mteb-es" rel="noreferrer">GitHub repository</a>.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/mteb-es" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/mteb-es: MTEB: Massive Text Embedding Benchmark with Spanish datasets
</div>
<div class="kg-bookmark-description">
MTEB: Massive Text Embedding Benchmark with Spanish datasets - jina-ai/mteb-es
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/6e71c1c34b09bea0278cbed9f0c639554954e953c35b93d4576539b808f0f813/jina-ai/mteb-es" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-image-card kg-width-full">
<img src="https://cms.jina.ai/content/images/2024/02/image-10.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/02/image-10.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/02/image-10.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/02/image-10.png 1600w, https://cms.jina.ai/content/images/2024/02/image-10.png 2241w" width="2000" height="227" alt="Technical table displaying models, sizes, and performance metrics for cross-language, retrieval, and classification tasks." />
</figure>

Jina Embeddings outperforms E5 on all metrics except classification and outperforms BGE-M3 in retrieval, clustering, and cross-language tasks, despite being 15% to 30% of the size of these larger models.

- Significantly better performance in **retrieval** tasks (like finding related documents in a database) and **clustering** (identifying groups of documents that belong together in a collection)
- Roughly equal performance with E5 on **reranking** (ordering documents by semantic similarity) and near-equal performance on **text classification** in Spanish.
- All three models have very similar benchmark scores for **cross-language tasks** (finding semantically similar texts in English to a Spanish input, or vice-versa), although Jina Embeddings still performs the best.

When compared to closed-source multilingual models from Open AI and Cohere, Jina Embeddings’ compact size makes its achievements even more impressive.

<figure class="kg-card kg-image-card kg-width-full">
<img src="https://cms.jina.ai/content/images/2024/02/image-11.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/02/image-11.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/02/image-11.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/02/image-11.png 1600w, https://cms.jina.ai/content/images/2024/02/image-11.png 1992w" width="1992" height="254" alt="Table comparing machine translation systems with models, vendors, and metrics like Spanish benchmarks and cross-language rera" />
</figure>

On retrieval tasks in Spanish, Jina outperforms the closed-source models offered by Open AI and Cohere and outperforms Open AI (and nearly equals Cohere’s performance) on cross-language tasks.

## Jina Embeddings: AI for a Multilingual World

Spanish is spoken by well over half a billion people, with official status in more than 20 countries, along with the [European Union](https://european-union.europa.eu/index_es), the [United Nations](https://www.un.org/es/), the [World Trade Organization](https://www.wto.org/indexsp.htm), and [FIFA](https://www.fifa.com/fifaplus/es/). Introducing this specialized bilingual model makes clear Jina AI’s commitment to bringing AI technologies to everyone.

In addition to Spanish and its high-performance <a href="https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai/" rel="noreferrer">English monolingual model</a>, Jina AI currently offers state-of-the-art embedding models for <a href="https://jina.ai/news/ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length/" rel="noreferrer">German</a>, <a href="https://jina.ai/news/8k-token-length-bilingual-embeddings-break-language-barriers-in-chinese-and-english/" rel="noreferrer">Chinese</a>, and <a href="https://jina.ai/news/elevate-your-code-search-with-new-jina-code-embeddings/" rel="noreferrer">programming languages</a>, with more to come.

Jina AI is committed to advancing AI technology for the broadest audience, placing a high value on transparency, accessibility, affordability, privacy, and data protection.

We value your feedback on all our models. Join our community channel to contribute and stay informed about new developments.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Start with 1M free tokens. Top-performing, 8192 context length bilingual embeddings for your search and RAG systems.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
