---
title: "Building RAG with Jina AI and SuperDuperDB"
slug: building-rag-with-jina-ai-and-superduperdb
url: https://cms.jina.ai/building-rag-with-jina-ai-and-superduperdb/
published_at: 2024-03-13T16:00:44.000+01:00
updated_at: 2024-03-13T19:07:45.000+01:00
reading_time: 2
authors: "Engineering Group"
tags: "Knowledge Base"
excerpt: "Jina Embeddings v2 are now integrated directly into SuperDuperDB, letting you skip the complexity of AI operations in your data-driven applications."
---

# Building RAG with Jina AI and SuperDuperDB

## SuperDuperDB

<a href="https://superduperdb.com/" rel="noreferrer">SuperDuperDB</a> has integrated <a href="https://jina.ai/embeddings/" rel="noreferrer">Jina Embeddings v2</a> directly into its data-driven AI operations framework. You can now use Jina AI's state-of-the-art embedding models with their groundbreaking 8k input context to work with your existing data stores via SuperDuperDB's integration libraries.

<figure class="kg-card kg-bookmark-card">
<a href="https://www.superduperdb.com/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
SuperDuperDB: Bring AI to your favorite database!
</div>
<div class="kg-bookmark-description">
Say goodbye to complex MLOps pipelines and specialized vector databases. Integrate and train AI directly with your preferred database, only using Python.
</div>
<div class="kg-bookmark-metadata">
<img src="https://www.superduperdb.com/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">SuperDuperDB</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://staging.d3rw8vtufdccov.amplifyapp.com/images/new_superduperdb_share_image.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Start with 1M free tokens. Top-performing, 8192 context length bilingual embeddings for your search and RAG systems.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

To show you how, we have collaborated with SuperDuperDB on a tutorial creating a Retrieval-Augmented Generation (RAG) application that lets you query SQL databases in plain language.

<figure class="kg-card kg-bookmark-card">
<a href="https://docs.superduperdb.com/blog/rag-system-on-duckdb-using-jinaai-and-superduperdb/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Implementing a RAG System on DuckDB Using Jina AI and SuperDuperDB | SuperDuperDB documentation
</div>
<div class="kg-bookmark-description">
Querying your SQL database purely in human language
</div>
<div class="kg-bookmark-metadata">
<img src="https://docs.superduperdb.com/img/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">SuperDuperDB</span><span class="kg-bookmark-publisher">Anita Okoh</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://docs.superduperdb.com/img/superDuperDB_img.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## **Jina AI**

Jina AI is committed to distributing reliable, affordable AI technologies that are easy to use and integrated with common frameworks. We value your feedback, and we’d love to hear about your business needs and discuss how AI can work for you.

For more information about Jina AI’s offerings and to contact us, check out the [<u>Jina AI website</u>](https://jina.ai/?ref=jina-ai-gmbh.ghost.io) or join our [<u>community on Discord</u>](https://discord.jina.ai/?ref=jina-ai-gmbh.ghost.io).

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina AI - Best Embeddings and Perfect Prompts
</div>
<div class="kg-bookmark-description">
Jina AI provides best-in-class embedding API and prompt optimizer, easing the development of multimodal AI applications.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Best Embeddings and Perfect Prompts</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://discord.com/invite/AWXCCC6G2P" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Join the Jina AI Discord Server!
</div>
<div class="kg-bookmark-description">
Check out the Jina AI community on Discord - hang out with 4493 other members and enjoy free voice and text chat.
</div>
<div class="kg-bookmark-metadata">
<img src="https://discord.com/assets/images/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Discord</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn.discordapp.com/splashes/1106542220112302130/80f2c2128aefeb55209a5bdb2130bb92.jpg?size=512" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
