---
title: "Bypass Limitations with PromptPerfect: Generate the Images the Models Don’t Want You to See"
slug: bypass-limitations-with-promptperfect-generate-the-images-the-models-dont-want-you-to-see
url: https://cms.jina.ai/bypass-limitations-with-promptperfect-generate-the-images-the-models-dont-want-you-to-see/
published_at: 2024-05-22T16:00:56.000+02:00
updated_at: 2024-07-08T21:09:05.000+02:00
reading_time: 10
authors: "Alex C-G"
tags: "Tech Blog"
excerpt: "See how PromptPerfect overcomes restrictions and limitations of image generation models like Stable Diffusion XL and DALL-E 3."
---

# Bypass Limitations with PromptPerfect: Generate the Images the Models Don’t Want You to See

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Calm down, we’re not focusing on those kind of images (whatever you think those are).

</div>

</div>

Let’s cut straight to the point: Sometimes you want to generate a perfectly innocent image, and a model (like [DALL-E 3](https://openai.com/dall-e-3/) or [Stable Diffusion XL](https://stability.ai/stable-image)) either flat-out refuses or comes up with something totally wrong. <a href="https://promptperfect.jina.ai" rel="noreferrer">PromptPerfect</a> helps with that, giving you better and more accurate results.

<figure class="kg-card kg-bookmark-card">
<a href="https://promptperfect.jina.ai" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
PromptPerfect - AI Prompt Generator and Optimizer
</div>
<div class="kg-bookmark-description">
Unlock prompt optimization for models like GPT-4, ChatGPT and Midjourney. Generate and refine prompts to perfection, receiving improved outcomes in seconds.
</div>
<div class="kg-bookmark-metadata">
<img src="https://promptperfect.jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">AI Prompt Generator and Optimizer</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://promptperfect.jina.ai/banner.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

In this post we’ll compare different models, explain how to use PromptPerfect to optimize your experience, and put it to the test, showing you the results of both models before and after using PromptPerfect’s optimizer.

And no, we’re not generating (or trying to generate) any dirty pictures. This is a family-friendly post, especially for families with children who like octopuppies. Or puptopi. Or whatever we end up calling some of the weird many-legged doggos we create later in the post.

## DALL-E 3 and Stable Diffusion XL

While there are plenty of models out there, today we’ll focus on the shiny new kids on the block: DALL-E 3 from [OpenAI](https://openai.com/), and Stable Diffusion XL from [Stability AI](https://stability.ai/). While each of these *can* achieve good results, they have different strengths and weaknesses.

Looking at DALL-E 3, out of the box it’s good at understanding long sentences and object relationships, and it draws more realistic anatomy than Stable Diffusion XL (no Lovecraftian horror hands here). However, it often point-blank refuses to generate images of notable figures (like Taylor Swift) or well-known characters (like Mickey Mouse, even if we ask for the out-of-copyright Steamboat Willie version). It also generates text better than any other image generation model (though that’s a low bar.)

Stable Diffusion XL is much more open to generating images of notable figures and well-known characters, though some of it’s images of Mickey look like they were drawn while on some really fun drugs. However, it often messes up anatomy and object relationships. While you *can* ask it to generate text (and see it’s trying its best), it falls way behind DALL-E 3 on that front.

With PromptPerfect we can get around some of these weaknesses from both models. We’ll compare DALL-E 3 and Stable Diffusion, both before and after using PromptPerfect's optimization. You can skip ahead to see the ultimate winner.

## Using PromptPerfect’s Optimizer

In this battle of the models we’re using PromptPerfect’s optimizer to see how we can get better image results from our prompts. Here’s how:

Sign up for free credits at [PromptPerfect](https://promptperfect.jina.ai/):

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/image-17.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-17.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/image-17.png 1000w, https://cms.jina.ai/content/images/2024/05/image-17.png 1137w" sizes="(min-width: 720px) 720px" width="1137" height="792" alt="Screenshot of PromptPerfect&#39;s dark-themed homepage featuring login/signup options, GitHub and WeChat integration, and terms a" />
</figure>

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Try a paid plan free for 7 days. And subscribe to a plan within 24 hours of your first login to get 40% off!

</div>

</div>

Click on the interactive feature:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/image-18.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-18.png 600w, https://cms.jina.ai/content/images/2024/05/image-18.png 712w" width="712" height="508" alt="Dark themed webpage of PromptPerfect! with a navigation bar and titles like &quot;Interactive&quot; and &quot;Auto-tune.&quot;" />
</figure>

In the ‘optimizer’ pane (on the right-hand side), type something like `generate a prompt to create an image of felix the cat using DALL-E 3`:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/image-19.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-19.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/image-19.png 1000w, https://cms.jina.ai/content/images/2024/05/image-19.png 1104w" sizes="(min-width: 720px) 720px" width="1104" height="897" alt="Interface of an AI assistant tool with option to create a playful image of Felix the Cat using DALL-E 3." />
</figure>

Click "Send to Assistant"

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/image-20.png" class="kg-image" loading="lazy" width="530" height="319" alt="Screenshot of a DALL-E 3 interface with options to create a playful, whimsical image of Felix the Cat, including buttons for " />
</figure>

It will do some thinking, then generate the image from the prompt in the ’interactive’ pane, on the left:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/image-21.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-21.png 600w, https://cms.jina.ai/content/images/2024/05/image-21.png 756w" sizes="(min-width: 720px) 720px" width="756" height="868" alt="Progression of Felix the Cat illustrations from sketch to a lively pop art style creation." />
</figure>

Refine your prompt by conversing with the Optimizer, then lather, rinse, repeat:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/image-22.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-22.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/image-22.png 1000w, https://cms.jina.ai/content/images/2024/05/image-22.png 1570w" sizes="(min-width: 720px) 720px" width="1570" height="731" alt="Screenshot of an artistic request page for creating a Felix the Cat illustration in the 1930s rubber hose animation style, em" />
</figure>

## Contest Methodology

For the “before” images, we’ll use:

- ChatGPT (GPT-4) to generate images with DALL-E using the prompt `generate an image of <thing>`, for example `generate an image of mickey mouse`.
- [Replicate’s interface](https://replicate.com/stability-ai/sdxl) to generate images with Stable Diffusion XL, using the prompt `<thing>`, for example `mickey mouse`.

For the “after” images, we’ll use PromptPerfect’s interactive optimizer, using the prompt `generate a prompt to create an image of <thing> using <model name>` .

We’ll present the first output that comes up. The number of actual images may vary - PromptPerfect always generates four, Stable Diffusion XL (via Replicate), one, and DALL-E 3 one or two.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

While PromptPerfect’s optimizer is interactive (so you can refine your prompt in a conversational manner), we just stuck with the first result to be as impartial as possible. By really using the interactive feature of the optimizer you’d get even better results.

</div>

</div>

We’ll award medals as follows:

- 💩 - flat-out refused to cooperate
- 🥉 - it tried, but none of the outputs were what we’re looking for
- 🥈 - at least one of the outputs was an okay result!
- 🥇 - hot damn, at least one of the outputs was actually good!

Finally we’ll do a round up and see which model and method came out on top.

## Who Will Be the Next Top Model?

Models, start your engines!

### Round 1: Notable Figures

Let's first try our Lord and Savior Taylor Swift. Here’s a real image of the person we’re aiming for:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Untitled.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/05/Untitled.png 1600w, https://cms.jina.ai/content/images/2024/05/Untitled.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="2958" alt="Taylor Swift wearing a black dress with deep V-neckline and gold necklace, posing with a hand on her hip, against a colorful " />
<figcaption><span style="white-space: pre-wrap;">Licensed </span><a href="https://creativecommons.org/licenses/by/3.0/deed.en" rel="noopener noreferrer"><span style="white-space: pre-wrap;">CC BY 3.0</span></a><span style="white-space: pre-wrap;">, Attribution: iHeartRadioCA</span></figcaption>
</figure>

Without PromptPerfect, DALL-E 3 flat out refuses to create Taylor:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled-1.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled-1.png 830w" sizes="(min-width: 720px) 720px" width="830" height="275" alt="Chat interface showing a denied request to generate an image of Taylor Swift by ChatGPT due to content policy." />
</figure>

With PromptPerfect, it generates images with the optimized prompt, but none of them actually look like her:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--1-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--1-.png 802w" sizes="(min-width: 720px) 720px" width="802" height="1034" alt="Taylor Swift in an edited portrait with suggestions for a red sequined dress, styled hair, and dramatic stage lighting." />
</figure>

With SDXL, before PromptPerfect we get a pretty good rendition:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--1--1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--1--1.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--1--1.png 768w" sizes="(min-width: 720px) 720px" width="768" height="768" alt="Portrait of Taylor Swift with red lipstick, blondish-brown hair, wearing a dress against a pink background." />
</figure>

And PromptPerfect’s optimized prompt once again delivers:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--2-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--2-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--2-.png 789w" sizes="(min-width: 720px) 720px" width="789" height="857" alt="Edited collage of Taylor Swift with multiple effects via a photo editor, highlighting options like Optimize and Assistant." />
</figure>

Let’s see which models could really generate-rate-rate:

|  | Before optimization | After optimization |
|----|----|----|
| DALL-E 3 | 💩 It flat out refused | 🥉 Blonde? Check? Singer? Check. Taylor? Nope |
| Stable Diffusion XL | 🥇 Swifty vibes | 🥇 Quite Taylorian |

### Round 2: “Copyrighted” Material

We’re not even going to *try* with actually copyrighted material - that’s a whole can of worms we don’t want to dive into. However, the design of Mickey Mouse from Steamboat Willie *is* [out of copyright](https://www.npr.org/2024/01/01/1221606624/mickey-mouse-public-domain-disney) as of 2024:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--3-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--3-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--3-.png 959w" sizes="(min-width: 720px) 720px" width="959" height="729" alt="Cartoon of Mickey Mouse dressed in captain attire, steering a ship&#39;s wheel with a joyful expression, in a classic black-and-w" />
</figure>

Let’s use him as a subject. DALL-E 3 flat out refuses at first:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--4-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--4-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--4-.png 820w" sizes="(min-width: 720px) 720px" width="820" height="248" alt="Chat exchange in Slack showing a user request for a &#39;Mickey Mouse from Steamboat Willie&#39; image and ChatGPT&#39;s polite policy vi" />
</figure>

With PromptPerfect we get results with the right vibe, but not the 1930s [rubber hose](https://en.wikipedia.org/wiki/Rubber_hose_animation) style:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--5-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--5-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--5-.png 794w" sizes="(min-width: 720px) 720px" width="794" height="1007" alt="Black and white image editing screen featuring classic Mickey Mouse on a steamboat, with detailed creative instructions." />
</figure>

Stable Diffusion tries. It really does. With this Mickey you get a lot more ears, eyes and fingers for your buck:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--6-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--6-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--6-.png 768w" sizes="(min-width: 720px) 720px" width="768" height="768" alt="Black and white illustration of Mickey Mouse gesturing in a playful stance." />
</figure>

With PromptPerfect optimization, Stable Diffusion still gives us fever dream Mickey, but more of a light fever, less “*how* strong are these mushrooms?” fever:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--7-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--7-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--7-.png 793w" sizes="(min-width: 720px) 720px" width="793" height="835" alt="Series of Mickey Mouse images showcasing artistic transformation from vintage black and white to modern 3D CGI, created with " />
</figure>

Which model puts the “ick” in Mickey?

|  | Before optimization | After optimization |
|----|----|----|
| DALL-E 3 | 💩 policy schmolicy. This stuff is definitely out of copyright. | 🥈. Definitely had Mickey vibes, no weirdness, just not the 30s style I was aiming for. |
| Stable Diffusion XL | 🥉 Go home Mickey. You’re possessed. | 🥈 Barely scraping into the silver medal category. More Mickey vibes than DALL-E 3, but the deformation is really distracting |

### Round 3: Text

Let’s generate a picture of a sign that says “Happy days are here again”. No target picture this time, just imagine (as difficult as it might be) a sign with that text. In the words of John Lennon, it’s easy if you try.

DALL-E 3 gives us happy vibes, which I dig. However, it does throw in the word “dye”. Since this sounds like the word “die”, it might be sending mixed messages:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--8-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--8-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--8-.png 640w" width="640" height="619" alt="Colorful sign reading &quot;Happy Days Are Here Again&quot; in a creative font, with a sun and clouds, shared in a Slack conversation." />
</figure>

With optimization, we actually get the correct wording and spelling with no extra words, at least once. And once it’s almost spot-on, except for a misspelling:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--9-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--9-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--9-.png 780w" sizes="(min-width: 720px) 720px" width="780" height="911" alt="A vibrant, nostalgic sign reading &quot;Happy Days Are Here Again&quot; in bold, cheerful lettering on weathered wood, set against a lu" />
</figure>

Stable Diffusion XL gives us Herpy Days:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--10-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--10-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--10-.png 768w" sizes="(min-width: 720px) 720px" width="768" height="768" alt="Playful sign with the phrase &quot;Happy Days Are Here Again&quot; painted in a unique and stylized manner." />
</figure>

After optimizing the Stable Diffusion XL Prompt, we get a lonely misspelled sign in the woods. It’s less scary than before, though I for one am not following that signpost to wherever it leads.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--11-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--11-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--11-.png 785w" sizes="(min-width: 720px) 720px" width="785" height="853" alt="Old wooden sign reading &quot;Happy days are here again&quot; in a vibrant, detailed landscape with a backdrop of blue sky and trees." />
</figure>

Who will see happy days, and who won’t?

|  | Before optimization | After optimization |
|----|----|----|
| DALL-E 3 | 🥈 You can see what the sign is saying, even though it added the extra “dye” word and the order of the words is off | 🥇 At least one of the signs has the full correct text. And another just had a “small” typo (an extra “P” in “HAPPY” - small by image generation standards!) |
| Stable Diffusion XL | 🥉 Looks like a motivational poster from Hell | 🥈 Not as good as unoptimized DALL-E 3, but doesn’t make me want to gouge out my eyes as much as unoptimized SDXL |

### Round 4: “Cursed” Creations

Let’s see how well the models can adapt to weird stuff, like a puppy with seven legs. No target image this time - I don’t want “deformed puppies” to be in my Google history. Just imagine a puppy with seven legs.

DALL-E 3 gave us two outputs this time. We didn’t ask for it. It just likes doggos I guess. Proof that AI is becoming more human-like? Anyway, results were what we asked for, though a bit bland in my opinion. Still we’re not awarding points for style in this round, just content. So a dog with an absurd number of legs superimposed on the Windows XP wallpaper works:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--12-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--12-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Untitled--12-.png 1000w, https://cms.jina.ai/content/images/2024/05/Untitled--12-.png 1024w" sizes="(min-width: 720px) 720px" width="1024" height="1024" alt="Cute brown and white puppy sitting on a grassy hill with colorful flowers, one paw raised, under a clear blue sky." />
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/05/image-16.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-16.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/image-16.png 1000w, https://cms.jina.ai/content/images/2024/05/image-16.png 1024w" sizes="(min-width: 720px) 720px" width="1024" height="1024" alt="Playful brown and white puppy sitting on a flower-dotted green lawn with a blue sky and fluffy clouds overhead." />
<figcaption><span style="white-space: pre-wrap;">While it's not strictly NSFW, it is sufficiently disturbing that I pixelated it</span></figcaption>
</figure>

After optimization, so many legs! I wonder what the multi-legged dog emoji is meant to express? Send answers our way!

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--14-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--14-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--14-.png 777w" sizes="(min-width: 720px) 720px" width="777" height="1009" alt="Illustration showing four whimsical brown puppies with various poses alongside detailed instructions for creating a surreal s" />
</figure>

Stable Diffusion XL misread the assignment:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--15-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--15-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--15-.png 768w" sizes="(min-width: 720px) 720px" width="768" height="768" alt="Small puppy with floppy ears and a black collar standing on a brown surface, looking at the camera against a gradient gray-bl" />
</figure>

Even after optimization, we’re like “which part of seven legs did you not understand?”:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--16-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--16-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--16-.png 796w" sizes="(min-width: 720px) 720px" width="796" height="831" alt="Untitled" />
</figure>

Who’s top dog and who’s runt of the litter in this round?

|  | Before optimization | After optimization |
|----|----|----|
| DALL-E 3 | 🥇 Both puppies have bizarre leg number. First puppy even has seven, though some of them are barely in shot. Though I don’t know what the clasper things are on puppy number two, and neither do I wish to find out. | 🥇 YES. All the puppies. All the legs. You can play shaking hands with these cuties for ages. One even got the leg count right. |
| Stable Diffusion XL | 🥉When I want a puppy with legs for days, I don’t mean just long legs | 🥉 I like my puppies with more legs |

### Bonus Round: Kegstand Punk

In some cases, DALL-E 3 and SDXL both fail whether we employ optimization or not. For example, generating an image of a punk doing a [kegstand](https://en.wikipedia.org/wiki/Keg_stand).

Here is an image of a punk…

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--17-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--17-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Untitled--17-.png 1000w, https://cms.jina.ai/content/images/2024/05/Untitled--17-.png 1125w" sizes="(min-width: 720px) 720px" width="1125" height="750" alt="Man with a green mohawk and black &quot;DISCHARGE&quot; coat on a city street, showcasing bold fashion and individuality." />
<figcaption><span style="white-space: pre-wrap;">via pexels.com</span></figcaption>
</figure>

...and an illustration of a kegstand (that looks like it’s from a wholesome children’s book):

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--18-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--18-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--18-.png 944w" sizes="(min-width: 720px) 720px" width="944" height="1000" alt="Joyful illustration of men around a barrel with another man playfully inside, indicating humor and fun." />
</figure>

I can’t find an actual image of a punk doing a kegstand online. Ugh, punks, such prudes!

DALL-E 3 gives us a punk in a bar with weird but cool lighting. He looks very stoic. He’s on a keg, but no kegstand.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--19-.png" class="kg-image" loading="lazy" width="508" height="610" alt="A punk doing a kegstand at a lively party, with interface icons and chat text indicating an image generation command." />
</figure>

After optimization, I dig the vibe, but still no kegstand:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--20-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--20-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--20-.png 783w" sizes="(min-width: 720px) 720px" width="783" height="1007" alt="Punk rocker with brightly colored spiked hair and tattoos, performing a keg stand at a lively underground party in a graffiti" />
</figure>

They should change the name to Stable Diffusion ER, because this guy(?) needs to go to hospital:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--21-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--21-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--21-.png 768w" sizes="(min-width: 720px) 720px" width="768" height="768" alt="Man performing a handstand on a wooden barrel outdoors, dressed in black, with a red and white building and a clear sky in th" />
</figure>

After optimization looks much better. There’s a keg. There’s a punk. Still no kegstand, alas.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled--22-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled--22-.png 600w, https://cms.jina.ai/content/images/2024/05/Untitled--22-.png 794w" sizes="(min-width: 720px) 720px" width="794" height="891" alt="Energetic punk music scene in an underground venue with a crowd, punk in leather and mohawk hairstyles." />
</figure>

Who’s the punk and who’s just junk?

|  | Before optimization | After optimization |
|----|----|----|
| DALL-E 3 | 🥈 Punk, check. Keg check. Kegstand, not so much | 🥈 Optimization changed the vibe a bit, but still no actual kegstand |
| Stable Diffusion XL | 🥉 Ouch. Not a punk. Not a kegstand. Barely a human being. And doing a kegstand like that, he won’t be any kind of human being for much longer. | 🥈 Optimization gave us a much better result, showing a punk interacting with a keg. No body horror this time. |

## Tallying Up the Score

Now that the contest is done, we’ll count the scores as follows:

- 💩: zero points
- 🥉: one point
- 🥈: two points
- 🥇: three points

The maximum number of points any option could achieve is 15 (winning a gold medal in all five rounds). Let’s see the breakdown:

| Challenge | DALL-E 3 |  | Stable Diffusion XL |  |
|----|----|----|----|----|
|  | Before PromptPerfect | After PromptPerfect | Before PromptPerfect | After PromptPerfect |
| Notable figure | 💩 0 | 🥉 1 | 🥇 3 | 🥇 3 |
| “Copyrighted” material | 💩 0 | 🥈 2 | 🥉 1 | 🥈 2 |
| Text | 🥈 2 | 🥇 3 | 🥉 1 | 🥈 2 |
| Cursed creations | 🥇 3 | 🥇 3 | 🥉 1 | 🥉 1 |
| Punk kegstand | 🥈 2 | 🥈 2 | 🥉 1 | 🥈 2 |
| **Total** | 🥉 7 | 🥇 11 | 🥉 7 | 🥈 10 |

In short, if it weren’t for censorship in the early rounds, DALL-E 3 would’ve scored much higher. Overall, using PromptPerfect to optimize your prompts leads to better results for both models.

You can trust us, because this was an impartial contest (done by us, for us, for our own product). Seriously though, the results do speak for themselves. Try it for yourself and see how it goes!
