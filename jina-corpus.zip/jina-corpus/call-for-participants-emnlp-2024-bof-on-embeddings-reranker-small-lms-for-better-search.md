---
title: "Call for Participants: EMNLP 2024 BoF on Embeddings, Reranker & Small LMs for Better Search"
slug: call-for-participants-emnlp-2024-bof-on-embeddings-reranker-small-lms-for-better-search
url: https://cms.jina.ai/call-for-participants-emnlp-2024-bof-on-embeddings-reranker-small-lms-for-better-search/
published_at: 2024-11-05T15:16:19.000+01:00
updated_at: 2024-11-05T19:09:38.000+01:00
reading_time: 2
authors: "Jina AI"
tags: "Events"
excerpt: "At EMNLP 2024 Miami? Join us for a Birds of a Feather session focusing on embeddings, rerankers, and small LMs for better search."
---

# Call for Participants: EMNLP 2024 BoF on Embeddings, Reranker & Small LMs for Better Search

Join us **on November 14, 2024, from 10:30 AM to 12:00 PM (Miami Time)** for a Birds of a Feather (BoF) session focusing on embeddings, rerankers, and small LMs for better search at EMNLP 2024 in Miami. Following [the success of our Embeddings BoF at EMNLP 2023 in Singapore](https://jina.ai/news/a-tale-of-two-worlds-emnlp-2023-at-sentosa/#embeddings-roundtable-a-birds-of-a-feather-at-emnlp-2023), this 1.5-hour in-person session will bring together researchers specializing in embedding models, rerankers, and various topics in information retrieval. The session will feature presentations and a panel discussion, offering an excellent opportunity to explore recent advances in search foundation models, share your work with a specialized audience, and discuss emerging trends in search models in 2024. All EMNLP on-site participants are welcome to attend.

## Event Details

- Date: Thursday, November 14, 2024
- Time: 10:30 AM - 12:00 PM (Miami Time)
- Location: Miami Lecture Hall
- Format: In-person

### Calendar Links

- [Add to Google Calendar](https://www.google.com/calendar/render?action=TEMPLATE&text=EMNLP+2024+BoF:+Embeddings,+Reranker,+Small+LMs+for+Better+Search&dates=20241114T103000/20241114T120000&ctz=America/New_York&details=Join+us+for+a+Birds+of+a+Feather+(BoF)+session+at+EMNLP+2024.%0A%0ATopics+of+Interest:%0A-+Advanced+embedding+architectures:+multimodal,+multilingual,+cross-lingual,+and+cross-modal+approaches%0A-+Efficient+retrieval+paradigms:+late-interaction+models,+sparse-dense+hybrid+systems%0A-+Resource-efficient+approaches:+lightweight+architectures,+compression,+Matryoshka+Representation+Learning%0A-+Learning+methodologies:+instruction-tuning,+contrastive+learning,+zero/few-shot+adaptation%0A-+Evaluation+and+benchmarking:+MTEB+frameworks,+metrics+for+embeddings+and+RAG%0A-+System+optimization:+attention+mechanisms,+real-time+retrieval%0A-+Foundation+models+for+search:+LLM-based+embeddings,+small+LMs%0A%0ALocation:+Miami+Lecture+Hall%0A%0AFor+more+event+details,+please+visit:+https://jina.ai&location=Miami+Lecture+Hall,+EMNLP+2024)
- Or download iCalendar/ics file:

<div class="kg-card kg-file-card">

<a href="https://cms.jina.ai/content/files/2024/11/emnlp2024-bof.ics" class="kg-file-card-container" download="" title="Download"></a>

<div class="kg-file-card-contents">

<div class="kg-file-card-title">

emnlp2024-bof

</div>

<div class="kg-file-card-caption">

</div>

<div class="kg-file-card-metadata">

<div class="kg-file-card-filename">

emnlp2024-bof.ics

</div>

<div class="kg-file-card-filesize">

854 Bytes

</div>

</div>

</div>

<div class="kg-file-card-icon">

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxkZWZzPjxzdHlsZT4uYXtmaWxsOm5vbmU7c3Ryb2tlOmN1cnJlbnRDb2xvcjtzdHJva2UtbGluZWNhcDpyb3VuZDtzdHJva2UtbGluZWpvaW46cm91bmQ7c3Ryb2tlLXdpZHRoOjEuNXB4O308L3N0eWxlPjwvZGVmcz48dGl0bGU+ZG93bmxvYWQtY2lyY2xlPC90aXRsZT48cG9seWxpbmUgY2xhc3M9ImEiIHBvaW50cz0iOC4yNSAxNC4yNSAxMiAxOCAxNS43NSAxNC4yNSI+PC9wb2x5bGluZT48bGluZSBjbGFzcz0iYSIgeDE9IjEyIiB5MT0iNi43NSIgeDI9IjEyIiB5Mj0iMTgiPjwvbGluZT48Y2lyY2xlIGNsYXNzPSJhIiBjeD0iMTIiIGN5PSIxMiIgcj0iMTEuMjUiPjwvY2lyY2xlPjwvc3ZnPg==)

</div>

</div>

## Registration

<figure class="kg-card kg-bookmark-card">
<a href="https://docs.google.com/forms/d/e/1FAIpQLScXmwLyE1Xye-FuWblIHszERde1SmVEOAtxatZcKRB4lOEVrg/viewform?usp=sf_link" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
EMNLP 2024/BoF: Embeddings, Reranker, Small LMs for Better Search
</div>
<div class="kg-bookmark-description">
What: A BoF (Birds of a Feather) in-person session on Embeddings, Reranker and Search LMs, co-organized by EMNLP PC and Jina AI. When &amp; Where: Date: Thursday, November 14, 2024 Time: 10:30 AM - 12:00 PM (Miami Time) Location: Miami Lecture Hall Highlights: multimodal embeddings, long context embeddings, multi- and bilingual embeddings, embeddings for low-resource languages, applications of embeddings, and the interplay between embeddings and prompts. Participation: The session is open to everyone; you can simply walk in to participate. If you’re interested in contributing to this BoF, we welcome you to fill in the details below.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/android_192.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Google Docs</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/5MYJcxbNpb8Z9Sw1zP7Lea67kBwmfp4XLQLFkFmBCZFma0k7NO966bupITjWHDHkC5yp_WQKJWg-w1200-h630-p" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

While general attendance registration is not mandatory, we strongly encourage participants to register via our Google Form to help us better organize the session. If you would like to present your work (10-minute slot) or participate as a panelist in this BoF session, please indicate this in the registration form. This is an excellent opportunity to share your research with experts in the field of embeddings and search models.

## Topics of Interest

- Multimodal, multilingual, cross-lingual, and cross-modal embeddings and rerankers
- Late-interaction models (e.g., ColBERT, ColPali) and late chunking
- Long-context embedding models
- Instruction-tuning for embedding and reranker models
- LLM-based embedding and reranker models
- Small language models for document reading
- Efficient and lightweight embedding architectures, attention mechanisms
- Zero/few-shot retrieval and adaptation methods
- Contrastive learning approaches for retriever
- Matryoshka representation learning, embedding compression and quantization
- Hybrid sparse-dense retrieval systems
- Task-LoRA, domain adaptation, OOD, fine-tuning for embedding models
- MTEB, LongMTEB, RAG evaluation metrics and benchmarks
- Embedding models for code, structured data and time series
- Privacy-preserving embedding techniques
