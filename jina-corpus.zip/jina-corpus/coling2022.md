---
title: "COLING2022 Summary on Multimodal AI"
slug: coling2022
url: https://cms.jina.ai/coling2022/
published_at: 2022-10-21T11:58:17.000+02:00
updated_at: 2024-01-24T19:32:06.000+01:00
reading_time: 12
authors: "Han Xiao"
tags: "Events"
excerpt: "Last week I was in Gyeongju, Korea for the COLING2022 conference. COLING is the premier conference in computational linguistics held every two years. In this article, I will review the multimodal AI-related work in COLING 2022."
---

# COLING2022 Summary on Multimodal AI

Last week I was in Gyeongju, Korea for the COLING2022 conference. COLING is the premier conference in computational linguistics held every two years.

The conference was very well organized, and the talks were very interesting. I learned a lot about the latest research in computational linguistics and NLP, such as automated writing evaluation and multi-hop question answering. I also had a chance to meet many old friends and make new ones at the Jina AI dinner event.

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/IMG_9203.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/IMG_9203.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/IMG_9203.jpg 1000w, https://cms.jina.ai/content/images/2022/10/IMG_9203.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="1200" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/IMG_9214-1.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/IMG_9214-1.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/IMG_9214-1.jpg 1000w, https://cms.jina.ai/content/images/2022/10/IMG_9214-1.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="1200" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/IMG_9222.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/IMG_9222.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/IMG_9222.jpg 1000w, https://cms.jina.ai/content/images/2022/10/IMG_9222.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="2133" />
</div>
</div>
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/IMG_9291.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/IMG_9291.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/IMG_9291.jpg 1000w, https://cms.jina.ai/content/images/2022/10/IMG_9291.jpg 1200w" sizes="(min-width: 720px) 720px" width="1200" height="1600" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/IMG_9295.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/IMG_9295.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/IMG_9295.jpg 1000w, https://cms.jina.ai/content/images/2022/10/IMG_9295.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="1200" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/IMG_9173.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/IMG_9173.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/IMG_9173.jpg 1000w, https://cms.jina.ai/content/images/2022/10/IMG_9173.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="1200" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">Dinner event hosted by Jina AI at COLING2022</span></p></figcaption>
</figure>

In this article, I will review the multimodal AI-related work presented at COLING 2022. Despite being primarily an NLP conference, there were 26 presentations focused on multimodal AI, covering text-image, text-video, and text-speech domains. I would like to highlight three presentations that I found particularly interesting.

## Are Visual-Linguistic Models Commonsense Knowledge Bases?

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.491/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Are Visual-Linguistic Models Commonsense Knowledge Bases?
</div>
<div class="kg-bookmark-description">
Hsiu-Yu Yang, Carina Silberer. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.491.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

We have all seen the huge potential for pretrained language models (PTLMs) over the last few years. Models such as Transformer and GPT have been widely used in many downstream tasks due to their potential as a commonsense knowledge base. However, the text corpora used to train PTLMs can make them very biased, and this can make them inconsistent and not very robust. In this paper, Yang and Silberer suggest that text corpora alone may be insufficient for knowledge acquisition and raise important questions for visual-linguistic models like UNITER, VILBERT, and CLIP:

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

🤔

</div>

<div class="kg-callout-text">

Can a language model with a visual component represent our physical world better?

</div>

</div>

They address this problem with probing questions like this one:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-8.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-8.png 600w, https://cms.jina.ai/content/images/2022/10/image-8.png 704w" width="704" height="350" alt="Educational slide with a quiz asking where a mouse is likely to be found, depicting an attic bedroom, a bridge over the ocean, and a forest" />
<figcaption><span style="white-space: pre-wrap;">Prompt-based zero-shot QA with visual input. QA pairs can be categorized into multiple commonsense dimensions to identify what sort of relational knowledge the model has acquired: part-whole, taxonomic, distinctness, similarity, quality, utility, creation, temporal, spatial, and desire. During experiments, the author selectively masks out image input to study the what commonsense knowledge the models have captured.</span></figcaption>
</figure>

### Which dimensions of commonsense do v**isual-linguistic** models possess compared to text-only PTLMs?

Hsui-Yu shows that visual-linguistic (VL) models such as UNITER and VILBERT are better at *part-whole*, *spatial*, and *desire* dimensions but struggle with *taxonomic*, *distinctness,* and *temporal* dimension. In terms of *spatial* dimension, VL models consistently outperform RoBERTa by 8%. On non-visual related dimensions such as *taxonomic* and *temporal,* VL models underperform by 8%, which is understandable as taxonomy and temporality are rarely represented in images. When using real-world images for training VL, *distinctness* is also hard to learn because opposite concepts e.g. *flood* and *drought*, rarely come together in one picture.

### During pretraining, does explicit visual information (i.e., images) benefit commonsense knowledge encoding?

When adding a BERT pretrained with image captions, the advantage of VL models becomes less significant, even on the *spatial* dimension. This shows that image captions can already provide a good proxy for visual information. The only dimension that VL models outperform is *part-whole,* with a tiny margin though*.*

### During inference, is explicit visual observation (i.e., images) necessary for recalling commonsense knowledge?

The above experiments have not used the visual input during the zero-shot QA task, so a natural question is, will adding images help? The answer is no. Visual information just makes everything worse. In fact, experiments show that all dual-stream (textual + visual) models underperform compared to their text-only counterparts on *part-whole*, *spatial, taxonomic*, and *distinctness* dimensions. This suggests that the texts are the driving force for successful inference on purely linguistic tasks.

What I found interesting about this work is the demystifying of the multimodal model, showing that although state-of-the-art VL models do encode complementary knowledge types to pure language models, the way that they combine visual and textual signals is still very primitive and not human-like at all.

## Dual Capsule Attention Mask Network with Mutual Learning for Visual Question Answering

It is worth mentioning that the probing task from the last work is **not** a visual question-answering (VQA) task, though it contains QA pairs and images. A formal VQA task looks like the following:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-9.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-9.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-9.png 1000w, https://cms.jina.ai/content/images/2022/10/image-9.png 1124w" sizes="(min-width: 720px) 720px" width="1124" height="578" alt="Concept map with &quot;VQA Model&quot; central node, &quot;Sleeping&quot; sub-node, and image of dog lying on pavement with bicycle" />
<figcaption><span style="white-space: pre-wrap;">The goal of VQA is to answer questions related to the content of images correctly. It has a wide range of practical applications, such as helping people with visual impairments and human-computer Q&amp;A</span></figcaption>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.500/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Dual Capsule Attention Mask Network with Mutual Learning for Visual Question Answering
</div>
<div class="kg-bookmark-description">
Weidong Tian, Haodong Li, Zhong-Qiu Zhao. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.500.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

The challenge of the VQA task is how to leverage fine-grained features with critical information to ensure that feature extraction emphasizes the objects related to the questions. Let's see two examples below:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2022/10/image-10.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-10.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-10.png 1000w, https://cms.jina.ai/content/images/2022/10/image-10.png 1486w" sizes="(min-width: 720px) 720px" width="1486" height="706" alt="Split image with a girl on a horse wearing a helmet on the left, and a multi-purpose bedroom with a bed, desk, and electronics on the right" />
</figure>

In the left example, the fine-grained features with attention have the critical information required for the answer inference, which helps the model generate the correct answer by eliminating irrelevant factors that could interfere. In the right example, unattended coarse-grained features contain the richer semantic information needed for a correct answer.

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

🤔

</div>

<div class="kg-callout-text">

Can we combine global coarse-grained information and local fine-grained information to provide better information for the VQA task?

</div>

</div>

Weidong et al. address that in their paper. They propose a dual capsule attention mask network (DCAMN) with mutual learning for VQA.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2022/10/image-11.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-11.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-11.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-11.png 1600w, https://cms.jina.ai/content/images/size/w2400/2022/10/image-11.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1115" alt="Diagram of a deep learning network with coarse-grained and fine-grained branches, decoders, and fusion blocks labeled" />
</figure>

DCAMN can process features at different granularities, taking global information into account and focusing on critical information. Combining different perspectives and granularities can improve the generalization capability of the model and make more accurate predictions.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-12.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-12.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-12.png 1000w, https://cms.jina.ai/content/images/2022/10/image-12.png 1450w" sizes="(min-width: 720px) 720px" width="1450" height="764" alt="Table displaying text classification performance by method, with columns for Test-dev, Test-std, and All, including numerical scores" />
<figcaption><span style="white-space: pre-wrap;">DCAMN performance on three types of VQA: yes/no, number, and others</span></figcaption>
</figure>

In addition, the proposed DCAMN can effectively fuse multimodal features and locate evidence, improving the interpretability of the network, as the picture below illustrates:

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-1.png" loading="lazy" width="510" height="538" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-2-1.png" loading="lazy" width="454" height="540" />
</div>
</div>
</div>
</figure>

The attention mechanism and the model's interpretability are of particular interest for explainable multimodal AI.

## In-the-Wild Video Question Answering

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.496/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
In-the-Wild Video Question Answering
</div>
<div class="kg-bookmark-description">
Santiago Castro, Naihao Deng, Pingxuan Huang, Mihai Burzo, Rada Mihalcea. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.496.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

As a temporal extension of Visual QA, Video QA plays an important role in the development of intelligent AI systems, as it enables the effective processing of modality and temporal information. In the example below, given a long-video and a question, a video QA system first aims to generate open-ended answers. Second, it retrieves visual support for a given question and answer, which is represented by a span.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-13.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-13.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-13.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-13.png 1600w, https://cms.jina.ai/content/images/2022/10/image-13.png 2338w" sizes="(min-width: 720px) 720px" width="2000" height="660" alt="Man in forest using bow saw and handaxe on tree branch, with timestamps 00:00, 00:37, and 00:51, indicating action progression" />
<figcaption><span style="white-space: pre-wrap;">Finding the relevant frames in a video for a given question-answer pair can help a system in its reasoning process, and is in line with ongoing efforts to build interpretable models</span></figcaption>
</figure>

Much of the existing work on Video QA is based on the MovieQA (Tapaswi et al., 2016), and TVQA (Lei et al., 2018) datasets, which focus on common human activities in a multiple-choice setting. These datasets consist primarily of video from cooking videos or movies, making them very limited in domain.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-15.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-15.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-15.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-15.png 1600w, https://cms.jina.ai/content/images/size/w2400/2022/10/image-15.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="785" alt="Comparative table of video QA datasets, indicating metrics like video counts, questions, average duration, and annotations" />
<figcaption><span style="white-space: pre-wrap;">Comparison between WILDQA and other existing datasets. VE?: Whether the dataset provides “Video Evidences”?; MC: “Multiple Choice” question answering; OE: “Open Ended” question answering; ES: “Evidence Selection”.</span></figcaption>
</figure>

Santiago et al. propose the WildQA dataset and tasks that focus on scenes recorded in the outside world in an open-ended setting, like the example below:

<figure class="kg-card kg-video-card kg-width-regular kg-card-hascaption" data-kg-thumbnail="https://cms.jina.ai/content/images/2022/10/media-thumbnail-ember964.jpg" data-kg-custom-thumbnail="">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjMuMTQgMTAuNjA4IDIuMjUzLjE2NEExLjU1OSAxLjU1OSAwIDAgMCAwIDEuNTU3djIwLjg4N2ExLjU1OCAxLjU1OCAwIDAgMCAyLjI1MyAxLjM5MkwyMy4xNCAxMy4zOTNhMS41NTcgMS41NTcgMCAwIDAgMC0yLjc4NVoiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration">1:16</span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz4=" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">Q1: What kinds of bodies of water are there? A1: There are rivers and streams. Evidence: 0:07 - 0:14</span></p></figcaption>
</figure>

## Multi-Task Learning of T5 Model with I3D Features

To solve WildQA, Santiago et al. concatenate the text features with the visual features and input the concatenated features to the T5 model. They extract [I3D video features](https://iashin.ai/video_features/models/i3d/) and take one feature per second.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2022/10/image-16.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-16.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-16.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-16.png 1600w, https://cms.jina.ai/content/images/2022/10/image-16.png 2270w" sizes="(min-width: 720px) 720px" width="2000" height="1107" alt="Diagram of a deep reinforcement learning model for video game question-answering featuring extractors, encoders, and decoders" />
</figure>

T5 encoder outputs a sequence of the encoded states. Santiago et al. treat the subsequence corresponding to the visual features as the encoded hidden sequence for the video frames. They then multiply the sequence with two vectors to get the maximum likelihood prediction of the start and the end of the evidence, respectively.

The tasks of visual evidence selection and video question-answering can be jointly trained together by simply combining the two losses in a weighted-manner.

In the experiment, Santiago et al. propose multiple baselines including: randomly choosing answers from the dev set (i.e. Random); always predicting the most common answer in the dev set (i.e. Common); and retrieving the answers for the dev set question whose embedding has the highest cosine similarity to the test question (i.e. Closest).

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-17.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-17.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-17.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-17.png 1600w, https://cms.jina.ai/content/images/2022/10/image-17.png 2020w" sizes="(min-width: 720px) 720px" width="2000" height="701" alt="Table comparing performance metrics like ROUGE scores and IOU-F1 for models including Random, Closest, T5, and Human" />
<figcaption><span style="white-space: pre-wrap;">Performance on video question-answering, measured by ROUGE score (left); and on video evidence selection (right) measured by Intersection-Over-Union. IOU is defined as the length of their intersection divided by the length of their union. The prediction is counted as a match if it overlaps with any of the ground truth spans by more than the threshold. They then use these partial matches to calculate an F1 score (i.e. IOU-F1 scores).</span></figcaption>
</figure>

I noticed that introducing video information (T5 T+V) does not improve performance on video question-answering tasks, which confirms what Yang & Silberer said in their work. This may also due to the types of questions in WildQA, which do not match commonsense knowledge. In the video evidence selection task, the T5 model is not even better than the random baseline. Adding multi-task learning does not help. In general, we can conclude WildQA is a pretty challenging task with a significant gap between the state-of-the-art multimodal model and human.

## Other Interesting Multimodal Research

### Multimodal Social Media

There are multiple research projects focusing on multimodality in the social media. For example, the upswing of text and image sharing on social media platforms during mass emergency situations has led to numerous opportunities to gain timely access to valuable information that can help disaster relief authorities act more quickly and more efficiently.

Iustin et al. extend the [FixMatch algorithm](https://arxiv.org/abs/2001.07685) to a multimodal scenario and offer two extensions to the original approach relevant for text and multimodal datasets. They show that multimodal FixMatch can leverage inexpensive unlabeled data to improve performance on diaster classification tasks.

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.239/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Multimodal Semi-supervised Learning for Disaster Tweet Classification
</div>
<div class="kg-bookmark-description">
Iustin Sirbu, Tiberiu Sosea, Cornelia Caragea, Doina Caragea, Traian Rebedea. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.239.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Extracting spatial information from social media and tweets has also received substantial attention recently. Zhaomin et al. propose BERT+VGG16 multimodal model to determine whether people are located in the places they mention in their tweets.

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.226/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Are People Located in the Places They Mention in Their Tweets? A Multimodal Approach
</div>
<div class="kg-bookmark-description">
Zhaomin Xiao, Eduardo Blanco. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.226.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

To better understand when the text and image are most beneficial, Zhaomin et al. perform a qualitative analysis of the errors made by the single-stream model, and how these errors are fixed by the dual-stream model.

Social media is a good place to conduct sentiment analysis. As a popular way to express emotion on social media, stickers & memes in posts can supplement missing sentiments and help identify sentiments precisely. Stickers and memes, despite being represented as images or simple gifs, have very different semantics from real-world photos. Feng et al. point out three challenges when working with stickers/memes:

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.591/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Towards Exploiting Sticker for Multimodal Sentiment Analysis in Social Media: A New Dataset and Baseline
</div>
<div class="kg-bookmark-description">
Feng Ge, Weizhao Li, Haopeng Ren, Yi Cai. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.591.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

- First, stickers may be inherently multimodal because they are embedded with texts. Same sticker with different sticker texts may vary significantly in sentiment.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-18.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-18.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-18.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-18.png 1600w, https://cms.jina.ai/content/images/size/w2400/2022/10/image-18.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1038" alt="Collage of Philosoraptor memes depicting philosophical and humorous questions related to the meme genre" />
<figcaption><span style="white-space: pre-wrap;">Millennial Humor on "Philosoraptor"</span></figcaption>
</figure>

- Second, stickers are highly varied in style, preventing the models from learning robust representations.
- Third, the way sentiment is fused together from text and stickers is complicated and sometimes inconsistent.

This work actually reminds me a popular Youtube video explaining Gen Z humor and their meme behaviors:

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-text">

Popular = Not Funny  
Was popular = Funny  
Ironic = Funny  
Make no sense = Funny  
Unfunny = Funny

</div>

</div>

There's nothing that Gen-Zers like more than changing and hating things. So perhaps our models on sentiment analysis have become obsolete?

<figure class="kg-card kg-embed-card">
<div class="iframe">
<div id="player">

</div>
<div class="player-unavailable">
<h1 id="an-error-occurred." class="message">An error occurred.</h1>
<div class="submessage">
Unable to execute JavaScript.
</div>
</div>
</div>
</figure>

### Text-Gestures Multimodal

Communication is a multimodal process. Information from verbal and non-verbal modalities are mixed into one channel. It has been revealed from a long history of empirical studies that speakers’ expression in the visual modality, including gestures, body poses, eye contacts and other types of non-verbal behaviors, play critical roles in face-to-face communication, because they add subtle information that is hard to convey in verbal language.

Yang etc. consider gestures as non-verbal communication and prove that non-verbal communication also conforms to the principle of entropy rate constancy (ERC). Under this assumption, communication in any form (written or spoken) should optimize the rate of information transmission rate by keeping the overall entropy rate constant.

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.12/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Gestures Are Used Rationally: Information Theoretic Evidence from Neural Sequential Models
</div>
<div class="kg-bookmark-description">
Yang Xu, Yang Cheng, Riya Bhatia. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.12.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

This means that the information encoded in hand gestures, albeit subtle, is actually organized in a rational way that enhances the decoding/understanding of information from a receiver’s perspective.

Artem etc. consider human gestures together with their corresponding utterances. They explore a multimodal approach to learning gesture embeddings through contrastive learning, and attempt to predict psycholinguistic categories and the language of the speaker from their gesture embeddings.

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.488/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Towards Understanding the Relation between Gestures and Language
</div>
<div class="kg-bookmark-description">
Artem Abzaliev, Andrew Owens, Rada Mihalcea. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.488.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

### Text-Image Multimodal, but via Topic Modelling

Perhaps the most surprising work to me is from Elaine et al., who present a novel neural multilingual and multimodal topic model that takes advantage of pretrained document and image embeddings to abstract the complexities between languages and modalities. Their work is based on the contextualized topic model, a family of topic models that uses contextualized document embeddings as input.

<figure class="kg-card kg-bookmark-card">
<a href="https://aclanthology.org/2022.coling-1.355/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Multilingual and Multimodal Topic Modelling with Pretrained Embeddings
</div>
<div class="kg-bookmark-description">
Elaine Zosa, Lidia Pivovarova. Proceedings of the 29th International Conference on Computational Linguistics. 2022.
</div>
<div class="kg-bookmark-metadata">
<img src="https://aclanthology.org/aclicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">ACL Anthology</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://aclanthology.org/thumb/2022.coling-1.355.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

It surprises me that after more than 12 years, Latent Dirichlet Allocation (LDA) models still show up in top conferences like COLING. After reading through the paper, I found a lot of adoption has been made over the last few years to make the original LDA more "deep". In fact, it is now called neural topic models (NTMs), which refers to a class of topic models that use neural networks to estimate the parameters of the topic-word and document-topic distributions.

## Summary

There has been some great work on multimodal AI presented at COLING this year. It is clear that this is a subject that is only going to continue to grow in importance, as I pointed out in the blog post below.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/paradigm-shift-towards-multimodal-ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
The Paradigm Shift Towards Multimodal AI
</div>
<div class="kg-bookmark-description">
We are on the cusp of a new era in AI, one in which multimodal AI will be the norm. At Jina AI, our MLOps platform helps businesses and developers win while they’re right at the starting line of this paradigm shift, and build the applications of the future today.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/android-icon-192x192.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2022/10/7.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Multimodal AI allows machines to better understand the world around them by processing data from multiple modalities (e.g. text, images, audio). This is an important step towards true artificial general intelligence, as it allows machines to more closely approximate the way humans process information.
