---
title: "Create Your Personalized Podcast With Jina Reader and PromptPerfect"
slug: create-your-personalized-podcast-with-jina-reader-and-promptperfect
url: https://cms.jina.ai/create-your-personalized-podcast-with-jina-reader-and-promptperfect/
published_at: 2024-04-29T18:00:33.000+02:00
updated_at: 2024-07-08T21:11:18.000+02:00
reading_time: 9
authors: "Alex C-G"
tags: "Tech Blog"
excerpt: "Use Jina Reader and PromptPerfect to generate your custom news podcast with RSS feeds, article extraction, LLMs, and Text-to-Speech."
---

# Create Your Personalized Podcast With Jina Reader and PromptPerfect

Like a lot of people, I listen to a bunch of podcasts. Some are about [science fiction](https://www.ouropinionsarecorrect.com/). Some are about [paleontology](https://commondescentpodcast.com/). And some are about [weird medieval guys](https://podcasts.apple.com/us/podcast/weird-medieval-guys/id1694002215). No true crime unfortunately, except for my occasionally poor taste.

<div class="kg-card kg-callout-card kg-callout-card-green">

<div class="kg-callout-emoji">

🎧

</div>

<div class="kg-callout-text">

What's not in poor taste (of course) is [Jina AI's own podcast](https://podcasts.apple.com/us/podcast/jina-ai-podcast/id1734573793). Be sure to give it a listen!

</div>

</div>

But...it's a drag to listen to all of these podcasts. Yet they aren't the worst of it. I *also* subscribe to a lot of news feeds. And that can be a lot of reading. It'd be fantastic if I could just take all the content of those news feeds, put it into a five-minute summary and have my phone read it out while I brush my teeth in the morning.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

🏥

</div>

<div class="kg-callout-text">

Dentists probably don't recommend brushing for a full five minutes. The Jina AI blog should not be treated as a source for medical advice. Some of us are doctors, but not that kind of doctor.

</div>

</div>

I guess you can see where this is going. I'm using Python to build a tool with (mostly) the Jina tech stack to create my personalized daily news podcast.

If you want to jump ahead and just hear how it sounds, you can listen below:

<div class="kg-card kg-audio-card">

<img src="" class="kg-audio-thumbnail kg-audio-hide" alt="audio-thumbnail" />

<div class="kg-audio-thumbnail placeholder">

![](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9Im5vbmUiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNNy41IDE1LjMzYS43NS43NSAwIDEgMCAwIDEuNS43NS43NSAwIDAgMCAwLTEuNVptLTIuMjUuNzVhMi4yNSAyLjI1IDAgMSAxIDQuNSAwIDIuMjUgMi4yNSAwIDAgMS00LjUgMFpNMTUgMTMuODNhLjc1Ljc1IDAgMSAwIDAgMS41Ljc1Ljc1IDAgMCAwIDAtMS41Wm0tMi4yNS43NWEyLjI1IDIuMjUgMCAxIDEgNC41IDAgMi4yNSAyLjI1IDAgMCAxLTQuNSAwWiIgLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjQ4NiA2LjgxQTIuMjUgMi4yNSAwIDAgMSAxNy4yNSA5djUuNTc5YS43NS43NSAwIDAgMS0xLjUgMHYtNS41OGEuNzUuNzUgMCAwIDAtLjkzMi0uNzI3Ljc1NS43NTUgMCAwIDEtLjA1OS4wMTNsLTQuNDY1Ljc0NGEuNzUuNzUgMCAwIDAtLjU0NC43MnY2LjMzYS43NS43NSAwIDAgMS0xLjUgMHYtNi4zM2EyLjI1IDIuMjUgMCAwIDEgMS43NjMtMi4xOTRsNC40NzMtLjc0NloiIC8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0zIDEuNWEuNzUuNzUgMCAwIDAtLjc1Ljc1djE5LjVhLjc1Ljc1IDAgMCAwIC43NS43NWgxOGEuNzUuNzUgMCAwIDAgLjc1LS43NVY1LjEzM2EuNzUuNzUgMCAwIDAtLjIyNS0uNTM1bC0uMDAyLS4wMDItMy0yLjg4M0EuNzUuNzUgMCAwIDAgMTggMS41SDNaTTEuNDA5LjY1OUEyLjI1IDIuMjUgMCAwIDEgMyAwaDE1YTIuMjUgMi4yNSAwIDAgMSAxLjU2OC42MzdsLjAwMy4wMDIgMyAyLjg4M2EyLjI1IDIuMjUgMCAwIDEgLjY3OSAxLjYxVjIxLjc1QTIuMjUgMi4yNSAwIDAgMSAyMSAyNEgzYTIuMjUgMi4yNSAwIDAgMS0yLjI1LTIuMjVWMi4yNWMwLS41OTcuMjM3LTEuMTY5LjY1OS0xLjU5MVoiIC8+PC9zdmc+)

</div>

<div class="kg-audio-player-container">

<div class="kg-audio-title">

Output

</div>

<div class="kg-audio-player">

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik0yMy4xNCAxMC42MDggMi4yNTMuMTY0QTEuNTU5IDEuNTU5IDAgMCAwIDAgMS41NTd2MjAuODg3YTEuNTU4IDEuNTU4IDAgMCAwIDIuMjUzIDEuMzkyTDIzLjE0IDEzLjM5M2ExLjU1NyAxLjU1NyAwIDAgMCAwLTIuNzg1WiIgLz48L3N2Zz4=)

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxyZWN0IHg9IjMiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjxyZWN0IHg9IjE0IiB5PSIxIiB3aWR0aD0iNyIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgcnk9IjEuNSIgLz48L3N2Zz4=)

<span class="kg-audio-current-time">0:00</span>

<div class="kg-audio-time">

/<span class="kg-audio-duration">79.464</span>

</div>

1×

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik0xNS4xODkgMi4wMjFhOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoMS43OTRhLjI0OS4yNDkgMCAwIDEgLjIyMS4xMzMgOS43MyA5LjczIDAgMCAwIDcuOTI0IDQuODVoLjA2YTEgMSAwIDAgMCAxLTFWMy4wMmExIDEgMCAwIDAtMS4wNi0uOTk4WiIgLz48L3N2Zz4=)

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik0xNi4xNzcgNC4zYS4yNDguMjQ4IDAgMCAwIC4wNzMtLjE3NnYtMS4xYTEgMSAwIDAgMC0xLjA2MS0xIDkuNzI4IDkuNzI4IDAgMCAwLTcuOTI0IDQuODUuMjQ5LjI0OSAwIDAgMS0uMjIxLjEzM0g1LjI1YTMgMyAwIDAgMC0zIDN2MmEzIDMgMCAwIDAgMyAzaC4xMTRhLjI1MS4yNTEgMCAwIDAgLjE3Ny0uMDczWk0yMy43MDcgMS43MDZBMSAxIDAgMCAwIDIyLjI5My4yOTJsLTIyIDIyYTEgMSAwIDAgMCAwIDEuNDE0bC4wMDkuMDA5YTEgMSAwIDAgMCAxLjQwNS0uMDA5bDYuNjMtNi42MzFBLjI1MS4yNTEgMCAwIDEgOC41MTUgMTdhLjI0NS4yNDUgMCAwIDEgLjE3Ny4wNzUgMTAuMDgxIDEwLjA4MSAwIDAgMCA2LjUgMi45MiAxIDEgMCAwIDAgMS4wNjEtMVY5LjI2NmEuMjQ3LjI0NyAwIDAgMSAuMDczLS4xNzZaIiAvPjwvc3ZnPg==)

</div>

</div>

</div>

## What's a News Feed?

First up, I'm calling them "news feeds" since most people aren't familiar with the terms [RSS or Atom feeds](https://roelofjanelsinga.com/articles/rss-atom-feed-why-should-have-for-blog/). In short, a feed is a structured list of articles published by a blog or news source, ordered from new to old. Many sites offer them, and there are [several apps and websites](https://www.wired.com/story/best-rss-feed-readers/) that let you import all your feeds, letting you read all your news in one app, without having to visit the websites for [Ars Technica](https://arstechnica.com/), [Taylor Swift fansites](https://swiftieconnection.com/), and [Washington Post](https://www.washingtonpost.com):

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://play-lh.googleusercontent.com/H60xGVYr2c9K-2fWe3Vhnuz_Fo83xlUh8eSqfYmoPqBUIJwD9E7aJvqroS_6xK0N8A=w2560-h1440-rw" class="kg-image" loading="lazy" width="1277" height="1440" alt="Screenshot image 8" />
<figcaption><a href="https://play.google.com/store/apps/details?id=com.nononsenseapps.feeder.play"><span style="white-space: pre-wrap;">Feeder</span></a><span style="white-space: pre-wrap;"> feed reader on Android, showing Ars Technica feed. Notice the simple layout, no ads or junk</span></figcaption>
</figure>

They're an [ancient technology](https://www.rssboard.org/rss-history) from the prehistoric web, but many websites support them, including Jina AI's own blog (here's [our feed](https://jina.ai/feed.rss)).

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

For sites that don't have their own feeds, there are [third-party tools](https://politepol.com/en/) to generate them.

</div>

</div>

In short, feeds let you read all your news in one place, skipping all the sidebar junk and ads. In this post, we'll be using news feeds to find and download the latest posts from the sites we follow.

## Let’s Start This Feeding Frenzy

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

The code in this post is a simplified version of what you'll find in the notebook. We're not going to muck around with `pip install`s and setting keys in this post, so if you want to follow along, follow the notebook for the full experience, and stick to this post for the bigger picture.  
  
[****Colab link****](https://colab.research.google.com/github/jina-ai/workshops/blob/main/notebooks/reader/news-reader/notebook.ipynb) ****\|**** [****GitHub link****](https://github.com/jina-ai/workshops/blob/main/notebooks/reader/news-reader/notebook.ipynb)

</div>

</div>

To make the magic happen, we're going to use several services and Python libraries:

- [**Feedparser**](https://feedparser.readthedocs.io/): A Python library to download and extract content from news feeds.
- [**Jina Reader**](https://jina.ai/reader/): Jina's API to extract just the content from each article, not downloading junk like headers, footers and sidebars.
- [**PromptPerfect**](https://promptperfect.jina.ai): [Prompts-as-Services](https://jina.ai/news/whats-next-for-prompt-engineering-prompts-as-a-service) will summarize each article then combine those summaries into a single paragraph, in the style of a news reader from NPR.
- [**gTTS**](https://pypi.org/project/gTTS/): Google's Text-to-Speech library, to read the news report out loud.

That's all we'll cover in the post. If you want to create a podcast feed for your personalized podcast, we suggest you check other sources.

## Downloading Feeds

Since this is just a simple example, we'll stick with just a couple of news feeds for [The Register](https://www.theregister.com/) and [OSNews](https://www.osnews.com/), two tech news websites.

``` python
feed_urls = [
    "https://www.osnews.com/feed/",
    "https://www.theregister.com/headlines.atom"
]
```

With Feedparser we can download the feeds and then download the article links from each feed:

``` python
import feedparser

for feed_url in feed_urls:
    feed = feedparser.parse(feed_url)
    for entry in feed["entries"]:
        page_urls.append(entry["link"])
```

## Extracting Article Text With Jina Reader

Each feed contains links to each article on the relevant website. If we just download that web page, we get a whole bunch of HTML, including sidebars, headers, footers and other junk we don't need. If you feed this to an LLM it'll be like you chewing on grass. Sure, the LLM can *do* it, but it's not what it naturally wants to eat.

What an LLM really wants is something close to plain text. [Jina Reader](https://jina.ai/reader/) converts an article to [Markdown](https://www.markdownguide.org/).

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/reader" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Reader API
</div>
<div class="kg-bookmark-description">
Read any URL into LLM-friendly text instantly, hassle-free.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-reader-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

This makes it look more like this:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="an">Title:</span><span class="co"> Unintended acceleration leads to recall of every Cybertruck produced so far</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>URL Source: https://www.theregister.com/2024/04/19/tesla_recalls_all_3878_cybertrucks/?td=rt-3a</span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>Published Time: 2024-04-19T13<span class="sc">:55:</span>08Z</span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>Markdown Content:</span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>Tesla has issued a recall notice for every single Cybertruck it has produced thus far, a sum of 3,878 vehicles.</span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>Today&#39;s <span class="co">[</span><span class="ot">recall notice</span><span class="co">](https://static.nhtsa.gov/odi/rcl/2024/RCLRPT-24V276-7026.PDF)</span> <span class="sc">\[</span>PDF<span class="sc">\]</span> by the National Highway Traffic Safety Administration states that Cybertrucks have a defect on the accelerator pedal, which can get wedged against the interior of the car, keeping it pushed down. The pedal actually comes in two parts: the pedal itself and then a longer piece on top of it. That top piece can become partially detached and then slide off against the interior trim, making it impossible for the pedal to lift up. This defect <span class="co">[</span><span class="ot">was already suspected</span><span class="co">](https://www.theregister.com/2024/04/15/tesla_lays_off_10_percent/)</span> as Tesla paused production of the Cybertruck due to an &quot;unexpected delay.&quot; Some Cybertruck owners also spoke on social media about their vehicles uncontrollably accelerating, with one crashing into a pole and another demonstrating <span class="co">[</span><span class="ot">on film</span><span class="co">](https://www.tiktok.com/@el.chepito1985/video/7357758176504089898)</span> how exactly the pedal breaks and gets stuck.</span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>...</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">We cut this shorter since including the whole article is overkill. But you can see that it's clear, human-readable (markdown) text.</span></p></figcaption>
</figure>

Instead of this:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode html"><code class="sourceCode html"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;!doctype</span> html<span class="dt">&gt;</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;</span><span class="kw">html</span><span class="ot"> lang</span><span class="op">=</span><span class="st">&quot;en&quot;</span><span class="dt">&gt;</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;</span><span class="kw">head</span><span class="dt">&gt;</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;text/html; charset=utf-8&quot;</span><span class="ot"> http-equiv</span><span class="op">=</span><span class="st">&quot;Content-Type&quot;</span><span class="dt">&gt;</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">title</span><span class="dt">&gt;</span>Unintended acceleration leads to recall of every Cybertruck • The Register<span class="dt">&lt;/</span><span class="kw">title</span><span class="dt">&gt;</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> name</span><span class="op">=</span><span class="st">&quot;robots&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;max-snippet:-1, max-image-preview:standard, max-video-preview:0&quot;</span><span class="dt">&gt;</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> name</span><span class="op">=</span><span class="st">&quot;viewport&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;initial-scale=1.0, width=device-width&quot;</span><span class="dt">/&gt;</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> property</span><span class="op">=</span><span class="st">&quot;og:image&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;https://regmedia.co.uk/2019/11/22/cybertruck.jpg&quot;</span><span class="dt">/&gt;</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> property</span><span class="op">=</span><span class="st">&quot;og:type&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;article&quot;</span><span class="ot"> </span><span class="dt">/&gt;</span></span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> property</span><span class="op">=</span><span class="st">&quot;og:url&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;https://www.theregister.com/2024/04/19/tesla_recalls_all_3878_cybertrucks/&quot;</span><span class="ot"> </span><span class="dt">/&gt;</span></span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> property</span><span class="op">=</span><span class="st">&quot;og:title&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;Unintended acceleration leads to recall of every Cybertruck&quot;</span><span class="ot"> </span><span class="dt">/&gt;</span></span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> property</span><span class="op">=</span><span class="st">&quot;og:description&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;That isn</span><span class="dv">&amp;#39;</span><span class="st">t what Tesla meant by Full Self-Driving&quot;</span><span class="ot"> </span><span class="dt">/&gt;</span></span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> name</span><span class="op">=</span><span class="st">&quot;twitter:card&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;summary_large_image&quot;</span><span class="dt">&gt;</span></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&lt;</span><span class="kw">meta</span><span class="ot"> name</span><span class="op">=</span><span class="st">&quot;twitter:site&quot;</span><span class="ot"> content</span><span class="op">=</span><span class="st">&quot;@TheRegister&quot;</span><span class="dt">&gt;</span></span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;</span><span class="kw">script</span><span class="ot"> type=</span><span class="st">&quot;application/ld+json&quot;</span><span class="dt">&gt;</span></span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a><span class="op">...</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">We had to cut this short before we even got to the actual content. There's just so much non-human-readable junk.</span></p></figcaption>
</figure>

By feeding the LLM something it can more naturally digest (like markdown rather than HTML), it can give us better output. Otherwise it's like feeding Doritos to a lion. Sure, it *can* eat them, but it won't be its best lion-self if it maintains that diet.

To extract just the text in a human-readable way we'll use Jina Reader's API:

``` python
import requests

articles = []

for url in page_urls:
    reader_url = f"https://r.jina.ai/{url}"
    article = requests.get(reader_url)
    articles.append(article.text)
```

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

You can view human-readable output directly in your web browser by going to `https://r.jina.ai/<url>`, for example <a href="https://r.jina.ai/https://www.theregister.com/2024/04/19/wing_commander_windows_95/" rel="noreferrer"><code spellcheck="false" style="white-space: pre-wrap;">https://r.jina.ai/https://www.theregister.com/2024/04/19/wing_commander_windows_95/</code></a>

</div>

</div>

## Summarizing the articles with PromptPerfect

Since there may be a *lot* of articles, we'll use an LLM to summarize each one separately. If we just put them all together and feed that to the LLM to summarize, it may choke on too many tokens at once.

This will vary depending on how many articles you want to deal with. For just a few it may be worth [concat](https://en.wiktionary.org/wiki/concatenate#Derived_terms)'ing them all into one long string and just making one call, saving time and money. However for this example we'll assume we're dealing with a larger number of articles.

To summarize them we'll use a [Prompt-as-a-Service](https://jina.ai/news/whats-next-for-prompt-engineering-prompts-as-a-service) from [PromptPerfect](https://promptperfect.jina.ai/).

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/whats-next-for-prompt-engineering-prompts-as-a-service" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
What’s Next for Prompt Engineering? PromptPerfect’s Prompt as a Service!
</div>
<div class="kg-bookmark-description">
Deploy prompts and flexible template prompts as REST API services, and integrate them into your applications with just a few clicks
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">PromptPerfect</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2023/06/Pic.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Here's our Prompt-as-Service:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://hackmd.io/_uploads/rkjn80QZ0.png" class="kg-image" loading="lazy" width="594" height="874" alt="image" />
<figcaption><span style="white-space: pre-wrap;">Our Prompt-as-Service to summarize articles</span></figcaption>
</figure>

We'll write a function to do this, since we'll call another Prompt-as-Service later in this post:

``` python
def get_paas_response(id, template_dict):
    url = f"https://api.promptperfect.jina.ai/{id}"
    headers = {
        "x-api-key": f"token {PROMPTPERFECT_KEY}",
        "Content-Type": "application/json"
    }
        response = requests.post(url, headers=headers, json={"parameters": template_dict})
        
    if response.status_code == 200:
        text = response.json()["data"]
        return text
    else:
        return response.text
```

We'll then take each summary and add them to a list, finally concat'ing them into a bulleted markdown list:

``` python
summaries = []

for article in articles:
    summary = get_paas_response(
        prompt_id="mkuMXLdx1kMU0Xa8l19A", 
        template_prompt={"article": article}
    )
    summaries.append(summary)
    
concat_summaries = "\n- ".join(summaries)
```

## Generating a News Report with PromptPerfect

Now that we've got that bulleted list, we can send that to another Prompt-as-a-Service to generate a news bulletin that sounds like natural newsreader speech:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://hackmd.io/_uploads/rJEJD07ZA.png" class="kg-image" loading="lazy" width="594" height="874" alt="image" />
<figcaption><span style="white-space: pre-wrap;">Our Prompt-as-Service to combine summaries into a cohesive news report</span></figcaption>
</figure>

The full prompt is:

> You are an NPR technology news editor. You have received the following news summaries:  
>   
> \[summaries\]  
>   
> Your job is to give a one paragraph overview of the news, covering each item in an organic way, with segues to the next item. You can change the order of the items if that makes sense, and merge duplicates.  
>   
> You will output a one paragraph script that sounds organic, to be read on NPR daily news. The script should take no longer than five minutes to read aloud.

We'll get the news script with this code:

``` python
news_script = get_paas_response(
    prompt_id="tmW07mipzJ14HgAjOcfD",
    template_prompt={"summaries": concat_summaries}
)
```

Here's the final text:

> Today in tech news, we have a range of updates and developments to discuss. First up, the Tiny11 Builder tool offers users the ability to debloat Windows 11, creating a customized image tailored to their preferences. Moving on to the world of gaming, we delve into the hidden components inside Super Nintendo cartridges, shedding light on the technology that fascinated gamers in the '90s. Shifting gears to software, the Niri tiling window manager for Wayland has released a major update, offering new features like infinite scrolling and improved animations. In the realm of AI, Microsoft's Copilot feature has faced some hiccups in its rollout to Windows Insiders, with bugs and intrusive behavior prompting a halt in the deployment. Meanwhile, the UK's Information Commissioner's Office raises concerns about Google's Privacy Sandbox, questioning its privacy implications and impact on competition. Lastly, the US Federal Aviation Administration has updated its launch license requirements, now mandating reentry vehicles to obtain a license before launch, following an incident involving Varda Space Industries. These diverse tech stories highlight the ongoing advancements and challenges in the tech world.

## Reading the News Out Loud

To read the text out loud we'll use the [Google's TTS library](https://pypi.org/project/gTTS/).

<figure class="kg-card kg-bookmark-card">
<a href="https://pypi.org/project/gTTS/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
gTTS
</div>
<div class="kg-bookmark-description">
gTTS (Google Text-to-Speech), a Python library and CLI tool to interface with Google Translate text-to-speech API
</div>
<div class="kg-bookmark-metadata">
<img src="https://pypi.org/static/images/favicon.35549fe8.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">PyPI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://pypi.org/static/images/twitter.abaf4b19.webp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

``` python
from gtts import gTTS

tts = gTTS(news_script, tld="us")
tts.save("output.mp3")
```

This will give us a final [audio file](https://github.com/jina-ai/workshops/raw/feat-reader-podcast-notebook/notebooks/reader/news-reader/output.mp3):

<div class="kg-card kg-audio-card">

<img src="" class="kg-audio-thumbnail kg-audio-hide" alt="audio-thumbnail" />

<div class="kg-audio-thumbnail placeholder">

![](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9Im5vbmUiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNNy41IDE1LjMzYS43NS43NSAwIDEgMCAwIDEuNS43NS43NSAwIDAgMCAwLTEuNVptLTIuMjUuNzVhMi4yNSAyLjI1IDAgMSAxIDQuNSAwIDIuMjUgMi4yNSAwIDAgMS00LjUgMFpNMTUgMTMuODNhLjc1Ljc1IDAgMSAwIDAgMS41Ljc1Ljc1IDAgMCAwIDAtMS41Wm0tMi4yNS43NWEyLjI1IDIuMjUgMCAxIDEgNC41IDAgMi4yNSAyLjI1IDAgMCAxLTQuNSAwWiIgLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjQ4NiA2LjgxQTIuMjUgMi4yNSAwIDAgMSAxNy4yNSA5djUuNTc5YS43NS43NSAwIDAgMS0xLjUgMHYtNS41OGEuNzUuNzUgMCAwIDAtLjkzMi0uNzI3Ljc1NS43NTUgMCAwIDEtLjA1OS4wMTNsLTQuNDY1Ljc0NGEuNzUuNzUgMCAwIDAtLjU0NC43MnY2LjMzYS43NS43NSAwIDAgMS0xLjUgMHYtNi4zM2EyLjI1IDIuMjUgMCAwIDEgMS43NjMtMi4xOTRsNC40NzMtLjc0NloiIC8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0zIDEuNWEuNzUuNzUgMCAwIDAtLjc1Ljc1djE5LjVhLjc1Ljc1IDAgMCAwIC43NS43NWgxOGEuNzUuNzUgMCAwIDAgLjc1LS43NVY1LjEzM2EuNzUuNzUgMCAwIDAtLjIyNS0uNTM1bC0uMDAyLS4wMDItMy0yLjg4M0EuNzUuNzUgMCAwIDAgMTggMS41SDNaTTEuNDA5LjY1OUEyLjI1IDIuMjUgMCAwIDEgMyAwaDE1YTIuMjUgMi4yNSAwIDAgMSAxLjU2OC42MzdsLjAwMy4wMDIgMyAyLjg4M2EyLjI1IDIuMjUgMCAwIDEgLjY3OSAxLjYxVjIxLjc1QTIuMjUgMi4yNSAwIDAgMSAyMSAyNEgzYTIuMjUgMi4yNSAwIDAgMS0yLjI1LTIuMjVWMi4yNWMwLS41OTcuMjM3LTEuMTY5LjY1OS0xLjU5MVoiIC8+PC9zdmc+)

</div>

<div class="kg-audio-player-container">

<div class="kg-audio-title">

Output

</div>

<div class="kg-audio-player">

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik0yMy4xNCAxMC42MDggMi4yNTMuMTY0QTEuNTU5IDEuNTU5IDAgMCAwIDAgMS41NTd2MjAuODg3YTEuNTU4IDEuNTU4IDAgMCAwIDIuMjUzIDEuMzkyTDIzLjE0IDEzLjM5M2ExLjU1NyAxLjU1NyAwIDAgMCAwLTIuNzg1WiIgLz48L3N2Zz4=)

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxyZWN0IHg9IjMiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjxyZWN0IHg9IjE0IiB5PSIxIiB3aWR0aD0iNyIgaGVpZ2h0PSIyMiIgcng9IjEuNSIgcnk9IjEuNSIgLz48L3N2Zz4=)

<span class="kg-audio-current-time">0:00</span>

<div class="kg-audio-time">

/<span class="kg-audio-duration">79.464</span>

</div>

1×

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik0xNS4xODkgMi4wMjFhOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoMS43OTRhLjI0OS4yNDkgMCAwIDEgLjIyMS4xMzMgOS43MyA5LjczIDAgMCAwIDcuOTI0IDQuODVoLjA2YTEgMSAwIDAgMCAxLTFWMy4wMmExIDEgMCAwIDAtMS4wNi0uOTk4WiIgLz48L3N2Zz4=)

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik0xNi4xNzcgNC4zYS4yNDguMjQ4IDAgMCAwIC4wNzMtLjE3NnYtMS4xYTEgMSAwIDAgMC0xLjA2MS0xIDkuNzI4IDkuNzI4IDAgMCAwLTcuOTI0IDQuODUuMjQ5LjI0OSAwIDAgMS0uMjIxLjEzM0g1LjI1YTMgMyAwIDAgMC0zIDN2MmEzIDMgMCAwIDAgMyAzaC4xMTRhLjI1MS4yNTEgMCAwIDAgLjE3Ny0uMDczWk0yMy43MDcgMS43MDZBMSAxIDAgMCAwIDIyLjI5My4yOTJsLTIyIDIyYTEgMSAwIDAgMCAwIDEuNDE0bC4wMDkuMDA5YTEgMSAwIDAgMCAxLjQwNS0uMDA5bDYuNjMtNi42MzFBLjI1MS4yNTEgMCAwIDEgOC41MTUgMTdhLjI0NS4yNDUgMCAwIDEgLjE3Ny4wNzUgMTAuMDgxIDEwLjA4MSAwIDAgMCA2LjUgMi45MiAxIDEgMCAwIDAgMS4wNjEtMVY5LjI2NmEuMjQ3LjI0NyAwIDAgMSAuMDczLS4xNzZaIiAvPjwvc3ZnPg==)

</div>

</div>

</div>

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

❓

</div>

<div class="kg-callout-text">

Why didn't we go with a model-driven TTS approach? Two reasons: Firstly, in our testing with [Bark](https://replicate.com/suno-ai/bark) we frequently encountered hallucinations when sending it more than six sentences or so. It didn't even hallucinate after six sentences – it started hallucinating really early on, throwing in numbers and gibberish words whenever we passed it too much information. Secondly, using a library rather than an API means one fewer API key you need to sign up for.

</div>

</div>

## Next Steps

We're not going to cover the rest of the podcast creation experience in this post. That's not our forte, and just like medical advice you probably shouldn't listen to us when it comes to the nitty-gritty of setting up a podcast feed, uploading it to Spotify, Apple Podcasts, etc. For medical or podcast advice, speak to your doctor or Joe Rogan respectively.

As for what else Jina Reader can do, think of all the [RAG](https://jina.ai/news/full-stack-rag-with-jina-embeddings-v2-and-llamaindex) applications you can create by downloading readable versions of any web page. Or for PromptPerfect, see how else it can help [YouTubers](https://jina.ai/news/elevating-youtube-scripts-with-promptperfect-ai-mastery-for-video-content-creators) (or [marketers](https://jina.ai/news/click-worthy-content-with-promptperfect-ai-marketing-for-newsletters-and-social-media), if that's your jam.)
