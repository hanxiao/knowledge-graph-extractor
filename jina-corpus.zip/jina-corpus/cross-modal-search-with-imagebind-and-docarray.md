---
title: "Cross-modal search with ImageBind and DocArray"
slug: cross-modal-search-with-imagebind-and-docarray
url: https://cms.jina.ai/cross-modal-search-with-imagebind-and-docarray/
published_at: 2023-05-22T16:00:56.000+02:00
updated_at: 2024-01-24T18:28:50.000+01:00
reading_time: 5
authors: "Alaeddine Abdessalem"
tags: "Tech Blog"
excerpt: "Combine ImageBind with DocArray to implement a cross-modal search system"
---

# Cross-modal search with ImageBind and DocArray

------------------------------------------------------------------------

## Background

Meta recently released yet another open-source model, after a series of cool models like LLaMA and SAM.

This time they embrace further multimodal AI with a focus on embeddings with the new [ImageBind](https://ai.facebook.com/blog/imagebind-six-modalities-binding-ai/) Model.

We gave it a try and in this blog post, we will show how you can use this cool model along with DocArray to implement a cross-modal search system!

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/05/multimodal-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/05/multimodal-1.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/05/multimodal-1.png 1000w, https://cms.jina.ai/content/images/2023/05/multimodal-1.png 1384w" sizes="(min-width: 720px) 720px" width="1384" height="786" />
</figure>

## ImageBind

[ImageBind](https://ai.facebook.com/blog/imagebind-six-modalities-binding-ai/) is a new embedding model from Meta that is capable of learning a joint embedding across six different modalities - images, text, audio, depth, thermal, and IMU data (inertial measurement units, which track motion and position).

The true power of ImageBind lies in its ability to surpass specialist models that are trained for one specific modality, demonstrating its capability to analyze a multitude of data forms in unison. This holistic approach enables ImageBind to relate objects in an image to their corresponding sounds, 3D shapes, temperatures, and motion patterns, mirroring our human ability to process a complex blend of sensory information.

Moreover, ImageBind demonstrates that it's feasible to create a shared embedding space across multiple modalities without the need for training on data encompassing every possible combination of these modalities. This is a crucial development given the impracticality of creating datasets that include every potential combination of modalities.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/05/Untitled.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/05/Untitled.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/05/Untitled.png 1000w, https://cms.jina.ai/content/images/size/w1600/2023/05/Untitled.png 1600w, https://cms.jina.ai/content/images/2023/05/Untitled.png 1920w" sizes="(min-width: 720px) 720px" width="1920" height="1080" />
<figcaption>Source: <a href="https://ai.facebook.com/blog/imagebind-six-modalities-binding-ai/">https://ai.facebook.com/blog/imagebind-six-modalities-binding-ai/</a></figcaption>
</figure>

Representing different modalities in the same embedding space allows for several use cases, like cross-modal generation, embedding-space generation, or cross-modal retrieval. In this blog, we’re interested in the latter use case and we’ll implement it using DocArray.

## DocArray

[DocArray](https://docs.docarray.org/) is a library for **representing, sending, and storing multi-modal data**, perfect for **Machine Learning applications**.

With DocArray you can:

1.  **[Represent data](https://docs.docarray.org/#represent)**
2.  **[Send data](https://docs.docarray.org/#send)**
3.  **[Store data](https://docs.docarray.org/#store)**

DocArray is also optimized for neural search and supports searching by vector either in-memory or using a variety of vector databases, notably Weaviate, Qdrant, and ElasticSearch.

As we observed more multimodal AI models, we reshaped DocArray to become more suitable for multimodal AI use cases: multimodal AI search and generation.

Since [the new release (v0.30.0)](https://jina.ai/news/docarray-v2-update/), you can enjoy flexible schemas, more multimodal datatypes, and native support for multimodal neural search.

Let’s see it in action with ImageBind!

## Cross-modal search with DocArray

First, we need to install DocArray:

``` bash
pip install docarray
```

Next, we need to install ImageBind. We can do so by cloning the repository:

``` bash
git clone https://github.com/facebookresearch/ImageBind
pip install -r ImageBind/requirements.txt
```

Once we install the dependencies, we can load the ImageBind model:

``` python
import os
os.chdir('ImageBind')

import data
import torch
from models import imagebind_model
from models.imagebind_model import ModalityType

device = "cuda:0" if torch.cuda.is_available() else "cpu"

# Instantiate model
model = imagebind_model.imagebind_huge(pretrained=True)
model.eval()
model.to(device)
```

We will use pre-defined documents from DocArray for 3 data types:

- [🖼️ Image](https://docs.docarray.org/data_types/image/image/)
- [🔤 Text](https://docs.docarray.org/data_types/text/text/)
- and [🔊 Audio](https://docs.docarray.org/data_types/audio/audio/).

The predefined documents offer several utilities like data loading, visualization, and built-in embedding.

Let’s first use these documents to implement an embedding function that uses the loaded ImageBind model:

``` python
from typing import Union
from docarray.documents import TextDoc, ImageDoc, AudioDoc

def embed(doc: Union[TextDoc, ImageDoc, AudioDoc]):
    """inplace embedding of document"""
    with torch.no_grad():
        if isinstance(doc, TextDoc):
            embedding = model({ModalityType.TEXT: data.load_and_transform_text([doc.text], device)})[ModalityType.TEXT]
        elif isinstance(doc, ImageDoc):
            embedding = model({ModalityType.VISION: data.load_and_transform_vision_data([doc.url], device)})[ModalityType.VISION]
        elif isinstance(doc, AudioDoc):
            embedding = model({ModalityType.AUDIO: data.load_and_transform_audio_data([doc.url], device)})[ModalityType.AUDIO]
        else:
            raise ValueError('one of the modality fields need to be set')

    doc.embedding = embedding.detach().cpu().numpy()[0]

    return doc
```

Let’s quickly try out the in-place embedding function:

``` python
doc = ImageDoc(url='.assets/car_image.jpg')
doc = embed(doc)
doc
```

``` bash
📄ImageDoc: e679676 ...
╭─────────────────────────────┬────────────────────────────────────────╮
│ Attribute                   │ Value                                  │
├─────────────────────────────┼────────────────────────────────────────┤
│ url: ImageUrl               │ .assets/car_image.jpg                  │
│ embedding: NdArrayEmbedding │ NdArrayEmbedding of shape (1024,)      │
╰─────────────────────────────┴────────────────────────────────────────╯
```

As we can see, the document has an embedding field generated with shape of `(1024,)`. Now let’s dive into search.

## Cross-modal search

### Text-to-image

In this blog, we will use [the in-memory vector index](https://docs.docarray.org/user_guide/storing/index_in_memory/) to perform neural search using the embeddings. However, feel free to check [our documentation](https://docs.docarray.org/user_guide/storing/docindex/) to find out about vector database integrations.

Let’s create an index for image documents and index some documents:

``` python
from docarray.index.backends.in_memory import InMemoryExactNNIndex

image_index = InMemoryExactNNIndex[ImageDoc]()
image_index.index([
    embed(doc) for doc in 
    [ImageDoc(url=img_path) for img_path in [".assets/dog_image.jpg", ".assets/car_image.jpg", ".assets/bird_image.jpg"]]
])
```

Now, let's search for bird images using text:

``` python
match = image_index.find(embed(TextDoc(text='bird')).embedding, search_field='embedding', limit=1) \
                   .documents[0]
match.url.display()
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/05/Untitled--1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/05/Untitled--1-.png 600w, https://cms.jina.ai/content/images/2023/05/Untitled--1-.png 640w" width="640" height="855" />
</figure>

### Text-to-audio

Now let's try a different modality: audio. The process is pretty much the same. First, create an index for audio documents:

``` python
from docarray.index.backends.in_memory import InMemoryExactNNIndex

audio_index = InMemoryExactNNIndex[AudioDoc]()
audio_index.index([
    embed(doc) for doc in
    [AudioDoc(url=audio_path) for audio_path in [".assets/dog_audio.wav", ".assets/car_audio.wav", ".assets/bird_audio.wav"]]
])
```

Now search for bird sounds by using text:

``` python
match = audio_index.find(embed(TextDoc(text='bird')).embedding, search_field='embedding', limit=1) \
                   .documents[0]
match.url.display()
# Displays the bird sound
```

<div class="kg-card kg-audio-card">

<img src="" class="kg-audio-thumbnail kg-audio-hide" alt="audio-thumbnail" />

<div class="kg-audio-thumbnail placeholder">

![](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik03LjUgMTUuMzNhLjc1Ljc1IDAgMSAwIDAgMS41Ljc1Ljc1IDAgMCAwIDAtMS41Wm0tMi4yNS43NWEyLjI1IDIuMjUgMCAxIDEgNC41IDAgMi4yNSAyLjI1IDAgMCAxLTQuNSAwWk0xNSAxMy44M2EuNzUuNzUgMCAxIDAgMCAxLjUuNzUuNzUgMCAwIDAgMC0xLjVabS0yLjI1Ljc1YTIuMjUgMi4yNSAwIDEgMSA0LjUgMCAyLjI1IDIuMjUgMCAwIDEtNC41IDBaIiAvPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTQuNDg2IDYuODFBMi4yNSAyLjI1IDAgMCAxIDE3LjI1IDl2NS41NzlhLjc1Ljc1IDAgMCAxLTEuNSAwdi01LjU4YS43NS43NSAwIDAgMC0uOTMyLS43MjcuNzU1Ljc1NSAwIDAgMS0uMDU5LjAxM2wtNC40NjUuNzQ0YS43NS43NSAwIDAgMC0uNTQ0LjcydjYuMzNhLjc1Ljc1IDAgMCAxLTEuNSAwdi02LjMzYTIuMjUgMi4yNSAwIDAgMSAxLjc2My0yLjE5NGw0LjQ3My0uNzQ2WiIgLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTMgMS41YS43NS43NSAwIDAgMC0uNzUuNzV2MTkuNWEuNzUuNzUgMCAwIDAgLjc1Ljc1aDE4YS43NS43NSAwIDAgMCAuNzUtLjc1VjUuMTMzYS43NS43NSAwIDAgMC0uMjI1LS41MzVsLS4wMDItLjAwMi0zLTIuODgzQS43NS43NSAwIDAgMCAxOCAxLjVIM1pNMS40MDkuNjU5QTIuMjUgMi4yNSAwIDAgMSAzIDBoMTVhMi4yNSAyLjI1IDAgMCAxIDEuNTY4LjYzN2wuMDAzLjAwMiAzIDIuODgzYTIuMjUgMi4yNSAwIDAgMSAuNjc5IDEuNjFWMjEuNzVBMi4yNSAyLjI1IDAgMCAxIDIxIDI0SDNhMi4yNSAyLjI1IDAgMCAxLTIuMjUtMi4yNVYyLjI1YzAtLjU5Ny4yMzctMS4xNjkuNjU5LTEuNTkxWiIgLz48L3N2Zz4=)

</div>

<div class="kg-audio-player-container">

<div class="kg-audio-title">

Bird audio

</div>

<div class="kg-audio-player">

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==)

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==)

<span class="kg-audio-current-time">0:00</span>

<div class="kg-audio-time">

/<span class="kg-audio-duration">0:05</span>

</div>

1×

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==)

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+)

</div>

</div>

</div>

### Image-to-audio

What’s cool with ImageBind is that you can do image-to-audio search as well. Let’s use the same index and perform one more search query, with an image this time!

``` python
# using the same audio_index, find by image:
match = audio_index.find(embed(ImageDoc(url='.assets/car_image.jpg')).embedding, search_field='embedding', limit=1) \
                                     .documents[0]
match.url.display()
# Displays the card sound
```

<div class="kg-card kg-audio-card">

<img src="" class="kg-audio-thumbnail kg-audio-hide" alt="audio-thumbnail" />

<div class="kg-audio-thumbnail placeholder">

![](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik03LjUgMTUuMzNhLjc1Ljc1IDAgMSAwIDAgMS41Ljc1Ljc1IDAgMCAwIDAtMS41Wm0tMi4yNS43NWEyLjI1IDIuMjUgMCAxIDEgNC41IDAgMi4yNSAyLjI1IDAgMCAxLTQuNSAwWk0xNSAxMy44M2EuNzUuNzUgMCAxIDAgMCAxLjUuNzUuNzUgMCAwIDAgMC0xLjVabS0yLjI1Ljc1YTIuMjUgMi4yNSAwIDEgMSA0LjUgMCAyLjI1IDIuMjUgMCAwIDEtNC41IDBaIiAvPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTQuNDg2IDYuODFBMi4yNSAyLjI1IDAgMCAxIDE3LjI1IDl2NS41NzlhLjc1Ljc1IDAgMCAxLTEuNSAwdi01LjU4YS43NS43NSAwIDAgMC0uOTMyLS43MjcuNzU1Ljc1NSAwIDAgMS0uMDU5LjAxM2wtNC40NjUuNzQ0YS43NS43NSAwIDAgMC0uNTQ0LjcydjYuMzNhLjc1Ljc1IDAgMCAxLTEuNSAwdi02LjMzYTIuMjUgMi4yNSAwIDAgMSAxLjc2My0yLjE5NGw0LjQ3My0uNzQ2WiIgLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTMgMS41YS43NS43NSAwIDAgMC0uNzUuNzV2MTkuNWEuNzUuNzUgMCAwIDAgLjc1Ljc1aDE4YS43NS43NSAwIDAgMCAuNzUtLjc1VjUuMTMzYS43NS43NSAwIDAgMC0uMjI1LS41MzVsLS4wMDItLjAwMi0zLTIuODgzQS43NS43NSAwIDAgMCAxOCAxLjVIM1pNMS40MDkuNjU5QTIuMjUgMi4yNSAwIDAgMSAzIDBoMTVhMi4yNSAyLjI1IDAgMCAxIDEuNTY4LjYzN2wuMDAzLjAwMiAzIDIuODgzYTIuMjUgMi4yNSAwIDAgMSAuNjc5IDEuNjFWMjEuNzVBMi4yNSAyLjI1IDAgMCAxIDIxIDI0SDNhMi4yNSAyLjI1IDAgMCAxLTIuMjUtMi4yNVYyLjI1YzAtLjU5Ny4yMzctMS4xNjkuNjU5LTEuNTkxWiIgLz48L3N2Zz4=)

</div>

<div class="kg-audio-player-container">

<div class="kg-audio-title">

Car audio

</div>

<div class="kg-audio-player">

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==)

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==)

<span class="kg-audio-current-time">0:00</span>

<div class="kg-audio-time">

/<span class="kg-audio-duration">0:05</span>

</div>

1×

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==)

![](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+)

</div>

</div>

</div>

## Conclusion

Cross-modal search, made possible with ImageBind and DocArray, is transforming the way we handle and interpret multimodal data. With ImageBind's ability to generate shared embedding spaces across multiple modalities and DocArray's clear and easy API to represent, send, and store this multimodal data, we have demonstrated how to implement a cross-modal search system.

These tools enable you to explore a wide range of use cases and applications. The cross-modal search capabilities we’ve showcased here are just the beginning, and we’re excited to see what you can build and the exciting applications around it.

Check out [DocArray’s documentation](https://docs.docarray.org/), [GitHub repo](https://github.com/docarray/docarray), and [Discord](https://discord.gg/WaMp6PVPgR) to find out how to implement multi-modal search systems.

Furthermore, you can check the ImageBind [paper](https://arxiv.org/abs/2305.05665) and [GitHub repo](https://github.com/facebookresearch/ImageBind) for more details about the model.

Happy searching!
