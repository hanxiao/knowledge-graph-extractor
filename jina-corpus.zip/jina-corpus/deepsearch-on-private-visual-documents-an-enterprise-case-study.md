---
title: "DeepSearch on Private Visual Documents: An Enterprise Case Study"
slug: deepsearch-on-private-visual-documents-an-enterprise-case-study
url: https://cms.jina.ai/deepsearch-on-private-visual-documents-an-enterprise-case-study/
published_at: 2025-03-31T13:36:51.000+02:00
updated_at: 2025-03-31T20:12:08.000+02:00
reading_time: 7
authors: "Maximilian Werk, Scott Martens"
tags: "Tech Blog"
excerpt: "Our DeepSearch works with private PDFs and visual documents right out of the box. Discover how DeepSearch can unlock valuable insights from your enterprise data."
---

# DeepSearch on Private Visual Documents: An Enterprise Case Study

Enterprise search is demanding. Queries can vary in quality, detail, and domain-specificity, but responses need to be accurate, direct, and highly relevant. At the same time, the underlying data is typically weakly structured, poorly structured, or completely unstructured, archived in various formats with differing levels of accessibility.

Having correct, up-to-date information on hand is essential to good customer service, and the most expensive workers in an enterprise — not just the C-suite but skilled technical staff and engineers — waste company resources when they have to spend hours sifting through masses of under-structured documentation to get actionable information.

These are the kinds of challenges that highlight AI’s real power in the enterprise.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/deepsearch" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
DeepSearch
</div>
<div class="kg-bookmark-description">
Search, read and reason until best answer found.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-28.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/banner-deepsearch.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Jina AI’s DeepSearch leverages new developments in AI for enterprise search by applying agentic reasoning to multimodal information retrieval. It does more than just retrieve a collection of candidate query matches on demand. DeepSearch *reflects intelligently* on user requests, reformulating queries and evaluating results, digging deeper into the data on the user’s behalf until it's satisfied with the result as a whole. It can identify ambiguities in queries that users may not be aware of, summarize relevant information, and present results. If a query can only be correctly answered with information from more than one document, it does so in a transparent and user-accessible way.

DeepSearch acts as the user’s agent, leveraging existing retrieval systems rather than replacing an entire technology stack. It adds powerful AI to critical systems without costly infrastructure changes.

## How Does DeepSearch Work?

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/a-practical-guide-to-implementing-deepsearch-deepresearch" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
A Practical Guide to Implementing DeepSearch/DeepResearch
</div>
<div class="kg-bookmark-description">
QPS out, depth in. DeepSearch is the new norm. Find answers through read-search-reason loops. Learn what it is and how to build it.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-29.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Han Xiao</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/a-practical-guide-to-implementing-deepsearch-deepresearch-3.webp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

DeepSearch operates iteratively, through a process of searching, reading, thinking, and reformulating its search, keeping track of what it’s learned and re-applying it. In short, it mimics ideal user behavior when engaging with a search system and body of documents.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2025/03/image-40.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-40.png 600w, https://cms.jina.ai/content/images/2025/03/image-40.png 696w" width="696" height="407" alt="Flowchart depicting a search and retrieval system process from user query to reading, reasoning, and providing an answer." />
</figure>

DeepSearch goes beyond just enhancing conventional retrieval. It doesn’t just fetch documents to present to users; it reads them and then makes new queries based on what it’s learned. It thinks and answers.

## DeepSearch with Visual Documents

To show how this works in action, we’re going to use a collection of PDF documents provided by our partner [Sikla GmbH](https://www.sikla.com/), a Germany-based global supplier of modular construction and engineering systems. These documents consist of product catalogs, specifications, and support documentation for fasteners and various construction products.

While DeepSearch works with whatever search and archiving systems you already have in place, for this article, we will use our prototype **Enterprise Visual Document Search**. This AI-driven document store supports unstructured mixed media, especially PDFs and HTML5/SVG renderings that integrate both diagrams and text, retrieving documents via multimodal and multilingual semantic indexing. In short: It just works with whatever you've got.

Let’s consider an example query:

> What is the tightening torque for a TCS F VdS/FM Beam Clamp?

Treating this like a normal query and just using DocumentSearch, without DeepSearch, the results look like this:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/image--43-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image--43-.png 600w, https://cms.jina.ai/content/images/2025/03/image--43-.png 722w" sizes="(min-width: 720px) 720px" width="722" height="689" alt="Collage of 6 German documents titled &quot;Anerkennung&quot; and &quot;VdS,&quot; indicating recognition and approval of technical standards." />
<figcaption><span style="white-space: pre-wrap;">Results for the query </span><em><em>"What is the tightening torque for a TCS F VdS/FM Beam Clamp?"</em></em></figcaption>
</figure>

This isn’t very helpful. The query terms are mostly matched, but the pages found aren’t very relevant to tightening torque.

One strategy to improve queries is to remove unneeded words:

> Tightening torque for TCS F VdS/FM Beam Clamp.

This query retrieves the mounting instructions, which specify the correct tightening torque.

<span id="fig1"></span>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/image-41.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-41.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/03/image-41.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/03/image-41.png 1600w, https://cms.jina.ai/content/images/2025/03/image-41.png 1690w" sizes="(min-width: 720px) 720px" width="1690" height="2375" alt="Technical manual page for Sikla Beam Clamp with mounting instructions, specifications, and company contact details." />
<figcaption><span style="white-space: pre-wrap;">First result for the query </span><em><em>"Tightening torque for TCS F VdS/FM Beam Clamp."</em></em></figcaption>
</figure>

This highlights the idiosyncrasies of information retrieval systems that are often sensitive to exact query wording. No matter how well-tuned your system is, it can still give you these kinds of problems.

DeepSearch is able to try different ways of constructing queries and evaluating the results, acting on the user’s behalf. Instead of wasting human time and effort fiddling with query wording, AI does it for them.

But DeepSearch can do more than just show you the right document. “What is the tightening torque for a TCS F VdS/FM Beam Clamp?” is a question with a specific correct answer: 10 Nm (newton-metres). DeepSearch reads the documents it finds and can give you the answer directly, with a link to the relevant document for you to inspect and verify if appropriate:

> The tightening torque for the nuts of the Sikla Beam Clamp TCS F VdS / FM is 10 Nm\[<a href="#fig1" rel="noreferrer">^1</a>\]. Position the beam clamp and hand-tighten both nuts, then tighten the nuts to a torque of 10 Nm.

## DeepSearch, auch als TiefenSuche

DeepSearch is multilingual, with training on over 100 languages. That means we can search in German too. For example:

> *Was ist der Anzugsmoment für eine 25mm Stabilrohrschelle?  
>   
> (What is the tightening torque of a 25mm Stabil (brand name) pipe clamp?)*

Using DocumentSearch directly, the top retrieval actually contains an answer:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/image-42.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-42.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/03/image-42.png 1000w, https://cms.jina.ai/content/images/2025/03/image-42.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="1700" alt="User manual in German and English detailing mounting instructions for Stabil D3G with technical tables and diagrams." />
<figcaption><span style="white-space: pre-wrap;">First result for the query "</span><em><em>Was ist der Anzugsmoment für eine 25mm Stabilrohrschelle?</em></em><span style="white-space: pre-wrap;">"</span></figcaption>
</figure>

This is pretty good, although you have to read the table and be aware that 25mm is in the range 24-65mm to get to the correct value: 2 Nm.

But there is still a problem: This query is ambiguous. Sikla sells several different Stabil-brand pipe clamps with different tightening torques. The page above only has the correct answer for the Stabil D3G clamp.

The third highest scoring page is clearer about this:

<span id="fig3"></span>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/image-43.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-43.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/03/image-43.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/03/image-43.png 1600w, https://cms.jina.ai/content/images/2025/03/image-43.png 1690w" sizes="(min-width: 720px) 720px" width="1690" height="2375" alt="Technical specification sheet for Sikla components with technical information in German and English." />
<figcaption><span style="white-space: pre-wrap;">Third highest result for the query "</span><em><em>Was ist der Anzugsmoment für eine 25mm Stabilrohrschelle?</em></em><span style="white-space: pre-wrap;">"</span></figcaption>
</figure>

We see here three different Stabil-brand clamps with different tightening torques. To get a complete, correct answer, users have to know that, first, their request matches more than one thing, and second, to look beyond the first page retrieved.

DeepSearch does that automatically. It gives a much more instantly informative answer to the same query:

> Der Anzugsmoment für eine 25-mm-Stabilrohrschelle von Sikla variiert je nach Modell. Hier eine Übersicht relevanter Modelle und zugehöriger Anzugsmomente, basierend auf den Spannbereichen:
>
> -   
> - **Stabil D-3G m.E.:** Für den Spannbereich 24-65 mm beträgt der Anzugsmoment 2 Nm \[[^1](#fig3)\]. Dieser Wert gilt sowohl für statische als auch für seismische Belastungen. Diese Schelle ist aus galvanisch verzinktem Stahl gefertigt.
> - **Stabil RB-A:** Diese Schelle hat keinen expliziten Wert für 25 mm genannt. Jedoch beträgt der Anzugsmoment für den Spannbereich 13-49 mm 20 Nm. Diese Schelle ist aus blankem Stahl gefertigt.
>
>   
>
> Es ist zu beachten, dass der korrekte Anzugsmoment entscheidend für die sichere Befestigung ist. Bei Unsicherheiten sollte immer die spezifische Montageanleitung des jeweiligen Sikla Produkts konsultiert werden.

Translation:

> The tightening torque for a 25 mm Stabil pipe clamp from Sikla varies depending on the model. Here is an overview of relevant models and associated tightening torques, based on their clamping ranges:
>
>   
>
> **Stabil D-3G m.E.:** For the clamping range of 24-65 mm, the tightening torque is 2 Nm \[[^1](#fig3)\]. This value applies to both static and seismic loads. This clamp is made of galvanized steel.
>
> **Stable RB-A:** This clamp has no explicit value for 25 mm. However, the tightening torque for the clamping range 13-49 mm is 20 Nm. This clamp is made of bright steel.
>
>   
>
> It should be noted that the correct tightening torque is crucial for secure fastening. In case of uncertainty, always consult the installation instructions for that specific Sikla product.

This shows the real power that DeepSearch adds to query systems: It does the in-depth due diligence that even well-informed and experienced users often do not do.

## DeepSearch Cuts Through the Clutter

The example documents from Sikla are often full of tables with very specific names and numbers. This is very important information for an engineering concern, but it’s also an eyesore and prone to being misread or skipped over by a human reader who’s just a little bit tired or bored.

For example:

> Welches ist die notwendige Verankerungstiefe in Porenbeton beim VMU plus System?  
>   
> *(What is the necessary anchoring depth for the VMU plus system in AAC?*)

This retrieves the right information, but in a page full of tables and numbers:

<span id="fig4"></span>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/image-45.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-45.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/03/image-45.png 1000w, https://cms.jina.ai/content/images/2025/03/image-45.png 1464w" sizes="(min-width: 720px) 720px" width="1464" height="1956" alt="Technical tables displaying load-bearing values, specifications, and factors for &#39;Steintyp: Porenbeton&#39; construction material" />
<figcaption><span style="white-space: pre-wrap;">First result for the query </span><em><em>"Welches ist die notwendige Verankerungstiefe in Porenbeton beim VMU plus System?"</em></em></figcaption>
</figure>

DeepSearch cuts through this and gives a response that excludes what doesn’t answer the query:

> Die notwendige Verankerungstiefe für das VMU plus System in Porenbeton hängt von der Steindruckfestigkeit des Porenbetons (fb) und dem Durchmesser der Ankerstange ab. Gemäß ETA-17/0307 sind folgende Werte für Porenbeton AAC6 (ρ: 0,6 kg/dm³) mit einer Steindruckfestigkeit von ≥ 6 N/mm² zu berücksichtigen \[<a href="#fig4" rel="noreferrer">^1</a>\]:  
>   
> Für Ankerstangen M8 bis M16 gilt eine Verankerungstiefe (hef) von 80 mm bis 100 mm. \[…\]

Translation:

> *The required anchoring depth for the VMU plus system in aerated concrete depends on the compressive strength of the aerated concrete (fb) and the diameter of the anchor rod. According to ETA-17/0307, the following values must be taken into account for AAC6 aerated concrete (ρ: 0.6 kg/dm³) with a compressive strength of ≥ 6 N/mm² \[*<a href="#fig4" rel="noreferrer"><em>^1</em></a>*\]:  
>   
> For anchor rods M8 to M16, an anchoring depth (hef) of 80 mm to 100 mm applies. \[...\]*

## DeepSearch for Enterprises: Let AI Search for You

There is no area of enterprise IT where AI technology is more immediately relevant than information retrieval. Jina AI offers a full stack of AI search technologies, from multimedia semantic indexing to AI language and reasoning models, that plug into an entire technology stack and take charge of the information it stores. Robust, accessible, and even inexpensive AI-driven solutions are available right now for customer service and employee support.

If your business has stored data that you need to have at your fingertips, we have solutions for businesses of all sizes and data protection needs. Jina AI is a European vendor providing access to AI models as needed via a GDPR-compliant public API, ready to install in your cloud deployment, or for installation on-site in your own server room.
