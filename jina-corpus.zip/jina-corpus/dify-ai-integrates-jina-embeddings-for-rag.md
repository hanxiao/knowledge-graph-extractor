---
title: "Dify.AI integrates Jina Embeddings for RAG"
slug: dify-ai-integrates-jina-embeddings-for-rag
url: https://cms.jina.ai/dify-ai-integrates-jina-embeddings-for-rag/
published_at: 2023-12-06T16:00:31.000+01:00
updated_at: 2024-01-30T10:54:22.000+01:00
reading_time: 3
authors: "Scott Martens"
tags: "Tech Blog"
excerpt: "Dify.AI, a leading open-source platform specialized in creating generative AI applications, is now leveraging Jina Embeddings v2!"
---

# Dify.AI integrates Jina Embeddings for RAG

Online LLM application development platform <a href="https://dify.ai/" rel="noreferrer">Dify.AI</a> has integrated the <a href="https://jina.ai/embeddings/" rel="noreferrer">Jina Embeddings v2 API</a> in its innovative AI toolkit for instant access when building and hosting LLM applications. All you need to do is add your Jina Embeddings API key via their intuitive web interface to get the full power of Jina AI’s industry-leading embedding models in your RAG (retrieval-augmented generation) applications.

<figure class="kg-card kg-bookmark-card">
<a href="https://dify.ai/blog/integrating-jina-embeddings-v2-dify-enhancing-rag-applications" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Dify.AI x Jina AI：Dify now Integrates Jina Embedding Model - Dify Blog
</div>
<div class="kg-bookmark-description">
The next-gen development platform - Easily build and operate generative AI applications. Create Assistants API and GPTs based on any LLMs.
</div>
<div class="kg-bookmark-metadata">
<img src="https://framerusercontent.com/images/KWDRAMQLGjoMFBAjNjoCFMP7XI.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Dify Blog</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://framerusercontent.com/images/2OftM3MmDVHkLcxaNn58ZNWaE.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Top-performing, 8192-token length, $100 for 1.25B tokens, seamless OpenAI alternative, free trial
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Integrating Embeddings in RAG

Current AI architectures today have no direct way to integrate outside information sources. The model itself encodes information from its training data with varying levels of accuracy, and it is impractical to retrain the model every time there is new, potentially useful data that could be incorporated into it.

For example, I asked [JinaChat](https://chat.jina.ai/chat) a question about current events:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/12/Screenshot-2023-12-01-at-11.48.59.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/12/Screenshot-2023-12-01-at-11.48.59.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/12/Screenshot-2023-12-01-at-11.48.59.png 1000w, https://cms.jina.ai/content/images/2023/12/Screenshot-2023-12-01-at-11.48.59.png 1408w" sizes="(min-width: 720px) 720px" width="1408" height="1654" alt="Jina AI chat application with a conversation about Henry Kissinger&#39;s status, a help disclaimer, and UI elements." />
</figure>

The only way to ensure that an LLM has the information needed to answer a factual question is to provide it in the prompt:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/12/Screenshot-2023-12-01-at-11.53.33.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/12/Screenshot-2023-12-01-at-11.53.33.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/12/Screenshot-2023-12-01-at-11.53.33.png 1000w, https://cms.jina.ai/content/images/2023/12/Screenshot-2023-12-01-at-11.53.33.png 1316w" sizes="(min-width: 720px) 720px" width="1316" height="1186" alt="Chatbot screen with a message about Henry Kissinger&#39;s death on November 29, 2023, at age 100, citing the Washington Post." />
</figure>

Naturally, an LLM that only answers questions correctly if you include the answer in your question isn’t very useful. This has led to a body of techniques called **Retrieval-Augmented Generation** or **RAG**. RAG is a framework installed around an LLM that searches external information sources for materials that might contain the information needed to answer a user’s request and then presents them, with the user’s prompt, to the LLM.

<figure class="kg-card kg-image-card kg-width-wide">
<img src="https://cms.jina.ai/content/images/2023/12/image-2.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/12/image-2.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/12/image-2.png 1000w, https://cms.jina.ai/content/images/size/w1600/2023/12/image-2.png 1600w, https://cms.jina.ai/content/images/2023/12/image-2.png 2000w" sizes="(min-width: 1200px) 1200px" width="2000" height="938" alt="Flowchart demonstrating a large language model process using &quot;When did Henry Kissinger die?&quot; as a user prompt example" />
</figure>

This strategy has the added benefit that LLMs hallucinate much less when they are expected to handle a given text rather than recall things they might partially remember from training.

## Leveraging Jina Embeddings Superior Performance

[Dify.AI](http://Dify.ai) has integrated Jina Embeddings v2 to enhance retrieval quality for RAG prompting. Jina AI’s models provide [state-of-the-art accuracy in RAG applications](https://blog.llamaindex.ai/boosting-rag-picking-the-best-embedding-reranker-models-42d079022e83), and [with an input window of 8,192 tokens](https://jina.ai/news/jina-embeddings-2-the-best-solution-for-embedding-long-documents/), they can support much larger and more complex questions than most competing models at a much lower price.

You can now use Jina Embeddings in your LLM projects via [Dify.AI](http://Dify.ai)’s intuitive application builder, as shown in the video below or in the <a href="https://dify.ai/blog/integrating-jina-embeddings-v2-dify-enhancing-rag-applications" rel="noreferrer">post on Dify.AI's blog</a>:

<figure class="kg-card kg-video-card kg-width-regular" data-kg-thumbnail="https://cms.jina.ai/content/media/2023/12/ssstwitter.com_1701878449396_thumb.jpg" data-kg-custom-thumbnail="">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjMuMTQgMTAuNjA4IDIuMjUzLjE2NEExLjU1OSAxLjU1OSAwIDAgMCAwIDEuNTU3djIwLjg4N2ExLjU1OCAxLjU1OCAwIDAgMCAyLjI1MyAxLjM5MkwyMy4xNCAxMy4zOTNhMS41NTcgMS41NTcgMCAwIDAgMC0yLjc4NVoiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration">0:38</span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz4=" />
</div>
</div>
</div>
</figure>

## Get Involved

Check out [Dify.AI](http://Dify.ai)’s LLM application builder and hosting service for yourself. You can get a free tester token from the [Jina AI website to use Jina Embeddings](https://jina.ai/embeddings/) to try it out.

<figure class="kg-card kg-bookmark-card">
<a href="https://dify.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Dify.AI · The Innovation Engine for Generative AI Applications
</div>
<div class="kg-bookmark-description">
The next-gen development platform - Easily build and operate generative AI applications. Create Assistants API and GPTs based on any LLMs.
</div>
<div class="kg-bookmark-metadata">
<img src="https://framerusercontent.com/images/KWDRAMQLGjoMFBAjNjoCFMP7XI.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://framerusercontent.com/images/wh4qGCAanwpqHs0Kot8VLBSty4.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Top-performing, 8192-token length, $100 for 1.25B tokens, seamless OpenAI alternative, free trial
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

For more information about Jina AI’s offerings, check out the [Jina AI website](https://jina.ai/) or join our [community on Discord](https://discord.jina.ai/).

<figure class="kg-card kg-bookmark-card">
<a href="https://discord.jina.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Join the Jina AI Discord Server!
</div>
<div class="kg-bookmark-description">
Check out the Jina AI community on Discord - hang out with 3873 other members and enjoy free voice and text chat.
</div>
<div class="kg-bookmark-metadata">
<img src="https://discord.jina.ai/assets/images/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Discord</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn.discordapp.com/splashes/1106542220112302130/80f2c2128aefeb55209a5bdb2130bb92.jpg?size=512" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
