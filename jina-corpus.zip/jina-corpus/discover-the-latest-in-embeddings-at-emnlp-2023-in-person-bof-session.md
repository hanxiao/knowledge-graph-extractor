---
title: "Discover the Latest in Embeddings at EMNLP 2023 In-Person BoF Session"
slug: discover-the-latest-in-embeddings-at-emnlp-2023-in-person-bof-session
url: https://cms.jina.ai/discover-the-latest-in-embeddings-at-emnlp-2023-in-person-bof-session/
published_at: 2023-12-01T15:25:49.000+01:00
updated_at: 2024-01-24T16:14:34.000+01:00
reading_time: 2
authors: "Jina AI"
tags: "Events"
excerpt: "Mark your calendars for an immersive BoF session on Embeddings at EMNLP 2023. Join us on December 9th from 11:00 AM to 12:30 PM, Singapore time, in the 'Aquarius 1' room for a deep dive into the latest embeddings."
---

# Discover the Latest in Embeddings at EMNLP 2023 In-Person BoF Session

At the EMNLP2023 BoF (birds of a feather) session, we're set to explore the frontiers of embeddings. While recent developments like `jina-embeddings-v2` [have made significant strides](https://blog.llamaindex.ai/boosting-rag-picking-the-best-embedding-reranker-models-42d079022e83), they also open the door to new questions and challenges in the field. This 1.5-hour session is a platform to tackle these emerging issues in embeddings. You can register via the Google Form below:

<figure class="kg-card kg-bookmark-card">
<a href="https://forms.gle/z5E5BFvQqFf3fpW68" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
EMNLP 2023/BoF 6: Embeddings
</div>
<div class="kg-bookmark-description">
What: A BoF (Birds of a Feather) in-person session on Embeddings, co-organized by EMNLP PC and Jina AI. When &amp; Where: Saturday, December 9th, from 11:00 AM to 12:30 PM Singapore time at ‘Aquarius 1’ room. Highlights: multimodal embeddings, long context embeddings, multi- and bilingual embeddings,…
</div>
<div class="kg-bookmark-metadata">
<img src="https://ssl.gstatic.com/docs/forms/device_home/android_192.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Google Docs</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://lh5.googleusercontent.com/osAO-g4ajeOU2CCB6rhbi9UfHIsCU8_oa8HaZjsx0e6UuWoulCngSugztdf3Yoe2a5FQVSymImg=w1200-h630-p" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Event Details

**Date & Time:** December 9th, 11:00 AM - 12:30 PM Singapore time, at 'Aquarius 1' room.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

📆

</div>

<div class="kg-callout-text">

Add Embeddings BoF at EMNLP to your calendar now \[<a href="https://www.google.com/calendar/render?action=TEMPLATE&amp;text=Embeddings:%20Birds%20of%20a%20Feather%206&amp;dates=20231209T040000/20231209T053000&amp;ctz=UTC&amp;details=Birds%20of%20a%20Feather%206&amp;location=&amp;sprop=&amp;sprop=name:" target="_blank">Google</a>\]\[<a href="https://outlook.office365.com/owa/?path=/calendar/action/compose&amp;rru=addevent&amp;subject=Embeddings:%20Birds%20of%20a%20Feather%206&amp;startdt=2023-12-09T05:00:00+01:00&amp;enddt=2023-12-09T06:30:00+01:00&amp;body=Birds%20of%20a%20Feather%206&amp;location=true" target="_blank">Office365</a>\]\[[Outlook](about:blank)\]\[[iCal](about:blank)\]

</div>

</div>

**Format:** In-person, with an interactive and collaborative approach.  
**Registration:** [Google Form](https://forms.gle/z5E5BFvQqFf3fpW68)

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/12/image-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/12/image-1.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/12/image-1.png 1000w, https://cms.jina.ai/content/images/2023/12/image-1.png 1288w" sizes="(min-width: 720px) 720px" width="1288" height="962" alt="Detailed venue layout with labeled sections for tutorials, workshops, diversity, quiet and prayer rooms" />
</figure>

## Themes and Highlights

This BoF session features a set of thought-provoking presentations, panel discussions, and lightning talks, reflecting the ongoing evolution in the field:

#### Multimodal Embeddings:

- "How can multimodal embeddings be advanced to handle the context and nuance in diverse data types?"
- "What are the challenges in scaling multimodal embeddings for complex applications like personalized AI assistants?"
- "In what ways can vector databases be integrated with multimodal embeddings to enhance their contextual understanding?"

#### Long Context Embeddings:

- "How can long context embeddings be optimized to reduce hallucination in LLMs?"
- "What are the computational and practical challenges in scaling embeddings to handle longer contexts efficiently?"
- "Beyond the 8K limit, what novel approaches can push the boundaries of context length in embeddings?"

#### Multi- and Bilingual Embeddings:

- "What are the key hurdles in achieving high accuracy and cultural sensitivity in multi- and bilingual embeddings?"
- "How can embeddings tackle the challenge of representing less popular factual knowledge accurately?"
- "In the development of bilingual embeddings, how can we address the lack of in-house NLP expertise and high development costs?"

#### Embeddings for Low-Resource Languages:

- "What innovative strategies can be adopted to significantly boost support for low-resource languages in embeddings?"
- "How can we incentivize the development of embeddings for less popular languages amidst high costs and complexity?"
- "What role can transfer learning and fine-tuning play in enhancing embeddings for low-resource languages?"

#### RAG (Retrieval Augmented Generation) Applications:

- "How can RAG applications overcome the limitations of vector databases in understanding complex, nuanced meanings?"
- "What are the potentials and challenges of using RAG in AI assistants for deep personalization and context understanding?"
- "Considering the current state of RAG, what are the ethical considerations and potential risks in its widespread adoption?"

For more information, visit [EMNLP2023 Program](https://2023.emnlp.org/program/bof/).

We are looking forward to seeing you in person in Singapore next week!
