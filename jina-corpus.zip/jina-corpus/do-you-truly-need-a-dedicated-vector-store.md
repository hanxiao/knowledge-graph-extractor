---
title: "Do You Truly Need a Dedicated Vector Store?"
slug: do-you-truly-need-a-dedicated-vector-store
url: https://cms.jina.ai/do-you-truly-need-a-dedicated-vector-store/
published_at: 2023-09-01T12:15:20.000+02:00
updated_at: 2023-09-01T12:53:36.000+02:00
reading_time: 4
authors: "Han Xiao"
tags: "Insights"
excerpt: "Unraveling vector search spaghetti: Lucene's charm vs. shiny vector stores. Navigating enterprise mazes & startup vibes. Where's search headed next?"
---

# Do You Truly Need a Dedicated Vector Store?

In the rapidly shifting landscape of technology, it's all too easy to be ensnared by the latest buzzwords and narratives. One such prevailing discourse is the perceived necessity for a dedicated "vector store" or "vector database" in the modern AI stack. This notion is propelled by the increasing application of deep neural networks to search, leading many to believe that managing a vast number of dense vectors demands a specialized store. But is this narrative grounded in reality?

Drawing from the insights of the paper "**Vector Search with OpenAI Embeddings: Lucene Is All You Need**" by Jimmy Lin etc., and enriched by the collective wisdom of the tech community, let's dissect this debate.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2308.14963" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Vector Search with OpenAI Embeddings: Lucene Is All You Need
</div>
<div class="kg-bookmark-description">
We provide a reproducible, end-to-end demonstration of vector search withOpenAI embeddings using Lucene on the popular MS MARCO passage ranking testcollection. The main goal of our work is to challenge the prevailing narrativethat a dedicated vector store is necessary to take advantage of recent…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Jimmy Lin</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" />
</div>
</figure>

## Lucene's Role in Modern Vector Search

Lucene, renowned for its inverted index-based search, has long been a cornerstone in the search realm. Critics argue its limitations, particularly in contextual search with fuzzy logic like min edit distance. Yet, Lucene is far from stagnant. As described in the paper, the advent of hierarchical navigable small-world network (HNSW) indexes showcases Lucene's adaptability, proving its prowess in vector search capabilities on par with any dedicated vector store.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/09/image.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/09/image.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/09/image.png 1000w, https://cms.jina.ai/content/images/2023/09/image.png 1112w" sizes="(min-width: 720px) 720px" width="1112" height="546" />
<figcaption>A standard bi-encoder architecture used in Jimmy's paper, where encoders generate dense vector representations (embeddings) from queries and documents (passages). Retrieval is framed as k-nearest neighbor search in vector space.</figcaption>
</figure>

It's not just Lucene making waves. Vector indices are now industry staples. Giants like ElasticSearch, Postgresql, and Redis are embracing this trend. Google's recent endorsement of pgvector for their AlloyDB offering underscores the mainstream shift towards vector search.

<figure class="kg-card kg-bookmark-card">
<a href="https://cloud.google.com/blog/products/databases/helping-developers-build-gen-ai-apps-with-google-cloud-databases" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Helping developers build Gen AI apps with Google Cloud PostgreSQL databases | Google Cloud Blog
</div>
<div class="kg-bookmark-description">
Announcing a series of new features and capabilities to help developers build enterprise generative AI apps with Google Cloud PostgreSQL databases.
</div>
<div class="kg-bookmark-metadata">
<img src="https://ssl.gstatic.com/cloud/images/icons/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Google Cloud</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://storage.googleapis.com/gweb-cloudblog-publish/images/AlloyDB_AI_for_building_gen_AI_apps_Blog.max-2600x2600.jpg" />
</div>
</figure>

## Enterprise Search Challenges: Navigating the Vector Store Maze

Modern enterprise architectures are intricate tapestries of legacy systems, cutting-edge solutions, and a myriad of tools aimed at solving specific problems. The introduction of a dedicated vector store would not just be a simple addition; it would be a paradigm shift. Historically, enterprises have shown a tendency to lean on tried-and-tested solutions, especially when significant investments have been made. Lucene-based platforms, with their proven track record, offer a sense of reliability. The challenge for enterprises is not just about technology but also about change management, training, and integration. The real question is: Is the potential performance gain worth the upheaval?

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/09/mermaid-diagram-2023-09-01-125304.svg" class="kg-image" loading="lazy" width="170" height="150" />
<figcaption>Navigating the Vector Store Decision: A Strategic Framework for Enterprises</figcaption>
</figure>

## Startup Innovations: Beyond the Vector Store Hype

The startup ecosystem thrives on disruption and innovation. The vision of a dedicated vector store is alluring, promising unparalleled performance and capabilities. But in the world of startups, vision needs to be backed by tangible benefits. The reality is that while vector stores offer a new approach, tools like Lucene have been refining their capabilities for years. For startups, the challenge is to prove that their solutions offer not just incremental improvements but transformative changes. In a data-driven world, the onus is on these startups to showcase empirical evidence of their superiority, not just in lab conditions but in real-world scenarios.

## Achieving the Ideal: Performance Meets Practicality in Search Solutions

Performance is the holy grail in the world of search. But it's essential to understand that performance doesn't exist in a vacuum. It's intertwined with factors like cost, scalability, and ease of integration. While specialized vector databases might offer a performance edge in specific scenarios, solutions like Lucene bring a balance of performance, reliability, and familiarity. The challenge is to discern when to chase the bleeding edge of performance and when to opt for a more pragmatic, holistic solution. In a world inundated with options, the true art lies in making choices that deliver consistent value over time.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/benchmark-vector-search-databases-with-one-million-data/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Benchmark Vector Search Databases with One Million Data
</div>
<div class="kg-bookmark-description">
In DocArray, Documents inside a DocumentArray can live in a document store instead of in memory. External store provides longer persistence and faster retrieval. Ever wonder about which one is best for your use case? Here’s a comprehensive benchmark to help guide you.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">DocArray 0.18.2 Documentation</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/2022/11/Jina-AI-Website-Banners-Templates--33-.png" />
</div>
</figure>

## The Future of Vector Search: Lucene vs. Dedicated Stores

The debate surrounding dedicated vector stores versus [hybrid](https://jina.ai/news/hype-and-hybrids-multimodal-search-means-more-than-keywords-and-vectors-2/) Lucene [solutions](https://jina.ai/news/hype-and-hybrids-multimodal-search-means-more-than-keywords-and-vectors-2/) is alive and well. However, a clear sentiment is emerging from the tech community: the inclination towards optimizing what we have rather than chasing the next shiny object. As we push the envelope in search capabilities, it's paramount to remember that often, the optimal solution is already within our grasp.
