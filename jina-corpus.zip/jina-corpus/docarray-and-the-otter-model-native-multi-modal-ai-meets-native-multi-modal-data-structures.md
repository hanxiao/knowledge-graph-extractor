---
title: "DocArray and the Otter Model: Native multi-modal AI meets native multi-modal data structures"
slug: docarray-and-the-otter-model-native-multi-modal-ai-meets-native-multi-modal-data-structures
url: https://cms.jina.ai/docarray-and-the-otter-model-native-multi-modal-ai-meets-native-multi-modal-data-structures/
published_at: 2023-07-04T16:15:52.000+02:00
updated_at: 2024-01-24T18:19:10.000+01:00
reading_time: 7
authors: "Ge Jin, Scott Martens"
tags: "Tech Blog"
excerpt: "We all love when a perfect couple finds each other, like DocArray and Otter."
---

# DocArray and the Otter Model: Native multi-modal AI meets native multi-modal data structures

Some things go together, like peanut butter and jelly, tea and biscuits, gin and tonic, or [DocArray](https://docarray.jina.ai/) and [Otter](https://otter-ntu.github.io/).

<figure class="kg-card kg-bookmark-card">
<a href="https://docarray.jina.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Welcome to DocArray!
</div>
<div class="kg-bookmark-description">
:arrow_up: DocArray v2: We are currently working on v2 of DocArray. Keep reading here if you are interested in the current (stable) version, or check out the v2 alpha branch and v2 roadmap! DocArray is a library for nested, unstructured, multimodal data in transit, including text, image, audio, v…
</div>
<div class="kg-bookmark-metadata">
<img src="https://docarray.jina.ai/_static/favicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">DocArray 0.21.0 Documentation</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://docarray.jina.ai/_static/banner.png" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://otter-ntu.github.io/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Otter
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://otter-ntu.github.io/assets/images/logo/otter_logo.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">Bo Li*,♠,1</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://otter-ntu.github.io/assets/images/logo/otter_logo.png" />
</div>
</figure>

We live in a world where information is usually multimodal — where texts, images, videos, and other media co-exist and come mixed together. The emergence of large language models has transformed the way we process, understand, and gain insights from this kind of complex, poorly structured multimedia data.

The nature of the Otter model — reading in combinations of images, videos, and texts as prompts — makes DocArray almost perfectly suited to it.

With DocArray, you can represent, send, and store multi-modal data easily. It integrates seamlessly with a wide array of databases, including [Weaviate](https://docarray.jina.ai/advanced/document-store/weaviate), [Qdrant](https://docarray.jina.ai/advanced/document-store/qdrant/), and [ElasticSearch](https://docarray.jina.ai/advanced/document-store/elasticsearch/)[,](https://docarray.jina.ai/) presenting users with a consistent API format for vector search. With DocArray, you can navigate your multimodal data effortlessly.

DocArray was designed for the data our complex, multimedia, multi-modal world naturally generates, exactly the same kind of data that Otter was designed to process. This article will show you how to bring the two together to get the most out of the Otter model.

## The Otter model

The Otter Model is a multimodal model fine-tuned for [in-context instruction](https://en.wikipedia.org/wiki/In-context_learning_(natural_language_processing)). It has been adapted from the [OpenFlamingo](https://github.com/mlfoundations/open_flamingo) model from LAION, which is an open-source reproduction of DeepMind's [Flamingo](https://doi.org/10.48550/arXiv.2204.14198) model. To train it, Otter’s developers created a partially human-curated dataset of 2.8 million instruction sets with examples.

The way in-context instruction works is to not just ask the AI model to respond to some prompt but to give it, as part of the prompt, a few examples of how you want it to respond. Instead of “zero-shot learning”, where the model responds without new information, this is “few-shot learning”, where it’s given a bit of positive instruction in the form of a small example set of inputs and appropriate responses.

For example:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/otter_drawing_1_small.png" class="kg-image" loading="lazy" width="350" height="521" />
</figure>

Now using the same images, the same question, but different answers in the examples:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/otter_drawing_2_small.png" class="kg-image" loading="lazy" width="350" height="505" />
</figure>

You can see in this example how Otter learns from the two examples given in each prompt what class of answer is required. When the question is *“Where was this picture taken?” “Paris”* is the same kind of answer as *“Rome”* and *“London”*, while “*at the Eiffel Tower*” is the same kind of answer as “*at the Colosseum*” and “*near Tower Bridge*”. This is the kind of processing Otter was trained for.

## Building multi-modal prompts with DocArray

### Prerequisites

First, Otter is an enormous model and will require a great deal of memory and very powerful GPUs. You will need either two GTX 3090 24G or a single A100.

<div class="kg-card kg-callout-card kg-callout-card-red">

<div class="kg-callout-emoji">

⚠️

</div>

<div class="kg-callout-text">

Otter has a very high hardware requirement. You may have to rent a compatible cloud instance.

</div>

</div>

If you have secured the necessary hardware, the next step is to install DocArray. Assuming you have Python and pip installed and they are on the path, perform the following command in a terminal:

``` bash
pip install docarray
```

Next, download the environment for the Otter model from GitHub:

``` bash
git clone https://github.com/Luodian/Otter.git
```

Finally, use `conda` to create a new virtual Python environment and install all necessary dependencies in it:

``` bash
conda env create -f environment.yml
```

The file `environment.yml` is in the root directory of the git downloaded in the previous step.

### Creating the classes and functions with DocArray

A multi-modal prompt is a combination of different data types in a single prompt. This is where DocArray can shine because it allows us to tap into the richer, multi-faceted contexts that diverse data types offer.

For this article, we will build a small application that answers questions about pictures, with prompts that contain example images with example answers.

First, we will define the prompt object format in DocArray:

``` python
from docarray import BaseDoc
from docarray.typing import ImageUrl

class OtterDoc(BaseDoc):
    url: ImageUrl
    prompt: str
    answer: str
```

A prompt contains an image URL, a string prompt, and a string answer.

Now, we can create a prompt to pass to the model containing multiple instances of `OtterDoc`, using the three images below:

``` python
from docarray import DocList

docs = DocList[OtterDoc](
    [
        OtterDoc(
            url="https://upload.wikimedia.org/wikipedia/commons/1/1f/Colosseo_Romano_Rome_04_2016_6289.jpg",
            prompt="Where was this picture taken?",
            answer="Rome",
        ),
        OtterDoc(
            url="https://upload.wikimedia.org/wikipedia/commons/a/a3/Westminster%2C_2023.jpg",
            prompt="Where was this picture taken?",
            answer="London",
        ),
        OtterDoc(
            url="https://upload.wikimedia.org/wikipedia/commons/d/d4/Eiffel_Tower_20051010.jpg",
            prompt="Where was this picture taken?",
            answer="",  ## leave this blank and Otter will answer
        ),
   ]
)
```

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/Colosseo_Romano_Rome_04_2016_6289.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/Colosseo_Romano_Rome_04_2016_6289.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/Colosseo_Romano_Rome_04_2016_6289.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2023/07/Colosseo_Romano_Rome_04_2016_6289.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2023/07/Colosseo_Romano_Rome_04_2016_6289.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1333" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/Westminster-_2023.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/Westminster-_2023.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/Westminster-_2023.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2023/07/Westminster-_2023.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2023/07/Westminster-_2023.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1333" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/Eiffel_Tower_20051010.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/Eiffel_Tower_20051010.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/Eiffel_Tower_20051010.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2023/07/Eiffel_Tower_20051010.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2023/07/Eiffel_Tower_20051010.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1502" />
</div>
</div>
</div>
<figcaption>From left to right: The Colosseum in Rome (<a href="https://commons.wikimedia.org/wiki/File:Colosseo_Romano_Rome_04_2016_6289.jpg">source</a>), The UK Parliament and Big Ben (<a href="https://commons.wikimedia.org/wiki/File:Westminster,_2023.jpg">source</a>), and Paris’s Eiffel Tower (<a href="https://commons.wikimedia.org/wiki/File:Eiffel_Tower_20051010.jpg">source</a>)</figcaption>
</figure>

<div class="kg-card kg-callout-card kg-callout-card-yellow">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

You can provide more than just two examples to the Otter model. Answer inference will be based only on the last image and prompt.

</div>

</div>

The Otter model has been trained with in-context instruction-response pairs, so it requires a specific text template to correctly process its input.

``` python
prompt = f"<image>User: {first_instruction} "
       + f"GPT:<answer> {first_response}<endofchunk>"
       + f"<image>User: {second_instruction} GPT:<answer>"
```

The `User` and `GPT` role labels are essential and must be used in the way shown above.

Let’s also write a helper function to convert a `DocList` containing `PromptDoc` instances into a prompt:

``` python
def format_prompt(docs: DocList) -> str:
    conversation = ""
    for doc in docs:
        conversation += f"<image>User: {doc.prompt} GPT:<answer> {doc.answer}"
    if len(doc.answer) != 0:
        conversation += "<|endofchunk|>"
    return conversation
```

We will also need a list of images ordered to match the text prompts. For this, we're going to use the `load_pil()` function from DocArray:

``` python
images = [doc.url.load_pil() for doc in docs]
```

### Building the inference engine

Next, we will need to import Otter. It contains functions that automatically download the Otter model:

``` python
from otter.modeling_otter import OtterForConditionalGeneration
import transformers

model = OtterForConditionalGeneration.from_pretrained(
    "luodian/otter-9b-hf", device_map="auto"
)
tokenizer = model.text_tokenizer
image_processor = transformers.CLIPImageProcessor()
```

Now that we're all set, we can preprocess the input text and image data into Otter’s input vectors:

``` python
vision_x = image_processor.preprocess(images, return_tensors="pt")["pixel_values"]
    .unsqueeze(1)
    .unsqueeze(0)

model.text_tokenizer.padding_side = "left"

lang_x = model.text_tokenizer([format_prompt(docs)], return_tensors="pt")
```

Finally, we can query the Otter model with the preprocessed input:

``` python
generated_text = model.generate(
    vision_x=vision_x.to(model.device),
    lang_x=lang_x["input_ids"].to(model.device),
    attention_mask=lang_x["attention_mask"].to(model.device),
    max_new_tokens=256,
    num_beams=3,
    no_repeat_ngram_size=3,
)

print(f"Result: {model.text_tokenizer.decode(generated_text[0])}")
```

For the example given, this will produce:

``` text
Result: This picture was taken in Paris.
```

This is correct, recalling that this is the image Otter is answering questions about:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/Eiffel_Tower_small.jpg" class="kg-image" loading="lazy" width="400" height="300" />
</figure>

## Beyond in-context prompting

DocArray and Otter are useful for more than just multi-modal in-context learning. It can support any multimedia prompt. For example, consider this prompt:

``` python
prompt = "<image>User: tell me what's the relation between " 
       + "the first image and this image <image> GPT:<answer>"
```

We could readily construct a DocArray extension for these kinds of queries.

For example, using the two images below:

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/Photo-from-the-CoCo-Dataset--1-.jpeg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/Photo-from-the-CoCo-Dataset--1-.jpeg 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/Photo-from-the-CoCo-Dataset--1-.jpeg 1000w, https://cms.jina.ai/content/images/size/w1600/2023/07/Photo-from-the-CoCo-Dataset--1-.jpeg 1600w, https://cms.jina.ai/content/images/2023/07/Photo-from-the-CoCo-Dataset--1-.jpeg 2000w" sizes="(min-width: 720px) 720px" width="2000" height="1500" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/image--1-.jpeg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/image--1-.jpeg 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/image--1-.jpeg 1000w, https://cms.jina.ai/content/images/size/w1600/2023/07/image--1-.jpeg 1600w, https://cms.jina.ai/content/images/2023/07/image--1-.jpeg 2000w" sizes="(min-width: 720px) 720px" width="2000" height="3000" />
</div>
</div>
</div>
<figcaption>Left to right: <a href="http://images.cocodataset.org/val2017/000000039769.jpg" rel="noopener noreferrer">Photo</a> from the <a href="https://cocodataset.org/" rel="noopener noreferrer">CoCo Dataset</a>, <a href="https://unsplash.com/photos/eGD69I3ODC4" rel="noopener noreferrer">Photo</a> from <a href="https://unsplash.com/" rel="noopener noreferrer">Unsplash</a>.</figcaption>
</figure>

When we did it, we got results like this:

``` text
The first image shows two cats sleeping on a couch, while the second
image shows a forest and the sunlight shining through them. The
relation between these two images is that the cats are resting in a
cozy indoor environment, which contrasts with the natural setting
of the forest. The sunlight streaming through the trees, and the
forests adds a sense of warmth and tranquility to the scene, creating
a peaceful atmosphere.
```

This does not exhaust the possibilities for constructing multi-modal queries with DocArray and Otter.

## Conclusion

So, we've had a look at the Otter model and the powerful DocArray library and how they go together like macaroni and cheese. Joining Otter with DocArray brings multi-modal AI to life, enabling it to interpret and respond to mixed data types like images and text in a way that feels too natural to resist.

And hey, we didn't just talk about it, we showed you just how easy it is to build a multi-modal prompt.

## Explore the possibilities

Check out [DocArray’s documentation](https://docs.docarray.org/?ref=jina-ai-gmbh.ghost.io), [GitHub repo](https://github.com/docarray/docarray?ref=jina-ai-gmbh.ghost.io), and [Discord](https://discord.gg/WaMp6PVPgR?ref=jina-ai-gmbh.ghost.io) to explore multi-modal data modeling and what it can do for your use case.

<figure class="kg-card kg-bookmark-card">
<a href="https://docarray.jina.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Welcome to DocArray!
</div>
<div class="kg-bookmark-description">
:arrow_up: DocArray v2: We are currently working on v2 of DocArray. Keep reading here if you are interested in the current (stable) version, or check out the v2 alpha branch and v2 roadmap! DocArray is a library for nested, unstructured, multimodal data in transit, including text, image, audio, v…
</div>
<div class="kg-bookmark-metadata">
<img src="https://docarray.jina.ai/_static/favicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">DocArray 0.21.0 Documentation</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://docarray.jina.ai/_static/banner.png" />
</div>
</figure>

You can also check Otter's <a href="https://github.com/Luodian/Otter" rel="noopener noreferrer">GitHub repo</a> and <a href="https://arxiv.org/abs/2305.03726" rel="noopener noreferrer">paper</a>.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/Luodian/Otter" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - Luodian/Otter: 🦦 Otter, a multi-modal model based on OpenFlamingo (open-sourced version of DeepMind’s Flamingo), trained on MIMIC-IT and showcasing improved instruction-following and in-context learning ability.
</div>
<div class="kg-bookmark-description">
🦦 Otter, a multi-modal model based on OpenFlamingo (open-sourced version of DeepMind&amp;#39;s Flamingo), trained on MIMIC-IT and showcasing improved instruction-following and in-context learning abili…
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">Luodian</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://repository-images.githubusercontent.com/622202906/afcab064-e15d-481a-9c31-f268fb208f60" />
</div>
</figure>
