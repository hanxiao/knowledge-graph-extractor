---
title: "Does Subspace Cosine Similarity Imply High-Dimensional Cosine Similarity?"
slug: does-subspace-cosine-similarity-imply-high-dimensional-cosine-similarity
url: https://cms.jina.ai/does-subspace-cosine-similarity-imply-high-dimensional-cosine-similarity/
published_at: 2024-01-23T12:22:57.000+01:00
updated_at: 2024-01-25T21:34:27.000+01:00
reading_time: 9
authors: "Han Xiao"
tags: "Tech Blog"
excerpt: "Does high similarity in subspace assure a high overall similarity between vectors? This post examines the theory and practical implications of subspace similarity."
---

# Does Subspace Cosine Similarity Imply High-Dimensional Cosine Similarity?

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

On Jan. 25, 2024, OpenAI released [a new embedding model](https://openai.com/blog/new-embedding-models-and-api-updates) with a new feature called *****"shortening"*****, which allows developers to trim embeddings—essentially cutting numbers from the sequence's end—without compromising the embedding's ability to represent concepts effectively. Dive into this post for a solid theoretical foundation on the viability and rationale behind this innovation.

</div>

</div>

Consider this: when measuring the cosine similarity of embedding vectors in high-dimensional spaces, how does their similarity in lower-dimensional subspaces imply the overall similarity? Is there a direct, proportional relationship, or is the reality more complex with high-dimensional data?

More concretely, **does high similarity between vectors in their first 256 dimensions assure a high similarity in their full 768 dimensions?** Conversely, if vectors significantly differ in some dimensions, does this spell a low overall similarity? These aren't mere theoretical musings; they are crucial considerations for efficient vector retrieval, database indexing, and the performance of RAG systems.

Developers often rely on heuristics, assuming that high subspace similarity equates to high overall similarity or that notable differences in one dimension significantly affect the overall similarity. The question is: are these heuristic methods built on firm theoretical ground, or are they simply assumptions of convenience?

This post delves into these questions, examining the theory and practical implications of subspace similarity in relation to overall vector similarity.

## Bounding the Cosine Similarity

Given vectors \$\mathbf{A}, \mathbf{B}\in \mathbb{R}^d\$, we decompose them as \$\mathbf{A}=\[\mathbf{A}\_1, \mathbf{A}\_2\]\$ and \$\mathbf{B}=\[\mathbf{B}\_1, \mathbf{B}\_2\]\$, where \$\mathbf{A}\_1,\mathbf{B}\_1\in\mathbb{R}^m\$ and \$\mathbf{A}\_2,\mathbf{B}\_2\in\mathbb{R}^n\$, with \$m+n=d\$.

The cosine similarity in the subspace \$\mathbb{R}^m\$ is given by \$\cos(\mathbf{A}\_1, \mathbf{B}\_1)=\frac{\mathbf{A}\_1\cdot\mathbf{B}\_1}{\\\mathbf{A}\_1\\\\\mathbf{B}\_1\\}\$; similarly, the similarity in the subspace \$\mathbb{R}^n\$ is \$\cos(\mathbf{A}\_2, \mathbf{B}\_2)=\frac{\mathbf{A}\_2\cdot\mathbf{B}\_2}{\\\mathbf{A}\_2\\\\\mathbf{B}\_2\\}\$.

In the original space \$\mathbb{R}^d\$, the cosine similarity is defined as:\$\$\begin{align\*}\cos(\mathbf{A},\mathbf{B})&=\frac{\mathbf{A}\cdot\mathbf{B}}{\\\mathbf{A}\\\\\mathbf{B}\\}\\&=\frac{\mathbf{A}\_1\cdot\mathbf{B}\_1+\mathbf{A}\_2\cdot\mathbf{B}\_2}{\sqrt{\\\mathbf{A}\_1\\^2+\\\mathbf{A}\_2\\^2}\sqrt{\\\mathbf{B}\_1\\^2+\\\mathbf{B}\_2\\^2}}\\&=\frac{\cos(\mathbf{A}\_1, \mathbf{B}\_1)\\\mathbf{A}\_1\\\\\mathbf{B}\_1\\+\cos(\mathbf{A}\_2, \mathbf{B}\_2)\\\mathbf{A}\_2\\\\\mathbf{B}\_2\\}{\sqrt{\\\mathbf{A}\_1\\^2+\\\mathbf{A}\_2\\^2}\sqrt{\\\mathbf{B}\_1\\^2+\\\mathbf{B}\_2\\^2}}\end{align\*}\$\$

Now, let \$s := \max(\cos(\mathbf{A}\_1, \mathbf{B}\_1), \cos(\mathbf{A}\_2, \mathbf{B}\_2))\$. Then, we have:\$\$\begin{align\*}\cos(\mathbf{A},\mathbf{B})&\leq\frac{s\\\mathbf{A}\_1\\\\\mathbf{B}\_1\\+s\\\mathbf{A}\_2\\\\\mathbf{B}\_2\\}{\sqrt{\\\mathbf{A}\_1\\^2+\\\mathbf{A}\_2\\^2}\sqrt{\\\mathbf{B}\_1\\^2+\\\mathbf{B}\_2\\^2}}\\&=\frac{\\\mathbf{A}\_1\\\\\mathbf{B}\_1\\+\\\mathbf{A}\_2\\\\\mathbf{B}\_2\\}{\sqrt{\\\mathbf{A}\_1\\^2+\\\mathbf{A}\_2\\^2}\sqrt{\\\mathbf{B}\_1\\^2+\\\mathbf{B}\_2\\^2}}\cdot s\\&=\cos(\underbrace{\[\\\mathbf{A}\_1\\, \\\mathbf{A}\_2\\\]}\_{\mathbb{R}^2}, \underbrace{\[\\\mathbf{B}\_1\\, \\\mathbf{B}\_2\\\]}\_{\mathbb{R}^2})\cdot s\\&\leq 1\cdot s \\&= \max(\cos(\mathbf{A}\_1, \mathbf{B}\_1), \cos(\mathbf{A}\_2, \mathbf{B}\_2))\end{align\*}\$\$

End of proof.

Note that in the final step of the proof, we leverage that the cosine similarity is always less than or equal to 1. This forms our upper bound. Similarly, we can show that the lower bound of \\\cos(\mathbf{A},\mathbf{B})\\ is given by:

\\ \cos(\mathbf{A},\mathbf{B}) \geq t \cdot \cos(\[\\\mathbf{A}\_1\\, \\\mathbf{A}\_2\\\], \[\\\mathbf{B}\_1\\, \\\mathbf{B}\_2\\\]) \\, where \$t:= \min(\cos(\mathbf{A}\_1, \mathbf{B}\_1), \cos(\mathbf{A}\_2, \mathbf{B}\_2))\$.

Note that for the lower bound, we can not hastily conclude that \\\cos(\mathbf{A},\mathbf{B}) \geq t\\. This is because of the range of the cosine function, which spans between \\\[-1, 1\]\\. Due to this range, it's impossible to establish a tighter lower bound than the trivial value of -1.

So in conclusion, we have the following loose bound: \$\$ -1\leq\cos(\mathbf{A},\mathbf{B})\leq\max(\cos(\mathbf{A}\_1, \mathbf{B}\_1), \cos(\mathbf{A}\_2, \mathbf{B}\_2)).\$\$ and a tighter bound \\\begin{align\*} \gamma \cdot t\leq&\cos(\mathbf{A}, \mathbf{B}) \leq\gamma\cdot s\\\gamma \cdot \min(\cos(\mathbf{A}\_1, \mathbf{B}\_1), \cos(\mathbf{A}\_2, \mathbf{B}\_2)) \leq &\cos(\mathbf{A}, \mathbf{B}) \leq \gamma \cdot \max(\cos(\mathbf{A}\_1, \mathbf{B}\_1), \cos(\mathbf{A}\_2, \mathbf{B}\_2))\end{align\*}\\, where \$\gamma = \cos(\[\\\mathbf{A}\_1\\, \\\mathbf{A}\_2\\\], \[\\\mathbf{B}\_1\\, \\\mathbf{B}\_2\\\]) \$.

### Connection to Johnson–Lindenstrauss Lemma

The JL lemma asserts that for any \\0 \< \epsilon \< 1\\ and any finite set of points \\ S \\ in \\ \mathbb{R}^d \\, there exists a mapping \\ f: \mathbb{R}^d \rightarrow \mathbb{R}^k \\ (with \\ k = O(\epsilon^{-2} \log \|S\|) \\) such that for all \\ \mathbf{u}, \mathbf{v} \in S \\, the Euclidean distances are approximately preserved:  
  
\\(1 - \epsilon) \\\mathbf{u} - \mathbf{v}\\^2 \leq \\f(\mathbf{u}) - f(\mathbf{v})\\^2 \leq (1 + \epsilon) \\\mathbf{u} - \mathbf{v}\\^2\\

<figure class="kg-card kg-bookmark-card">
<a href="https://en.wikipedia.org/wiki/Johnson%E2%80%93Lindenstrauss_lemma" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Johnson–Lindenstrauss lemma - Wikipedia
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://en.wikipedia.org/static/apple-touch/wikipedia.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Wikimedia Foundation, Inc.</span><span class="kg-bookmark-publisher">Contributors to Wikimedia projects</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://wikimedia.org/api/rest_v1/media/math/render/svg/7f173a9fe1686cca4e497db35b4f908926294930" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

To make \$f\$ work like a subspace selection, we can use a diagonal matrix for projection, such as a \\5 \times 3\\ matrix \\f\\, albeit not random (note, the typical formulation of the JL lemma involves linear transformations that often utilize random matrices drawn from a Gaussian distribution). For instance, if we aim to retain the 1st, 3rd, and 5th dimensions from a 5-dimensional vector space, the matrix \\f\\ could be designed as follows: \\f = \begin{bmatrix}1 & 0 & 0 \\0 & 0 & 0 \\0 & 1 & 0 \\0 & 0 & 0 \\0 & 0 & 1\end{bmatrix}\\  
However, by specifying \$f\$ to be diagonal, we limit the class of functions that can be used for the projection. The JL lemma guarantees the existence of a suitable \$f\$ within the broader class of linear transformations, but when we restrict \$f\$ to be diagonal, such a suitable \$f\$ may not exist within this restricted class for applying the JL lemma's bounds.

## Validating the Bounds

To empirically explore the theoretical bounds on cosine similarity in high-dimensional vector spaces, we can employ a Monte Carlo simulation. This method allows us to generate a large number of random vector pairs, compute their similarities in both the original space and subspaces, and then assess how well the theoretical upper and lower bounds hold in practice.

The following Python code snippet implements this concept. It randomly generates pairs of vectors in a high-dimensional space and computes their cosine similarity. Then, it divides each vector into two subspaces, calculates the cosine similarity within each subspace, and evaluates the upper and lower bounds of the full-dimensional cosine similarity based on the subspace similarities.

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode python"><code class="sourceCode python"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="im">import</span> numpy <span class="im">as</span> np</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a><span class="kw">def</span> compute_cosine_similarity(U, V):</span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>    <span class="co"># Normalize the rows to unit vectors</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>    U_norm <span class="op">=</span> U <span class="op">/</span> np.linalg.norm(U, axis<span class="op">=</span><span class="dv">1</span>, keepdims<span class="op">=</span><span class="va">True</span>)</span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>    V_norm <span class="op">=</span> V <span class="op">/</span> np.linalg.norm(V, axis<span class="op">=</span><span class="dv">1</span>, keepdims<span class="op">=</span><span class="va">True</span>)</span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>    <span class="co"># Compute pairwise cosine similarity</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>    <span class="cf">return</span> np.<span class="bu">sum</span>(U_norm <span class="op">*</span> V_norm, axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a><span class="co"># Generate random data</span></span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a>num_points <span class="op">=</span> <span class="dv">5000</span></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a>d <span class="op">=</span> <span class="dv">1024</span></span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a>A <span class="op">=</span> np.random.random([num_points, d])</span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a>B <span class="op">=</span> np.random.random([num_points, d])</span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a><span class="co"># Compute cosine similarity between A and B</span></span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a>cos_sim <span class="op">=</span> compute_cosine_similarity(A, B)</span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a><span class="co"># randomly divide A and B into subspaces</span></span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a>m <span class="op">=</span> np.random.randint(<span class="dv">1</span>, d)</span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a>A1 <span class="op">=</span> A[:, :m]</span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a>A2 <span class="op">=</span> A[:, m:]</span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a>B1 <span class="op">=</span> B[:, :m]</span>
<span id="cb1-26"><a href="#cb1-26" aria-hidden="true" tabindex="-1"></a>B2 <span class="op">=</span> B[:, m:]</span>
<span id="cb1-27"><a href="#cb1-27" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-28"><a href="#cb1-28" aria-hidden="true" tabindex="-1"></a><span class="co"># Compute cosine similarity in subspaces</span></span>
<span id="cb1-29"><a href="#cb1-29" aria-hidden="true" tabindex="-1"></a>cos_sim1 <span class="op">=</span> compute_cosine_similarity(A1, B1)</span>
<span id="cb1-30"><a href="#cb1-30" aria-hidden="true" tabindex="-1"></a>cos_sim2 <span class="op">=</span> compute_cosine_similarity(A2, B2)</span>
<span id="cb1-31"><a href="#cb1-31" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-32"><a href="#cb1-32" aria-hidden="true" tabindex="-1"></a><span class="co"># Find the element-wise maximum and minimum of cos_sim1 and cos_sim2</span></span>
<span id="cb1-33"><a href="#cb1-33" aria-hidden="true" tabindex="-1"></a>s <span class="op">=</span> np.maximum(cos_sim1, cos_sim2)</span>
<span id="cb1-34"><a href="#cb1-34" aria-hidden="true" tabindex="-1"></a>t <span class="op">=</span> np.minimum(cos_sim1, cos_sim2)</span>
<span id="cb1-35"><a href="#cb1-35" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-36"><a href="#cb1-36" aria-hidden="true" tabindex="-1"></a>norm_A1 <span class="op">=</span> np.linalg.norm(A1, axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-37"><a href="#cb1-37" aria-hidden="true" tabindex="-1"></a>norm_A2 <span class="op">=</span> np.linalg.norm(A2, axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-38"><a href="#cb1-38" aria-hidden="true" tabindex="-1"></a>norm_B1 <span class="op">=</span> np.linalg.norm(B1, axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-39"><a href="#cb1-39" aria-hidden="true" tabindex="-1"></a>norm_B2 <span class="op">=</span> np.linalg.norm(B2, axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-40"><a href="#cb1-40" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-41"><a href="#cb1-41" aria-hidden="true" tabindex="-1"></a><span class="co"># Form new vectors in R^2 from the norms</span></span>
<span id="cb1-42"><a href="#cb1-42" aria-hidden="true" tabindex="-1"></a>norm_A_vectors <span class="op">=</span> np.stack((norm_A1, norm_A2), axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-43"><a href="#cb1-43" aria-hidden="true" tabindex="-1"></a>norm_B_vectors <span class="op">=</span> np.stack((norm_B1, norm_B2), axis<span class="op">=</span><span class="dv">1</span>)</span>
<span id="cb1-44"><a href="#cb1-44" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-45"><a href="#cb1-45" aria-hidden="true" tabindex="-1"></a><span class="co"># Compute cosine similarity in R^2</span></span>
<span id="cb1-46"><a href="#cb1-46" aria-hidden="true" tabindex="-1"></a>gamma <span class="op">=</span> compute_cosine_similarity(norm_A_vectors, norm_B_vectors)</span>
<span id="cb1-47"><a href="#cb1-47" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-48"><a href="#cb1-48" aria-hidden="true" tabindex="-1"></a><span class="co"># print some info and validate the lower bound and upper bound</span></span>
<span id="cb1-49"><a href="#cb1-49" aria-hidden="true" tabindex="-1"></a><span class="bu">print</span>(<span class="st">&#39;d: </span><span class="sc">%d</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-50"><a href="#cb1-50" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;m: </span><span class="sc">%d</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-51"><a href="#cb1-51" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;n: </span><span class="sc">%d</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-52"><a href="#cb1-52" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;avg. cosine(A,B): </span><span class="sc">%f</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-53"><a href="#cb1-53" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;avg. upper bound: </span><span class="sc">%f</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-54"><a href="#cb1-54" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;avg. lower bound: </span><span class="sc">%f</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-55"><a href="#cb1-55" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;lower bound satisfied: </span><span class="sc">%s</span><span class="ch">\n</span><span class="st">&#39;</span></span>
<span id="cb1-56"><a href="#cb1-56" aria-hidden="true" tabindex="-1"></a>      <span class="st">&#39;upper bound satisfied: </span><span class="sc">%s</span><span class="st">&#39;</span> <span class="op">%</span> (</span>
<span id="cb1-57"><a href="#cb1-57" aria-hidden="true" tabindex="-1"></a>          d, m, (d <span class="op">-</span> m), np.mean(cos_sim), np.mean(s), np.mean(gamma <span class="op">*</span> t), np.<span class="bu">all</span>(s <span class="op">&gt;=</span> cos_sim),</span>
<span id="cb1-58"><a href="#cb1-58" aria-hidden="true" tabindex="-1"></a>          np.<span class="bu">all</span>(gamma <span class="op">*</span> t <span class="op">&lt;=</span> cos_sim)))</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">A Monte Carlo validator for validating cosine similarity bounds</span></p></figcaption>
</figure>

<figure class="kg-card kg-code-card">
<pre class="output"><code>d: 1024
m: 743
n: 281
avg. cosine(A,B): 0.750096
avg. upper bound: 0.759080
avg. lower bound: 0.741200
lower bound satisfied: True
upper bound satisfied: True</code></pre>
<figcaption><p><span style="white-space: pre-wrap;">A sample output from our Monte Carlo validator. It's important to note that the </span><span><code spellcheck="false" style="white-space: pre-wrap;">lower/upper bound satisfied</code></span><span style="white-space: pre-wrap;"> condition is checked for every vector individually. Meanwhile, the </span><span><code spellcheck="false" style="white-space: pre-wrap;">avg. lower/upper bound</code></span><span style="white-space: pre-wrap;"> provides a more intuitive overview of the statistics related to these bounds but doesn't directly influence the validation process.</span></p></figcaption>
</figure>

## Understanding the Bounds

In a nutshell, when comparing two high-dimensional vectors, the overall similarity lies between the best and worst similarities of their subspaces, adjusted for how large or important those subspaces are in the overall scheme. This is what the bounds for cosine similarity in higher dimensions intuitively represent: the balance between the most and least similar parts, weighted by their relative sizes or importance.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/01/Explore-image-storytelling-beyond-pixels--35-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/01/Explore-image-storytelling-beyond-pixels--35-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/01/Explore-image-storytelling-beyond-pixels--35-.png 1000w, https://cms.jina.ai/content/images/2024/01/Explore-image-storytelling-beyond-pixels--35-.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="627" alt="Illustrative comparison of two stylus pen caps and bodies with labeled sections on a black background" />
<figcaption><span style="white-space: pre-wrap;">Each pen has two main components: the body and the cap.</span></figcaption>
</figure>

Imagine you're trying to compare two multi-part objects (let's say, two fancy pens) based on their overall similarity. Each pen has two main components: the body and the cap. The similarity of the whole pen (both body and cap) is what we're trying to determine:

### Upper Bound (\$\gamma \cdot s\$)

Think of \$s\$ as the best match between corresponding parts of the pens. If the caps are very similar but the bodies aren't, \$s\$ is the similarity of the caps.

Now, \$\gamma\$ is like a scaling factor based on the size (or importance) of each part. If one pen has a very long body and a short cap, while the other has a short body and a long cap, \$\gamma\$ adjusts the overall similarity to account for these differences in proportions.

The upper bound tells us that no matter how similar some parts are, the overall similarity can't exceed this "best part similarity" scaled by the proportion factor.

### Lower Bound (\$\gamma \cdot t\$)

Here, \$t\$ is the similarity of the least matching parts. If the bodies of the pens are quite different but the caps are similar, \$t\$ reflects the body's similarity.

Again, \$\gamma\$ scales this based on the proportion of each part.

The lower bound means that the overall similarity can't be worse than this "worst part similarity" after accounting for the proportion of each part.

## Implications of the Bounds

For software engineers working with embeddings, vector search, retrieval, or databases, understanding these bounds has practical implications, particularly when dealing with high-dimensional data. Vector search often involves finding the closest (most similar) vectors in a database to a given query vector, typically using cosine similarity as a measure of closeness. The bounds we discussed can provide insights into the effectiveness and limitations of using subspace similarities for such tasks.

### Using Subspace Similarity for Ranking

**Safety and Accuracy**: Using subspace similarity for ranking and retrieving top-k results can be effective, but with caution. The upper bound indicates that the overall similarity can't exceed the maximum similarity of the subspaces. Thus, if a pair of vectors is highly similar in a particular subspace, it's a strong candidate for being similar in the high-dimensional space.

**Potential Pitfalls**: However, the lower bound suggests that two vectors with low similarity in one subspace could still be quite similar overall. Therefore, relying solely on subspace similarity might miss some relevant results.

### Misconceptions and Cautions

**Overestimating Subspace Importance**: A common misconception is overestimating the importance of a particular subspace. While high similarity in one subspace is a good indicator, it doesn't guarantee high overall similarity due to the influence of other subspaces.

**Ignoring Negative Similarities**: In cases where the cosine similarity in a subspace is negative, it indicates an opposing relationship in that dimension. Engineers should be wary of how these negative similarities impact the overall similarity.
