---
title: "Don’t Build the Thing, Build the Thing that Builds the Thing!"
slug: dont-build-the-thing-build-the-thing-that-builds-the-thing
url: https://cms.jina.ai/dont-build-the-thing-build-the-thing-that-builds-the-thing/
published_at: 2023-06-28T14:25:21.000+02:00
updated_at: 2024-01-24T18:21:05.000+01:00
reading_time: 8
authors: "Florian Hönicke, Scott Martens"
tags: "Tech Blog"
excerpt: "Dev-GPT is a tool that uses LLMs to build custom microservices, replacing the traditional software development process with AI. Just describe a service in natural language and a virtual development team will generate, debug, and deploy it for you."
---

# Don’t Build the Thing, Build the Thing that Builds the Thing!

## Once upon a time, in the future

*An Introduction to Computer Programming class at Metaverse University. The holographic professor stands before the class in the formal uniform of IT engineers: A ratty AC/DC t-shirt and faded blue jeans, her hair frazzled and tangled in uncombed knots in the style customary among STEM professionals.*

*She begins her lecture.*

“In olden times, a programmer’s day consisted of reading JIRA tickets and then going to [Stack Overflow](https://stackoverflow.com/) to find code snippets that would do the job specified. This was considered highly skilled work, requiring considerable background knowledge and experience.”

“But in 2023, things changed. Primitive conversational AI began to seep into the job.”

“At first, it wasn’t much more than an error-prone personification of Stack Overflow and dozens of similar programmer forums. A programmer might routinely ask it: *I encountered the following error.”*

“Then they would control-c/control-v some error message and ask: *How do I solve it?”*

“The fundamental laziness at the heart of all skilled programming could never abide having to actually press two buttons at the same time and then mouse over to another application, moving data from one window to another, much less tolerate having to do all that typing. So before long, companies started building solutions like [GitHub Copilot](https://github.com/features/copilot) to bind programmers’ development environments directly to the AI.”

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/06/holo.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/holo.png 600w, https://cms.jina.ai/content/images/2023/06/holo.png 1000w" sizes="(min-width: 720px) 720px" width="1000" height="1000" />
</figure>

“This was fine for a while, but before long the programmer’s instinct for recursive self-reflection changed the paradigm: They no longer thought of these developments as tools for solving specific problems but as automated factories that generate solutions for whole classes of problems.”

“The focus of software development shifted from *building the thing we need*, to *building the thing that builds the thing we need*. The introduction of large language models moved software engineering to a higher level of abstraction.”

“The whole history of programming is a history of rising to higher levels of abstraction, letting software handle more and more of the details. As far back as the 1940s, assembly language abstracted from hand-coded 0’s and 1’s. Early programming languages abstracted from assembly language. Progressively higher-level languages took greater charge of the details that humans previously dealt with directly.”

“But AI did more than just move the programmer one level further up on the ladder of abstraction. It changed our entire understanding of the process of software development.”

## **What is Dev-GPT?**

[Jina AI’s Dev-GPT](https://github.com/jina-ai/dev-gpt) is a tool that uses [OpenAI’s GPT-3.5-turbo or GPT-4](https://platform.openai.com/docs/models) to build custom microservices, replacing the traditional software development process with AI automation. You can simply describe a service in natural language and a virtual development team will generate, debug, and deploy it for you.

To do this, Dev-GPT instantiates three AI agents:

- **Product Manager**: The Product Manager interacts with you to clarify the requirements and make sure even the corner cases are well-defined.
- **Developer**: The refined requirements are then handed over to the Developer agent, which writes code to implement the microservice, writes test cases, and debugs the code until the tests pass.
- **DevOps**: Finally, the DevOps agent deploys the microservice and monitors it.

Let’s look at a specific example. Run `dev-gpt generate` at the command prompt:

``` Text
% dev-gpt generate   
👩‍💼👋 Hi, I'm Susana, a PM at Jina AI. Gathering the requirements
for our engineers.
👩‍💼❓ What should your microservice do?
you:
```

Susana, your AI project manager asks what you want to build.

So tell her in plain English:

``` Text
you: Translate English to French
```

And she answers:

``` Text
I suggest that we implement the following microservice:

This microservice receives an input text in English and translates it to 
French using gpt_3_5_turbo. The input parameters include the "input_text" 
which is a string containing the English text to be translated. The output of 
the microservice is the "translated_text", a string containing the translated 
text in French.
Do you agree? [y/n]
```

This is your chance to clarify the specs with your project manager. When you are done:

``` Text
👩‍💼 👍 Great, I will handover the following requirements to our engineers:

Microservice Description:

This microservice receives an input text in English and translates it to 
French using gpt_3_5_turbo. The input parameters include the "input_text" 
which is a string containing the English text to be translated. The output of 
the microservice is the "translated_text", a string containing the translated 
text in French.
```

Susana then passes this spec to the developers:

    Great! I will hand this over to the developers!

The developers will:

1.  Generate microservice Python code.
2.  Separately, generate test code from the spec.
3.  Test the generated code using the test code, and debug if needed.

If you add the `--verbose` flag to the command, you will see detailed log information about this process.

Finally, you are given a choice of DevOps:

    You can now run or deploy your microservice:
    dev-gpt run --path <project path>/microservice
    dev-gpt deploy --path <project path>/microservice

The first will run it locally (in a Docker if possible) and the second will deploy to [Jina AI Cloud](https://cloud.jina.ai/), which requires [an account and login](https://docs.jina.ai/jina-ai-cloud/login/).

If you deploy to Jina AI Cloud, your virtual DevOps engineer will eventually respond with something like:

``` Text
% dev-gpt deploy --path ./microservice
Deploy a jina flow
INFO     Successfully submitted flow with ID gptdeploy-c2ba13c314             
INFO     Check the Flow deployment logs: https://cloud.jina.ai/ !

╭───────────────────────── 🎉 Flow is available!────────────────────────╮
│                                                                       │
│   ID          gptdeploy-c2ba13c314                                    │
│   Gateway     https://gptdeploy-c2ba13c314.wolf.jina.ai               │
│   Dashboard   https://cloud.jina.ai/                                  │
│                                                                       │
╰────────────────────────────────────────────────────────────────────────╯

Your Microservice is deployed at https://gptdeploy-c2ba13c314.wolf.jina.ai 
and is available at https://gptdeploy-c2ba13c314.wolf.jina.ai/playground
We open now the playground in your browser.

waiting for app to be ready...
```

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

⚠️

</div>

<div class="kg-callout-text">

These are example values and URIs. Pay attention to Dev-GPT’s screen output because your own values will be different.

</div>

</div>

You can then use this new microservice via a web interface:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/06/Screenshot-2023-06-26-at-14.41.05.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/Screenshot-2023-06-26-at-14.41.05.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/Screenshot-2023-06-26-at-14.41.05.png 1000w, https://cms.jina.ai/content/images/2023/06/Screenshot-2023-06-26-at-14.41.05.png 1514w" sizes="(min-width: 720px) 720px" width="1514" height="1228" />
</figure>

Or interact directly with its REST endpoint:

``` bash
% curl -X "POST" "<https://gptdeploy-c2ba13c314.wolf.jina.ai/post>" 
-H "accept: application/json" -H "Content-Type: application/json" 
-d '{"data": [{"text": "{\\"english_text\\": \\"This is not a pipe.\\"}"}]}'
```

Which returns:

``` json
{
  "header": { ... },
  "parameters": {},
  "routes": [ ... ],
  "data": [
    {
      "id": "5a51dfb440e83c532a1cc8f9df4518b7",
          ... ,
      "text": "{\\"french_text\\": \\"Ce n'est pas une pipe.\\"}",
       ... 
    }
  ]
}
```

Try it out yourself at <https://gptdeploy-c2ba13c314.wolf.jina.ai/playground>.

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

⚠️

</div>

<div class="kg-callout-text">

This service is available as of 28 June 2023. It won't stay online for very long, so if you are reading this long after publication, the URL may not work.

</div>

</div>

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/06/Untitled-4.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/Untitled-4.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/Untitled-4.png 1000w, https://cms.jina.ai/content/images/2023/06/Untitled-4.png 1024w" sizes="(min-width: 720px) 720px" width="1024" height="1024" />
</figure>

## Why build **the thing that builds the thing?**

Why does this represent the future of software development?

The way Dev-GPT uses AI models in programming signals a change of paradigm for software developers. It is a major break from traditional, labor-intensive coding processes. Instead, Dev-GPT deploys the power of the latest large language models to ensure that the microservices generated are robust and efficient.

An AI-driven approach has a lot of benefits over traditional software development:

### **Cost**

With Dev-GPT, the development cost for a microservice can be as low as 4 to 20 cents, depending on the AI model, the number of calls to it, and the cost per call. This makes possible the development of large numbers of diverse microservices for a fraction of the cost of hiring a team to develop even one.

### Speed

Building the "thing that builds the thing" also saves time. Rather than spending hours to weeks writing, testing, and debugging code, Dev-GPT generates microservices in minutes. Companies can bring new services online quickly in response to new needs and market changes.

### **Simplicity**

Dev-GPT simplifies development by taking care of everything from conception to deployment. No more tickets and scrums!

### **Promoting creativity**

Dev-GPT frees engineering staff and technical managers to focus on more complex, strategic questions that demand creativity. Removing the grunt work from the development process moves the focus from *getting things done* to *what can and should be done?*  It creates greater space for imagination and innovation.

## **Examples**

It is up to you to decide what you want to build. You can let your creativity run free. Here are some examples to inspire you and give you a feeling of what is possible:

### **Rainbow Tweet 🌈**

Do you know someone who gets irrationally angry about pineapple on pizza?

Are you sick of vitriolic Internet debates over minutiae?

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/06/Someone-is-wrong-on-internet.png" class="kg-image" loading="lazy" width="500" height="550" />
<figcaption>“Duty Calls” - <a href="https://xkcd.com/386/" rel="noopener noreferrer">https://xkcd.com/386/</a></figcaption>
</figure>

Do you just not care what angry little pearl of wisdom has made someone the main character on Twitter this week?

That’s why I used Dev-GPT to build [Rainbow Tweet](https://chrome.google.com/webstore/detail/rainbow-tweet/ckjindkmeaoifikfdcjlffmaajjfbddh). It's a Chrome extension that turns negative speech into fluffy rainbow speech, showing how easy it is to bring creative applications to life using [Dev-GPT](https://github.com/jina-ai/dev-gpt).

Here is the prompt I used to create the backend for the plugin:

``` Text
Input is a tweet that contains passive-aggressive language. The output is the 
positive version of that tweet.
```

And here is the result:

<figure class="kg-card kg-video-card">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration"></span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+" />
</div>
</div>
</div>
</figure>

### Chemical Structure Diagram

``` bash
dev-gpt generate \\
--description "Convert a chemical formula into a 2D chemical structure diagram. Example inputs: C=C, CN=C=O, CCC(=O)O" \\
--model gpt-4
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/06/Untitled--2-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/Untitled--2-.png 600w, https://cms.jina.ai/content/images/2023/06/Untitled--2-.png 654w" width="654" height="826" />
</figure>

### Word Cloud Generator

``` bash
dev-gpt generate \\
--description "Generate a word cloud from a given text" \\
--model gpt-4
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/06/Untitled--3-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/Untitled--3-.png 600w, https://cms.jina.ai/content/images/2023/06/Untitled--3-.png 732w" sizes="(min-width: 720px) 720px" width="732" height="951" alt="Untitled" />
</figure>

------------------------------------------------------------------------

### Audio to Mel Spectrogram

Mel spectrograms are frequency spectrograms that use the [mel scale](https://en.wikipedia.org/wiki/Mel_scale).

    dev-gpt generate \\
    --description "Create mel spectrogram from audio file. Example: <https://cdn.pixabay.com/download/audio/2023/02/28/audio_550d815fa5.mp3>" \\
    --model gpt-4

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/06/Untitled--4-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/Untitled--4-.png 600w, https://cms.jina.ai/content/images/2023/06/Untitled--4-.png 732w" sizes="(min-width: 720px) 720px" width="732" height="663" alt="Untitled" />
</figure>

## Back to the Future

*The professor wraps up her Introduction to Computer Programming class at Metaverse University. Much of the class is visibly paying her no attention.*

“In the aftermath of Dev-GPT and its descendants, programming became increasingly a question of nudging and cajoling large language models to correctly understand the desired outcome. This why today most of you, the programmers of tomorrow, have come to this field with previous experience as physical trainers, coaches for sports teams, theatre directors, and elementary school teachers. Your capacity to get stubborn people to do things transfers to getting AI models to do them.”

*She looks over the class, knowing only half of them were listening at best, and then dismisses them with a gesture before her hologram flickers away, momentarily replaced by a stylized image of birds carrying a whale before disappearing entirely.*

## Get started with Dev-GPT

To get started with Dev-GPT, just install the package:

``` bash
pip install dev-gpt
```

Then start generating:

``` bash
dev-gpt generate --description "<description of the microservice>"
```

And get in touch with the Dev-GPT community on [Discord](https://discord.gg/nfQyTbUsh7).

<div class="kg-card kg-button-card kg-align-center">

<a href="https://discord.com/channels/1106542220112302130/1106544097637957702" class="kg-btn kg-btn-accent">Dev-GPT on the Jina AI Discord</a>

</div>
