---
title: "Elevate Your Code Search with New Jina Code Embeddings"
slug: elevate-your-code-search-with-new-jina-code-embeddings
url: https://cms.jina.ai/elevate-your-code-search-with-new-jina-code-embeddings/
published_at: 2024-02-05T18:46:33.000+01:00
updated_at: 2024-02-06T10:30:07.000+01:00
reading_time: 4
authors: "Jina AI"
tags: "Press"
excerpt: "New 𝗷𝗶𝗻𝗮-𝗲𝗺𝗯𝗲𝗱𝗱𝗶𝗻𝗴𝘀-𝘃𝟮-𝗯𝗮𝘀𝗲-𝗰𝗼𝗱𝗲 is optimized for code & docstring search. This powerful model supports searches between English and 30 widely-used programming languages, all with 8192 context length and SOTA performance."
---

# Elevate Your Code Search with New Jina Code Embeddings

Accurately searching through code and documentation is more critical than ever. We're thrilled to unveil our latest embeddings in the world of coding: **`jina-embeddings-v2-base-code`**. This new open-source programming language embedding model is designed to improve how developers interact with code and documentation. Supporting English and 30 popular programming languages, it stands out as the only open-source model of its kind that accommodates up to 8,192 input tokens. The `jina-embeddings-v2-base-code` is now available on [HuggingFace](https://huggingface.co/jinaai/jina-embeddings-v2-base-code) under an Apache 2.0 license and can be freely accessed via our [Embedding API](https://jina.ai/embeddings).

<figure class="kg-card kg-video-card kg-width-regular kg-card-hascaption" data-kg-thumbnail="https://cms.jina.ai/content/media/2024/02/ea1f0faf379bde31c7e6b56846326a11_thumb.jpg" data-kg-custom-thumbnail="">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjMuMTQgMTAuNjA4IDIuMjUzLjE2NEExLjU1OSAxLjU1OSAwIDAgMCAwIDEuNTU3djIwLjg4N2ExLjU1OCAxLjU1OCAwIDAgMCAyLjI1MyAxLjM5MkwyMy4xNCAxMy4zOTNhMS41NTcgMS41NTcgMCAwIDAgMC0yLjc4NVoiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration">0:07</span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz4=" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">Visit </span><a href="https://jina.ai/embeddings"><span style="white-space: pre-wrap;">Embedding API</span></a><span style="white-space: pre-wrap;"> and select </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v2-base-code</code></span><span style="white-space: pre-wrap;"> from the dropdown list. Enjoy 1M tokens for free.</span></p></figcaption>
</figure>

## Why Develop an Embedding Model for Code?

Developers often find themselves navigating through vast codebases, not in search of errors, but to locate specific functionalities or understand how certain processes are implemented. This task can be time-consuming and, at times, akin to finding a needle in a haystack. Integrated Development Environments (IDEs) have significantly improved this process by providing tools and features that automate the search for information. However, the potential for further enhancement exists, and this is where our embedding model comes into play.

### Use Cases of `jina-embeddings-v2-base-code`

By integrating AI-powered search capabilities, we're not just augmenting existing functionalities within IDEs; we're transforming how developers engage with codebases. This technology goes beyond simple text search, offering semantic understanding that can interpret the intent behind a query, thereby significantly reducing the time and effort required for code reviews, unit testing, and overall quality management.

#### **Enhanced Code Navigation**

- **Query Format**: Natural language description of the functionality or code snippet you're searching for.
- **Retrieved Result Format**: Relevant code files or snippets where the described functionality is implemented, along with annotations or highlights that point to the specific parts of the code.

#### **Streamlined Code Review**

- **Query Format**: Description of the programming concepts or patterns you want to review across the codebase.
- **Retrieved Result Format**: A list of code snippets or pull requests that match the described concepts, patterns, or best practices, enabling reviewers to focus on critical areas for improvement.

#### **Automated Documentation Assistance**

- **Query Format**: Code snippet for which you need documentation or an explanation.
- **Retrieved Result Format**: Suggested docstrings or documentation entries that explain the code's functionality, parameters, and return types, making it easier to maintain up-to-date and comprehensive documentation.

By addressing these specific use cases, `jina-embeddings-v2-base-code` not only enhances the development experience but also promotes a more collaborative and efficient coding environment.

## Benchmark the Performance

In a field where precision and accuracy are paramount, `jina-embeddings-v2-base-code` has outshined its competitors, leading the pack in nine out of fifteen crucial [CodeNetSearch](https://github.com/github/CodeSearchNet) benchmarks. What's more, our model holds highly competitive scores in the remaining benchmarks. When compared to its nearest competitors, including those from tech giants like Microsoft and Salesforce, `jina-embeddings-v2-base-code` not only ranks higher but also showcases its superior design and capabilities.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/02/image-8.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/02/image-8.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/02/image-8.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/02/image-8.png 1600w, https://cms.jina.ai/content/images/2024/02/image-8.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="793" alt="Table of NLP model results comparing performance metrics across multiple programming languages." />
<figcaption><span style="white-space: pre-wrap;">Our model's excellence is not just in isolated instances; across the board, all Jina Embedding models have achieved top ranks on relevant benchmarks, distinguishing themselves among open-source models for code retrieval.</span></figcaption>
</figure>

## Model Highlights

- **State-of-the-Art Performance**: Our commitment to excellence is reflected in the performance of Jina Embedding models, which consistently top benchmark lists against other open-source offerings and even outperform models from Microsoft and Salesforce.
- **Compact Yet Powerful**: In the world of AI, efficiency is key. With 161 million parameters (307MB without quantization), `jina-embeddings-v2-base-code` is designed for efficiency, offering high-speed performance and cost savings without compromising on capability.
- **Extended Context Capability**: The ability to process up to 8192 tokens allows for the handling of large functions and numerous object files, providing a depth of understanding and context that surpasses the limitations of models supporting only a few hundred tokens.
- **Multi-Language Support**: Tailored for versatility, our model's training encompasses 30 programming languages and frameworks, emphasizing six of the most popular ones: Python, JavaScript, Java, PHP, Go, and Ruby. This extensive coverage ensures that `jina-embeddings-v2-base-code` meets the diverse needs of the programming community.
- **RAG Integration for Seamless Code Generation**: The model's compatibility with RAG and integration with a code generation model facilitate not just code generation from general knowledge but also the ability to read relevant APIs and documentation, enabling automatic code integration that is both efficient and accurate.

## Seamless API Integration

`jina-embeddings-v2-base-code` is designed for easy integration, supporting major vector databases like MongoDB, Qdrant, and Weaviate, and frameworks such as Haystack and LlamaIndex. This ensures that developers can effortlessly incorporate our model into their existing systems, leveraging its capabilities to enhance their code retrieval and documentation processes.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/02/image-7.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/02/image-7.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/02/image-7.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/02/image-7.png 1600w, https://cms.jina.ai/content/images/2024/02/image-7.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="725" alt="Black background with colorful logos including MongoDB, Pinecone, and Chroma for various tech projects." />
<figcaption><span style="white-space: pre-wrap;">Frameworks that support our embedding API</span></figcaption>
</figure>

We value your feedback on `jina-embeddings-v2-base-code`. Join our community channel to contribute feedback and stay informed about our advancements. Together, we're shaping a more robust and inclusive AI future.
