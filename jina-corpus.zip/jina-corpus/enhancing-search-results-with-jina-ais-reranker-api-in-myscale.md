---
title: "Improving Search Quality with Reranker API in MyScale"
slug: enhancing-search-results-with-jina-ais-reranker-api-in-myscale
url: https://cms.jina.ai/enhancing-search-results-with-jina-ais-reranker-api-in-myscale/
published_at: 2024-04-16T16:19:47.000+02:00
updated_at: 2024-04-23T15:02:08.000+02:00
reading_time: 2
authors: "Scott Martens"
tags: "Knowledge Base"
excerpt: "With full integration of Jina Reranker, you can now bring Jina AI's state-of-the-art technology to SQL retrieval."
---

# Improving Search Quality with Reranker API in MyScale

<a href="https://jina.ai/reranker/" rel="noreferrer">Jina Reranker API</a> is now fully integrated into <a href="https://myscale.com/" rel="noreferrer">MyScale</a>'s AI-focused SQL vector database. Jina AI's state-of-the-art reranking models dramatically improve the precision of SQL query results. With MyScale, Jina Reranker is an easy, drop-in solution to bring the power of modern AI to your SQL, combining traditional database management with the intelligence and context-awareness of semantic similarity.

Follow the link below to MyScale's website to see how to use Jina Reranker in your SQL databases.

<figure class="kg-card kg-bookmark-card">
<a href="https://myscale.com/blog/enhancing-search-results-with-jina-ai-reranker-api-in-myscale/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Enhancing Search Results with Jina AI’s Reranker API in MyScale
</div>
<div class="kg-bookmark-description">
This article describes how to use Jina AI’s Reranker in MyScale.
</div>
<div class="kg-bookmark-metadata">
<img src="https://myscale.com/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://d3lhz231q7ogjd.cloudfront.net/blog/myscale-jina-reranker.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Auch auf Deutsch verfügbar:

<figure class="kg-card kg-bookmark-card">
<a href="https://myscale.com/blog/de/enhancing-search-results-with-jina-ai-reranker-api-in-myscale/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Verbesserung der Suchergebnisse mit Jina AI’s Reranker API in MyScale
</div>
<div class="kg-bookmark-description">
Dieser Artikel beschreibt, wie man Jina AI’s Reranker in MyScale verwendet.
</div>
<div class="kg-bookmark-metadata">
<img src="https://myscale.com/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://d3lhz231q7ogjd.cloudfront.net/blog/myscale-jina-reranker.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Jina AI is committed to making state-of-the-art AI available and accessible to enterprises. Contact us via <a href="https://jina.ai/" rel="noreferrer">our website</a> or [our Discord channel](https://discord.jina.ai/?ref=jina-ai-gmbh.ghost.io) to share your feedback and stay up-to-date with our latest models.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina AI - Your Search Foundation, Supercharged.
</div>
<div class="kg-bookmark-description">
Jina AI provides best-in-class embedding API and prompt optimizer, easing the development of multimodal AI applications.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Your Search Foundation, Supercharged.</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://discord.jina.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Join the Jina AI Discord Server!
</div>
<div class="kg-bookmark-description">
Check out the Jina AI community on Discord - hang out with 4864 other members and enjoy free voice and text chat.
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.ghost.org/v5.0.0/images/link-icon.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Discord</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn.discordapp.com/splashes/1106542220112302130/80f2c2128aefeb55209a5bdb2130bb92.jpg?size=512" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
