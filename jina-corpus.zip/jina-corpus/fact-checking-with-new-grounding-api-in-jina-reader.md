---
title: "Fact-Checking with New Grounding API in Jina Reader"
slug: fact-checking-with-new-grounding-api-in-jina-reader
url: https://cms.jina.ai/fact-checking-with-new-grounding-api-in-jina-reader/
published_at: 2024-10-15T10:08:02.000+02:00
updated_at: 2025-04-14T12:22:46.000+02:00
reading_time: 9
authors: "Jina AI"
tags: "Press"
excerpt: "With the new g.jina.ai, you can easily ground statements to reduce LLM hallucinations or improve the integrity of human-written content."
---

# Fact-Checking with New Grounding API in Jina Reader

## Update: Grounding Is Now Part of DeepSearch

Grounding has moved from Jina Reader to [Jina DeepSearch](https://jina.ai/news/a-practical-guide-to-implementing-deepsearch-deepresearch). That means you can now access grounding via the [DeepSearch API](https://jina.ai/deepsearch/) (using a JSON Schema) for fact-checking as follows:

``` python
import requests

url = 'https://deepsearch.jina.ai/v1/chat/completions'
headers = {'Content-Type': 'application/json'}

statement = "fire is hot"

schema = {
    "type": "object",
    "properties": {
        "statement": {
            "type": "string",
            "description": "The statement being checked"
        },
        "validity": {
            "type": "string",
            "enum": ["true", "false", "unknown"],
            "description": "Whether the statement is valid"
        },
        "explanation": {
            "type": "string",
            "description": "A short explanation of the statement's validity"
        }
    },
    "required": ["statement", "validity", "explanation"]
}

data = {
    "model": "jina-deepsearch-v1",
    "messages": [
        {"role": "user", "content": f"Fact-check the statement: '{statement}'"}
    ],
    "response_format": {
        "type": "json_schema",
        "json_schema": schema
    }
}

response = requests.post(url, headers=headers, json=data)
print(response.json())
```

The model will return a structured response confirming whether the statement is true, false, or unknown, along with a short explanation.

------------------------------------------------------------------------

Grounding is *absolutely essential* for GenAI applications.

Without grounding, LLMs are more prone to hallucinations and generating inaccurate information, especially when their training data lacks up-to-date or specific knowledge. No matter how strong an LLM's reasoning ability is, it simply can't provide a correct answer if the information was introduced *after* its knowledge cut-off date.

Grounding is not just important for LLMs but also for human-written content to prevent misinformation. A great example is [X's Community Notes,](https://communitynotes.x.com/guide/en/about/introduction) where users collaboratively add context to potentially misleading posts. This highlights the value of grounding, which ensures factual accuracy by providing clear sources and references, much like Community Notes helps maintain information integrity.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/10/image.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/10/image.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/10/image.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/10/image.png 1600w, https://cms.jina.ai/content/images/2024/10/image.png 2048w" sizes="(min-width: 720px) 720px" width="2000" height="1113" alt="Screenshot of a mobile chat in the Sage app discussing whether whales are mammals and how they hydrate, with options to rate " />
</figure>

With <a href="https://jina.ai/reader" rel="noreferrer">Jina Reader</a>, we’ve been actively developing an easy-to-use grounding solution. For example, `r.jina.ai` converts web pages into LLM-friendly markdown, and `s.jina.ai` aggregates search results into a unified markdown format based on a given query.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/reader" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Reader API
</div>
<div class="kg-bookmark-description">
Read URLs or search the web, get better grounding for LLMs.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-9.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/banner-reader-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

**Today, we're excited to introduce a new endpoint to this suite: `g.jina.ai`.** The new API takes a given statement, grounds it using real-time web search results, and returns a factuality score and **the exact references used**. Our experiments show this API achieves a higher F1 score for fact-checking compared to models like GPT-4, o1-mini and Gemini 1.5 Flash & Pro with search grounding.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/10/Evaluation-of-grounding-solutions-on-fact-checking-100-statements--1-.svg" class="kg-image" loading="lazy" width="1218" height="371" alt="Bar graph illustrating the evaluation of various grounding solutions for fact-checking 100 statements, with software scores r" />
<figcaption><span style="white-space: pre-wrap;">We manually collected 100 statements with ground truth labels of either 'true' or 'false' and used different methods to determine if they could be fact-checked. This process essentially converts the task into a binary classification problem, where the final performance is measured by the F1 score—the higher, the better.</span></figcaption>
</figure>

What sets `g.jina.ai` apart from Gemini’s Search Grounding is that each result includes up to 30 URLs (typically providing at least 10), each accompanied by direct quotes that contribute to the conclusion. Below is an example of grounding the statement, `"The latest model released by Jina AI is jina-embeddings-v3,"` using `g.jina.ai` (as of Oct. 14, 2024). Explore the <a href="https://jina.ai/reader#apiform" rel="noreferrer">API playground</a> to discover the full features. Note that <a href="#limitations" rel="noreferrer">limitations</a> apply:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode bash"><code class="sourceCode bash"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="ex">curl</span> <span class="at">-X</span> POST https://g.jina.ai <span class="dt">\</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>     <span class="at">-H</span> <span class="st">&quot;Content-Type: application/json&quot;</span> <span class="dt">\</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>     <span class="at">-H</span> <span class="st">&quot;Authorization: Bearer </span><span class="va">$YOUR_JINA_TOKEN</span><span class="st">&quot;</span> <span class="dt">\</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>     <span class="at">-d</span> <span class="st">&#39;{</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a><span class="st">           &quot;statement&quot;:&quot;the last model released by Jina AI is jina-embeddings-v3&quot;</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="st">         }&#39;</span></span></code></pre></div>
<figcaption><p><span><code spellcheck="false" style="white-space: pre-wrap;">YOUR_JINA_TOKEN</code></span><span style="white-space: pre-wrap;"> is your Jina AI API key. You can </span><a href="https://jina.ai/?sui=apikey" rel="noreferrer"><span style="white-space: pre-wrap;">get 1M free tokens from our homepage</span></a><span style="white-space: pre-wrap;">, which allows for about three or four free trials. With the current API pricing of 0.02USD per 1M tokens, each grounding request costs approximately $0.006.</span></p></figcaption>
</figure>

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode json"><code class="sourceCode json"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="fu">{</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;code&quot;</span><span class="fu">:</span> <span class="dv">200</span><span class="fu">,</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;status&quot;</span><span class="fu">:</span> <span class="dv">20000</span><span class="fu">,</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;data&quot;</span><span class="fu">:</span> <span class="fu">{</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&quot;factuality&quot;</span><span class="fu">:</span> <span class="fl">0.95</span><span class="fu">,</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&quot;result&quot;</span><span class="fu">:</span> <span class="kw">true</span><span class="fu">,</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&quot;reason&quot;</span><span class="fu">:</span> <span class="st">&quot;The majority of the references explicitly support the statement that the last model released by Jina AI is jina-embeddings-v3. Multiple sources, such as the arXiv paper, Jina AI&#39;s news, and various model documentation pages, confirm this assertion. Although there are a few references to the jina-embeddings-v2 model, they do not provide evidence contradicting the release of a subsequent version (jina-embeddings-v3). Therefore, the statement that &#39;the last model released by Jina AI is jina-embeddings-v3&#39; is well-supported by the provided documentation.&quot;</span><span class="fu">,</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&quot;references&quot;</span><span class="fu">:</span> <span class="ot">[</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://arxiv.org/abs/2409.10173&quot;</span><span class="fu">,</span></span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;arXiv September 18, 2024 jina-embeddings-v3: Multilingual Embeddings With Task LoRA&quot;</span><span class="fu">,</span></span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://arxiv.org/abs/2409.10173&quot;</span><span class="fu">,</span></span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;We introduce jina-embeddings-v3, a novel text embedding model with 570 million parameters, achieves state-of-the-art performance on multilingual data and long-context retrieval tasks, supporting context lengths of up to 8192 tokens.&quot;</span><span class="fu">,</span></span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://azuremarketplace.microsoft.com/en-us/marketplace/apps/jinaai.jina-embeddings-v3?tab=Overview&quot;</span><span class="fu">,</span></span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;jina-embeddings-v3 is a multilingual multi-task text embedding model designed for a variety of NLP applications.&quot;</span><span class="fu">,</span></span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://docs.pinecone.io/models/jina-embeddings-v3&quot;</span><span class="fu">,</span></span>
<span id="cb1-26"><a href="#cb1-26" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;Jina Embeddings v3 is the latest iteration in the Jina AI’s text embedding model series, building upon Jina Embedding v2.&quot;</span><span class="fu">,</span></span>
<span id="cb1-27"><a href="#cb1-27" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-28"><a href="#cb1-28" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-29"><a href="#cb1-29" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-30"><a href="#cb1-30" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://haystack.deepset.ai/integrations/jina&quot;</span><span class="fu">,</span></span>
<span id="cb1-31"><a href="#cb1-31" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;Recommended Model: jina-embeddings-v3 : We recommend jina-embeddings-v3 as the latest and most performant embedding model from Jina AI.&quot;</span><span class="fu">,</span></span>
<span id="cb1-32"><a href="#cb1-32" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-33"><a href="#cb1-33" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-34"><a href="#cb1-34" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-35"><a href="#cb1-35" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://huggingface.co/jinaai/jina-embeddings-v2-base-en&quot;</span><span class="fu">,</span></span>
<span id="cb1-36"><a href="#cb1-36" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;The embedding model was trained using 512 sequence length, but extrapolates to 8k sequence length (or even longer) thanks to ALiBi.&quot;</span><span class="fu">,</span></span>
<span id="cb1-37"><a href="#cb1-37" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">false</span></span>
<span id="cb1-38"><a href="#cb1-38" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-39"><a href="#cb1-39" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-40"><a href="#cb1-40" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://huggingface.co/jinaai/jina-embeddings-v2-base-en&quot;</span><span class="fu">,</span></span>
<span id="cb1-41"><a href="#cb1-41" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;With a standard size of 137 million parameters, the model enables fast inference while delivering better performance than our small model.&quot;</span><span class="fu">,</span></span>
<span id="cb1-42"><a href="#cb1-42" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">false</span></span>
<span id="cb1-43"><a href="#cb1-43" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-44"><a href="#cb1-44" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-45"><a href="#cb1-45" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://huggingface.co/jinaai/jina-embeddings-v2-base-en&quot;</span><span class="fu">,</span></span>
<span id="cb1-46"><a href="#cb1-46" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;We offer an `encode` function to deal with this.&quot;</span><span class="fu">,</span></span>
<span id="cb1-47"><a href="#cb1-47" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">false</span></span>
<span id="cb1-48"><a href="#cb1-48" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-49"><a href="#cb1-49" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-50"><a href="#cb1-50" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://huggingface.co/jinaai/jina-embeddings-v3&quot;</span><span class="fu">,</span></span>
<span id="cb1-51"><a href="#cb1-51" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;jinaai/jina-embeddings-v3 Feature Extraction • Updated 3 days ago • 278k • 375&quot;</span><span class="fu">,</span></span>
<span id="cb1-52"><a href="#cb1-52" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-53"><a href="#cb1-53" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-54"><a href="#cb1-54" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-55"><a href="#cb1-55" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://huggingface.co/jinaai/jina-embeddings-v3&quot;</span><span class="fu">,</span></span>
<span id="cb1-56"><a href="#cb1-56" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;the latest version (3.1.0) of [SentenceTransformers] also supports jina-embeddings-v3&quot;</span><span class="fu">,</span></span>
<span id="cb1-57"><a href="#cb1-57" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-58"><a href="#cb1-58" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-59"><a href="#cb1-59" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-60"><a href="#cb1-60" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://huggingface.co/jinaai/jina-embeddings-v3&quot;</span><span class="fu">,</span></span>
<span id="cb1-61"><a href="#cb1-61" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;jina-embeddings-v3: Multilingual Embeddings With Task LoRA&quot;</span><span class="fu">,</span></span>
<span id="cb1-62"><a href="#cb1-62" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-63"><a href="#cb1-63" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-64"><a href="#cb1-64" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-65"><a href="#cb1-65" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://jina.ai/embeddings/&quot;</span><span class="fu">,</span></span>
<span id="cb1-66"><a href="#cb1-66" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;v3: Frontier Multilingual Embeddings is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.&quot;</span><span class="fu">,</span></span>
<span id="cb1-67"><a href="#cb1-67" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-68"><a href="#cb1-68" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-69"><a href="#cb1-69" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-70"><a href="#cb1-70" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model&quot;</span><span class="fu">,</span></span>
<span id="cb1-71"><a href="#cb1-71" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;Jina Embeddings v3: A Frontier Multilingual Embedding Model jina-embeddings-v3 is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.&quot;</span><span class="fu">,</span></span>
<span id="cb1-72"><a href="#cb1-72" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-73"><a href="#cb1-73" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-74"><a href="#cb1-74" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span></span>
<span id="cb1-75"><a href="#cb1-75" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;url&quot;</span><span class="fu">:</span> <span class="st">&quot;https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model/&quot;</span><span class="fu">,</span></span>
<span id="cb1-76"><a href="#cb1-76" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;keyQuote&quot;</span><span class="fu">:</span> <span class="st">&quot;As of its release on September 18, 2024, jina-embeddings-v3 is the best multilingual model ...&quot;</span><span class="fu">,</span></span>
<span id="cb1-77"><a href="#cb1-77" aria-hidden="true" tabindex="-1"></a>        <span class="dt">&quot;isSupportive&quot;</span><span class="fu">:</span> <span class="kw">true</span></span>
<span id="cb1-78"><a href="#cb1-78" aria-hidden="true" tabindex="-1"></a>      <span class="fu">}</span></span>
<span id="cb1-79"><a href="#cb1-79" aria-hidden="true" tabindex="-1"></a>    <span class="ot">]</span><span class="fu">,</span></span>
<span id="cb1-80"><a href="#cb1-80" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&quot;usage&quot;</span><span class="fu">:</span> <span class="fu">{</span></span>
<span id="cb1-81"><a href="#cb1-81" aria-hidden="true" tabindex="-1"></a>      <span class="dt">&quot;tokens&quot;</span><span class="fu">:</span> <span class="dv">112073</span></span>
<span id="cb1-82"><a href="#cb1-82" aria-hidden="true" tabindex="-1"></a>    <span class="fu">}</span></span>
<span id="cb1-83"><a href="#cb1-83" aria-hidden="true" tabindex="-1"></a>  <span class="fu">}</span></span>
<span id="cb1-84"><a href="#cb1-84" aria-hidden="true" tabindex="-1"></a><span class="fu">}</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">The response of of grounding the statement, "The latest model released by Jina AI is jina-embeddings-v3," using </span><span><code spellcheck="false" style="white-space: pre-wrap;">g.jina.ai</code></span><span style="white-space: pre-wrap;"> (as of Oct. 14, 2024).</span></p></figcaption>
</figure>

## How Does It Work?

At its core, `g.jina.ai` wraps `s.jina.ai` and `r.jina.ai` , adding multi-hop reasoning through Chain of Thought (CoT). This approach ensures that each grounded statement is thoroughly analyzed with the help of online searches and document reading.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/10/User-Render.svg" class="kg-image" loading="lazy" width="1400" height="630" alt="UI of Jina AI reader app, displaying three panels: User Input, Response, and User Render with interactive links and buttons a" />
<figcaption><span style="white-space: pre-wrap;">Grounding API is a wrapper on top of </span><span><code spellcheck="false" style="white-space: pre-wrap;">s.jina.ai</code></span><span style="white-space: pre-wrap;"> and </span><span><code spellcheck="false" style="white-space: pre-wrap;">r.jina.ai</code></span><span style="white-space: pre-wrap;">, adding CoT for planning and reasoning. </span></figcaption>
</figure>

### Step-by-Step Explanation

Let’s walk through the entire process to better understand how `g.jina.ai` handles grounding from input to final output:

1.  **Input Statement**:  
    The process begins when a user provides a statement they want to ground, such as *"The latest model released by Jina AI is jina-embeddings-v3."* Note, there is no need to add any fact-checking instruction before the statement.
2.  **Generate Search Queries**:  
    An LLM is employed to generate a list of unique search queries that are relevant to the statement. These queries aim to target different factual elements, ensuring that the search covers all key aspects of the statement comprehensively.
3.  **Call `s.jina.ai` for Each Query**:  
    For each generated query, `g.jina.ai` performs a web search using `s.jina.ai`. The search results consist of a diverse set of websites or documents related to the queries. Behind the scene, `s.jina.ai` calls `r.jina.ai` to fetch the page content.
4.  **Extract References from Search Results**:  
    From each document retrieved during the search, an LLM extracts the key references. These references include:
    - **`url`**: The web address of the source.
    - **`keyQuote`**: A direct quote or excerpt from the document.
    - **`isSupportive`**: A Boolean value indicating whether the reference supports or contradicts the original statement.
5.  **Aggregate and Trim References**:  
    All the references from the retrieved documents are combined into a single list. If the total number of references exceeds 30, the system selects 30 random references to maintain manageable output.
6.  **Evaluate the Statement**:  
    The evaluation process involves using an LLM to assess the statement based on the gathered references (up to 30). In addition to these external references, the model’s internal knowledge also plays a role in the evaluation. The final result includes:
    - **`factuality`**: A score between 0 and 1 that estimates the factual accuracy of the statement.
    - **`result`**: A Boolean value indicating whether the statement is true or false.
    - **`reason`**: A detailed explanation of why the statement is judged as correct or incorrect, referencing the supporting or contradicting sources.
7.  **Output the Result**:  
    Once the statement has been fully evaluated, the output is generated. This includes the **factuality score**, the **assertion of the statement**, a **detailed reasoning**, and a list of **references** with citations and URLs. The references are limited to the citation, URL, and whether or not they support the statement, keeping the output clear and concise.

## Benchmark

We manually collected 100 statements with ground truth labels of either `true` (62 statements) or `false` (38 statements) and used different methods to determine if they could be fact-checked. This process essentially converts the task into a binary classification problem, where the final performance is measured by the precision, recall and F1 score—the higher, the better.

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://docs.google.com/spreadsheets/d/1xE-uCTQ4G0cYRw_g781zZXHO8eRYi31HbCb-3BPlNh8/edit?gid=1283553680#gid=1283553680" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Grounding Validation Dataset
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/spreadsheets_2023q4.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Google Docs</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/AHkbwyJpf4HNZ3zF1snMGetpmkt0oOTQGGviY1-ZTOrq5dXuafT8uWLmZ806MU1A_agTpgO52Z_xZ-iDougmFm0ViL0sVSqDxe3C4fVuPcYXKoS5O90jN3Qy-w1200-h630-p" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">The full list of statements can be found here.</span></p></figcaption>
</figure>

| Model                                 | Precision | Recall   | F1 Score |
|---------------------------------------|-----------|----------|----------|
| **Jina AI Grounding API (g.jina.ai)** | 0.96      | **0.88** | **0.92** |
| Gemini-flash-1.5-002 w/ grounding     | **1.00**  | 0.73     | 0.84     |
| Gemini-pro-1.5-002 w/ grounding       | 0.98      | 0.71     | 0.82     |
| gpt-o1-mini                           | 0.87      | 0.66     | 0.75     |
| gpt-4o                                | 0.95      | 0.58     | 0.72     |
| Gemini-pro-1.5-001 w/ grounding       | 0.97      | 0.52     | 0.67     |
| Gemini-pro-1.5-001                    | 0.95      | 0.32     | 0.48     |

Note, in practice, some LLMs return a third class, *I don’t know*, in their predictions. For evaluation, these instances are excluded from the score calculation. This approach avoids penalizing uncertainty as harshly as incorrect answers. Admitting uncertainty is preferred over guessing, to discourage models from making uncertain predictions.

## Limitations

Despite the promising results, we’d like to highlight some limitations of the current version of the grounding API:

- **High Latency & Token Consumption**: A single call to `g.jina.ai` can take around **30 seconds** and use up to **300K tokens**, due to the active web search, page reading, and multi-hop reasoning by the LLM. With a free 1M token API key, this means you can only test it about three or four times. To maintain service availability for paid users, we've also implemented <a href="https://jina.ai/contact-sales#rate-limit" rel="noreferrer">a conservative rate limit for <code>g.jina.ai</code>.</a> With our current API pricing of \$0.02 per 1M tokens, each grounding request costs approximately 0.006 USD.
- **Applicability Constraints**: *Not every statement can or should be grounded.* Personal opinions or experiences, such as “I feel lazy,” are not suitable for grounding. Similarly, future events or hypothetical statements do not apply. There are many cases where grounding would be irrelevant or nonsensical. To avoid unnecessary API calls, we recommend users selectively submit only sentences or sections that genuinely require fact-checking. On the server side, we’ve implemented a comprehensive set of error codes to explain why a statement might be rejected for grounding.
- **Dependence on Web Data Quality**: The accuracy of the grounding API is only as good as the quality of the sources it retrieves. If the search results contain low-quality or biased information, the grounding process might reflect that, potentially leading to inaccurate or misleading conclusions. To prevent this issue, we allow users to manually specify the `references` parameter and restrict the URLs that the system searches against. This gives users more control over the sources used for grounding, ensuring a more focused and relevant fact-checking process.

## Conclusion

The grounding API offers end-to-end, near real-time fact-checking experience. Researchers can use it to find references that support or challenge their hypotheses, adding credibility to their work. In company meetings, it ensures strategies are built on accurate, up-to-date information by validating assumptions and data. In political discussions, it quickly verifies claims, bringing more accountability to debates.

Looking ahead, we plan to enhance the API by integrating private data sources like internal reports, databases, and PDFs for more tailored fact-checking. We also aim to expand the number of sources checked per request for deeper evaluations. Improving multi-hop question-answering will add depth to the analysis, and increasing consistency is a priority to ensure that repeated requests produce more reliable, consistent results.
