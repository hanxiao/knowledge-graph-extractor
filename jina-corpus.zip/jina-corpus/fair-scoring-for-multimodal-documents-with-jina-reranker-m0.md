---
title: "Fair Scoring for Multimodal Documents with jina-reranker-m0"
slug: fair-scoring-for-multimodal-documents-with-jina-reranker-m0
url: https://cms.jina.ai/fair-scoring-for-multimodal-documents-with-jina-reranker-m0/
published_at: 2025-05-25T08:25:10.000+02:00
updated_at: 2025-05-25T20:13:37.000+02:00
reading_time: 8
authors: "Nan Wang, Alex C-G"
tags: "Tech Blog"
excerpt: "Text similarity: 0.7. Image similarity: 0.5. Which document is more relevant? You literally cannot tell—and that's the core problem breaking multimodal search. We solve it with unified reranking."
---

# Fair Scoring for Multimodal Documents with jina-reranker-m0

Imagine you're building a sports news search system. A user searches for "tennis players celebrating championship victory" and you need to find the most relevant articles from your database. Each article contains both a text caption and an image - typical of modern sports coverage.

Your system needs to take a **text query** and return a **ranked list of the most relevant multimodal documents** from your corpus. Sounds straightforward, but there's a fundamental problem that breaks all obvious approaches.

Here's what happens when you try to rank these documents. Your embedding model say `jina-clip-v2` produces similarity scores like this:

| Article | Content Type | Description | Similarity Score |
|----|----|----|----|
| A | Text | Novak Djokovic wins Australian Open final in straight sets | 0.72 |
| A | Image | \[photo of player holding trophy and smiling\] | 0.31 |
| B | Text | Weather delays affect outdoor tournament scheduling | 0.23 |
| B | Image | \[photo of tennis players jumping and celebrating\] | 0.54 |

Which article is more relevant? Article A has a high text score but low image score. Article B has a low text score but higher image score. The fundamental challenge is that **you cannot compare 0.72 (text) with 0.54 (image)** because these similarity scores exist on completely different scales.

## When Trivial Solutions Fail

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/the-what-and-why-of-text-image-modality-gap-in-clip-models/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
The What and Why of Text-Image Modality Gap in CLIP Models
</div>
<div class="kg-bookmark-description">
You can’t just use a CLIP model to retrieve text and images and sort the results by score. Why? Because of the modality gap. What is it, and where does it come from?
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-32.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Bo Wang, Scott Martens</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/the-what-and-why-of-text-image-modality-gap-in-clip-models.webp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

**Because of the modality gap** in `jina-clip-v2` or in almost every other CLIP-like models, any obvious approach you might try doesn't work. If you just use the higher score, you run into the fact that text scores cluster around 0.2-0.8 while image scores cluster around 0.4-0.6. This means a mediocre text match (0.6) will always beat an excellent image match (0.5).

Averaging the scores doesn't help either. Computing (0.7 + 0.3)/2 = 0.5 gives you a number, but what does it actually mean? You're averaging fundamentally meaningless quantities. Similarly, any fixed weighting scheme is arbitrary - sometimes text matters more, sometimes images do, and this depends entirely on the specific query and document.

Even normalizing the scores first doesn't solve the core issue. You're still trying to combine fundamentally different similarity measures that capture different aspects of relevance.

## What Actually Happens

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2305.13631" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
EDIS: Entity-Driven Image Search over Multimodal Web Content
</div>
<div class="kg-bookmark-description">
Making image retrieval methods practical for real-world search applications requires significant progress in dataset scales, entity comprehension, and multimodal information fusion. In this work, we introduce \textbf{E}ntity-\textbf{D}riven \textbf{I}mage \textbf{S}earch (EDIS), a challenging dataset for cross-modal image search in the news domain. EDIS consists of 1 million web images from actual search engine results and curated datasets, with each image paired with a textual description. Unlike datasets that assume a small set of single-modality candidates, EDIS reflects real-world web image search scenarios by including a million multimodal image-text pairs as candidates. EDIS encourages the development of retrieval models that simultaneously address cross-modal information fusion and matching. To achieve accurate ranking results, a model must: 1) understand named entities and events from text queries, 2) ground entities onto images or text descriptions, and 3) effectively fuse textual and visual representations. Our experimental results show that EDIS challenges state-of-the-art methods with dense entities and a large-scale candidate set. The ablation study also proves that fusing textual features with visual features is critical in improving retrieval results.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-20.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Siqi Liu</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/arxiv-logo-fb-16.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

To get a better idea of what we're working with, here's an example document from the [EDIS dataset](https://arxiv.org/abs/2305.13631), showing the image (a German football match) and the caption (`One More Field Where the Content Trails Germany`).

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/image-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/image-1.png 600w, https://cms.jina.ai/content/images/2025/05/image-1.png 928w" sizes="(min-width: 720px) 720px" width="928" height="261" alt="A group of fans cheers enthusiastically, holding flags and banners, with the text &quot;One more field where the continent trails " />
<figcaption><span style="white-space: pre-wrap;">Figure 1: Example multimodal document containing both image and text content. Since we have two modalities, for any given query there are now </span><em><em>two</em></em><span style="white-space: pre-wrap;"> semantic gaps (between the query and the text, and the query and the image). To get the best results, should we search the text content of the documents, or the image content?</span></figcaption>
</figure>

Overall, `jina-clip-v2` shows much higher similarities when comparing query-to-text than query-to-image in the EDIS dataset, in part because of the way the model was trained and in part due to the dataset itself:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/image-2.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/image-2.png 600w, https://cms.jina.ai/content/images/2025/05/image-2.png 964w" sizes="(min-width: 720px) 720px" width="964" height="679" alt="Chart showing the distribution of similarity scores between a query and corpus in jina-clip-v2. Three color-coded query types" />
<figcaption><span style="white-space: pre-wrap;">Figure 2: Similarity scores between query-to-image (in red) and query-to-text (in blue) using </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;">.</span></figcaption>
</figure>

Therefore, it seems logical to retrieve a document based on its text rather than its image. And, as we can see in the graphic below, we get much better results comparing the text query `... for undocumented immigrants helping to establish legal status in the United States` to the text contents of the corpus. In fact, searching by image fails to retrieve the ground truth document (highlighted in yellow) at all:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/image-3.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/image-3.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/05/image-3.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/05/image-3.png 1600w, https://cms.jina.ai/content/images/2025/05/image-3.png 1767w" sizes="(min-width: 720px) 720px" width="1767" height="2454" alt="A collage of photos showing immigrant rights demonstrations, with people holding signs and long lines of people waiting to ac" />
<figcaption><span style="white-space: pre-wrap;">Figure 3: Example where ground-truth document (highlighted with yellow border) can be retrieved only via </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;">'s query-to-text retrieval when using </span><span><code spellcheck="false" style="white-space: pre-wrap;">top_k</code></span><span style="white-space: pre-wrap;"> of 3.</span></figcaption>
</figure>

But don’t be fooled. Despite query-to-text showing higher similarity scores, query-to-text and query-to-image similarity scores are *not* comparable. We can see this by looking at recall@10 when we use `jina-clip-v2` to retrieve 32 documents from the EDIS dataset. Clearly, recall is higher with query-to-*image*:

|                | Recall@10 |
|----------------|-----------|
| Query-to-text  | 14.55     |
| Query-to-image | **22.38** |

We can see this below: If we use a query from the dataset, `Ear ear An elephant is decorated with Bhartiya Janta Party symbols near the BJP headquarters in New Delhi.`, we can retrieve the ground truth document only by its image content. Searching by its text content doesn’t return any matches:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/image-4.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/image-4.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/05/image-4.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/05/image-4.png 1600w, https://cms.jina.ai/content/images/2025/05/image-4.png 1753w" sizes="(min-width: 720px) 720px" width="1753" height="2454" alt="A collage of six images related to Indian culture and politics, featuring a decorated elephant with BJP symbols and a festive" />
<figcaption><span style="white-space: pre-wrap;">Figure 4: Example where ground-truth document (highlighted with yellow border) can be retrieved only via </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;">'s query-to-image retrieval when using </span><span><code spellcheck="false" style="white-space: pre-wrap;">top_k</code></span><span style="white-space: pre-wrap;"> of 3.</span></figcaption>
</figure>

So, if similarity scores imply we should retrieve documents from their text, and recall implies we should retrieve them from their images, which should we choose? Certainly, Figures 3 and 4 suggest no outright winner. Which modality *really* presents the closest match between our query and the document we’re looking for? And if we want to merge candidates from *both* query-to-text and query-to-image retrieval, how can we meaningfully select the top matches if we can’t even compare scores? Clearly just using `jina-clip-v2` won’t cut it. We need to throw another model into the mix.

## A Simple Two-Stage Pipeline

In April 2025 we released `jina-reranker-m0`, a multilingual multimodal reranker for retrieving visual documents. We can see its narrower modality gap below, where `jina-reranker-m0` shows comparable query-to-text and query-to-image similarity scores, contrasted with the much wider gap shown by `jina-clip-v2`:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/Distribution_of_similarity_between_query_and_corpus_in_jina-reranker-m0.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/Distribution_of_similarity_between_query_and_corpus_in_jina-reranker-m0.png 600w, https://cms.jina.ai/content/images/2025/05/Distribution_of_similarity_between_query_and_corpus_in_jina-reranker-m0.png 964w" sizes="(min-width: 720px) 720px" width="964" height="679" alt="Probability distribution chart of similarity scores in jina-reeanker-m0, with x-axis from -4 to 2.5 and y-axis for probabilit" />
<figcaption><span style="white-space: pre-wrap;">Figure 6: Compared to </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;">, </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-reranker-m0</code></span><span style="white-space: pre-wrap;"> shows much less difference between query-to-image (red) and query-to-text (blue) similarity scores.</span></figcaption>
</figure>

With this in mind, we can use `jina-reranker-m0` for a second pass in the retrieval chain, after initial results are retrieved from `jina-clip-v2`:

**Stage 1: Retrieve candidates from both modalities**

- Use `jina-clip-v2` to get 16 documents via text search + 16 via image search
- Accept that we can't compare scores yet

**Stage 2: Unified reranking**

- Feed each (query + full document) pair into `jina-reranker-m0`
- The reranker processes both text AND image together
- Output: Single relevance score on a unified scale

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/image-5.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/image-5.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/05/image-5.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/05/image-5.png 1600w, https://cms.jina.ai/content/images/2025/05/image-5.png 2048w" sizes="(min-width: 720px) 720px" width="2000" height="1305" alt="Dark gray process flow diagram on black background showing Query, Indexing, Initial retrieval, and Reranking of text and imag" />
<figcaption><span style="white-space: pre-wrap;">Figure 5: Indexing multimodal documents and a two-stage multimodal retrieval process with </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;"> and </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-reranker-m0</code></span><span style="white-space: pre-wrap;">.</span></figcaption>
</figure>

We expanded the experiments from Table 1, now using `jina-clip-v2` to retrieve documents from the corpus, then `jina-reranker-m0` to rerank them:

1.  Retrieve 32 documents via query-to-text, then rerank based on query-to-text score.
2.  Retrieve 32 documents via query-to-image, then rerank based on query-to-image score.
3.  Retrieve 16 documents via query-to-text and 16 via query-to-image. Rerank based on query-to-text or query-to-image score, depending on query modality.
4.  Retrieve 16 documents via query-to-text and 16 via query-to-image. Rerank based on each document’s averaged query-to-text and query-to-image scores, giving a final score of (query-to-text + query-to-image)/2.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Note that we’re measuring zero-shot performance on EDIS. We didn’t finetune either `jina-clip-v2` or `jina-reranker-m0` using the dataset.

</div>

</div>

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr>
<th>Experiment</th>
<th>Description</th>
<th>Recall@10 - with jina-clip-v2</th>
<th>Recall@10 - with jina-reranker-m0</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>32 docs: query-to-text</td>
<td>14.55</td>
<td>17.42</td>
</tr>
<tr>
<td>2</td>
<td>32 docs: query-to-image</td>
<td>22.38</td>
<td>28.94</td>
</tr>
<tr>
<td>3</td>
<td>16 docs: query-to-text<br />
16 docs: query-to-image</td>
<td>14.55</td>
<td>33.81</td>
</tr>
<tr>
<td>4</td>
<td>16 docs: query-to-text<br />
16 docs: query-to-image<br />
Combined average reranker scores</td>
<td>14.55</td>
<td><strong>36.24</strong></td>
</tr>
</tbody>
</table>

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Experiments 1, 3 and 4 all show the same result for recall@10 with `jina-clip-v2` due to query-to-text scores being higher than query-to-image scores. Therefore, the top ten results are dominated by the documents retrieved via text.

</div>

</div>

As we can see, by performing a second pass with `jina-reranker-m0`, recall goes up across the board, regardless of modality. However, **we see the largest increase when we combine both textual and image content from the retrieved documents**, hitting a recall@10 of 36.24. A visual example shows that `jina-reranker-m0` consistently ranks the ground truth document first, whether searching text or image content:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/clip-vs-reranker.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/clip-vs-reranker.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/05/clip-vs-reranker.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/05/clip-vs-reranker.png 1600w, https://cms.jina.ai/content/images/size/w2400/2025/05/clip-vs-reranker.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1146" alt="Grid of nine panels featuring varying car interiors and exteriors, showcasing diverse designs, styles, and backgrounds in a v" />
<figcaption><span style="white-space: pre-wrap;">Figure 7: Sample queries (on the left) and </span><span><code spellcheck="false" style="white-space: pre-wrap;">top_k</code></span><span style="white-space: pre-wrap;"> of 1 result for each reranking methodology (four columns on the right), showing that combining image and text similarity scores consistently ranks ground truth document first.</span></figcaption>
</figure>

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

While Figures 3 and 4 show a `top_k` of 3 for the different retrieval methods, for reasons of space Figure 7 shows only `top_k` of 1 for each query.

</div>

</div>

## Conclusions

This simple two-stage approach delivers a 62% improvement in recall because the system finally leverages what humans do naturally: considering both what we read and what we see to determine relevance. The lesson extends beyond search: when dealing with multimodal AI systems, single-pass approaches that treat modalities separately will always hit this scoring incompatibility wall. Two-stage architectures that retrieve broadly then rank intelligently are becoming essential. Try `jina-reranker-m0` via our API or on AWS, GCP and Azure.
