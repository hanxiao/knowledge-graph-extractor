---
title: "Fine-Tuning Falcon40b for Code Generation"
slug: fine-tuning-falcon40b-for-code-generation
url: https://cms.jina.ai/fine-tuning-falcon40b-for-code-generation/
published_at: 2023-07-24T13:19:48.000+02:00
updated_at: 2024-01-24T18:14:40.000+01:00
reading_time: 7
authors: "Sami Jaghouar, Alaeddine Abdessalem, Sebastian Weisshaar, Scott Martens"
tags: "Tech Blog"
excerpt: "Falcon40b is an open-source commercial-use friendly large language model. We've trained it to write code."
---

# Fine-Tuning Falcon40b for Code Generation

[Falcon40b](https://huggingface.co/tiiuae/falcon-40b) is one of the biggest open-source LLMs currently available and comes with a commercial-use-friendly Apache 2.0 license. This makes it interesting for developers looking to bring NLP products to market.

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/tiiuae/falcon-40b" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
tiiuae/falcon-40b · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/tiiuae/falcon-40b.png" />
</div>
</figure>

The [Falcon-40b-Instruct](https://huggingface.co/tiiuae/falcon-40b-instruct) model, which is the base Falcon40b model fine-tuned for instruction-taking and chat, ranks [near the top of the Hugging Face LLM benchmark](https://huggingface.co/spaces/HuggingFaceH4/open_llm_leaderboard), with only models based on Meta’s non-open-source Llama family performing better. Falcon40b’s performance is far superior to other open-source models.

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/tiiuae/falcon-40b-instruct" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
tiiuae/falcon-40b-instruct · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/tiiuae/falcon-40b-instruct.png" />
</div>
</figure>

The Falcon family of models belongs to the recent wave of open-source LLMs inspired by the Llama family. The underlying insight behind them is to train smaller models longer (for more epochs) and with more data (over a trillion tokens in this case). [The empirical literature on LLM scaling](https://arxiv.org/abs/2001.08361) suggests that model size, training compute, and training dataset size should rise in tandem, but this family of models uses far more compute and training data than would be expected for a model of this size.

### Fine-tuning with CodeAlpaca

Falcon40b is a pre-trained model but has not been trained for any specific task. Its zero-shot performance is not especially good, and it needs to be trained to function as a chatbot or to follow instructions.

When we want it to follow instructions, we train it using a collection of instruction-response pairs like the <a href="https://huggingface.co/datasets/tatsu-lab/alpaca" rel="noopener noreferrer">Alpaca dataset</a>.

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/datasets/tatsu-lab/alpaca" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
tatsu-lab/alpaca · Datasets at Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/datasets/tatsu-lab/alpaca.png" />
</div>
</figure>

For example, this instruction-response pair comes from Alpaca:

``` Text
Below is an instruction that describes a task. Write a response that 
appropriately completes the request.

### Instruction:
Create an array of length 5 which contains all even numbers between 1 
and 10.

### Response:
arr = [2, 4, 6, 8, 10]
```

The [Falcon-40b-Instruct](https://huggingface.co/tiiuae/falcon-40b-instruct) model has already been trained as a general instruction-following model, so we decided to go in a different direction. There has been a lot of recent interest in training LLMs to write code, and there are a number of open-source projects in this field, notably [Starcoder](https://github.com/bigcode-project/starcoder), [Replit3b](https://huggingface.co/replit/replit-code-v1-3b), [CodeGen](https://arxiv.org/abs/2305.02309) and [CodeGen2](https://arxiv.org/abs/2305.02309). So we decided to try to train Falcon40b to write code from natural language prompts by fine-tuning it with the [CodeAlpaca dataset](https://github.com/sahil280114/codealpaca).

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/sahil280114/codealpaca" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - sahil280114/codealpaca
</div>
<div class="kg-bookmark-description">
Contribute to sahil280114/codealpaca development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">sahil280114</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/75509f0d30f8eedc29bc635dda1a0e5f9d3946412ad91ce09296d3affd527825/sahil280114/codealpaca" />
</div>
</figure>

CodeAlpaca is a set of 20,000 instruction-input-code triplets that, like the Alpaca dataset, were generated by a closed-source language model. An example:

    Below is an instruction that describes a task, paired with an input 
    that provides further context. Write a response that appropriately 
    completes the request.

    ### Instruction:
    Generate a snippet of code to extract all the URLs from the given 
    string.

    ### Input:
    This string contains some urls such as <https://www.google.com> and 
    <https://www.facebook.com>.

    ### Response:
    import re

    string = "This string contains some urls such as <https://www.google.com> and <https://www.facebook.com>."
    urls = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\\\(\\\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', string)
    print(urls)

Training Falcon40b specifically on code construction rather than the more general task of instruction-following results in better performance on those tasks.

### Fine-tuning hyperparameters

We fine-tuned Falcon40b using [LoRA](https://doi.org/10.48550/arXiv.2106.09685) with 8-bit quantization on four NVIDIA A100 Tensor Core GPUs with 80GB of VRAM. Fine-tuning took approximately 4 hours, at a cost of approximately 25 euros on [runpod.io](http://runpod.io).

We used the following hyperparameters:

- Epochs: **2**
- Layer to add LoRA: **full attention layer (QKV)**
- LoRA rank: **8**
- Learning rate: **3.0e-4**
- Batch size: **128**

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

We noticed that increasing the number of epochs to 2 helped the model “learn” when to stop. Otherwise, we were experiencing problems where it would repeat the instruction template instead of stopping.

</div>

</div>

## Results

We selected [45 coding instructions](https://github.com/jina-ai/jerboa/blob/main/jerboa/code_eval.jsonl) that we used to assess the ability of the model to follow instructions. Our fine-tuned models are able to perform code generation from natural language instructions, answer questions about segments of code, and answer general computer programming questions.

For example:

**Generic programming questions**

``` text
Question: 

Explain the difference between an iterator and a generator 
in Python. Provide examples.
```

``` text
Response: 

An iterator is an object that can be used to iterate over a 
sequence of items, such as a list or a string. It provides a way to 
access each item in the sequence one at a time. A generator is a 
function that can be used to generate a sequence of items, such as a 
list or a string. It provides a way to generate each item in the 
sequence one at a time. The main difference between an iterator and 
a generator is that an iterator is an object that can be used to 
iterate over a sequence, while a generator is a function that can be 
used to generate a sequence.
```

**Code generation from natural language prompts**

``` text
Question: 

Write a Python function that accepts a list of words, and returns a 
dictionary where keys are the words and values are the frequencies of 
the words in the list. Use a for loop, if clause, and dictionary in 
your solution.
```

``` Python
Response: 

def word_frequency(words):
    frequencies = {}
    for word in words:
        if word in frequencies:
            frequencies[word] += 1
        else:
            frequencies[word] = 1
    return frequencies
```

**Answering questions about specific pieces of code**

``` Python
Question:

Explain the following Python script that uses FastAPI to create a basic 
'Hello World' API.

from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"Hello": "World"}
```

``` Text
Response:

This Python script uses FastAPI to create a basic 'Hello World' API. 
FastAPI is a web framework that makes it easy to create APIs in Python. 
The @app.get("/") decorator defines a route for the API, and the 
read_root() function is called when the route is accessed. The function 
returns a dictionary with the key "Hello" and the value "World".
```

**Writing code to handle AI models**

``` text
Question: 

Write a Python script using transformers that tokenizes an input 
text and generates model output.
```

``` Python
Response: 

import transformers

tokenizer = transformers.AutoTokenizer.from_pretrained("bert-base-uncased")
model = transformers.AutoModel.from_pretrained("bert-base-uncased")

input_text = "This is an example text."

tokenized_text = tokenizer.tokenize(input_text)
model_output = model.generate(input_text)

print(tokenized_text)
print(model_output)
```

In quantitative terms, our headline result is 22% on the first pass using the [HumanEval](https://github.com/openai/human-eval) benchmark, scored using this [codebase](https://github.com/abacaj/code-eval). Although this is a good result, it is well below the best-documented performance of an AI model specialized in writing code.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/openai/human-eval" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - openai/human-eval: Code for the paper “Evaluating Large Language Models Trained on Code”
</div>
<div class="kg-bookmark-description">
Code for the paper “Evaluating Large Language Models Trained on Code” - GitHub - openai/human-eval: Code for the paper “Evaluating Large Language Models Trained on Code”
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">openai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/30dbb59ad66ca06006966a2e0276327e5a999398d5bddf83738c2b500ee02412/openai/human-eval" />
</div>
</figure>

Falcon-40b-Instruct scored 18% on the same tasks. We expect that this is because training it on a much larger dataset makes it better at following instructions, even if it is not better at writing code or solving programming problems.  Most of its knowledge appears to have been acquired in the pre-training phase.

## In a nutshell

We have released two models via HuggingFace: The full [weight](https://huggingface.co/jinaai/falcon-40b-code-alpaca) model and the LoRA adapter [weights](https://huggingface.co/jinaai/falcon-40b-code-alpaca-lora) for our fine-tuned Falcon40b.

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/falcon-40b-code-alpaca" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/falcon-40b-code-alpaca · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/falcon-40b-code-alpaca.png" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/falcon-40b-code-alpaca-lora" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/falcon-40b-code-alpaca-lora · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/falcon-40b-code-alpaca-lora.png" />
</div>
</figure>

Although Falcon40b is not specialized for coding, it performs quite well on coding problems. With our fine-tuned LoRA mask, you can turn any Falcon40b installation into a coding assistant by only loading a few megabytes of additional data into memory.

## Downloading our code and reproducing our results

You can reproduce what we did by checking out [our codebase from GitHub](https://github.com/jina-ai/jerboa/). The code consists of fairly transparent wrappers around HuggingFace’s transformers module.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/jerboa/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/jerboa: LLM finetuning
</div>
<div class="kg-bookmark-description">
LLM finetuning. Contribute to jina-ai/jerboa development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/5e031ee5708bcafc07222ce7b09b091094cf6e8b8279ac8c1cd7dfd84e4aad0b/jina-ai/jerboa" />
</div>
</figure>

First, get our code from GitHub:

``` bash
git clone https://github.com/jina-ai/jerboa.git
```

Then, go into the root directory of the git repository and run the following:

``` bash
cd jerboa

finetune.py --base-model tiiuae/falcon-40b --lora-target-modules query_key_value --data-path sahil2801/CodeAlpaca-20k --output-dir ./lora-alpaca-code --batch-size 128 --micro-batch-size 4 --eval-limit 45 --eval-file code_eval.jsonl --wandb-project jerboa --wandb-log-model --wandb-watch gradients --num-epochs 2
```

If you have trouble, you can revert to the checkpoint of the version we used for this article:

``` bash
git checkout abe1a23a4e9f5e141e19be0336ca8a4c888dd024  
```

You may also be able to reduce compute and training time with [LLM Foundry](https://github.com/mosaicml/llm-foundry) or some other tool that optimizes for low training costs.

## Get involved

Check out [Jina AI's website](https://jina.ai), [GitHub repo](https://github.com/docarray/docarray?ref=jina-ai-gmbh.ghost.io), and [Discord](https://discord.gg/WaMp6PVPgR?ref=jina-ai-gmbh.ghost.io) to explore what AI can do for you.
