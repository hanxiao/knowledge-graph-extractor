---
title: "Fine-tuning with Low Budget and High Expectations"
slug: fine-tuning-with-low-budget-and-high-expectations
url: https://cms.jina.ai/fine-tuning-with-low-budget-and-high-expectations/
published_at: 2022-12-01T16:37:52.000+01:00
updated_at: 2022-12-01T16:37:52.000+01:00
reading_time: 7
authors: "Han Xiao, Bo Wang, Scott Martens"
tags: "Tech Blog"
excerpt: "Fine-tuning is highly effective, economical, and eco-friendly; or at least that's what all the deep learning tweets will tell you. Exactly how much data & time do you need to get a good result?"
---

# Fine-tuning with Low Budget and High Expectations

Fine-tuning is a transfer learning technique developed as part of the Deep Learning revolution in artificial intelligence. Instead of learning a new task from scratch, fine-tuning takes a pre-trained model, trained on a related task, and then further trains it for the new task. Alternately, it can mean taking a model pre-trained for an open domain task, and further training it for a domain-specific one.

Compared to training from scratch, fine-tuning is a much more cost-efficient solution whenever it is feasible. It requires:

- **less labeled data,** as there is no need to learn everything all over again. All the training is devoted to acquiring domain-specific knowledge.
- **less time to train,** since the number of variables is much smaller and most layers in the deep neural network freeze during fine-tuning.

Leveraging and transferring pre-existing training to new problems is one of the major practical developments of the Deep Learning revolution. It is highly effective, economical, and environmentally friendly. This is especially true for small businesses and individuals that hope to take advantage of new AI technologies.

Or at least that's what all the deep learning tweets will tell you.

But if you think about it, or try to use fine-tuning in a real world use-case, you will quickly find out that the promise comes with a lot of caveats:

- **Exactly *how much data* do you** ** **need to get a good result?** One labeled data point? Ten? One thousand? Ten thousand?
- **Exactly *how much time* do you need to get good results?** One minute of fine-tuning? An hour? A day? A week?

These are not trivial questions, even for large enterprises, but they are especially critical to SME's and individuals who have limited resources to invest in AI. Domain-specific data is neither free nor error-free and requires costly human labor to generate. Top of the line GPU pipelines are frighteningly expensive to buy and maintain, with most enterprises renting time on a cloud service. An unplanned AWS bill in the thousands of euros is unwelcome at the best of times.

This article will give you a **quantitative answer** to these questions, using the Jina AI Finetuner. This tool is designed to improve the performance of pre-trained models and make them production-ready without expensive hardware.

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://github.com/jina-ai/finetuner" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/finetuner: Task-oriented finetuning for better embeddings on neural search
</div>
<div class="kg-bookmark-description">
:dart: Task-oriented finetuning for better embeddings on neural search - GitHub - jina-ai/finetuner: Task-oriented finetuning for better embeddings on neural search
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://repository-images.githubusercontent.com/394994747/b1cc3a87-d80f-4b52-9522-6647d88d0aaa" />
</div>
<figcaption>Finetuner makes neural network fine-tuning easier and faster by streamlining the workflow and handling all the complexity and infrastructure requirements in the cloud. </figcaption>
</figure>

## Experiment design

We designed two experiments to quantitatively study how **labeled data** and **training time** affect fine-tuning performance. For each experiment, we construct three multimodal search tasks by fine-tuning three deep neural networks. We chose seven datasets, two of which are non-domain-specific public datasets, to ensure the generality of our experiment.

We measure the performance of fine-tuned models by evaluating their ability to perform search tasks, as measured by [Mean Reciprocal Rank](https://en.wikipedia.org/wiki/Mean_reciprocal_rank) (mRR), Recall, and [Mean Average Precision](https://stats.stackexchange.com/questions/127041/mean-average-precision-vs-mean-reciprocal-rank) (mAP). These metrics are calculated using the top 20 results of each search in the validation subset held out from each dataset.

The table below summarizes the tasks, models and datasets used in our experiments, as well their performance metrics without any fine-tuning.

<table>
<thead>
<tr>
<th>Task</th>
<th>Model</th>
<th>Dataset</th>
<th>Metric@20</th>
<th>Pretrained Results</th>
</tr>
</thead>
<tbody>
<tr>
<td rowspan="6">Text-to-text search</td>
<td rowspan="6">bert-base-cased</td>
<td rowspan="3">QuoraQA</td>
<td>mRR</td>
<td>0.835</td>
</tr>
<tr>
<td>recall</td>
<td>0.9154</td>
</tr>
<tr>
<td>mAP</td>
<td>0.8143</td>
</tr>
<tr>
<td rowspan="3">Clinc150</td>
<td>mRR</td>
<td>0.7628</td>
</tr>
<tr>
<td>recall</td>
<td>0.2313</td>
</tr>
<tr>
<td>mAP</td>
<td>0.6131</td>
</tr>
<tr>
<td rowspan="9">Text-to-image search</td>
<td rowspan="9">openai/clip-vit-base-patch32</td>
<td rowspan="3">Flickr8K</td>
<td>mRR</td>
<td>0.5512</td>
</tr>
<tr>
<td>recall</td>
<td>0.7626</td>
</tr>
<tr>
<td>mAP</td>
<td>0.5893</td>
</tr>
<tr>
<td rowspan="3">Flickr30K</td>
<td>mRR</td>
<td>0.5901</td>
</tr>
<tr>
<td>recall</td>
<td>0.792</td>
</tr>
<tr>
<td>mAP</td>
<td>0.6272</td>
</tr>
<tr>
<td rowspan="3">COCO Captions</td>
<td>mRR</td>
<td>0.2118</td>
</tr>
<tr>
<td>recall</td>
<td>0.4847</td>
</tr>
<tr>
<td>mAP</td>
<td>0.2118</td>
</tr>
<tr>
<td rowspan="6">Image-to-image search</td>
<td rowspan="6">resnet50</td>
<td rowspan="3">TLL</td>
<td>mRR</td>
<td>0.0845</td>
</tr>
<tr>
<td>recall</td>
<td>0.2076</td>
</tr>
<tr>
<td>mAP</td>
<td>0.0845</td>
</tr>
<tr>
<td rowspan="3">Celeba</td>
<td>mRR</td>
<td>0.1416</td>
</tr>
<tr>
<td>recall</td>
<td>0.0241</td>
</tr>
<tr>
<td>mAP</td>
<td>0.1279</td>
</tr>
</tbody>
</table>

We already knew, even before performing any experiments, that all else being equal, more **labeled data** and more **training time** positively influence performance. But it's not enough to say that. We need to know how much is enough?

The overarching question of our experiment is:

> Can we estimate the minimum domain- and task-specific labeled data and training time to deliver an adequate performance?

## How much labeled data is needed for good fine-tuning?

We gradually increase the amount of labeled data fed to Finetuner from 100 items to 100,000 and see how this affects performance on the metrics described in the previous section.

We further calculate the *return on investment* (ROI), by dividing the relative improvement (a proxy for net profit) by the amount of labeled data (a proxy for investment cost). **This is useful because it indicates the point at which adding more data is producing diminishing returns.**

In the figures below, the X-axis represents the amount of labeled data, and the Y-axis represents the relative improvement over the pre-trained model. The higher, the better.

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-QuoraQA--3-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-Clinc150--3-.svg" loading="lazy" width="387" height="385" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr8K--5-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr30K--5-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-CoCoCaptions--4-.svg" loading="lazy" width="387" height="385" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Totally-looks-like.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Celeba--4-.svg" loading="lazy" width="387" height="385" />
</div>
</div>
</div>
</figure>

These results are promising but *not* particularly surprising. Performance improves with more labeled data on nearly all tasks and all datasets, more for some tasks and datasets than for others. However, the only conclusion we can draw from these figures is that the Finetuner works as advertised. So far so good.

What is more interesting is the ROI curve. In the figures below, the X-axis represents the amount of labeled data, and the Y-axis represents the ROI per labeled data item. The higher, the better. In particular, `ROI=0` means adding new labeled data at that point no longer contributes to any improvement.

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-QuoraQA--7-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-Clinc150--7-.svg" loading="lazy" width="387" height="385" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr8K--6-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr30K--6-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-CoCoCaptions--5-.svg" loading="lazy" width="387" height="385" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Totally-looks-like--1-.svg" loading="lazy" width="387" height="385" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Celeba--5-.svg" loading="lazy" width="387" height="385" />
</div>
</div>
</div>
</figure>

Surprisingly, we can see that the ROI per unit of new labeled data starts to drop almost immediately. We expected that it would eventually decrease, but this is an unexpected result.

## How much time is needed for fine-tuning?

To measure the value of added training time, we fixed the amount of new labeled data to 1000 items, and then we gradually increased the number of training epochs from 1 to 10. At each increase, we measure improvement over the pre-trained model and calculate the ROI. For these experiments, the ROI is calculated by dividing the relative improvement by the elapsed time in seconds. This means that when `ROI=0` , adding training time no longer improves performance.

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-QuoraQA--4-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-Clinc150--4-.svg" loading="lazy" width="380" height="371" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr8K--3-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr30K--3-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-CocoCaptions--2-.svg" loading="lazy" width="380" height="371" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Totally-look-like--2-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Celeba--2-.svg" loading="lazy" width="380" height="371" />
</div>
</div>
</div>
</figure>

We knew in advance that adding more time does not guarantee any improvement at all. It can, in fact, reduce performance due to the *overfitting problem*. Some models (e.g. CLIP) are more prone to overfitting than others. In principle, if we keep training with the same 1000 data points over and over, we are guaranteed to overfit the data and the overall performance will drop.

Let's look at the ROI curves.

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-QuoraQA--5-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-text-search-on-Clinc150--9-.svg" loading="lazy" width="380" height="371" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr8K--4-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-Flickr30K--4-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Text-to-image-search-on-CocoCaptions--3-.svg" loading="lazy" width="380" height="371" />
</div>
</div>
</div>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Totally-look-like--3-.svg" loading="lazy" width="380" height="371" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2022/12/Image-to-image-search-on-Celeba--3-.svg" loading="lazy" width="380" height="371" />
</div>
</div>
</div>
</figure>

The ROI drops immediately after the first epoch of fine-tuning. Unlike in the last experiment, where ROI approached zero but stayed positive when increasing the labeled data, here, the ROI on added time can go negative due to the overfitting problem!

## Summary

What does this mean for users looking to maximize gains and minimize costs?

- Many state-of-the-art deep neural networks are capable of *few-shot* learning. They are quick learners and can make large improvements with only a few hundred items of labeled data and only a few minutes of training time. You might have thought that deep neural network training requires millions of data items and a week of runtime, but we have shown in this article how that stereotype does not hold up to reality.
- Because they can learn so much, so fast, from so little data, ROI drops quickly as you put more time and data into fine-tuning. In the experiments above, ROI shrinks by 70% from its highest value after 500 labeled data items or 600 added seconds of GPU training time. Further investment beyond a few hundred items of training data and very minimal training time may not pay off as well as you would like.

All in all, fine-tuning is not economically comparable to training from scratch. It is far, far cheaper, especially with the help of [Finetuner](https://github.com/jina-ai/finetuner). So the next time you receive a marketing email from the sales department of a GPU vendor or a company offering crowdsourced data acquisition, you know how to bargain with them.
