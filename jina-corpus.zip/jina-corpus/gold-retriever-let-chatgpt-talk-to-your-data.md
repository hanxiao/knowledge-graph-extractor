---
title: "Gold Retriever: Let ChatGPT talk to your data"
slug: gold-retriever-let-chatgpt-talk-to-your-data
url: https://cms.jina.ai/gold-retriever-let-chatgpt-talk-to-your-data/
published_at: 2023-05-23T16:00:29.000+02:00
updated_at: 2024-01-24T18:28:21.000+01:00
reading_time: 3
authors: "Saba Sturua, Alex C-G"
tags: "Tech Blog"
excerpt: "With Gold Retriever, you can easily enable ChatGPT to store, retrieve, and reason with your data in just a few steps"
---

# Gold Retriever: Let ChatGPT talk to your data

In the realm of AI, language models like ChatGPT have revolutionized how we interact with machines. However, as efficient as these models are, they encounter certain limitations. One key hurdle is their inability to seamlessly integrate and reason with new, personalized, or up-to-date data, which is often critical for users.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/05/image-6.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/05/image-6.png 600w, https://cms.jina.ai/content/images/2023/05/image-6.png 932w" sizes="(min-width: 720px) 720px" width="932" height="587" />
<figcaption>Out-of-date data</figcaption>
</figure>

Language models have a knowledge cut-off, beyond which they aren't informed about new world events, scientific discoveries, or technological breakthroughs. They may also lack depth in specific knowledge domains, struggle with real-time data, and produce outputs that might need fact-checking for accuracy. Additionally, users desire AI interactions tailored to their profiles and control over their data, which requires the AI to access user-specific data.

Enter "Gold Retriever", a powerful open-source tool powered by [Jina](https://github.com/jina-ai/jina) and [DocArray](https://github.com/docarray/docarray), that addresses these very needs.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/GoldRetriever" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/GoldRetriever: Create and host retrieval plugins for ChatGPT in one click
</div>
<div class="kg-bookmark-description">
Create and host retrieval plugins for ChatGPT in one click - GitHub - jina-ai/GoldRetriever: Create and host retrieval plugins for ChatGPT in one click
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://repository-images.githubusercontent.com/621363017/b2bbcea2-ccf0-4597-ae30-0b168212a9fb" />
</div>
</figure>

It equips users to create custom plugins that enable ChatGPT to interact with their data, overcoming inherent limitations. Gold Retriever acts as a bridge linking ChatGPT with the vast and dynamic world of data, making AI interactions more meaningful, accurate, and personal.

### Gold Retriever in Action: Study Assistant

To better illustrate how Gold Retriever works, let's consider a practical scenario. Imagine you're a student seeking assistance from ChatGPT with your coursework. However, your course materials exceed ChatGPT's prompt limit, preventing you from getting the help you need. That's exactly where Gold Retriever comes in handy.

In this example, we'll use resources from MIT's open course - [Ecology I: The Earth System](https://ocw.mit.edu/courses/1-018j-ecology-i-the-earth-system-fall-2009/).

<figure class="kg-card kg-bookmark-card">
<a href="https://ocw.mit.edu/courses/1-018j-ecology-i-the-earth-system-fall-2009/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Ecology I: The Earth System | Civil and Environmental Engineering | MIT OpenCourseWare
</div>
<div class="kg-bookmark-description">
We will cover fundamentals of ecology, considering Earth as an integrated dynamic system. Topics include coevolution of the biosphere, geosphere, atmosphere and oceans; photosynthesis and respiration; the hydrologic, carbon and nitrogen cycles. We will examine the flow of energy and materials throug…
</div>
<div class="kg-bookmark-metadata">
<img src="https://ocw.mit.edu/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">MIT OpenCourseWare</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://ocw.mit.edu/courses/1-018j-ecology-i-the-earth-system-fall-2009/6fb954a330c3fe950f2305df362b755a_1-018jf09.jpg" />
</div>
</figure>

The first step is to gather all relevant text files in one directory, which will serve as your data source. Next, you'll need to create a Gold Retriever plugin. Here's how:

Install Gold Retriever via pip with the command:

``` shell
pip install goldretriever
```

Now, deploy a plugin providing your OpenAI key:

``` shell
goldretriever deploy --key <your openai key>
```

After deployment, make a note of the "Gateway (HTTP)" URL and the Bearer token, as you'll need them to incorporate the plugin into ChatGPT.

``` shell
╭──────────────────────── 🎉 Flow is available! ────────────────────────╮
│                                                                       │
│   ID               retrieval-plugin-<plugin id>                       │
│   Gateway (Http)   https://retrieval-plugin-<plugin id>.wolf.jina.ai  │
│   Dashboard        https://dashboard.wolf.jina.ai/flow/<plugin id>    │
│                                                                       │
╰───────────────────────────────────────────────────────────────────────╯
Bearer token: <your bearer token>
```

Next, let's index the data we've gathered:

``` shell
goldretriever index --data <dir_name>
```

With the data indexed successfully, the plugin can now be integrated into ChatGPT. Navigate to plugins, choose "Develop your own plugin", and provide the "Gateway (HTTP)" URL and Bearer token from the deployment phase. Voila! Your plugin is now installed and ready for a test run!

With Gold Retriever at your disposal, there are numerous ways to use ChatGPT to assist with coursework. A fun and effective studying strategy is to create flashcards from course materials, and you can enlist ChatGPT's help for this task:

<figure class="kg-card kg-video-card">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration"></span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+" />
</div>
</div>
</div>
</figure>

ChatGPT looks into your notes, extracts relevant material about the chosen topic (Thermodynamics, in this instance), and creates comprehensive flashcards based on the information. It can also provide further clarification on certain concepts:

<figure class="kg-card kg-video-card">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration"></span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+" />
</div>
</div>
</div>
</figure>

ChatGPT first identifies the example you're seeking and then responds with a detailed explanation.

This case study showcases just one of the countless applications for Gold Retriever. If you have textual data that you'd like ChatGPT to remember and use, Gold Retriever is your go-to tool.

Be sure to watch the video for the full tutorial:

<figure class="kg-card kg-embed-card">
<div class="iframe">
<div id="player">

</div>
<div class="player-unavailable">
<h1 id="an-error-occurred." class="message">An error occurred.</h1>
<div class="submessage">
Unable to execute JavaScript.
</div>
</div>
</div>
</figure>

For more information, head over to the [Gold Retriever](https://github.com/jina-ai/GoldRetriever) repository and join the discussion on [Discord](https://discord.jina.ai/). Happy coding!
