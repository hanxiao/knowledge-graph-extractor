---
title: "Graph Embedding 101: Unraveling the Magic of Relational Data"
slug: graph-embedding-101-unraveling-the-magic-of-relational-data
url: https://cms.jina.ai/graph-embedding-101-unraveling-the-magic-of-relational-data/
published_at: 2023-08-29T17:25:14.000+02:00
updated_at: 2024-01-24T18:00:54.000+01:00
reading_time: 10
authors: "Engineering Group"
tags: "Knowledge Base"
excerpt: "Graphs → everywhere. Social. Knowledge. Molecular. Critical infrastructure. Complex hairy ball visuals. Hard for machines.

Now graph embeddings vectorize nodes. Distill graphs into geometry. Embeddings work magic. AI devours graphs."
---

# Graph Embedding 101: Unraveling the Magic of Relational Data

Graphs are everywhere, from the intricate web of neurons in our brains to the sprawling networks of social media platforms. But how do we translate these complex structures into a language that AI models can understand?

In this post, we'll delve deep into the world of graph embeddings, drawing parallels with familiar concepts, and exploring the challenges and potential of this transformative technique.

## What is Graph Embedding?

In short, **graph embedding vectorizes nodes.**

Imagine a vast, sprawling city - a tangled web of streets and junctions. Each intersection is a point of interest, and each road between them is a connection. Now picture looking down on this city from above - you see a complex mess of intersections and streets spreading out in all directions.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail.png 1000w, https://cms.jina.ai/content/images/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail.png 1280w" sizes="(min-width: 720px) 720px" width="1280" height="720" alt="Berlin cityscape featuring the landmark TV Tower, historical red-roofed buildings, and surrounding greenery under a clear blue sky" />
</figure>

This city is like a graph - a set of nodes (the junctions) and edges between them (the streets). Handling very large, complex graphs tends to be computationally demanding, just as navigating a vast city can be overwhelming.

This is where graph embedding comes in - it takes this vast graph and simplifies it down into a simpler space as if we squeeze all the myriad streets and intersections down into basic proximity on a 2D map. Nodes highly interconnected end up clustered together, just as related city sights group together on a tourist map. Each node gets converted into a single point on a map, represented by coordinates in a lower-dimensional space. Nearby nodes in the original graph end up close together on the map. Far away nodes end up far apart.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail--1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail--1-.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail--1-.png 1000w, https://cms.jina.ai/content/images/2023/08/Dark-Modern-Elegant-Singer-New-Song-YouTube-Thumbnail--1-.png 1280w" sizes="(min-width: 720px) 720px" width="1280" height="720" alt="19th-century map of Berlin, highlighted in red with details of streets and the River Spree, including the label &quot;BERLIN." />
</figure>

So in summary, graph embedding takes a hairball graph and simplifies it down into a tidy map - a vector space that preserves the structure and relationships from the original graph. This is mathematically equivalent to [sentence embeddings](https://arxiv.org/abs/2307.11224) applied to graphs instead of sentences. In essence, **graph embedding vectorizes nodes like sentence embeddings vectorize sentences.** It massages graphs into a format friendly for machine learning models.

## Formal Definition of Graph Embeddings

Formally, a graph \$G = (V, E)\$ is a representation of relationships using nodes \$V\$ and edges \$E\$. Now, navigating a city can be overwhelming due to its vastness. Similarly, handling large graphs can be computationally challenging. Enter graph embedding.

Graph embedding is the art of translating this city (or graph) into a simplified map, where each point of interest (or node) is represented by a coordinate in a lower-dimensional space. Mathematically, it's about learning a function \$f: v_i → y_i ∈ R^d\$ that maps each node \$v_i\$ to a vector \$y_i\$ in a space \$R^d\$ where \$d\$ is much smaller than \$\|V\|\$.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/08/image-15.png" class="kg-image" loading="lazy" width="557" height="326" alt="A customer embedding graph with data points such as demographics, region, prior purchases, web logs, searches, and complaints, connected by lines" />
<figcaption><span style="white-space: pre-wrap;">Source: TigerGraph - Graph Embedding: Understanding Graph Embedding AlgorithmsS</span></figcaption>
</figure>

## Why is Graph Embedding a Game-Changer?

From predicting potential friendships on social media to visualizing intricate datasets, graph embeddings are proving invaluable. They're pivotal in node classification tasks, link predictions, and even in clustering nodes with similar properties. Moreover, as we venture into the realm of multimodal AI, where different types of data converge, graph embeddings can serve as a bridge, connecting structured data with unstructured data.

1.  **Machine Learning Compatibility**: Traditional ML models, from linear regressors to deep neural networks, thrive on numerical data. Graph embeddings translate the intricate relationships of a graph into a numerical format, making them digestible for these models.
2.  **Preserving Topology and Features**: A well-crafted graph embedding retains the original graph's structure and node features. [This dual preservation is a challenge that many earlier methods struggled with](https://static.googleusercontent.com/media/research.google.com/en//pubs/archive/40839.pdf).
3.  **Dimensionality Reduction**: Instead of grappling with a dimension for every node, we can now work in a much-reduced space, often just 50-1000 dimensions. This simplification is a boon for computational efficiency.
4.  **Unearthing Latent Patterns**: Beyond the explicit, graph embeddings can tease out hidden relationships, offering insights that might not be immediately apparent in the original graph.

## How to Compute Graph Embeddings?

Graph embedding techniques are as diverse as the graphs they seek to represent. However, most can be bucketed into a few broad categories:

- **Matrix Factorization**: Techniques like HOPE and Laplacian Eigenmaps revolve around factorizing the graph's adjacency matrix `A`. For instance, HOPE employs a generalized SVD to approximate `A` as `Y_s Y_t^T`, extracting the embedding `Y` in the process.

<figure class="kg-card kg-bookmark-card">
<a href="https://zw-zhang.github.io/publication/2016-08-Asymmetric-Transitivity-Preserving-Graph-Embedding" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Asymmetric Transitivity Preserving Graph Embedding
</div>
<div class="kg-bookmark-description">
Key words: graph embedding, asymmetric transitivity, Generalized SVD (GSVD)
</div>
<div class="kg-bookmark-metadata">
<img src="https://zw-zhang.github.io/images/android-chrome-192x192.png?v=M44lzPylqQ" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Ziwei Zhang</span><span class="kg-bookmark-publisher">Email</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://zw-zhang.github.io/images/profile-photo.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://proceedings.neurips.cc/paper_files/paper/2001/hash/f106b7f99d2cb30c3db1c3cc0fde9ccb-Abstract.html" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Laplacian Eigenmaps and Spectral Techniques for Embedding and Clustering
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://proceedings.neurips.cc/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">NeurIPS Proceedings</span>
</div>
</div>
</figure>

- **Random Walks**: Picture a drunken walk through our earlier city analogy, meandering through landmarks. Methods like DeepWalk and node2vec use such random walks to capture the essence of a graph. These walks are then fed to models akin to Word2Vec to derive the embeddings.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/1403.6652" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
DeepWalk: Online Learning of Social Representations
</div>
<div class="kg-bookmark-description">
We present DeepWalk, a novel approach for learning latent representations of vertices in a network. These latent representations encode social relations in a continuous vector space, which is easily exploited by statistical models. DeepWalk generalizes recent advancements in language modeling and un…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Bryan Perozzi</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/1607.00653" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
node2vec: Scalable Feature Learning for Networks
</div>
<div class="kg-bookmark-description">
Prediction tasks over nodes and edges in networks require careful effort in engineering features used by learning algorithms. Recent research in the broader field of representation learning has led to significant progress in automating prediction by learning the features themselves. However, present…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Aditya Grover</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

- **Neural Networks**: The neural revolution hasn't spared graph embeddings. Approaches like GraphSAGE and GCNs employ neural encoders, which, when applied to a node's local neighborhood, distill both the graph's topology and node features into the embeddings.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/1706.02216" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Inductive Representation Learning on Large Graphs
</div>
<div class="kg-bookmark-description">
Low-dimensional embeddings of nodes in large graphs have proved extremely useful in a variety of prediction tasks, from content recommendation to identifying protein functions. However, most existing approaches require that all nodes in the graph are present during training of the embeddings; these…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">William L. Hamilton</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/1609.02907" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Semi-Supervised Classification with Graph Convolutional Networks
</div>
<div class="kg-bookmark-description">
We present a scalable approach for semi-supervised learning on graph-structured data that is based on an efficient variant of convolutional neural networks which operate directly on graphs. We motivate the choice of our convolutional architecture via a localized first-order approximation of spectral…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Thomas N. Kipf</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## A Toy Implementation of Graph Embeddings

Implementing graph embedding techniques from scratch can be challenging. The algorithm below shows a simple way to generate graph embeddings. It takes an adjacency matrix as input, which represents the connections in a graph. Each row and column corresponds to a node, and a 1 indicates an edge between those nodes.

``` python
from typing import List 
import numpy as np

def graph_embedding(adj_matrix: List[List[int]], emb_size: int = 16) -> List[np.ndarray]:
    """Generate graph embedding
    
    Args:
        adj_matrix: Adjacency matrix as nested list
        emb_size: Size of embedding vectors
        
    Returns:
        List of numpy arrays as node embeddings
    """
        
    # Initialize empty embeddings
    embeddings = [np.random.rand(emb_size) for _ in adj_matrix]
    
    # Train embedding -visualize nodes moving closer if connected
    for _ in range(100): 
        for v1, row in enumerate(adj_matrix):
            for v2, is_connected in enumerate(row):
                if is_connected:
                    # Move embeddings closer if nodes connected
                    embeddings[v1] -= 0.1 * (embeddings[v1] - embeddings[v2])  

    return embeddings
```

- It initializes an embedding vector of random values for each node. Then it *trains* these embeddings by iterating through the adjacency matrix to identify connected nodes.
- For any pair of nodes that are connected, it moves their embedding vectors slightly closer together. This is done by subtracting a fraction of their vector difference from the first node's embedding.
- Over multiple iterations, nodes that are tightly interconnected will have very similar embedding vectors, while disconnected nodes will remain far apart in the embedding space.
- The `for _ in range(100)` loop controls the number of training iterations. More iterations allow the embeddings to converge closer to their optimal values for representing the graph structure.

Finally, the embeddings are returned as a list of `numpy` arrays. Each array is the vector representation for a node.

## Top 3 Open Source Packages for Graph Embeddings

This algorithm above gives a simple illustrative example of how graph embeddings can capture topology, which is not recommended to use in production of course. Instead, there are several excellent open source packages available to make working with graph embeddings much easier. Here are 3 popular options:

### PyTorch Geometric

[PyTorch Geometric](https://pytorch-geometric.readthedocs.io/en/latest/) is a geometric deep learning extension library for PyTorch. It includes a wide range of graph embedding techniques including GCN, GAT, GraphSAGE, and more. The mini-batches and autograd support make PyTorch Geometric great for developing and training new graph embedding models.

<figure class="kg-card kg-bookmark-card">
<a href="https://pytorch-geometric.readthedocs.io/en/latest/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
PyG Documentation — pytorch_geometric documentation
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://raw.githubusercontent.com/pyg-team/pyg_sphinx_theme/master/pyg_sphinx_theme/static/img/favicon.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://raw.githubusercontent.com/pyg-team/pyg_sphinx_theme/master/pyg_sphinx_theme/static/img/pyg_logo.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

### Deep Graph Library (DGL)

[DGL](https://www.dgl.ai/) is a Python package from AWS that provides building blocks optimized for deep learning on graphs. DGL supports inductive graph representation learning techniques like GraphSAGE and GAT out of the box. The flexible frameworks allow you to implement custom graph neural network architectures.

<figure class="kg-card kg-bookmark-card">
<a href="https://www.dgl.ai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Deep Graph Library
</div>
<div class="kg-bookmark-description">
Library for deep learning on graphs
</div>
<div class="kg-bookmark-metadata">
<img src="https://www.dgl.ai/assets/images/dgl-favicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">logo</span><span class="kg-bookmark-publisher">Themeix</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://www.dgl.ai/assets/images/logo.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

### StellarGraph

[StellarGraph](https://www.stellargraph.io/) is a Python library for machine learning on network data. It has implementations of graph embedding algorithms including node2vec, DeepWalk, and GraphSAGE. StellarGraph integrates seamlessly with common ML frameworks like TensorFlow and Scikit-Learn.

<figure class="kg-card kg-bookmark-card">
<a href="https://www.stellargraph.io/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
StellarGraph - Machine Learning on Graphs
</div>
<div class="kg-bookmark-description">
StellarGraph provides graph analytics software for machine learning on networks. Uncover insights with the next generation of data science tools.
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.wixstatic.com/media/91c550_bf9afe8aa7dd463891bd08edcbc42191~mv2.png/v1/fill/w_32%2Ch_32%2Clg_1%2Cusm_0.66_1.00_0.01/91c550_bf9afe8aa7dd463891bd08edcbc42191~mv2.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Stellar2</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.wixstatic.com/media/91c550_bf9afe8aa7dd463891bd08edcbc42191~mv2.png/v1/fill/w_512,h_512,al_c/91c550_bf9afe8aa7dd463891bd08edcbc42191~mv2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

These libraries make it easy to leverage graph embeddings in your own projects. They handle low-level optimizations and provide pre-built models so you can focus on your application. Graph embeddings are now more accessible than ever for researchers and developers.

## Graph Embeddings vs. Sentence Embeddings

Graph embeddings and sentence embeddings, both aim to distill intricate structures into compact vector forms, yet they cater to distinct data types and possess their own set of challenges and strengths. Let's embark on an expedition to discern their similarities, differences, and unique attributes.

### The Common Ground

- **Dimensionality Reduction**: Both graph and sentence embeddings endeavor to encapsulate high-dimensional data within a more compact, lower-dimensional space. This transformation not only makes the data more tractable but also primes it for machine learning models.
- **Preservation of Relationships**: Be it the intricate ties between nodes in a graph or the semantic dance of words in a sentence, both embeddings are committed to ensuring that the spatial relationships in the original structure find their echo in the embedding space.
- **Facilitating Machine Learning**: By transmuting graphs and sentences into fixed-length vectors, both embeddings pave the way for the application of a plethora of machine learning algorithms, spanning from clustering to classification.

### Diving into the Differences

| Aspect | Graph Embedding | Sentence Embedding |
|----|----|----|
| **Nature of Data** | Focuses on relational data, with nodes (entities) and edges (relationships) taking center stage. | Hones in on sequential data, where the order and semantic interplay of words are paramount. |
| **Embedding Techniques** | Techniques often orbit around matrix factorization, random walks, or neural networks. For instance, node2vec leverages random walks to encapsulate the graph's neighborhood structure. | Methods like Word2Vec or BERT distill embeddings by delving into the context of word appearances. Deep learning architectures, especially transformers, are the tools of choice to capture linguistic intricacies. |
| **Applications** | Finds its niche in tasks like link prediction or node classification. | Primarily employed in natural language processing endeavors such as sentiment analysis or machine translation. |
| **Challenges** | The dual task of capturing both the topological intricacies and the attributes of nodes and edges can be daunting. Scalability, especially with mammoth graphs, is another hurdle. | Sentences, with their chameleon-like nature, can adopt multiple meanings based on context (polysemy). Grasping these nuances, especially in linguistically rich languages, is a formidable challenge. |

## Challenges and the Road Ahead

Graph embeddings, while transformative, are not without their challenges. Striking the right balance between preserving topology and node features is a tightrope walk. As graphs burgeon in size and intricacy, the specter of computational inefficiency looms large. However, as evidenced by initiatives like the RESTORE framework, the community is rallying together, pooling resources and expertise to surmount these challenges.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2308.14659" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
RESTORE: Graph Embedding Assessment Through Reconstruction
</div>
<div class="kg-bookmark-description">
Following the success of Word2Vec embeddings, graph embeddings (GEs) have gained substantial traction. GEs are commonly generated and evaluated extrinsically on downstream applications, but intrinsic evaluations of the original graph properties in terms of topological structure and semantic informat…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Hong Yung Yip</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

In conclusion, graph embeddings are not just reshaping our understanding of relational data; they are laying the foundation for a future where data, irrespective of its form or source, can be seamlessly integrated and processed. As we continue our foray into the uncharted territories of machine learning, tools and techniques like graph embeddings will be the compass guiding our way. Stay tuned as we journey deeper into the mesmerizing realm of machine learning, uncovering treasures and charting new courses!
