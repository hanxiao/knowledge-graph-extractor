---
title: "Handcrafting Image Prompts Is Dead: Reverse Engineer Midjourney-style Images with PromptPerfect"
slug: handcrafting-image-prompts-is-dead-reverse-engineer-midjourney-style-images-with-promptperfect
url: https://cms.jina.ai/handcrafting-image-prompts-is-dead-reverse-engineer-midjourney-style-images-with-promptperfect/
published_at: 2024-06-28T16:00:16.000+02:00
updated_at: 2024-07-08T21:07:20.000+02:00
reading_time: 7
authors: "Alex C-G"
tags: "Tech Blog"
excerpt: "From Punk Einstein to Turbo Pigeons: Use PromptPerfect Interactive to reverse engineer prompts from pictures and generate Midjourney-style images with real-time feedback."
---

# Handcrafting Image Prompts Is Dead: Reverse Engineer Midjourney-style Images with PromptPerfect

Hey you! Yeah, you, reading this. The prompt engineer who spends far too much time on Midjourney and other image generation models. This post is just for you.

> 'I never thought ~~Leopards~~ AI would eat MY face,' sobs woman who voted for the ~~Leopards~~ AI Eating People's Faces Party.

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

With apologies to [Adrian Bott](https://x.com/Cavalorn/status/654934442549620736)

</div>

</div>

With AI eating more jobs, we might also say:

> First AI came for the artists, and I did not speak out – because I was not an artist. Then it came for the prompt engineers (who used AI to bulldoze the artists in the first place), and I got screwed over because that was *my* job.

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

With apologies to [Martin Niemöller](https://en.wikiquote.org/wiki/Martin_Niem%C3%B6ller)

</div>

</div>

That's right, pal. You put the "mid" in Midjourney. Your Stable Diffusion is more like unstable confusion. And your DALL-E skills are actually CRAP-E. With tools like PromptPerfect anyone can simply reverse engineer existing images to generate prompts, or generate prompts with real-time, step-by-step feedback from a human in the loop.

So, let's jump in and see how you can reverse engineer prompts from images, so you can keep ahead of the AI leopards who want to eat *your* face...at least for now.

<div class="kg-card kg-callout-card kg-callout-card-yellow">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

PromptPerfect doesn't just support Midjourney-style images - you can also generate better prompts tailored for DALL-E 3 and Stable Diffusion XL, as well as many LLMs.

</div>

</div>

## PromptPerfect Interactive

PromptPerfect Interactive transforms how you generate content and tackle complex tasks. It's built on a dual approach:

- **Dedicated Assistant**: An AI companion that understands your needs and helps you craft effective prompts, making the content generation process as seamless as possible.
- **Powerful Optimizer**: An advanced tool that fine-tunes your prompts for optimal results, ensuring that your creative and productive endeavors are more effective than ever.

PromptPerfect has recently introduced Midjourney-style image generation, so in this post, we'll use Interactive’s assistant and optimizer to reverse engineer prompts from images and then generate new images based on those prompts in the style of Midjourney.

## How to Reverse Engineer Image Prompts

First up, we need an image to work from. Let's use this image of punk Einstein I generated in Midjourney previously:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--24-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--24-.png 600w, https://cms.jina.ai/content/images/2024/06/Untitled--24-.png 819w" sizes="(min-width: 720px) 720px" width="819" height="1024" alt="Artistic rendition of Albert Einstein in punk style with colorful hair and stylistic elements set against a blurred, vibrant " />
</figure>

To generate the image I used this prompt in Midjourney:

``` text
Realistic photo of Albert Einstein as a punk, retaining his recognizable facial
features, with a brightly colored mohawk, visible tattoos, facial piercings,
and wearing a spiked leather jacket, highly detailed, photorealistic, vibrant
colors, dramatic lighting --ar 4:5 --s 500 --v 6
```

I then uploaded the image to PromptPerfect's Interactive Assistant and asked it to generate a prompt based on that image:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--23---1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--23---1-.png 600w, https://cms.jina.ai/content/images/2024/06/Untitled--23---1-.png 780w" sizes="(min-width: 720px) 720px" width="780" height="775" alt="Screenshot of an AI optimizer article with a prompt feature, including a vibrant image of Einstein and styling options." />
</figure>

The prompt it returned was:

``` text
Colorful punk hairstyle, vibrant pink, orange, and gray hair, edgy jacket with
spikes and colorful geometric patterns, urban background, bokeh lighting,
cyberpunk aesthetic --ar 4:5 --v 6 --s 500
```

Nice...except there's one thing missing: Old Albert himself. Since Interactive has a chat-based interface, I just told it to add him to the prompt:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--25-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--25-.png 600w, https://cms.jina.ai/content/images/2024/06/Untitled--25-.png 781w" sizes="(min-width: 720px) 720px" width="781" height="307" alt="Screenshot of a draft email featuring a creative depiction of Albert Einstein with instructions by Alex Cureton-Griffiths." />
</figure>

I then got:

``` text
Albert Einstein with a colorful punk hairstyle in vibrant pink, orange, and
gray hues, wearing an edgy jacket adorned with spikes and colorful geometric
patterns, set against an urban background with bokeh lighting, cyberpunk
aesthetic --ar 4:5 --v 6 --stylize 500
```

You'll notice it's not exactly the same prompt that I used to create the initial image. This is perfectly normal - firstly because AI-generated images incorporate features beyond the prompt used to create them. For instance, in the initial image, Einstein is looking to the right, and has a splash of red on his lapel - I didn't specify those in the prompt, so if you reverse engineer a prompt from the image, you won’t just get back the same prompt you started with. The second reason is that the image analysis model (like a lot of AI) is non-deterministic -- you can ask it a second time to reverse engineer a prompt from the same image and it may pick up different details.

Anyway, now that we have a prompt, we can click the "send to Assistant" button to generate four Midjourney-style images:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--26-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--26-.png 600w, https://cms.jina.ai/content/images/2024/06/Untitled--26-.png 788w" sizes="(min-width: 720px) 720px" width="788" height="214" alt="Text generation interface with a prompt for a stylized Albert Einstein and a &#39;Send to Assistant&#39; button." />
</figure>

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--27-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--27-.png 600w, https://cms.jina.ai/content/images/2024/06/Untitled--27-.png 796w" sizes="(min-width: 720px) 720px" width="796" height="1028" alt="A vibrant depiction of Albert Einstein with a pink, orange, and gray punk hairstyle, wearing a spiked jacket against a bokeh-" />
</figure>

Again, you can see it doesn't match the initial image, and it never will. Just try putting the same prompt into an image generation model a second time and you'll get completely different results - like the image recognition model it's non-deterministic.

I really like the top-left image. By clicking it I can choose to upscale, and voila, here's my final image of everybody’s favorite crazy-haired physics uncle:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/739c52d1-97a8-4eea-b529-b4e44871dadf--1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/739c52d1-97a8-4eea-b529-b4e44871dadf--1-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/739c52d1-97a8-4eea-b529-b4e44871dadf--1-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/739c52d1-97a8-4eea-b529-b4e44871dadf--1-.png 1600w, https://cms.jina.ai/content/images/2024/06/739c52d1-97a8-4eea-b529-b4e44871dadf--1-.png 1920w" sizes="(min-width: 720px) 720px" width="1920" height="2400" alt="Colorful portrait of Albert Einstein with graying hair, a mustache, pierced nose, and a spiky jacket against a vivid bokeh ba" />
</figure>

Of course, you can also test the prompt in Midjourney proper, and you'll get similar results:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--28-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--28-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/Untitled--28-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/Untitled--28-.png 1600w, https://cms.jina.ai/content/images/2024/06/Untitled--28-.png 1920w" sizes="(min-width: 720px) 720px" width="1920" height="2400" alt="Collage of four lively portraits of Albert Einstein in vivid outfits and varying hair colors, set against expressive urban sc" />
</figure>

## More Examples

Here are a few more examples. The order of content is:

1.  Initial prompt
2.  Image generated on Midjourney proper
3.  Reverse-engineered prompt
4.  Midjourney-style image generated on PromptPerfect Interactive

### Turbo Pigeon

``` text
abstract, minimalist mesh wireframe of A pigeon::4 , wearing a helmet and
carrying a turbo booster on its back, with a gradient of green, cyan, and blue
lines against a black background, Vanishing point, with minimal detailing::4 ,
--ar 16:9 --s 750 --v 6.0
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/pigeon1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/pigeon1.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/pigeon1.png 1000w, https://cms.jina.ai/content/images/2024/06/pigeon1.png 1456w" sizes="(min-width: 720px) 720px" width="1456" height="816" alt="Futuristic bird with neon pink, blue, and red features against a black background, creating a techno-artistic ambiance." />
</figure>

    Futuristic bird with neon lights, intricate feather details, glowing pink and
    blue colors, highly detailed, digital art, ethereal and luminous, dark
    background, dynamic light streaks, cybernetic effect, hyper-realistic --ar
    16:9 --v 6 --stylize 750

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--29-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--29-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/Untitled--29-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/Untitled--29-.png 1600w, https://cms.jina.ai/content/images/2024/06/Untitled--29-.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="1121" alt="Digital art of a mystical red and blue bird with colorful lights and sparks against a gradient background." />
</figure>

### Melting brain

``` text
melting brain, floating in space, plain black background --ar 16:9 --niji 6
--s 750
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/meltbrain1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/meltbrain1.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/meltbrain1.png 1000w, https://cms.jina.ai/content/images/2024/06/meltbrain1.png 1456w" sizes="(min-width: 720px) 720px" width="1456" height="816" alt="Colorful digital art of a melting brain in pink and blue, with vein-like patterns and floating bubbles against a dark backgro" />
</figure>

``` text
Surreal, melting brain suspended in space, dripping neon pink and blue colors,
abstract, fluid textures, hyper-detailed, futuristic, digital art, cosmic
background with stars, vibrant and glowing, soft lighting --ar 16:9 --v 6
--stylize 750
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--30-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--30-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/Untitled--30-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/Untitled--30-.png 1600w, https://cms.jina.ai/content/images/2024/06/Untitled--30-.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="1121" alt="Abstract depiction of a glowing brain in pink hues against a dark, starry backdrop, evoking a mystical aura." />
</figure>

### Bollywood Princess Leia

``` text
Bollywood Star Wars scene, close up shot of Princess Leia Organa in traditional
Indian attire, intricate jewelry, holding a defender sporting blaster pistol,
vibrant colors, futuristic elements, sci-fi, dramatic lighting, detailed
background, cinematic, 8K resolution, Unreal Engine, --ar 4:5 --v 6.0
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/leia1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/leia1.png 600w, https://cms.jina.ai/content/images/2024/06/leia1.png 960w" sizes="(min-width: 720px) 720px" width="960" height="1200" alt="Woman cosplaying as Princess Leia with a blaster, styled hair in buns, in a red-tinted room with hanging lanterns." />
</figure>

``` text
Princess Leia, holding a blaster, futuristic sci-fi setting, white robe,
detailed hair buns, dramatic lighting, heroic pose, vibrant colors, cinematic
scene, intricate background with glowing elements --ar 4:5 --s 500 --v 6
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--31-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--31-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/Untitled--31-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/Untitled--31-.png 1600w, https://cms.jina.ai/content/images/2024/06/Untitled--31-.png 1920w" sizes="(min-width: 720px) 720px" width="1920" height="2400" alt="Digital painting of a woman styled like Princess Leia in white, holding a blaster, against a colorful bokeh background." />
</figure>

Hmm...gotta say, I really miss the Bollywood aspect. That's just a fact of reverse engineering - sometimes the image analysis algorithm doesn't see something that a human would. After a bit of jiggery-pokery (a highly technical prompt engineering term), I refined the prompt to this:

``` text
Princess Leia, holding a blaster, futuristic sci-fi setting, dressed in a 
white robe with intricate Indian embroidery, ethnically Indian with 
traditional Indian facial features, detailed hair buns adorned with 
traditional Indian jewelry, dramatic lighting, heroic pose, vibrant colors, 
Bollywood-inspired design, charismatic expression, cinematic scene, intricate 
background with glowing elements and traditional Indian patterns --ar 4:5 --s 
500 --v 6
```

Which gave me this image:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/ac2c47db-41a6-4171-9347-d0962c5924aa.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/ac2c47db-41a6-4171-9347-d0962c5924aa.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/ac2c47db-41a6-4171-9347-d0962c5924aa.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/ac2c47db-41a6-4171-9347-d0962c5924aa.png 1600w, https://cms.jina.ai/content/images/2024/06/ac2c47db-41a6-4171-9347-d0962c5924aa.png 1920w" sizes="(min-width: 720px) 720px" width="1920" height="2400" alt="Woman in Indian attire with braided hair and jewelry holding a gun, against a luminous background." />
</figure>

This is where the interactive optimizer really shines. If it were just me, I would've simply thrown the term `bollywood` into the prompt. But by asking the optimizer to `Refine this Midjourney-style prompt to include more Bollywood vibes` PromptPerfect added more descriptive words to the prompt (`traditional Indian patterns`, etc.). Adding more words and details suggestive of a specific outcome is usually a much better way to influence the generated image than fiddling with weights and styles.

### Pastel Medal

``` text
a medal is sitting on a podium against pastel colored confetti, in the style
of simplified forms and shapes, yellow and beige, columns and totems, playful
streamlined forms, nerdcore, contest winner, repetition and pattern --ar 64:39
--s 750 --v 6.0
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/medal1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/medal1.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/medal1.png 1000w, https://cms.jina.ai/content/images/2024/06/medal1.png 1392w" sizes="(min-width: 720px) 720px" width="1392" height="848" alt="Celebratory image featuring a bronze medal with a red ribbon and laurel wreath pattern against a rich blue background." />
</figure>

``` text
Award medal, intricate laurel design, suspended from a ribbon, celebratory
background, vibrant confetti, glowing lights, high detail, 3D render, soft
lighting, pink and blue color scheme, festive atmosphere --ar 16:9 --s 500
--v 6 --stylize 750
```

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Untitled--32-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Untitled--32-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/Untitled--32-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/06/Untitled--32-.png 1600w, https://cms.jina.ai/content/images/2024/06/Untitled--32-.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="1121" alt="Mysterious medal with silver edges, suspended amidst red particles on a deep blue bokeh background with heart and star-shaped" />
</figure>

## Start Reverse Engineering Images

To get started using PromptPerfect to reverse engineer image prompts, sign up and try a paid PromptPerfect plan free for seven days. And subscribe to a plan within 24 hours of your first login to get 40% off:

<figure class="kg-card kg-bookmark-card">
<a href="https://promptperfect.jina.ai" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
PromptPerfect - AI Prompt Generator and Optimizer
</div>
<div class="kg-bookmark-description">
Unlock prompt optimization for models like GPT-4, ChatGPT and Midjourney. Generate and refine prompts to perfection, receiving improved outcomes in seconds.
</div>
<div class="kg-bookmark-metadata">
<img src="https://promptperfect.jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">AI Prompt Generator and Optimizer</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://promptperfect.jina.ai/banner.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

You know it’s the only way to keep ahead of those hungry AI leopards!
