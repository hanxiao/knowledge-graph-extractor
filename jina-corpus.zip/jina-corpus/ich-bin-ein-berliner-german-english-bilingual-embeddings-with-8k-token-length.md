---
title: "Ich bin ein Berliner: German-English Bilingual Embeddings with 8K Token Length"
slug: ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length
url: https://cms.jina.ai/ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length/
published_at: 2024-01-15T17:28:14.000+01:00
updated_at: 2024-11-27T06:00:57.000+01:00
reading_time: 5
authors: "Jina AI"
tags: "Press"
excerpt: "Jina AI introduces a German/English bilingual embedding model, featuring an extensive 8,192-token length, specifically designed to support German businesses thriving in the U.S. market."
---

# Ich bin ein Berliner: German-English Bilingual Embeddings with 8K Token Length

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings v3: A Frontier Multilingual Embedding Model
</div>
<div class="kg-bookmark-description">
jina-embeddings-v3 is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-13.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/v3banner-3.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v3</code></span><span style="white-space: pre-wrap;"> has been released on Sept. 18, 2024. The best &lt;1B multilingual embedding model.</span></p></figcaption>
</figure>

**Berlin, Germany - January 15, 2023** – Echoing JFK's iconic 'Ich bin ein Berliner', at Jina AI we're thrilled to bridge languages in our own way. Today, we're proud to announce our latest innovation: `jina-embeddings-v2-base-de`, a German/English embedding model. This state-of-the-art bilingual model is a significant stride forward in language representation, boasting a context length of **8,192 tokens**. What sets it apart is its remarkable efficiency: it achieves top-tier performance while being **only 1/7th the size** of comparable models.

Embeddings are crucial for German businesses looking to expand into the U.S. market. According to the [German American Business Outlook (GABO) 2022](https://www.gaccny.com/en/media/press-releases/news-details/german-american-business-outlook-gabo-2022-companies-in-the-us-remain-profitable), approximately a third of German companies generate over 20% of their global sales and profits in the U.S., with 93% expecting an increase in U.S. sales​​. This trend continues as 93% plan to grow their company's U.S. investments in the next three years, with [85% expecting net sales growth and a significant focus on digital transformation](https://www.globenewswire.com/news-release/2023/02/09/2604561/0/en/SURVEY-SHOWS-GERMAN-COMPANIES-IN-THE-US-PROFIT-FROM-ROBUST-MARKET-SIZE-AND-CUSTOMER-DEMAND.html)​​. Good embeddings can play a pivotal role in this expansion by facilitating better understanding of customer preferences, enabling more effective communication, and positioning culturally resonant products.

Our breakthrough is particularly beneficial for German businesses looking to implement bilingual applications in English-speaking countries. With `jina-embeddings-v2-base-de`, we're excited to see how German companies will innovate and thrive in an increasingly connected world.

## Model Highlights

- **State-of-the-art Performance**: `jina-embeddings-v2-base-de` consistently ranking at the top in relevant benchmarks and leading among open-source models of similar size.
- **Bilingual Model:** This model encodes texts in both German and English, allowing the use of either language as the query or target document in retrieval applications. Texts with equivalent meanings in both languages are mapped to the same embedding space, forming the basis for multilingual applications.
- **Extended Context**: An 8192-token length enables `jina-embeddings-v2-base-de` to support longer texts and document fragments, far surpassing models that only support a few hundred tokens at a time.
- **Compact Size**: `jina-embeddings-v2-base-de` is built for high performance on standard computer hardware. With only 161 million parameters, the entire model is 322MB and fits in the memory of commodity computers. The embeddings themselves are 768 dimensions, a relatively small vector size compared to many models, saving space and run-time for applications.
- **Bias Minimization**: [Recent research](https://aclanthology.org/2023.findings-eacl.89.pdf) shows that multilingual models without specific language training show strong biases towards English grammatical structures in embeddings. Embedding models should be about capturing meaning and not favor sentence pairs that are merely superficially similar.
- **Seamless Integration**: Jina Embeddings v2 models have native integrations with major vector databases, including [MongoDB](https://www.mongodb.com/developer/products/atlas/jina-ai-semantic-search/?ref=jina-ai-gmbh.ghost.io), [Qdrant](https://qdrant.tech/documentation/embeddings/jina-embeddings/), and [Weaviate](https://weaviate.io/developers/weaviate/modules/retriever-vectorizer-modules/text2vec-jinaai), as well as RAG and LLM frameworks such as [Haystack](https://haystack.deepset.ai/integrations/jina) and [LlamaIndex](https://docs.llamaindex.ai/en/stable/examples/embeddings/jinaai_embeddings.html).

## Leading Performance in German NLP

We've put `jina-embeddings-v2-base-de` to the test against four renowned baselines that also support both German and English. These include:

- [Multilingual-E5-large](https://huggingface.co/intfloat/multilingual-e5-large) and [Multilingual-E5-base](https://huggingface.co/intfloat/multilingual-e5-base) from Microsoft
- T-Systems’ [Cross English & German RoBERTa for Sentence Embeddings](https://huggingface.co/T-Systems-onsite/cross-en-de-roberta-sentence-transformer)
- [Sentence-BERT](https://huggingface.co/sentence-transformers/distiluse-base-multilingual-cased-v2) (`distiluse-base-multilingual-cased-v2`)

Our benchmarks include [the MTEB tasks for English](https://huggingface.co/mteb) and our own custom benchmark. Given the lack of a comprehensive benchmark suite for German embeddings, we took the initiative to [develop our own](https://github.com/jina-ai/mteb-de), inspired by the MTEB. We're proud to share our findings and breakthroughs with you here.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/mteb-de" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/mteb-de: MTEB: Massive Text Embedding Benchmark
</div>
<div class="kg-bookmark-description">
MTEB: Massive Text Embedding Benchmark. Contribute to jina-ai/mteb-de development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/a1d1679b83d58c1685db0d4d12d6bb6360edfe08fb0c4a9ebda71b57379853f3/jina-ai/mteb-de" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-image-card kg-width-wide">
<img src="https://cms.jina.ai/content/images/2024/01/image-4.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/01/image-4.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/01/image-4.png 1000w, https://cms.jina.ai/content/images/2024/01/image-4.png 1310w" sizes="(min-width: 1200px) 1200px" width="1310" height="925" alt="A table comparing machine learning model performance with four distinct models listed by name, size in MB, and proficiency in German and English tasks" />
</figure>

### Compact Size, Superior Results

`jina-embeddings-v2-base-de` demonstrates exceptional performance, especially in German language tasks. It outshines the E5 base model while being less than a third of its size. Moreover, it stands toe-to-toe with the E5 large model, which is seven times larger, showcasing its efficiency and power. This efficiency makes `jina-embeddings-v2-base-de` a game-changer, particularly when compared to other popular bi- and multilingual embedding models.

### Excelling in German-English Cross-Language Retrieval

Our model isn't just about size and efficiency; it's also a top performer in English-German cross-language retrieval tasks. This is evident in its performance in various key benchmarks:

- [WikiCLIR](https://www.cl.uni-heidelberg.de/statnlpgroup/wikiclir/), for English to German retrieval
- [STS17](https://huggingface.co/datasets/mteb/sts17-crosslingual-sts), part of the MTEB evaluation for English to German retrieval
- [STS22](https://huggingface.co/datasets/mteb/sts22-crosslingual-sts), for German to English retrieval, also part of MTEB
- [BUCC](https://huggingface.co/datasets/mteb/bucc-bitext-mining), for German to English retrieval, included in MTEB

The performance in these benchmarks, particularly in the MTEB evaluation tests (with the exception of WikiCLIR), underscores the effectiveness of `jina-embeddings-v2-base-de` in handling complex bilingual tasks.

<figure class="kg-card kg-image-card kg-width-wide">
<img src="https://cms.jina.ai/content/images/2024/01/image-6.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/01/image-6.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/01/image-6.png 1000w, https://cms.jina.ai/content/images/2024/01/image-6.png 1275w" sizes="(min-width: 1200px) 1200px" width="1275" height="625" alt="Comparison table of language models with sizes in MB and accuracy percentages for metrics like WikiCLIR and STS17" />
</figure>

## Get API Access

Our offerings for our enterprise users who value privacy and data compliance, including `jina-embeddings-v2-base-de`, are accessible via the Jina Embeddings API:

1.  Visit <a href="https://jina.ai/embeddings" rel="noreferrer">Jina Embeddings API</a> and click on the model dropdown
2.  Select `jina-embeddings-v2-base-de`

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Top-performing, 8192-token context length, $100 for 1.25B tokens, seamless OpenAI alternative, free trial
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/01/image-3.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/01/image-3.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/01/image-3.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/01/image-3.png 1600w, https://cms.jina.ai/content/images/2024/01/image-3.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="1062" alt="Screenshot of technology platform with highlighted language models, code snippets, and options like &#39;Integrate&#39; and &#39;Try out&#39;" />
</figure>

We will make this model available in the AWS Sagemaker marketplace for Amazon cloud users and for download on HuggingFace very soon.

## Jina 8K Embeddings: The Cornerstone of Diverse AI Applications

Embeddings are crucial for a wide range of AI applications, including information retrieval, data quality control, classification, and recommendation. They are fundamental to enhancing numerous AI tasks.

Jina AI is committed to advancing the state-of-the-art in embedding technology, keeping our core AI components transparent, accessible, and affordable to enterprises of all types and sizes that value privacy and data compliance. In addition to `jina-embeddings-v2-base-de`, Jina AI has released state-of-the-art embedding models for [Chinese](https://jina.ai/news/8k-token-length-bilingual-embeddings-break-language-barriers-in-chinese-and-english/) and high-performance [English monolingual models](https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai/). This is part of our mission to make AI technology more inclusive and globally applicable.

We value your feedback. Join our community channel to contribute feedback and stay informed about our advancements. Together, we're shaping a more robust and inclusive AI future.

<figure class="kg-card kg-bookmark-card">
<a href="https://discord.com/invite/AWXCCC6G2P" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Join the Jina AI Discord Server!
</div>
<div class="kg-bookmark-description">
Check out the Jina AI community on Discord - hang out with 4232 other members and enjoy free voice and text chat.
</div>
<div class="kg-bookmark-metadata">
<img src="https://discord.com/assets/images/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Discord</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn.discordapp.com/splashes/1106542220112302130/80f2c2128aefeb55209a5bdb2130bb92.jpg?size=512" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
