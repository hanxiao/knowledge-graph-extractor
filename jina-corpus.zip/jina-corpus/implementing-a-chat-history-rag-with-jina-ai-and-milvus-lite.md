---
title: "Implementing a Chat History RAG with Jina AI and Milvus Lite"
slug: implementing-a-chat-history-rag-with-jina-ai-and-milvus-lite
url: https://cms.jina.ai/implementing-a-chat-history-rag-with-jina-ai-and-milvus-lite/
published_at: 2024-06-03T16:09:33.000+02:00
updated_at: 2024-07-08T21:08:43.000+02:00
reading_time: 6
authors: "Francesco Kruk, Saahil Ognawala"
tags: "Tech Blog"
excerpt: "Enhance your search applications in Python with Jina Embeddings and Reranker and lightweight, easy-to-deploy Milvus Lite."
---

# Implementing a Chat History RAG with Jina AI and Milvus Lite

Developers and operations engineers put a high value on infrastructure that they can easily set up, quickly start, and, later, efficiently deploy in a scaled production environment without additional hassle. For this reason, [<u>Milvus Lite</u>](https://milvus.io/docs/milvus_lite.md), the latest lightweight vector database offering from our partner [<u>Milvus</u>](https://milvus.io/), is an important tool for Python developers to quickly develop search applications, especially when used together with high-quality and easy-to-use search foundation models.

In this article, we’ll describe how Milvus Lite integrates [<u>Jina Embeddings v2</u>](https://jina.ai/embeddings/) and [<u>Jina Reranker v1</u>](https://jina.ai/reranker) using the example of a [<u>Retrieval Augmented Generation (RAG)</u>](https://jina.ai/news/albus-by-springworks-empowering-employees-with-enterprise-search) application built on a fictitious company’s internal public channel chats to let employees get answers to their organization-related questions in an accurate and helpful manner.

## Overview of Milvus Lite, Jina Embeddings and Jina Reranker

Milvus Lite is a new, lightweight version of leading vector database Milvus, which is now also offered as a Python library. Milvus Lite shares the same API as Milvus deployed on Docker or Kubernetes but can be easily installed via a one-line pip command, without setting up a server.

With the integration of Jina Embeddings v2 and Jina Reranker v1 in [<u>pymilvus</u>](https://github.com/milvus-io/pymilvus), Milvus's Python SDK, you now have the option to directly embed documents using the same Python client for any deployment mode of Milvus, including Milvus Lite. You can find details of the Jina Embeddings and Reranker integration on pymilvus’ [<u>documentation pages</u>](https://milvus.io/docs/integrate_with_jina.md).

With its 8k-token context window and multilingual capabilities, Jina Embeddings v2 encodes the broad semantics of text and ensures accurate retrieval. By adding Jina Reranker v1 to the pipeline, you can further refine your results by cross-encoding the retrieved results directly with the query for a deeper contextual understanding.

## Milvus and Jina AI Models in Action

This tutorial will focus on a practical use case: Querying a company's Slack chat history to answer a wide range of questions based on past conversations.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/06/E-R-slack--2-.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/E-R-slack--2-.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/E-R-slack--2-.jpg 1000w, https://cms.jina.ai/content/images/2024/06/E-R-slack--2-.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="900" alt="Flowchart detailing the Rust community&#39;s model training process, featuring steps from the &quot;Next training step?&quot; query through" />
<figcaption><span style="white-space: pre-wrap;">Process flow for querying the Slack data using an example query</span></figcaption>
</figure>

For example, an employee could ask about the next step in some AI training process, as in the process schema above. By using Jina Embeddings, Jina Reranker, and Milvus, we can accurately identify relevant information in the logged Slack messages. This application can level up your workplace productivity by making it easier to access valuable information from past communications.

To generate the answers, we will use [<u>Mixtral 7B Instruct</u>](https://huggingface.co/mistralai/Mixtral-8x7B-Instruct-v0.1) through [<u>HuggingFace’s integration in Langchain</u>](https://python.langchain.com/v0.1/docs/integrations/llms/huggingface_endpoint/). To use the model, you need a HuggingFace access token that you can generate as described [<u>here</u>](https://huggingface.co/docs/hub/en/security-tokens).

You can follow along in [<u>Colab</u>](https://colab.research.google.com/github/jina-ai/workshops/blob/main/notebooks/embeddings/milvus/milvus_lite_jina_integration.ipynb) or by [<u>downloading the notebook</u>](https://raw.githubusercontent.com/jina-ai/workshops/main/notebooks/embeddings/milvus/milvus_lite_jina_integration.ipynb).

<figure class="kg-card kg-bookmark-card">
<a href="https://colab.research.google.com/github/jina-ai/workshops/blob/main/notebooks/embeddings/milvus/milvus_lite_jina_integration.ipynb" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Google Colab
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://ssl.gstatic.com/colaboratory-static/common/0d8af74d4089ab8b6d127bd74854be98/img/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://colab.research.google.com/img/colab_favicon_256px.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

### About the Dataset

The dataset used in this tutorial was generated using GPT-4 and is meant to replicate the chat histories of Blueprint AI’s Slack channels. Blueprint is a fictitious AI startup developing its own foundational models. You can download the dataset <a href="https://raw.githubusercontent.com/jina-ai/workshops/main/notebooks/embeddings/milvus/chat_history.json" rel="noreferrer"><u>here</u></a>.

The data is organized in *channels*, each representative of a collection of related Slack threads. Each channel has a topic label, one of ten topic options: *model distribution*, *model training*, *model fine-tuning*, *ethics and bias mitigation*, *user feedback*, *sales*, *marketing*, *model onboarding*, *creative design*, and *product management*. One participant is known as the "expert user". You can use this field to validate the results of querying for the most expert user in a topic, which we will show you how to do below.

Each channel also contains a chat history with conversation threads of up to 100 messages per channel. Each message in the dataset contains the following information:

- The **user** that sent the message
- The **message text** sent by the user
- The **timestamp** of the message
- The **name of the file** the user might have attached to the message
- The **message ID**
- The **parent message ID** if the message was within a thread originated from another message

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/06/image-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/image-1.png 600w, https://cms.jina.ai/content/images/2024/06/image-1.png 780w" sizes="(min-width: 720px) 720px" width="780" height="450" alt="Diagram showing the structure of a messaging system, detailing the relationship between &#39;Channel&#39; and &#39;Message&#39; entities, wit" />
<figcaption><span style="white-space: pre-wrap;">A UML diagram of the chat data's structure.</span></figcaption>
</figure>

### Set up the Environment

To start, install all the necessary components:

``` Python
pip install -U pymilvus
pip install -U "pymilvus[model]"
pip install langchain
pip install langchain-community
```

Download the dataset:

``` Python
import os

if not os.path.exists("chat_history.json"):
    !wget https://raw.githubusercontent.com/jina-ai/workshops/main/notebooks/embeddings/milvus/chat_history.json
```

Set your Jina AI API Key in an environment variable. You can generate one [<u>here</u>](https://jina.ai/reranker?ref=jina-ai-gmbh.ghost.io).

``` Python
import os
import getpass

os.environ["JINAAI_API_KEY"] = getpass.getpass(prompt="Jina AI API Key: ")
```

Do the same for your Hugging Face Token. You can find how to generate one [<u>here</u>](https://huggingface.co/docs/hub/en/security-tokens). Make sure that it is set to `READ` to access the [<u>Hugging Face Hub</u>](https://huggingface.co/docs/hub/en/index).

``` Python
os.environ["HUGGINGFACEHUB_API_TOKEN"] = getpass.getpass(prompt="Hugging Face Token: ")
```

### Create the Milvus Collection

Create the Milvus Collection to index the data:

``` Python
from pymilvus import MilvusClient, DataType

# Specify a local file name as uri parameter of MilvusClient to use Milvus Lite
client = MilvusClient("milvus_jina.db")

schema = MilvusClient.create_schema(
    auto_id=True,
    enable_dynamic_field=True,
)

schema.add_field(field_name="id", datatype=DataType.INT64, description="The Primary Key", is_primary=True)
schema.add_field(field_name="embedding", datatype=DataType.FLOAT_VECTOR, description="The Embedding Vector", dim=768)

index_params = client.prepare_index_params()
index_params.add_index(field_name="embedding", metric_type="COSINE", index_type="AUTOINDEX")

client.create_collection(collection_name="milvus_jina", schema=schema, index_params=index_params)
```

### Prepare the Data

Parse the chat history and extract the metadata:

``` Python
import json

with open("chat_history.json", "r", encoding="utf-8") as file:
    chat_data = json.load(file)

messages = []
metadatas = []

for channel in chat_data:
  chat_history = channel["chat_history"]
  chat_topic = channel["topic"]
  chat_expert = channel["expert_user"]
  for message in chat_history:
    text = f"""{message["user"]}: {message["message"]}"""
    messages.append(text)
    meta = {
        "time_stamp": message["time_stamp"],
        "file_name": message["file_name"],
        "parent_message_nr": message["parent_message_nr"],
        "channel": chat_topic,
        "expert": True if message["user"] == chat_expert else False
    }
    metadatas.append(meta)
```

### Embed the Chat Data

Create embeddings for each message using Jina Embeddings v2 to retrieve relevant chat information:

``` Python
from pymilvus.model.dense import JinaEmbeddingFunction

jina_ef = JinaEmbeddingFunction("jina-embeddings-v2-base-en")

embeddings = jina_ef.encode_documents(messages)
```

### Index the Chat Data

Index the messages, their embeddings, and the related metadata:

``` Python
collection_data = [{
    "message": message,
    "embedding": embedding,
    "metadata": metadata
} for message, embedding, metadata in zip(messages, embeddings, metadatas)]

data = client.insert(
    collection_name="milvus_jina",
    data=collection_data
)
```

### Query the Chat History

Time to ask a question:

``` Python
query = "Who knows the most about encryption protocols in my team?"
```

Now embed the query and retrieve relevant messages. Here we retrieve the five most relevant messages and rerank them using Jina Reranker v1:

``` Python
from pymilvus.model.reranker import JinaRerankFunction

query_vectors = jina_ef.encode_queries([query])

results = client.search(
    collection_name="milvus_jina",
    data=query_vectors,
    limit=5,
)

results = results[0]

ids = [results[i]["id"] for i in range(len(results))]

results = client.get(
    collection_name="milvus_jina",
    ids=ids,
    output_fields=["id", "message", "metadata"]
)

jina_rf = JinaRerankFunction("jina-reranker-v1-base-en")

documents = [results[i]["message"] for i in range(len(results))]
reranked_documents = jina_rf(query, documents)

reranked_messages = []
for reranked_document in reranked_documents:
  idx = reranked_document.index
  reranked_messages.append(results[idx])
```

Lastly, generate an answer to the query using Mixtral 7B Instruct and the reranked messages as context:

``` Python
from langchain.prompts import PromptTemplate
from langchain_community.llms import HuggingFaceEndpoint

llm = HuggingFaceEndpoint(repo_id="mistralai/Mixtral-8x7B-Instruct-v0.1")

prompt = """<s>[INST] Context information is below.\\n
        It includes the five most relevant messages to the query, sorted based on their relevance to the query.\\n
        ---------------------\\n
        {context_str}\\\\n
        ---------------------\\n
        Given the context information and not prior knowledge,
        answer the query. Please be brief, concise, and complete.\\n
        If the context information does not contain an answer to the query,
        respond with \\"No information\\".\\n
        Query: {query_str}[/INST] </s>"""

prompt = PromptTemplate(template=prompt, input_variables=["query_str", "context_str"])

llm_chain = prompt | llm

answer = llm_chain.invoke({"query_str":query, "context_str":reranked_messages})

print(f"\n\nANSWER:\n\n{answer}")
```

The answer to our question is:

> “Based on the context information, User5 seems to be the most knowledgeable about encryption protocols in your team. They have mentioned that the new protocols enhance data security significantly, especially for cloud deployments.”

If you read through the messages in `chat_history.json`, you can verify for yourself if User5 is the most expert user.

## Summary

We have seen how to set up Milvus Lite, embed chat data using Jina Embeddings v2, and refine search results with Jina Reranker v1, all within a practical use case of searching a Slack chat history. Milvus Lite simplifies Python-based application development without the need for complex server setups. Its integration with Jina Embeddings and Reranker aims to boost productivity by making it easier to access valuable information from your workplace.

## **Use Jina AI Models and Milvus Now**

<a href="https://milvus.io/docs/integrate_with_jina.md" rel="noreferrer"><u>Milvus Lite</u></a> with integrated [<u>Jina Embeddings</u>](https://jina.ai/embeddings) and [<u>Reranker</u>](https://jina.ai/reranker) provides you with a complete processing pipeline, ready to use with just a few lines of code.

We would love to hear about your use cases and talk about how the Jina AI Milvus extension can fit your business needs. Contact us via [<u>our website</u>](https://jina.ai/contact-sales) or [<u>our Discord channel</u>](https://discord.jina.ai/) to share your feedback and stay up-to-date with our latest models. For questions about Milvus and Jina AI's integration, join the [<u>Milvus community</u>](https://milvus.io/community).
