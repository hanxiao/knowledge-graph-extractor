---
title: "Jina AI’s 8K Embedding Models Hit AWS Marketplace for On-Prem Deployment"
slug: jina-ai-8k-embedding-models-hit-aws-marketplace-for-on-prem-deployment
url: https://cms.jina.ai/jina-ai-8k-embedding-models-hit-aws-marketplace-for-on-prem-deployment/
published_at: 2023-11-20T15:32:57.000+01:00
updated_at: 2024-01-24T16:24:19.000+01:00
reading_time: 4
authors: "Jina AI"
tags: "Press"
excerpt: "Jina AI launches 8K token length embedding v2 models on AWS marketplace, elevating enterprise AI deployments with EU-engineered innovation and a commitment to data sovereignty."
---

# Jina AI’s 8K Embedding Models Hit AWS Marketplace for On-Prem Deployment

**Berlin, Germany - November 20, 2023** - Catering to enterprise customers, Jina AI has released [Embeddings v2](https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai/) on AWS SageMaker, a milestone in accessible, top-tier AI solutions. Enterprise users can now search for `jina-embeddings-v2-base/small` on the AWS Marketplace and deploy them directly to their own AWS accounts. As a part of the AWS Startups program, this release underscores the collaboration between Jina AI's innovation and AWS's commitment to supporting groundbreaking startups, marking a significant advancement in AI development.

<figure class="kg-card kg-image-card kg-card-hascaption">
<a href="https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy"><img src="https://cms.jina.ai/content/images/2023/11/image-60.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-60.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-60.png 1000w, https://cms.jina.ai/content/images/size/w1600/2023/11/image-60.png 1600w, https://cms.jina.ai/content/images/2023/11/image-60.png 2134w" sizes="(min-width: 720px) 720px" width="2000" height="1556" alt="AWS Marketplace page for Jina AI with search options, product listings, and descriptions of two Jina Embeddings models" /></a>
<figcaption><span style="white-space: pre-wrap;">Enterprise users can now search jina-embeddings-v2-base/small on the AWS marketplace and deploy them directly on their own AWS account.</span></figcaption>
</figure>

## Superior Models on a Robust Platform

- *SageMaker Integration*: With global availability on the AWS SageMaker Marketplace, Jina AI underscores its dedication to enterprise users, providing them with an effortless way to build applications using our advanced embedding models.
- *Seamless Deployment*: Enterprises can now easily deploy Jina Embedding v2 models as SageMaker endpoints, bypassing the complexity associated with custom infrastructure setups.
- *Cost-Effective Licensing*: The English [base](https://aws.amazon.com/marketplace/pp/prodview-egsf72y46ursa) and [small](https://aws.amazon.com/marketplace/pp/prodview-jwbhofu3iesos) models are available *without licensing fees*. Clients incur costs only for their AWS instances, ensuring a privacy-first, cost-effective solution within their VPC.

### Tailored Solutions for Varied Use Cases

- *Model Diversity*: With a [0.27GB base model](https://aws.amazon.com/marketplace/pp/prodview-egsf72y46ursa) and a [0.07GB small model](https://aws.amazon.com/marketplace/pp/prodview-jwbhofu3iesos), Jina AI provides tailored solutions for various needs, from in-depth analytics to lightweight applications.
- *Use Cases*: The base model is designed for comprehensive semantic representation, ideal for enterprise search and content discovery, while the small model caters to mobile and edge devices, optimizing for speed and efficiency.

Commenting on this significant milestone, Dr. Han Xiao, CEO of Jina AI, offered the following insights:

> Launching Jina AI's 8K Context Length v2 Embedding Models on AWS Marketplace, we advance industry standards for private AI solutions. Developed in Germany, this pivotal release emphasizes data sovereignty and customer-centric innovation, addressing today's needs and shaping future secure, private AI deployments.

Jina AI aims to make continuous strides towards privacy-aware, state-of-the-art AI, as evident from its plans.

## Why Jina Embeddings v2: A Leap in AI Capability

- *Extended Context Length*: Jina Embeddings v2 models support an [unprecedented 8K](https://arxiv.org/abs/2310.19923) (8192 tokens) context length, allowing for a full understanding of longer documents.
- *Open Source Pioneer*: Jina AI takes pride in offering the only open-source model with a context length that matches OpenAI’s proprietary models, broadening access to advanced AI.
- *Benchmark Leadership*: On the Massive Text Embedding Benchmark (MTEB) [leaderboard](https://huggingface.co/spaces/mteb/leaderboard), our models boast performance on par with industry-leading models, attesting to our commitment to excellence.

### Performance vs. OpenAI's text-embedding-ada002

Below is a comparative performance snapshot that showcases the robust capabilities of Jina Embeddings v2:

|  |  |  |
|----|----|----|
| Model | text-embedding-ada-002 | jina-embeddings-v2-base-en |
| Rank | **18** | 21 |
| Model Size (GB) | Unknown | 0.27 |
| Average (56 datasets) | **60.99** | 60.38 |
| Embedding Dimensions | 1536 | **768** |
| Sequence Length | 8191 | 8192 |
| Classification Average (12 datasets) | 70.93 | **73.45** |
| Pair Classification Average (3 datasets) | 84.89 | **85.38** |
| Summarization Average (1 dataset) | 30.8 | **31.6** |
| Retrieval Average (15 datasets) | **49.25** | 47.87 |

Jina AI's base model excels particularly in Classification and Pair Classification tasks, underscoring its value in diverse applications ranging from document analysis to recommendation systems.

## Get Started with Jina Embeddings v2 on AWS

To begin using Jina Embeddings v2, visit the [AWS Marketplace listings](https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy) and select the model that best fits your needs.

<figure class="kg-card kg-bookmark-card">
<a href="https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
AWS Marketplace: Jina AI
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://d32gc0xr2ho6pa.cloudfront.net/img/general/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://d32gc0xr2ho6pa.cloudfront.net/img/general/v2/socialPreview.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

These sample notebooks can help users get started with Jina Embeddings v2 models:

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://github.com/jina-ai/jina-sagemaker/blob/main/notebooks/Real-time%20inference.ipynb" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jina-sagemaker/notebooks/Real-time inference.ipynb at main · jina-ai/jina-sagemaker
</div>
<div class="kg-bookmark-description">
Jina Embedding Models on AWS SageMaker. Contribute to jina-ai/jina-sagemaker development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/91499715ca0bec59273499acfddecae62d0a3833146f7ceaf9968656007b16f0/jina-ai/jina-sagemaker" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">Real-time inference on SageMaker</span></p></figcaption>
</figure>

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://github.com/jina-ai/jina-sagemaker/blob/main/notebooks/Batch%20transform.ipynb" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jina-sagemaker/notebooks/Batch transform.ipynb at main · jina-ai/jina-sagemaker
</div>
<div class="kg-bookmark-description">
Jina Embedding Models on AWS SageMaker. Contribute to jina-ai/jina-sagemaker development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/91499715ca0bec59273499acfddecae62d0a3833146f7ceaf9968656007b16f0/jina-ai/jina-sagemaker" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">Embedding multiple sentences in a batch with SageMaker</span></p></figcaption>
</figure>

## Coming Soon: Multilingual Embeddings and More

Looking ahead, Jina AI is already deep in developing multilingual embedding models, making them available to its enterprise clients for private deployment on various cloud service providers (CSPs). With the imminent launch of these models, Jina AI is set to bridge language barriers, unlocking global opportunities for its clients.

## About Jina AI GmbH

Located at <a href="https://maps.app.goo.gl/rAZ1QiqoKp49KZAg6" rel="noreferrer">Ohlauer Str. 43 (1st floor), zone A, 10999 Berlin, Germany</a>, Jina AI is at the vanguard of reshaping the landscape of multimodal artificial intelligence. For inquiries, please reach out at contact@jina.ai.  
