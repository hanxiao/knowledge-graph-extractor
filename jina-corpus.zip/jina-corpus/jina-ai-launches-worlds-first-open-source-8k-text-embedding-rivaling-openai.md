---
title: "Jina AI Launches World's First Open-Source 8K Text Embedding, Rivaling OpenAI"
slug: jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai
url: https://cms.jina.ai/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai/
published_at: 2023-10-25T07:43:17.000+02:00
updated_at: 2024-11-27T06:00:13.000+01:00
reading_time: 4
authors: "Jina AI"
tags: "Press"
excerpt: "Jina AI introduces jina-embeddings-v2, the world's first open-source model boasting an 8K context length. Matching the prowess of OpenAI's proprietary models, this innovation is now publicly accessible on Huggingface, signaling a significant milestone in the landscape of text embeddings."
---

# Jina AI Launches World's First Open-Source 8K Text Embedding, Rivaling OpenAI

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings v3: A Frontier Multilingual Embedding Model
</div>
<div class="kg-bookmark-description">
jina-embeddings-v3 is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-13.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/v3banner-3.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v3</code></span><span style="white-space: pre-wrap;"> has been released on Sept. 18, 2024. The best &lt;1B multilingual embedding model.</span></p></figcaption>
</figure>

**Berlin, Germany - October 25, 2023** – Jina AI, the Berlin-based artificial intelligence company, is thrilled to announce the launch of its second-generation text embedding model: **`jina-embeddings-v2`**. This cutting-edge model is now the only open-source offering that supports an impressive 8K (8192 tokens) context length, putting it on par with OpenAI's proprietary model, `text-embedding-ada-002`, in terms of both capabilities and performance <a href="https://huggingface.co/spaces/mteb/leaderboard" rel="noreferrer">on the Massive Text Embedding Benchmark (MTEB) leaderboard.</a>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Start with 1M free tokens. Top-performing, 8192 context length bilingual embeddings for your search and RAG systems.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## **Benchmarking Against the Best 8K Model from Open AI**

When directly compared with OpenAI's 8K model `text-embedding-ada-002`, `jina-embeddings-v2` showcases its mettle. Below is a performance comparison table, highlighting areas where `jina-embeddings-v2` particularly excels:

| Rank | Model | Model Size (GB) | Embedding Dimensions | Sequence Length | Average (56 datasets) | Classification Average (12 datasets) | Reranking Average (4 datasets) | Retrieval Average (15 datasets) | Summarization Average (1 dataset) |
|----|----|----|----|----|----|----|----|----|----|
| 15 | text-embedding-ada-002 | Unknown | 1536 | 8191 | 60.99 | 70.93 | 84.89 | 56.32 | 30.8 |
| 17 | jina-embeddings-v2-base-en | 0.27 | 768 | 8192 | 60.38 | 73.45 | 85.38 | 56.98 | 31.6 |

Notably, `jina-embedding-v2` outperforms its OpenAI counterpart in Classification Average, Reranking Average, Retrieval Average, and Summarization Average.

## **Features and Benefits**

Jina AI’s dedication to innovation is evident in this latest offering:

- **From Scratch to Superiority**: The `jina-embeddings-v2` was built from the ground up. Over the last three months, the team at Jina AI engaged in intensive R&D, data collection, and tuning. The outcome is a model that marks a significant leap from its predecessor.
- **Unlocking Extended Context Potential with 8K**: `jina-embeddings-v2` isn’t just a technical feat; its 8K context length opens doors to new industry applications:
  - **Legal Document Analysis**: Ensure every detail in extensive legal texts is captured and analyzed.
  - **Medical Research**: Embed scientific papers holistically for advanced analytics and discovery.
  - **Literary Analysis**: Dive deep into long-form content, capturing nuanced thematic elements.
  - **Financial Forecasting**: Attain superior insights from detailed financial reports.
  - **Conversational AI**: Improve chatbot responses to intricate user queries.

Benchmarking shows that in several datasets, this extended context enabled `jina-embeddings-v2` to outperform other leading base embedding models, emphasizing the practical advantages of longer context capabilities.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/10/Screenshot-from-2023-10-23-17-41-40.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/10/Screenshot-from-2023-10-23-17-41-40.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/10/Screenshot-from-2023-10-23-17-41-40.png 1000w, https://cms.jina.ai/content/images/size/w1600/2023/10/Screenshot-from-2023-10-23-17-41-40.png 1600w, https://cms.jina.ai/content/images/2023/10/Screenshot-from-2023-10-23-17-41-40.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="647" alt="Two color-coded bar charts showing performance comparisons of various models based on NDCG@10% values for retrieval and clustering tasks" />
</figure>

- **Availability**: Both models are freely available for download on Huggingface:
  - **Base Model** (0.27G) - Designed for heavy-duty tasks requiring higher accuracy, like academic research or business analytics.
  - **Small Model** (0.07G) - Crafted for lightweight applications such as mobile apps or devices with limited computing resources.
- **Size Options for Different Needs**: Understanding the diverse needs of the AI community, Jina AI offers two versions of the model:

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-embeddings-v2-base-en" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-embeddings-v2-base-en · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-embeddings-v2-base-en.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-embeddings-v2-small-en" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-embeddings-v2-small-en · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-embeddings-v2-small-en.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

In reflecting on the journey and significance of this launch, Dr. Han Xiao, CEO of Jina AI, shared his thoughts:

> *"In the ever-evolving world of AI, staying ahead and ensuring open access to breakthroughs is paramount. With `jina-embeddings-v2`, we've achieved a significant milestone. Not only have we developed **the world's first open-source 8K context length model**, but we have also brought it to a performance level on par with industry giants like OpenAI. Our mission at Jina AI is clear: we aim to democratize AI and empower the community with tools that were once confined to proprietary ecosystems. Today, I am proud to say, we have taken a giant leap towards that vision."*

This pioneering spirit is evident in Jina AI's forward-looking plans.

## **A Glimpse into the Future**

Jina AI is committed to leading the forefront of innovation in AI. Here’s what’s next on their roadmap:

- **Academic Insights**: An academic paper detailing the technical intricacies and benchmarks of `jina-embeddings-v2` will soon be published, allowing the AI community to gain deeper insights.
- **API Development**: The team is in the advanced stages of developing an OpenAI-like embeddings API platform. This will provide users with the capability to effortlessly scale the embedding model according to their needs.
- **Language Expansion**: Venturing into multilingual embeddings, Jina AI is setting its sights on launching German-English models, further expanding its repertoire.

------------------------------------------------------------------------

About Jina AI GmbH:  
Located at Ohlauer Str. 43 (1st floor), zone A, 10999 Berlin, Germany, Jina AI is at the vanguard of reshaping the landscape of multimodal artificial intelligence. For inquiries, please reach out at contact@jina.ai.
