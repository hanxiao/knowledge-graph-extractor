---
title: "Jina CLIP v1: A Truly Multimodal Embeddings Model for Text and Image"
slug: jina-clip-v1-a-truly-multimodal-embeddings-model-for-text-and-image
url: https://cms.jina.ai/jina-clip-v1-a-truly-multimodal-embeddings-model-for-text-and-image/
published_at: 2024-06-05T11:42:02.000+02:00
updated_at: 2024-11-28T08:20:59.000+01:00
reading_time: 9
authors: "Sofia Vasileva, Scott Martens, Susana Guzmán"
tags: "Press"
excerpt: "Jina AI's new multimodal embedding model not only outperforms OpenAI CLIP in text-image retrieval, it's a solid image embedding model and state-of-the-art text embedding model at the same time. You don't need different models for different modalities any more."
---

# Jina CLIP v1: A Truly Multimodal Embeddings Model for Text and Image

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/news/jina-clip-v2-multilingual-multimodal-embeddings-for-text-and-images" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina CLIP v2: Multilingual Multimodal Embeddings for Text and Images
</div>
<div class="kg-bookmark-description">
Jina-CLIP v2, a 0.9B multimodal embedding model with multilingual support of 89 languages, high image resolution at 512x512, and Matryoshka representations.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-12.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Your Search Foundation, Supercharged.</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/clipv2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;"> has been released on Nov. 22, 2024!</span></p></figcaption>
</figure>

Jina CLIP v1 (`jina-clip-v1`) is a new multimodal embedding model that extends the capabilities of OpenAI’s [original CLIP model](https://openai.com/index/clip/). With this new model, users have a single embedding model that delivers state-of-the-art performance in both text-only and text-image cross-modal retrieval. Jina AI has improved on OpenAI CLIP’s performance by 165% in text-only retrieval, and 12% in image-to-image retrieval, with identical or mildly better performance in text-to-image and image-to-text tasks. This enhanced performance makes Jina CLIP v1 indispensable for working with multimodal inputs.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

`jina-clip-v1` improves on OpenAI CLIP in <a href="#compare_table" rel="noreferrer">every category of retrieval</a>.

</div>

</div>

In this article, we will first discuss the shortcomings of the original CLIP model and how we have addressed them using a unique co-training method. Then, we will demonstrate the effectiveness of our model on various retrieval benchmarks. Finally, we will provide detailed instructions on how users can get started with Jina CLIP v1 via our Embeddings API and Hugging Face.

## The CLIP Architecture for Multimodal AI

In January 2021, OpenAI released the [CLIP](https://openai.com/index/clip/) (Contrastive Language–Image Pretraining) model. CLIP has a straightforward yet ingenious architecture: it combines two embedding models, one for texts and one for images, into a single model with a single output embedding space. Its text and image embeddings are directly comparable to each other, making the distance between a text embedding and an image embedding proportionate to how well that text describes the image, and vice versa.

This has proven to be very useful in multimodal information retrieval and zero-shot image classification. Without further special training, CLIP performed well at placing images into categories with natural language labels.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/180-1.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/180-1.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/180-1.jpg 1000w, https://cms.jina.ai/content/images/2024/06/180-1.jpg 1600w" sizes="(min-width: 720px) 720px" width="1600" height="900" alt="Diagram illustrating image to text translation using an astronaut on Mars with a red moon as an example." />
</figure>

The text embedding model in the original CLIP was a custom neural network with only 63 million parameters. On the image side, OpenAI released CLIP with a selection of <a href="https://huggingface.co/docs/transformers/model_doc/resnet" rel="noopener noreferrer">ResNet</a> and <a href="https://huggingface.co/docs/transformers/en/model_doc/vit" rel="noopener noreferrer">ViT models</a>. Each model was pre-trained for its individual modality and then trained with captioned images to produce similar embeddings for prepared image-text pairs.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/Blog-images--1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/Blog-images--1-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/Blog-images--1-.png 1000w, https://cms.jina.ai/content/images/2024/06/Blog-images--1-.png 1600w" sizes="(min-width: 720px) 720px" width="1600" height="900" alt="Flowchart with text &quot;Embedding Space&quot;, linked to &quot;Image Encoder&quot; and &quot;Text Encoder&quot;, with a &quot;Distracted boyfriend&quot; label." />
</figure>

This approach yielded impressive results. Particularly notable is its zero-shot classification performance. For example, even though the training data did not include labeled images of [astronauts](https://docs.vultr.com/zero-shot-image-classification-using-openai-clip), CLIP could correctly identify pictures of astronauts based on its understanding of related concepts in texts and images.

However, OpenAI’s CLIP has two important drawbacks:

- First is its very limited text input capacity. It can take a maximum 77 tokens of input, but [empirical analysis shows](https://arxiv.org/abs/2403.15378) that in practice it doesn’t use more than 20 tokens to produce its embeddings. This is because CLIP was trained from images with captions, and captions tend to be very short. This is in contrast to current text embedding models which support several thousand tokens.
- Second, the performance of its text embeddings in text-only retrieval scenarios is very poor. Image captions are a very limited kind of text, and do not reflect the broad array of use cases a text embedding model would be expected to support.

In most real use cases, text-only and image-text retrieval are combined or at least both are available for tasks. Maintaining a second embeddings model for text-only tasks effectively doubles the size and complexity of your AI framework.

Jina AI’s new model addresses these issues directly, and `jina-clip-v1` takes advantage of the progress made in the last several years to bring state-of-the-art performance to tasks involving all combinations of text and image modalities.

## Introducing Jina CLIP v1

Jina CLIP v1 retains the OpenAI’s original CLIP schema: two models co-trained to produce output in the same embedding space.

For text encoding, we adapted the [Jina BERT v2](https://jina.ai/news/jina-embeddings-2-the-best-solution-for-embedding-long-documents/) architecture used in the [Jina Embeddings v2 models](https://jina.ai/embeddings/). This architecture supports a state-of-the-art 8k token input window and outputs 768-dimensional vectors, producing more accurate embeddings from longer texts. This is more than 100 times the 77 token input supported in the original CLIP model.

For image embeddings, we are using the latest model from the Beijing Academy for Artificial Intelligence: the [`EVA-02` model](https://github.com/baaivision/EVA/tree/master/EVA-02). We have empirically compared a number of image AI models, testing them in cross-modal contexts with similar pre-training, and `EVA-02`clearly outperformed the others. It’s also comparable to the Jina BERT architecture in model size, so that compute loads for image and text processing tasks are roughly identical.

These choices produce important benefits for users:

- Better performance on all benchmarks and all modal combinations, and especially large improvements in text-only embedding performance.
- `EVA-02`'s empirically superior performance both in image-text and image-only tasks, with the added benefit of Jina AI’s additional training, improving image-only performance.
- Support for much longer text inputs. [Jina Embeddings’ 8k token](https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai/) input support makes it possible to process detailed textual information and correlate it with images.
- A large net savings in space, compute, code maintenance, and complexity because this multimodal model is highly performant even in non-multimodal scenarios.

### Training

Part of our recipe for high-performance multimodal AI is our training data and procedure. We notice that the very short length of texts used in image captions is the major cause of poor text-only performance in CLIP-style models, and our training is explicitly designed to remedy this.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/06/dark-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/06/dark-1.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/06/dark-1.png 1000w, https://cms.jina.ai/content/images/2024/06/dark-1.png 1600w" sizes="(min-width: 720px) 720px" width="1600" height="900" alt="Flowchart illustrating optimization of text and caption-image similarity in three tasks, using a model and encoders, ending i" />
</figure>

Training takes place in three steps:

1.  Use captioned image data to learn to align image and text embeddings, interleaved with text pairs with similar meanings. This co-training jointly optimizes for the two kinds of tasks. The text-only performance of the model declines during this phase, but not as much as if we had trained with only image-text pairs.
2.  Train using synthetic data which aligns images with larger texts, generated by an AI model, that describes the image. Continue training with text-only pairs at the same time. During this phase, the model learns to attend to larger texts in conjunction with images.
3.  Use text triplets with <a href="https://finetuner.jina.ai/advanced-topics/negative-mining/" rel="noreferrer">hard negatives</a> to further improve text-only performance by learning to make finer semantic distinctions. At the same time, continue training using synthetic pairs of images and long texts. During this phase, text-only performance improves dramatically without the model losing any image-text abilities.

For more information on the details of training and model architecture, please read [our recent paper](https://arxiv.org/abs/2405.20204):

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2405.20204" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina CLIP: Your CLIP Model Is Also Your Text Retriever
</div>
<div class="kg-bookmark-description">
Contrastive Language-Image Pretraining (CLIP) is widely used to train models to align images and texts in a common embedding space by mapping them to fixed-sized vectors. These models are key to multimodal information retrieval and related tasks. However, CLIP models generally underperform in text-only tasks compared to specialized text models. This creates inefficiencies for information retrieval systems that keep separate embeddings and models for text-only and multimodal tasks. We propose a novel, multi-task contrastive training method to address this issue, which we use to train the jina-clip-v1 model to achieve the state-of-the-art performance on both text-image and text-text retrieval tasks.
</div>
<div class="kg-bookmark-metadata">
<img src="https://arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Andreas Koukounas</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## New State-of-the-Art in Multimodal Embeddings

We evaluated Jina CLIP v1’s performance across text-only, image-only, and cross-modal tasks involving both input modalities. We used the [MTEB retrieval benchmark](https://huggingface.co/blog/mteb) to evaluate text-only performance. For image-only tasks, we used the [CIFAR-100](https://www.cs.toronto.edu/~kriz/cifar.html) benchmark. For cross-model tasks, we evaluate on [Flickr8k](https://www.kaggle.com/datasets/adityajn105/flickr8k), [Flickr30K](https://www.kaggle.com/datasets/adityajn105/flickr30k), and [MSCOCO Captions](https://arxiv.org/abs/1504.00325), which are included in the [CLIP Benchmark](https://arxiv.org/abs/2203.05796).

The results are summarized in the table below:

<table id="compare_table">
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr>
<th>Model</th>
<th>Text-Text</th>
<th>Text-to-Image</th>
<th>Image-to-Text</th>
<th>Image-Image</th>
</tr>
</thead>
<tbody>
<tr>
<td>jina-clip-v1</td>
<td>0.429</td>
<td>0.899</td>
<td>0.803</td>
<td>0.916</td>
</tr>
<tr>
<td>openai-clip-vit-b16</td>
<td>0.162</td>
<td>0.881</td>
<td>0.756</td>
<td>0.816</td>
</tr>
<tr style="font-weight:bold">
<td>% increase<br />
vs OpenAI CLIP</td>
<td>165%</td>
<td>2%</td>
<td>6%</td>
<td>12%</td>
</tr>
</tbody>
</table>

You can see from these results that `jina-clip-v1` outperforms OpenAI’s original CLIP in all categories, and is dramatically better in text-only and image-only retrieval. Averaged over all categories, this is a 46% improvement in performance.

You can find a more detailed evaluation in [our recent paper](https://arxiv.org/abs/2405.20204).

## Getting Started with Embeddings API

You can easily integrate Jina CLIP v1 into your applications using the [Jina Embeddings API](https://jina.ai/embeddings).

The code below shows you how to call the API to get embeddings for texts and images, using the `requests` package in Python. It passes a text string and a URL to an image to the Jina AI server and returns both encodings.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

☝️

</div>

<div class="kg-callout-text">

Remember to replace `<YOUR_JINA_AI_API_KEY>` with an activated Jina API key. You can get a trial key with a million free tokens from the [Jina Embeddings web page](https://jina.ai/embeddings/#apiform).

</div>

</div>

``` python
import requests
import numpy as np
from numpy.linalg import norm

cos_sim = lambda a,b: (a @ b.T) / (norm(a)*norm(b))

url = 'https://api.jina.ai/v1/embeddings'

headers = {
  'Content-Type': 'application/json',
  'Authorization': 'Bearer <YOUR_JINA_AI_API_KEY>'
}

data = {
  'input': [
     {"text": "Bridge close-shot"},
     {"url": "https://fastly.picsum.photos/id/84/1280/848.jpg?hmac=YFRYDI4UsfbeTzI8ZakNOR98wVU7a-9a2tGF542539s"}],
  'model': 'jina-clip-v1',
  'encoding_type': 'float'
}

response = requests.post(url, headers=headers, json=data)
sim = cos_sim(np.array(response.json()['data'][0]['embedding']), np.array(response.json()['data'][1]['embedding']))
print(f"Cosine text<->image: {sim}")
```

### Integration with major LLM Frameworks

Jina CLIP v1 is already available for <a href="https://www.llamaindex.ai/" rel="noreferrer">LlamaIndex</a> and <a href="https://www.langchain.com/" rel="noreferrer">LangChain</a>:

- [LlamaIndex](https://docs.llamaindex.ai/en/stable/examples/embeddings/jinaai_embeddings/): Use `JinaEmbedding` with the `MultimodalEmbedding` base class, and invoke `get_image_embeddings` or `get_text_embeddings` .
- [LangChain](https://python.langchain.com/v0.1/docs/integrations/text_embedding/jina/): Use `JinaEmbeddings`, and invoke `embed_images` or `embed_documents`.

### Pricing

Both text and image inputs are charged by token consumption.

For text in English, [we have empirically calculated](https://jina.ai/news/a-deep-dive-into-tokenization/) that on average you will need 1.1 tokens for every word.

For images, we count the number of 224x224 pixel tiles required to cover your image. Some of these tiles may be partly blank but count just the same. Each tile costs 1,000 tokens to process.

**Example**

For an image with dimensions 750x500 pixels:

1.  The image is divided into 224x224 pixel tiles.
    1.  To calculate the number of tiles, take the width in pixels and divide by 224, then round up to the nearest integer.  
        750/224 ≈ 3.35 → 4
    2.  Repeat for the height in pixels:  
        500/224 ≈ 2.23 → 3
2.  The total number of tiles required in this example is:  
    4 (horizontal) x 3 (vertical) = 12 tiles
3.  The cost will be 12 x 1,000 = 12,000 tokens

### Enterprise Support

We are introducing a new benefit for users who purchase the Production Deployment plan with [11 billion tokens](https://jina.ai/embeddings/#pricing). This includes:

- One hours of consultation with our product and engineering teams to discuss your specific use cases and requirements.
- A customized Python notebook designed for your RAG (Retrieval-Augmented Generation) or vector search use case, demonstrating how to integrate Jina AI’s models into your application.
- Assignment to an account executive and priority email support to ensure your needs are met promptly and efficiently.

## Open-Source Jina CLIP v1 on Hugging Face

Jina AI is committed to an open-source search foundation, and for that purpose, we are making this model available for free under an [Apache 2.0 license](https://www.apache.org/licenses/LICENSE-2.0), on [Hugging Face](https://huggingface.co/jinaai/jina-clip-v1).

You can find example code to download and run this model on your own system or cloud installation on the Hugging Face model page for `jina-clip-v1` .

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-clip-v1" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-clip-v1 · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-clip-v1.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Summary

Jina AI’s latest model — `jina-clip-v1` — represents a significant advance in multimodal embedding models, offering substantial performance gains over OpenAI's CLIP. With notable improvements in text-only and image-only retrieval tasks, as well as competitive performance in text-to-image and image-to-text tasks, it stands as a promising solution for complex embeddings use cases.

This model currently only supports English-language texts due to resource constraints. We are working to expand its capabilities to more languages.
