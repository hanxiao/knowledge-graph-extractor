---
title: "Jina CLIP v2: Multilingual Multimodal Embeddings for Text and Images"
slug: jina-clip-v2-multilingual-multimodal-embeddings-for-text-and-images
url: https://cms.jina.ai/jina-clip-v2-multilingual-multimodal-embeddings-for-text-and-images/
published_at: 2024-11-21T17:29:45.000+01:00
updated_at: 2024-12-11T19:10:09.000+01:00
reading_time: 9
authors: "Jina AI"
tags: "Press"
excerpt: "Jina-CLIP v2, a 0.9B multimodal embedding model with multilingual support of 89 languages, high image resolution at 512x512, and Matryoshka representations."
---

# Jina CLIP v2: Multilingual Multimodal Embeddings for Text and Images

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-clip-v2" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-clip-v2 · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-11.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/jina-clip-v2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/?sui&amp;model=jina-clip-v2" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina AI - Your Search Foundation, Supercharged.
</div>
<div class="kg-bookmark-description">
Best-in-class embeddings, rerankers, LLM-reader, web scraper, classifiers. The best search AI for multilingual and multimodal data.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-11.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Your Search Foundation, Supercharged.</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/banner-1.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span><code spellcheck="false" style="white-space: pre-wrap;">jina-clip-v2</code></span><span style="white-space: pre-wrap;"> API is available under the "Embeddings" tab.</span></p></figcaption>
</figure>

Multimodal embeddings enable searching and understanding data across different modalities through a coherent representation. They serve as the backbone of neural information retrieval and multimodal GenAI applications. Today, we're excited to release `jina-clip-v2`, a new general-purpose multilingual multimodal embeddings built upon `jina-clip-v1` and our recently released `jina-embeddings-v3`, featuring several key improvements:

- **Improved Performance**: v2 shows a 3% performance improvement over v1 in both text-image and text-text retrieval tasks. Similar to v1, v2's text encoder can serve as an effective multilingual long-context dense retriever. It performs on par with our frontier model `jina-embeddings-v3` (currently the best multilingual embeddings under 1B parameters on MTEB).
- **Multilingual Support**: Powered by `jina-embeddings-v3` as the text tower, `jina-clip-v2` supports 89 languages for multilingual-image retrieval, showing up to 4% improvement compared to `nllb-clip-large-siglip` on multilingual image retrieval tasks.
- **Higher Image Resolution**: v2 now supports 512x512 input image resolution, a significant increase from v1's 224x224. This higher resolution enables better processing of detailed images, improved feature extraction, and more accurate recognition of fine-grained visual elements.
- **Matryoshka Representations**: v2 allows users to truncate the output dimensions of both text and image embeddings from 1024 down to 64, reducing storage and processing overhead while maintaining strong performance.

## Model Architecture

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/clipv2-model-architecture.svg" class="kg-image" loading="lazy" width="1200" height="630" alt="Diagram of JINA-CLIP-V2 model showing stages from input to output for English and multilingual text processing." />
<figcaption><span style="white-space: pre-wrap;">Jina-CLIP v2 combines a text encoder (Jina XLM-RoBERTa, 561M parameters) and a vision encoder (EVA02-L14, 304M parameters) for a total of 865M parameters. The text encoder is also used in jina-embeddings-v3.</span></figcaption>
</figure>

`jina-clip-v2` is a 0.9B CLIP-style model that combines two powerful encoders: the text encoder `Jina XLM-RoBERTa` (the backbone of `jina-embeddings-v3`) and the vision encoder `EVA02-L14` (an efficient vision Transformer developed by BAAI). These encoders are jointly trained to create aligned representations of images and text.

| Feature               | Text Encoder           | Image Encoder    |
|-----------------------|------------------------|------------------|
| Base Model            | Jina XLM-RoBERTa       | EVA02-L          |
| Parameters            | 561M                   | 304M             |
| Input Specification   | 8,192 tokens (max)     | 512×512 pixels   |
| Min Output Dimensions | 64                     | 64               |
| Max Output Dimensions | 1,024                  | 1,024            |
| Layers                | 24                     | 24               |
| Attention Mechanism   | FlashAttention2        | xFormers         |
| Pooling Strategy      | Mean pooling           | CLS pooling      |
| Additional Features   | 89 languages supported | Patch size 14x14 |

## Cross-Modal Retrieval Performance

Jina CLIP v2 provides multilingual support for 89 languages and with top performance in major languages including Arabic, Chinese, English, French, German, Japanese, Russian, and Spanish. In multilingual image retrieval benchmarks, Jina-CLIP v2 (865M parameters) matches or surpasses [NLLB-CLIP-SigLIP](https://huggingface.co/visheratin/nllb-clip-large-siglip), a state-of-the-art CLIP-style model using a pre-trained text encoder from NLLB models. Our model sits between the two NLLB-CLIP-SigLIP versions in terms of size: `nllb-siglip-base` (507M parameters, 41% smaller than ours) and `nllb-siglip-large` (1.2B parameters, 39% larger than ours).

### English-Only Text and Images

On standard cross-modal retrieval benchmarks (Flickr30k and COCO), `jina-clip-v2` demonstrates strong improvements across the board. It achieves state-of-the-art performance of 98.0% on Flickr30k image-to-text retrieval, surpassing both its predecessor and NLLB-CLIP-SigLIP. The model shows consistent gains across all retrieval scenarios, with notable improvements of up to 3.3% over v1 on COCO image-to-text retrieval, while maintaining competitive performance with NLLB-CLIP-SigLIP across different benchmarks and modality directions.

**Flickr30k Recall@5 Performance:**

| Task          | Model             | Score | Δ v1  | Δ NLLB-L |
|---------------|-------------------|-------|-------|----------|
| Image-to-text | jina-clip-v2      | 98.0  | +1.7% | +0.9%    |
|               | jina-clip-v1      | 96.4  | \-    | -0.7%    |
|               | nllb-siglip-large | 97.1  | \-    | \-       |
|               | nllb-siglip-base  | 95.0  | \-    | \-       |
| Text-to-image | jina-clip-v2      | 89.8  | +0.9% | -2.6%    |
|               | jina-clip-v1      | 89.0  | \-    | -3.5%    |
|               | nllb-siglip-large | 92.2  | \-    | \-       |
|               | nllb-siglip-base  | 90.0  | \-    | \-       |

**COCO Recall@5 Performance:**

Task

Model

Score

Δ v1

Δ NLLB-L

Image-to-text

jina-clip-v2

81.5

+3.3%

+2.9%

jina-clip-v1

78.9

\-

-0.4%

nllb-siglip-large

79.2

\-

\-

nllb-siglip-base

77.7

\-

\-

Text-to-image

jina-clip-v2

68.4

+2.9%

-3.4%

jina-clip-v1

66.5

\-

-6.1%

nllb-siglip-large

70.8

\-

\-

nllb-siglip-base

69.1

\-

\-

### Multilingual Text and Images

On multilingual cross-modal benchmarks, `jina-clip-v2` demonstrates robust performance, particularly excelling in image-to-text retrieval where it outperforms NLLB-SigLIP across all datasets, with up to +3.8% improvement on Crossmodal 3600. While NLLB-SigLIP shows slightly stronger text-to-image retrieval capabilities, the performance gap remains small, typically within 3%.

**Image2Text Recall@5 Performance:**

| Benchmark            | Model             | Score | Δ NLLB-L |
|----------------------|-------------------|-------|----------|
| Crossmodal 3600      | jina-clip-v2      | 83.23 | +3.8%    |
|                      | nllb-siglip-large | 80.16 | \-       |
|                      | nllb-siglip-base  | 76.56 | \-       |
| Multilingual MS Coco | jina-clip-v2      | 86.03 | +0.8%    |
|                      | nllb-siglip-large | 85.37 | \-       |
|                      | nllb-siglip-base  | 84.87 | \-       |
| XTD10                | jina-clip-v2      | 85.98 | +0.7%    |
|                      | nllb-siglip-large | 85.41 | \-       |

**Text2Image Recall@5 Performance:**

| Benchmark            | Model             | Score | Δ NLLB-L |
|----------------------|-------------------|-------|----------|
| Crossmodal 3600      | jina-clip-v2      | 81.43 | -0.8%    |
|                      | nllb-siglip-large | 82.07 | \-       |
|                      | nllb-siglip-base  | 79.29 | \-       |
| Multilingual MS Coco | jina-clip-v2      | 84.87 | -3.1%    |
|                      | nllb-siglip-large | 87.60 | \-       |
|                      | nllb-siglip-base  | 86.23 | \-       |
| XTD10                | jina-clip-v2      | 85.03 | -3.0%    |
|                      | nllb-siglip-large | 87.63 | \-       |

## Text-Only Dense Retriever Performance

Similar to its predecessor, `jina-clip-v2`'s text encoder can serve as an effective multilingual dense retriever. On the comprehensive Multilingual MTEB benchmarks, it achieves strong performance, reaching 69.86% on retrieval and 67.77% on semantic similarity tasks. These results demonstrate its versatility, performing competitively with our specialized text embedding model `jina-embeddings-v3`:

| Task                | Model              | Score | Relative to v3 |
|---------------------|--------------------|-------|----------------|
| Retrieval           | jina-clip-v2       | 69.86 | -3.8%          |
|                     | jina-embeddings-v3 | 72.59 | \-             |
| Semantic Similarity | jina-clip-v2       | 67.77 | -2.9%          |
|                     | jina-embeddings-v3 | 69.81 | \-             |

On English tasks, `jina-clip-v2` shows consistent improvements over both its predecessor and NLLB-SigLIP, with particularly strong advantages in retrieval performance (nearly double NLLB-SigLIP's score).

| Task      | Model             | Score | Relative to v1 |
|-----------|-------------------|-------|----------------|
| STS       | jina-clip-v2      | 81.29 | +0.5%          |
|           | jina-clip-v1      | 80.92 | \-             |
|           | nllb-siglip-large | 74.65 | \-             |
| Retrieval | jina-clip-v2      | 49.33 | +2.1%          |
|           | jina-clip-v1      | 48.33 | \-             |
|           | nllb-siglip-large | 24.92 | \-             |

## Matryoshka Representation Performance

Both text and image encoders support MRL, and their output dimensions can be truncated to 64 while maintaining strong performance. Our embedding truncation evaluation revealed remarkable compression potential. Even an aggressive 75% dimensional reduction maintained over 99% performance across text, image, and cross-modal tasks.

### Image Classification

Across 37 diverse image classification benchmarks, the image encoder shows strong resilience to truncated dimensions. Compressing from 1024 to 64 dimensions (94% reduction) results in only an 8% drop in top-5 accuracy and 12.5% in top-1, highlighting its potential for efficient deployment with minimal performance loss.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/accuracy_performance--1-.svg" class="kg-image" loading="lazy" width="947" height="954" alt="Line graph demonstrating the accuracy of image classification models across various embedding dimensions." />
<figcaption><span style="white-space: pre-wrap;">For image classification, we used the 19 benchmarks in the </span><a href="https://github.com/google-research/task_adaptation"><span style="white-space: pre-wrap;">VTAB dataset</span></a><span style="white-space: pre-wrap;"> , </span><a href="http://host.robots.ox.ac.uk/pascal/VOC/voc2007/"><span style="white-space: pre-wrap;">VOC 2007</span></a><span style="white-space: pre-wrap;">, </span><a href="https://www.tensorflow.org/datasets/catalog/sun397"><span style="white-space: pre-wrap;">SUN397</span></a><span style="white-space: pre-wrap;">, </span><a href="https://cs.stanford.edu/~acoates/stl10/"><span style="white-space: pre-wrap;">STL10</span></a><span style="white-space: pre-wrap;">, </span><a href="https://github.com/openai/CLIP/blob/main/data/rendered-sst2.md"><span style="white-space: pre-wrap;">Rendered SST2</span></a><span style="white-space: pre-wrap;">, </span><a href="https://objectnet.dev/"><span style="white-space: pre-wrap;">ObjectNet</span></a><span style="white-space: pre-wrap;">, </span><a href="https://github.com/cvdfoundation/mnist"><span style="white-space: pre-wrap;">MNIST</span></a><span style="white-space: pre-wrap;">, German Traffic Sign Recognition Benchmark (</span><a href="https://benchmark.ini.rub.de/gtsrb_dataset.html"><span style="white-space: pre-wrap;">GTSRB</span></a><span style="white-space: pre-wrap;">), Fine-Grained Visual Classification of Aircraft (</span><a href="https://www.robots.ox.ac.uk/~vgg/data/fgvc-aircraft/"><span style="white-space: pre-wrap;">FGVC-Aircraft</span></a><span style="white-space: pre-wrap;">), </span><a href="https://www.kaggle.com/c/challenges-in-representation-learning-facial-expression-recognition-challenge"><span style="white-space: pre-wrap;">FER 2013</span></a><span style="white-space: pre-wrap;">, </span><a href="https://github.com/openai/CLIP/blob/main/data/country211.md"><span style="white-space: pre-wrap;">Country211</span></a><span style="white-space: pre-wrap;">, </span><a href="https://www.tensorflow.org/datasets/catalog/cars196"><span style="white-space: pre-wrap;">Cars196</span></a><span style="white-space: pre-wrap;">, </span><a href="https://github.com/hendrycks/natural-adv-examples"><span style="white-space: pre-wrap;">ImageNet-A, ImageNet-O,</span></a><a href="https://huggingface.co/datasets/ILSVRC/imagenet-1k"><span style="white-space: pre-wrap;">IxmageNet1k</span></a><span style="white-space: pre-wrap;">, </span><a href="https://github.com/HaohanWang/ImageNet-Sketch"><span style="white-space: pre-wrap;">ImageNet Sketch</span></a><span style="white-space: pre-wrap;">, and </span><a href="https://imagenetv2.org/"><span style="white-space: pre-wrap;">ImageNet v2</span></a><span style="white-space: pre-wrap;">.</span></figcaption>
</figure>

### Cross-Modal Retrieval

Despite a dramatic 94% reduction to just 64 dimensions, cross-modal retrieval using both truncated image and text embeddings remained remarkably robust, preserving 93% of image-to-text and 90% of text-to-image performance.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/crossmodal_performance--1-.svg" class="kg-image" loading="lazy" width="947" height="954" alt="Graph depicting Cross-Modal Retrieval Performance with Text-to-Image scores on the y-axis and Embedding Dimensions on the x-a" />
<figcaption><span style="white-space: pre-wrap;">We used six benchmarks, three of which are multilingual: </span><a href="https://google.github.io/crossmodal-3600/"><span style="white-space: pre-wrap;">Crossmodal-3600</span></a><span style="white-space: pre-wrap;"> (36 languages), </span><a href="https://shannon.cs.illinois.edu/DenotationGraph/"><span style="white-space: pre-wrap;">flickr30k</span></a><span style="white-space: pre-wrap;"> (English only), </span><a href="https://hockenmaier.cs.illinois.edu/8k-pictures.html"><span style="white-space: pre-wrap;">flickr8k</span></a><span style="white-space: pre-wrap;"> (English only), </span><a href="https://arxiv.org/abs/1504.00325"><span style="white-space: pre-wrap;">MS COCO Captions</span></a><span style="white-space: pre-wrap;"> (English only), </span><a href="https://github.com/LAION-AI/CLIP_benchmark"><span style="white-space: pre-wrap;">Multilingual MS COCO Captions</span></a><span style="white-space: pre-wrap;"> (10 languages), </span><a href="https://github.com/LAION-AI/CLIP_benchmark"><span style="white-space: pre-wrap;">XTD 200</span></a><span style="white-space: pre-wrap;"> (27 languages)</span></figcaption>
</figure>

### Text-Only Retrieval

On **English-only MTEB benchmarks**, 64-dimension text embeddings (compressed from 1024) preserved semantic similarity remarkably well, dropping only 2.1%, while retrieval saw a modest 17.5% decrease.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/11/mteb_performance.svg" class="kg-image" loading="lazy" width="947" height="954" alt="Graph depicting English-only MTEB Performance across various embedding dimensions, with lines representing retrieval scores." />
</figure>

## Getting Started

### Via API

The code demonstrates how to generate embeddings using Python's `requests`. Pass a text string with either a base64 image or URL, plus your desired dimension size (default 1024, shown as 768 below).

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode Python"><code class="sourceCode python"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="im">import</span> requests</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a><span class="im">import</span> numpy <span class="im">as</span> np</span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="im">from</span> numpy.linalg <span class="im">import</span> norm</span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>cos_sim <span class="op">=</span> <span class="kw">lambda</span> a,b: (a <span class="op">@</span> b.T) <span class="op">/</span> (norm(a)<span class="op">*</span>norm(b))</span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>url <span class="op">=</span> <span class="st">&#39;https://api.jina.ai/v1/embeddings&#39;</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>headers <span class="op">=</span> {</span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;Content-Type&#39;</span>: <span class="st">&#39;application/json&#39;</span>,</span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;Authorization&#39;</span>: <span class="st">&#39;Bearer &lt;YOUR_JINA_AI_API_KEY&gt;&#39;</span></span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>}</span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a>data <span class="op">=</span> {</span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;input&#39;</span>: [</span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a>     {<span class="st">&quot;text&quot;</span>: <span class="st">&quot;Bridge close-shot&quot;</span>},</span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a>     {<span class="st">&quot;url&quot;</span>: <span class="st">&quot;https://fastly.picsum.photos/id/84/1280/848.jpg?hmac=YFRYDI4UsfbeTzI8ZakNOR98wVU7a-9a2tGF542539s&quot;</span>}],</span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;model&#39;</span>: <span class="st">&#39;jina-clip-v2&#39;</span>,</span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;encoding_type&#39;</span>: <span class="st">&#39;float&#39;</span>,</span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;dimensions&#39;</span>: <span class="st">&#39;768&#39;</span> </span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a>}</span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a>response <span class="op">=</span> requests.post(url, headers<span class="op">=</span>headers, json<span class="op">=</span>data)</span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a>sim <span class="op">=</span> cos_sim(np.array(response.json()[<span class="st">&#39;data&#39;</span>][<span class="dv">0</span>][<span class="st">&#39;embedding&#39;</span>]), np.array(response.json()[<span class="st">&#39;data&#39;</span>][<span class="dv">1</span>][<span class="st">&#39;embedding&#39;</span>]))</span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a><span class="bu">print</span>(<span class="ss">f&quot;Cosine text&lt;-&gt;image: </span><span class="sc">{</span>sim<span class="sc">}</span><span class="ss">&quot;</span>)</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Remember to replace &lt;YOUR_JINA_AI_API_KEY&gt; with an activated Jina API key. You can get </span><a href="https://jina.ai/?sui=apikey" rel="noreferrer"><span style="white-space: pre-wrap;">a free API key with a million free tokens from here.</span></a></p></figcaption>
</figure>

### Image Tokens Pricing

Our API counts both text and image tokens. For images, token consumption is based on the number of 512x512 pixel tiles needed to cover the entire image area. Each tile costs 4,000 tokens to process, including partially filled tiles. **For optimal cost-efficiency, we recommend that API users resize their images to 512x512 before sending requests.**

| Image Resolution | Required Tiles | Token Cost |
|------------------|----------------|------------|
| 512x512          | 1              | 4,000      |
| 720x720          | 4              | 16,000     |
| 1080x1080        | 9              | 36,000     |

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/Heading--37-.svg" class="kg-image" loading="lazy" width="1200" height="630" alt="Educational graphic showing three image format adjustments: square, landscape, and portrait, each with details on resizing an" />
<figcaption><span style="white-space: pre-wrap;">For square images, resize to 512x512 for best cost-efficiency. For aspect ratio-sensitive tasks, scale the longest edge to 512, center the image, and pad with black. For general purposes, direct 512x512 resizing works well.</span></figcaption>
</figure>

### Via CSP Marketplaces

Jina CLIP v2 is available directly on AWS, Azure and GCP at the prices listed there.

<figure class="kg-card kg-bookmark-card">
<a href="https://aws.amazon.com/marketplace/pp/prodview-bfbctuqmky676" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
AWS Marketplace: Jina CLIP v2
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-10.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/socialPreview-2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://azuremarketplace.microsoft.com/en-gb/marketplace/apps?search=Jina" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Microsoft Azure Marketplace
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-9.ico" class="kg-bookmark-icon" />
</div>
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://console.cloud.google.com/marketplace/browse?q=jina" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Google Cloud console
</div>
<div class="kg-bookmark-description">
Spend smart, procure faster and retire committed Google Cloud spend with Google Cloud Marketplace. Browse the catalog of over 2000 SaaS, VMs, development stacks, and Kubernetes apps optimized to run on Google Cloud.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/default.png" class="kg-bookmark-icon" />
</div>
</div>
</figure>

### **Via VectorDB**

<figure class="kg-card kg-bookmark-card">
<a href="https://docs.pinecone.io/models/jina-clip-v2" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
The vector database to build knowledgeable AI | Pinecone
</div>
<div class="kg-bookmark-description">
Search through billions of items for similar matches to any object, in milliseconds. It’s the next generation of search, an API call away.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-3.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Pinecone Docs</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/docs_og_image.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://weaviate.io/developers/weaviate/model-providers/jinaai/embeddings-multimodal" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Multimodal Embeddings | Weaviate
</div>
<div class="kg-bookmark-description">
Weaviate’s integration with Jina AI’s APIs allows you to access their models’ capabilities directly from Weaviate.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-12.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Weaviate</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/provider_integrations_jinaai.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://qdrant.tech/documentation/embeddings/jina-embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings - Qdrant
</div>
<div class="kg-bookmark-description">
Qdrant is an Open-Source Vector Database and Vector Search Engine written in Rust. It provides fast and scalable vector similarity search service with convenient API.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-4.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">edit</span><span class="kg-bookmark-publisher">Qdrant</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/jina-embeddings-social-preview-1.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Conclusion

Building on our `jina-clip-v1` release in June, which extended OpenAI's CLIP model with text input up to 8,192 tokens, and the frontier multilingual `jina-embeddings-v3`, `jina-clip-v2` brings three major advances: multilingual support for 89 languages, increased image resolution at 512x512, and Matryoshka representation learning for more truncated embeddings.

CLIP-like models have established themselves as the backbone for general-purpose multimodal applications. With `jina-clip-v2`, we're taking these capabilities to the next level, breaking down language barriers to deliver more accurate cross-modal understanding and retrieval. We believe this release delivers a promise in making multimodal search and retrieval both more powerful and more accessible to developers worldwide.
