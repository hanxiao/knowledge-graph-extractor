---
model_name: "jina-clip-v2"
model_version: "v2"
model_type: "multimodal"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
input_type:
  - image
  - text
output_type:
  - vector
language:
  - multilingual
diagrams:
  - jina-clip-v2.svg
  - jina-clip-v2-1.svg
token_length: 8K
image_size: 512×512
output_dimension: 1024
matryoshka_dimensions:
  - 64
  - 128
  - 256
  - 512
  - 768
  - 1024
release_date: "2024-11-05"
device: "cuda"
api_link: "/?sui&model=jina-clip-v2"
huggingface: "https://huggingface.co/jinaai/jina-clip-v2"
aws: "arn:aws:sagemaker:us-east-1:253352124568:model-package/jina-clip-v2"
arxiv: "https://arxiv.org/abs/2412.08802"
release_blog: "/news/jina-clip-v2-multilingual-multimodal-embeddings-for-text-and-images/"
related_models:
  - jina-clip-v1
parameter_size: "865M"
tags:
  - multimodal-embedding
  - image-text-alignment
  - multilingual
  - large-context
  - instruction-tuned
  - masked-region-learning
  - production
  - cross-lingual-retrieval
  - zero-shot-classification
  - modality-gap-aware
endpoints:
  - embedding
  - train
  - classify
features:
  - instruction_enabled: true
  - mrl_enabled: true
availability:
  - elastic
  - api
  - license
  - huggingface
  - aws
  - azure
  - gcp
---

## Overview

Jina CLIP v2 revolutionizes multimodal AI by bridging the gap between visual and textual understanding across 89 languages. This model solves critical challenges in global e-commerce, content management, and cross-cultural communication by enabling accurate image-text matching regardless of language barriers. For businesses expanding internationally or managing multilingual content, it eliminates the need for separate models per language or complex translation pipelines. The model particularly shines in scenarios requiring precise visual search across language boundaries, such as global marketplace product discovery or multilingual digital asset management.

## Methods

At its core, Jina CLIP v2 employs a sophisticated dual-encoder architecture that combines a Jina XLM-RoBERTa text encoder (561M parameters) with an EVA02-L14 vision encoder (304M parameters). The text encoder processes content in 89 languages with a massive context window of 696,320 tokens, while the vision encoder handles high-resolution images up to 512x512 pixels. The model introduces innovative Matryoshka representation learning, which enables dynamic embedding dimension adjustment from 1024 down to 64 dimensions while preserving performance. This architecture processes both text and images through their respective encoders, projecting them into a shared semantic space where similar concepts align regardless of their original modality or language.

## Performance

The model achieves state-of-the-art performance with 98.0% accuracy on Flickr30k image-to-text retrieval tasks, surpassing both its predecessor and NLLB-CLIP-SigLIP. In multilingual scenarios, it demonstrates up to 4% improvement over NLLB-CLIP-SigLIP in cross-lingual image retrieval tasks, despite having fewer parameters than its largest competitor. The model maintains strong performance even when embeddings are compressed - reducing dimensions by 75% still preserves over 99% of performance across text, image, and cross-modal tasks. On the comprehensive Multilingual MTEB benchmarks, it achieves 69.86% on retrieval and 67.77% on semantic similarity tasks, performing competitively with specialized text embedding models.

## Guidance

For optimal deployment, users should consider several key factors. The model requires CUDA-capable hardware for efficient processing, with memory requirements scaling based on batch size and image resolution. To optimize API costs and performance, resize images to 512x512 pixels before processing - larger images are automatically tiled, increasing token usage and processing time. The model excels at matching images with descriptive text across languages but may struggle with abstract concepts or highly specialized domain-specific content. It's particularly effective for e-commerce product search, content recommendation systems, and visual search applications, but may not be suitable for tasks requiring fine-grained visual detail analysis or highly specialized domain expertise. When using the Matryoshka representation feature, consider the trade-off between dimension reduction and performance - while 64-dimension embeddings maintain strong performance, critical applications may benefit from higher dimensions.
