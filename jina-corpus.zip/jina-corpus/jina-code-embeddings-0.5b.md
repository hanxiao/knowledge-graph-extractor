---
model_name: "jina-code-embeddings-0.5b"
model_version: "v1"
model_type: "text-embeddings"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "494M"
language:
    - multilingual
input_type:
  - text (code)
output_type:
  - vector
diagrams:
  - jina-code-embeddings.svg
token_length: 32K
output_dimension: 896
matryoshka_dimensions:
  - 64
  - 128
  - 256
  - 512
  - 896
quantized: true
release_date: "2025-09-01"
device: "cuda"
late_chunking: false
api_link: "/?sui&model=jina-code-embeddings-0.5b"
huggingface: "https://huggingface.co/jinaai/jina-code-embeddings-0.5b"
arxiv: "https://arxiv.org/abs/2508.21290"
aws: ""
azure: "https://azuremarketplace.microsoft.com/en-us/marketplace/apps/jinaai.jina-code-embeddings-500m?tab=Overview"
release_blog: "/news/jina-code-embeddings-sota-code-retrieval-at-0-5b-and-1-5b"
related_models:
  - jina-code-embeddings-1.5b
  - jina-embeddings-v2-base-code
tasks:
  - nl2code
  - techqa
  - code2code
  - code2nl
  - code2completion
tags:
  - code-embeddings
  - programming-languages
  - semantic-code-search
  - code-similarity
  - long-context
  - text-embeddings
  - multilingual-code
  - docstring-search
endpoints:
  - embedding
availability:
  - api
  - huggingface
  - aws
  - azure
  - gcp
---

## Overview


## Methods


## Performance


## Guidance

