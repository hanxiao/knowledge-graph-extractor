---
title: "Jina ColBERT v2: Multilingual Late Interaction Retriever for Embedding and Reranking"
slug: jina-colbert-v2-multilingual-late-interaction-retriever-for-embedding-and-reranking
url: https://cms.jina.ai/jina-colbert-v2-multilingual-late-interaction-retriever-for-embedding-and-reranking/
published_at: 2024-08-30T09:19:58.000+02:00
updated_at: 2024-11-12T12:47:47.000+01:00
reading_time: 10
authors: "Jina AI"
tags: "Press"
excerpt: "Jina ColBERT v2 supports 89 languages with superior retrieval performance, user-controlled output dimensions, and 8192 token-length."
---

# Jina ColBERT v2: Multilingual Late Interaction Retriever for Embedding and Reranking

Today, we’re excited to release Jina ColBERT v2 (`jina-colbert-v2`), an advanced late interaction retrieval model built on the ColBERT architecture. This new language model improves performance of `jina-colbert-v1-en` and adds multilingual support and dynamic output dimensions.

This new release highlights the following features:

- **Superior retrieval performance** compared to the original ColBERT-v2 (+6.5%) and our previous release, `jina-colbert-v1-en`(+5.4%).
- **Multilingual support** for 89 languages, delivering strong performance across major global languages.
- **User-controlled output embedding sizes** through Matryoshka representation learning, enabling users to flexibly balance between efficiency and precision.

## Technical Summary of `jina-colbert-v2`

The full technical report can be found on arXiv:

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2408.16672" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina-ColBERT-v2: A General-Purpose Multilingual Late Interaction Retriever
</div>
<div class="kg-bookmark-description">
Multi-vector dense models, such as ColBERT, have proven highly effective in information retrieval. ColBERT’s late interaction scoring approximates the joint query-document attention seen in cross-encoders while maintaining inference efficiency closer to traditional dense retrieval models, thanks to its bi-encoder architecture and recent optimizations in indexing and search. In this paper, we introduce several improvements to the ColBERT model architecture and training pipeline, leveraging techniques successful in the more established single-vector embedding model paradigm, particularly those suited for heterogeneous multilingual data. Our new model, Jina-ColBERT-v2, demonstrates strong performance across a range of English and multilingual retrieval tasks, while also cutting storage requirements by up to 50% compared to previous models.
</div>
<div class="kg-bookmark-metadata">
<img src="https://arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Rohan Jha</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr>
<th></th>
<th><code>jina-colbert-v2</code></th>
<th><code>jina-colbert-v1-en</code></th>
<th>Original ColBERTv2</th>
</tr>
</thead>
<tbody>
<tr>
<td>Average of 14 English<br />
BEIR tasks</td>
<td><strong>0.521</strong></td>
<td>0.494</td>
<td>0.489</td>
</tr>
<tr>
<td>Multilingual</td>
<td><strong>89 languages</strong></td>
<td>English-only</td>
<td>English-only</td>
</tr>
<tr>
<td>Output dimensions</td>
<td><strong>128, 96, or 64</strong></td>
<td>Fixed 128</td>
<td>Fixed 128</td>
</tr>
<tr>
<td>Max query length</td>
<td>32 tokens</td>
<td>32 tokens</td>
<td>32 tokens</td>
</tr>
<tr>
<td>Max document length</td>
<td>8192 tokens</td>
<td>8192 tokens</td>
<td>512 tokens</td>
</tr>
<tr>
<td>Parameters</td>
<td>560M</td>
<td>137M</td>
<td>110M</td>
</tr>
<tr>
<td>Model size</td>
<td>1.1GB</td>
<td>550MB</td>
<td>438MB</td>
</tr>
</tbody>
</table>

## Asymmetric Embedding in ColBERT

ColBERT builds on the BERT architecture by adding **late interaction** and **asymmetric** query-document encoding.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/what-is-colbert-and-late-interaction-and-why-they-matter-in-search/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
What is ColBERT and Late Interaction and Why They Matter in Search?
</div>
<div class="kg-bookmark-description">
Jina AI’s ColBERT on Hugging Face has set Twitter abuzz, bringing a fresh perspective to search with its 8192-token capability. This article unpacks the nuances of ColBERT and ColBERTv2, showcasing their innovative designs and why their late interaction feature is a game-changer for search.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/2024/02/Untitled-design--28-.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

The asymmetric nature of ColBERT means that when using models like `jina-colbert-v2` or `jina-colbert-v1-en`, you need to specify whether you are embedding a query, a document, or both (for reranking purposes). This added flexibility enhances performance over homogeneous embedding models in retrieval tasks.

## Multilingual Support For Over 89 Languages

Jina ColBERT v2 has extensive multilingual capabilities, designed to meet the demands of modern, globalized information retrieval and AI applications. The training corpus for `jina-colbert-v2` incorporates 89 languages, with additional stages of training for major international languages including **Arabic, Chinese, English, French, German, Japanese, Russian, and Spanish**, as well as **programming languages**. The training also included a corpus of aligned bilingual texts to unlock cross-lingual potentials, allowing queries and documents in different languages to be matched in reranking/retrieval tasks.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/08/Distribution-of-the-languages-in-the-training-corpus-at-the-pretrained-stage--3-.svg" class="kg-image" loading="lazy" width="1456" height="743" alt="Chart of language distribution in training data, highlighting dominance of English and Chinese." />
<figcaption><span style="white-space: pre-wrap;">Pre-training dataset data distribution by language (specified by </span><a href="https://en.wikipedia.org/wiki/List_of_ISO_639_language_codes"><span style="white-space: pre-wrap;">ISO-639</span></a><span style="white-space: pre-wrap;"> code) in logarithmic scale.</span></figcaption>
</figure>

Today, Jina ColBERT v2 stands out as **the only multilingual ColBERT-like model** that generates compact embeddings, significantly outperforming BM25-based retrieval across all languages tested on MIRACL benchmarks.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/08/Evaluation-on-Multilingual-Data--1-.svg" class="kg-image" loading="lazy" width="691" height="426" alt="Bar chart comparing jina-colbert-v2 and BM25 performance across 20 languages on multilingual tasks." />
<figcaption><span style="white-space: pre-wrap;">Jina ColBERT v2 performance over 16 languages, compared to BM25, on MIRACL benchmarks.</span></figcaption>
</figure>

Furthermore, on English-language retrieval tasks, Jina ColBERT v2 exceeds the performance of its predecessor `jina-colbert-v1-en` and the original ColBERT v2 model, with comparable performance to the highly specialized English-only <a href="https://huggingface.co/answerdotai/answerai-colbert-small-v1" rel="noreferrer">AnswerAI-ColBERT-small</a> model.

**Model Name**

**Average score  
(14 BEIR English-only benchmarks)  **

**Multilingual Support**

`jina-colbert-v2`

0.521

Multilingual

`jina-colbert-v1-en`

0.494

English-only

ColBERT v2.0

0.489

English-only

AnswerAI-ColBERT-small

0.549

English-only

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/08/Evaluation-on-English-only-datasets-from-BEIR--2-.svg" class="kg-image" loading="lazy" width="1088" height="712" alt="Bar chart showing model evaluations on English BEIR datasets, with several models like &#39;jina-colbert&#39; and &#39;BM25&#39;." />
<figcaption><span style="white-space: pre-wrap;">Evaluation of jina-colbert-v2 on a selection of English-only datasets from BEIR benchmark.</span></figcaption>
</figure>

## Matryoshka Representation Learning

[Matryoshka Representation Learning](https://arxiv.org/abs/2205.13147) is a technique for training models to support different output vector sizes while minimizing any loss in accuracy. We train the hidden layers of the network with several different linear projection heads — the final layers of a neural network — each supporting a different output size. **Jina ColBERT v2 supports output vectors of 128, 96, and 64 dimensions.**

Jina ColBERT v2 produces 128-dimension output embeddings by default, but can produce 96 and 64 dimensions that are nearly identical in performance but are 25% and 50% shorter respectively.

The table below shows the [nDGC](https://en.wikipedia.org/wiki/Discounted_cumulative_gain) performance of `jina-colbert-v2` for the top ten results (*nDGC@10*) over six datasets from the BEIR benchmark. You can see here that the difference in performance between 128 dimensions and 96 is barely 1% and under 1.5% between 128 and 64 dimensions.

**Output Dimensions**

**Average** **Score  
(nDGC@10 for 6 benchmarks)  **

128

0.565

96

0.558

64

0.556

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/08/Performance-on-selected-BEIR-benchmarks.svg" class="kg-image" loading="lazy" width="732" height="538" alt="Bar chart of BEIR benchmarks, highlighting scores of datasets like nfcorpus to msmarco, with jina-colbert-v2.64 excelling." />
<figcaption><span style="white-space: pre-wrap;">Jina ColBERT v2 performance at different output dimensions.</span></figcaption>
</figure>

Reducing the size of the output vectors saves space and speeds up applications like vector-based information retrieval that have to compare different vectors or measure the distance between them.

This has significant cost consequences, even just in terms of reduced storage. For example, using [Qdrant’s cloud cost estimator](https://cloud.qdrant.io/calculator), storing 100 million documents on AWS with 128-dimension vectors for each has an [estimated cost of US\$1,319.24 per month](https://cloud.qdrant.io/calculator?provider=aws&region=eu-central-1&replicas=1&quantization=None&vectors=100000000&dimension=128). At 64 dimensions, this [falls to US\$659.62](https://cloud.qdrant.io/calculator?provider=aws&region=eu-central-1&replicas=1&quantization=None&vectors=100000000&dimension=64).

## Getting Started with Jina ColBERT v2

Jina ColBERT v2 is available via the Jina Search Foundation API, the [AWS marketplace](https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy), and [on Azure](https://azuremarketplace.microsoft.com/en-gb/marketplace/apps?search=Jina). It is also available for *non-commercial use only* ([CC BY-NC-4.0](https://www.creativecommons.org/licenses/by-nc/4.0/deed.en)) via [Hugging Face](https://huggingface.co/jinaai/jina-colbert-v2).

### Via Jina Search Foundation API

#### For Embedding

The following `curl` command shows how to specify the input and options to get document embeddings from `jina-colbert-v2` via the Jina Embeddings API. To get vectors of your preferred size, specify 128 or 64 for the `dimensions` parameter. This parameter is optional and the default value is 128.

Input documents will be truncated if longer than 8192 tokens.

Specify your Jina API key in the authorization header `Authorization: Bearer <YOUR JINA API KEY>`:

``` bash
curl https://api.jina.ai/v1/multi-vector \\
     -H "Content-Type: application/json" \\
     -H "Authorization: Bearer <YOUR JINA API KEY>" \\
     -d '{
    "model": "jina-colbert-v2",
    "dimensions": 128, # Or 64 for half-size vectors
    "input_type": "document", # For query embeddings see below
    "embedding_type": "float",
    "input": [
        "Your document text string goes here", 
        "You can send multiple texts", 
        "Each text can be up to 8192 tokens long"
    ]}'
```

To get query embeddings, set the `input_type` parameter to `query` instead of `document`. Note that queries have much stricter size limits than documents. They will be truncated at 32 tokens. Query encoding will *always* return 32 tokens, including embeddings for the padding if less than 32 tokens long.

``` bash
curl https://api.jina.ai/v1/multi-vector \\
     -H "Content-Type: application/json" \\
     -H "Authorization: Bearer <YOUR JINA API KEY>" \\
     -d '{
    "model": "jina-colbert-v2",
    "dimensions": 128, # Or 64 for half-size vectors    
    "input_type": "query", # This must be specified for query embeddings
    "embedding_type": "float",
    "input": [
        "Your query text string goes here", 
        "You can send multiple texts", 
        "Each query text can be up to 32 tokens long"
    ]}'
```

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/#apiform" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Multimodal, bilingual long-context embeddings for your search and RAG.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

#### For Reranking

To use `jina-colbert-v2` via the Jina Reranker API, passing in one query and several documents and getting back rankable match scores, construct your request like the one below:

``` bash
curl https://api.jina.ai/v1/rerank \\
     -H "Content-Type: application/json" \\
     -H "Authorization: Bearer <YOUR JINA API KEY>" \\
     -d '{
      "model": "jina-colbert-v2",
      "query": "What is the population of Berlin?",
      "top_n": 3,
      "documents": [
        "Berlin's population grew by 0.7 percent in 2023 compared with the previous year. Accordingly, around 27,300 more residents lived in Berlin at the end of the last year than in 2022. Those of 30 to under 40 years old form the numerically largest age group. With roughly 881,000 foreign residents from around 170 nations and an average age of the population of 42.5 years old.",
        "Mount Berlin is a glacier-covered volcano in Marie Byrd Land, Antarctica, 100 kilometres (62 mi) from the Amundsen Sea. It is a roughly 20-kilometre-wide (12 mi) mountain with parasitic vents that consists of two coalesced volcanoes: Berlin proper with the 2-kilometre-wide (1.2 mi) Berlin Crater and Merrem Peak with a 2.5-by-1-kilometre-wide (1.55 mi × 0.62 mi) crater, 3.5 kilometres (2.2 mi) away from Berlin.",
        "Population as of 31.12.2023 by nationality and federal states Land\\tTotal\\tGermans\\tForeigners\\tincluding EU-states number\\t%\\tnumber\\t%",
        "The urban area of Berlin has a population of over 4.5 million and is therefore the most populous urban area in Germany. The Berlin-Brandenburg capital region has around 6.2 million inhabitants and is Germany's second-largest metropolitan region after the Rhine-Ruhr region, and the sixth-biggest metropolitan region by GDP in the European Union.",
        "Irving Berlin (born Israel Beilin) was an American composer and songwriter. His music forms a large part of the Great American Songbook. Berlin received numerous honors including an Academy Award, a Grammy Award, and a Tony Award.",
        "Berlin is a town in the Capitol Planning Region, Connecticut, United States. The population was 20,175 at the 2020 census.",
        "Berlin is the capital and largest city of Germany, both by area and by population. Its more than 3.85 million inhabitants make it the European Union's most populous city, as measured by population within city limits.",
        "Berlin, Berlin ist eine für die ARD produzierte Fernsehserie, die von 2002 bis 2005 im Vorabendprogramm des Ersten ausgestrahlt wurde. Regie führten unter anderem Franziska Meyer Price, Christoph Schnee, Sven Unterwaldt Jr. und Titus Selge."
        ]
    }'
```

Note the `top_n` argument, which specifies the number of documents you want to retrieve. For example, if your application only uses the top match, set `top_n` to 1.

For code snippets in Python and other programming languages and frameworks, go to the [Jina AI Embeddings API page](https://jina.ai/embeddings/#apiform), or select `jina-colbert-v2` from the drop-down menu on the [Jina Reranker API page](https://jina.ai/reranker/#apiform).

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/reranker/#apiform" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Reranker API
</div>
<div class="kg-bookmark-description">
Maximize the search relevancy and RAG accuracy at ease.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-reranker-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

### Via Stanford ColBERT

You can also use Jina ColBERT v2 as a drop-in replacement for [ColBERT v2](https://github.com/stanford-futuredata/ColBERT) in the Stanford ColBERT library. Just specify `jinaai/jina-colbert-v2` as the model source:

``` python
from colbert.infra import ColBERTConfig
from colbert.modeling.checkpoint import Checkpoint

ckpt = Checkpoint("jinaai/jina-colbert-v2", colbert_config=ColBERTConfig())
docs = ["Your list of texts"] 
query_vectors = ckpt.queryFromText(docs)
```

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

⚠️

</div>

<div class="kg-callout-text">

You must install `einops` and `flash_attn` to use the above code.

</div>

</div>

### Via RAGatouille

Jina ColBERT v2 is similarly integrated into [RAGatouille](https://github.com/AnswerDotAI/RAGatouille). You can download and use it via the method `RAGPretrainedModel.from_pretrained()`:

``` python
from ragatouille import RAGPretrainedModel

RAG = RAGPretrainedModel.from_pretrained("jinaai/jina-colbert-v2")
docs = ["Your list of texts"]
RAG.index(docs, index_name="your_index_name")
query = "Your query"
results = RAG.search(query)
```

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

⚠️

</div>

<div class="kg-callout-text">

You must install `einops` and `flash_attn` to use the above code.

</div>

</div>

### Via Qdrant

Since version 1.10, Qdrant has added [support](https://qdrant.tech/blog/qdrant-1.10.x/) for multi-vectors and late-interaction models. Existing users of Qdrant engines, whether local or managed cloud versions, can benefit by directly integrating `jina-colbert-v2` using Qdrant’s client.

**Creating a new Collection using the MAX_SIM operation**

``` Python
from qdrant_client import QdrantClient, models

qdrant_client = QdrantClient(
    url="<YOUR_ENDPOINT>",
    api_key="<YOUR_API_KEY>",
)

qdrant_client.create_collection(
    collection_name="{collection_name}",
    vectors_config={
        "colbert": models.VectorParams(
            size=128,
            distance=models.Distance.COSINE,
            multivector_config=models.MultiVectorConfig(
                comparator=models.MultiVectorComparator.MAX_SIM
            ),
        )
    }
)
```

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

⚠️

</div>

<div class="kg-callout-text">

Correctly setting the `multivector_config` parameter is essential to using ColBERT-style models in Qdrant.

</div>

</div>

**Inserting Documents Into Multi-vector Collections**

``` Python
import requests
from qdrant_client import QdrantClient, models

url = 'https://api.jina.ai/v1/multi-vector'

headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer <YOUR BEARER>'
}

data = {
    'model': 'jina-colbert-v2',
    'input_type': 'query',
    'embedding_type': 'float',
    'input': [
        'Your text string goes here',
        'You can send multiple texts',
        'Each text can be up to 8192 tokens long'
    ]
}

response = requests.post(url, headers=headers, json=data)
rows = response.json()["data"]

qdrant_client = QdrantClient(
    url="<YOUR_ENDPOINT>",
    api_key="<YOUR_API_KEY>",
)

for i, row in enumerate(rows):
    qdrant_client.upsert(
        collection_name="{collection_name}",
        points=[
            models.PointStruct(
                id=i,  
                vector=row["embeddings"],  
                payload={"text": data["input"][i]} 
            )
        ],
    )
```

**Querying Collections**

``` Python
from qdrant_client import QdrantClient, models
import requests

url = 'https://api.jina.ai/v1/multi-vector'

headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer <YOUR BEARER>'
}


data = {
    'model': 'jina-colbert-v2',
    "input_type": "query",
    "embedding_type": "float",
    "input": [
        "how many tokens in an input do Jina AI's embedding models support?"
    ]
}

response = requests.post(url, headers=headers, json=data)
vector = response.json()["data"][0]["embeddings"]


qdrant_client = QdrantClient(
    url="<YOUR_ENDPOINT>",
    api_key="<YOUR_API_KEY>",
)

results = qdrant_client.query_points(
    collection_name="{collection_name}",
    query=vector,
)

print(results)
```

### Summary

Jina ColBERT v2 (`jina-colbert-v2`) builds on the high performance of `jina-colbert-v1-en` and expands its capabilities to a wide range of global languages. With support for multiple embedding sizes, `jina-colbert-v2` allows users to tune the precision/efficiency trade-off to suit their specific use cases, potentially offering significant savings in time and computing costs.

This model combines all these features into a single, competitively priced package, accessible via an intuitive web API and compatible with any computing framework that supports HTTP requests. <a href="https://jina.ai/?sui" rel="noreferrer">Try it out for yourself</a> with 1 million free tokens to see how it can enhance your applications and processes.
