---
model_name: "jina-colbert-v2"
model_version: "v2"
model_type: "colbert"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "560M"
language:
  - multilingual
input_type:
  - text
output_type:
  - multi-vector
diagrams:
  - jina-colbert-v2.svg
  - jina-colbert-v2-1.svg
token_length: 8K
output_dimension: 128
matryoshka_dimensions:
  - 64
  - 96
  - 128
release_date: "2024-08-31"
device: "cuda"
huggingface: "https://huggingface.co/jinaai/jina-colbert-v2"
aws: "https://aws.amazon.com/marketplace/seller-profile/vendor/jinaai"
api_link: "/?sui&model=jina-colbert-v2"
arxiv: "https://arxiv.org/abs/2408.16672"
release_blog: "/news/jina-colbert-v2-multilingual-late-interaction-retriever-for-embedding-and-reranking"
related_models:
  - jina-colbert-v1-en
tags:
  - multilingual
  - late-interaction
  - long-context
  - high-performance
  - production-ready
  - retriever
  - token-level
  - 89-languages
  - cross-lingual
  - matryoshka
  - storage-efficient
endpoints:
  - rank
  - multi-embeddings
  - late-interaction
  - multi-vector
  - matryoshka-embeddings
supported_languages: 89
availability:
  - api
  - license
  - huggingface
  - aws
  - azure
  - gcp
---

## Overview

Jina-ColBERT-v2 is a groundbreaking multilingual information retrieval model that solves the critical challenge of efficient, high-quality search across multiple languages. As the first multilingual ColBERT-like model to generate compact embeddings, it addresses the growing need for scalable, cost-effective multilingual search solutions in global applications. Organizations dealing with multilingual content, from e-commerce platforms to content management systems, can leverage this model to provide accurate search results across 89 languages while significantly reducing storage and computational costs through its innovative dimension reduction capabilities.

## Methods

The model builds upon the ColBERT architecture, introducing a sophisticated late interaction mechanism that fundamentally changes how queries and documents are matched. At its core, it uses a modified XLM-RoBERTa backbone with 560M parameters, enhanced by rotary position embeddings and optimized with flash attention. The training process involves two key stages: initial pretraining with diverse weakly-supervised data from various languages, followed by fine-tuning with labeled triplet data and supervised distillation. What makes this approach unique is the implementation of Matryoshka representation learning, which enables the model to produce embeddings in multiple dimensions (128, 96, or 64) from a single training process, allowing for dynamic storage optimization without retraining.

## Performance


In real-world testing, Jina-ColBERT-v2 demonstrates exceptional capabilities across multiple benchmarks. It achieves a 6.5% improvement over the original ColBERT-v2 on English tasks, with an average score of 0.521 across 14 BEIR benchmarks. More impressively, it outperforms traditional BM25-based retrieval methods across all tested languages on MIRACL benchmarks, showing particular strength in cross-lingual scenarios. The model maintains this high performance even when using reduced embedding dimensions - dropping from 128 to 64 dimensions results in only a 1.5% performance decrease while halving storage requirements. This translates to significant cost savings in production: for example, storing 100 million documents with 64-dimension vectors costs $659.62 per month on AWS, compared to $1,319.24 for 128 dimensions.

## Guidance

To effectively deploy Jina-ColBERT-v2, teams should consider several practical aspects. The model requires CUDA-capable hardware for optimal performance and supports document lengths up to 8,192 tokens (extendable to 12,288) while limiting queries to 32 tokens. For production deployment, the model is available through the Jina Search Foundation API, AWS marketplace, and Azure, with a non-commercial version accessible via Hugging Face. When implementing, teams should specify whether they're embedding queries or documents, as the model uses asymmetric encoding. The model isn't designed for real-time processing of extremely large document collections without proper indexing, and while it excels at multilingual retrieval, it may show slightly lower performance on specialized domain-specific tasks compared to models fine-tuned for those specific domains.
