---
title: "Jina Embeddings 2: The Best Solution for Embedding Long Documents"
slug: jina-embeddings-2-the-best-solution-for-embedding-long-documents
url: https://cms.jina.ai/jina-embeddings-2-the-best-solution-for-embedding-long-documents/
published_at: 2023-11-02T16:00:06.000+01:00
updated_at: 2024-01-24T17:08:09.000+01:00
reading_time: 7
authors: "Scott Martens"
tags: "Tech Blog"
excerpt: "With Jina Embeddings 2 models you get high-quality embeddings from an open-source, downloadable model with an input size of 8,192 tokens."
---

# Jina Embeddings 2: The Best Solution for Embedding Long Documents

Text embeddings are the backbone of AI language processing, powering text clustering, information retrieval, sentiment analysis, text-to-image processing, and information extraction, among other core tasks. But there’s a catch: Until now, text embedding models have been trained for very short text segments, typically a few hundred tokens at most. [Jina Embeddings 1 models](https://arxiv.org/abs/2307.11224), based on the [T5 models](https://huggingface.co/docs/transformers/model_doc/t5), are limited to 512 tokens. Tokens don’t *quite* match up to words one-to-one, but this means the largest texts that they can support are just a few short paragraphs.

But not anymore!

With <a href="https://arxiv.org/abs/2310.19923" rel="noreferrer">Jina Embeddings 2 models</a>, you can get high-quality embeddings from an open-source, Apache 2-licensed model with an input size of 8,192 tokens — more than sixteen times as much as Jina Embeddings 1 and the widely used [SBERT](https://www.sbert.net/) models!

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://arxiv.org/abs/2310.19923" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings 2: 8192-Token General-Purpose Text Embeddings for Long Documents
</div>
<div class="kg-bookmark-description">
Text embedding models have emerged as powerful tools for transforming sentences into fixed-sized feature vectors that encapsulate semantic information. While these models are essential for tasks like information retrieval, semantic clustering, and text re-ranking, most existing open-source models, e…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Michael Günther</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">Read the Jina Embeddings 2 paper on arXiv</span></p></figcaption>
</figure>

Few other embedding models offer input sizes exceeding 512 tokens, and at present, the *only* one that accepts over 8,000 tokens is neither open-source nor available for download. Jina Embeddings 2 models not only give you a larger input size than all other open-source models, but they also rival the performance of the closed-source alternative.

Check for yourself on the [HuggingFace MTEB leaderboard](https://huggingface.co/spaces/mteb/leaderboard).

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/spaces/mteb/leaderboard" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
MTEB Leaderboard - a Hugging Face Space by mteb
</div>
<div class="kg-bookmark-description">
Discover amazing ML apps made by the community
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">a Hugging Face Space by mteb</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/spaces/mteb/leaderboard.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## How Jina Embeddings 2 Supports Long Documents

Jina AI has implemented the [ALiBi approach](https://arxiv.org/abs/2108.12409), the first embedding model to do so. ALiBi is an alternative to the positional encoding system first proposed in the famous “[Attention is all you need](https://dl.acm.org/doi/10.5555/3295222.3295349)” paper. This scheme makes it possible to train embedding models on short texts and still get high-quality results on longer texts.

For Jina Embeddings 2, Jina AI has taken the BERT architecture and grafted it into ALiBi.

ALiBi was originally proposed for text generators (like ChatGPT) that only care about dependencies on previous words. This means that the last tokens in the input matter more than earlier ones because a text generator’s task is to produce the next word after the input. This makes no sense for an embedding model that tries to create a representation of the whole text input, so Jina Embeddings 2 models implement a bi-directional version of ALiBi.

This architectural change, however, means that we can’t use the pre-training of the original BERT model and have to completely retrain the model from scratch.

## English-Only for Now, German and Chinese Soon

Although there are plenty of multilingual text embedding models out there, there are known issues with providing universal language support. Not all languages are equal when it comes to embedding quality, and [recent research](https://aclanthology.org/2023.sigtyp-1.16.pdf) shows that models tend to be biased towards structures that parallel English ones, distorting embeddings.

In short, multilingual models have an “accent”, usually an English one due to the majority of English data in the training.

For superior language-specific performance, and more compact, easier-to-train models, Jina Embeddings are currently English-only. We’re planning German and Chinese models for the near future.

## Training Jina Embeddings 2 for Top Performance up to 8,192 Tokens

Using ALiBi means that even though Jina Embeddings 2 models support larger input sizes, the models don’t have to be trained with larger input data. The training learned for short sequences scales up to larger ones automatically.

Our training is similar to the way other embedding models are trained. We start with [masked word pre-training](https://aclanthology.org/N19-1423.pdf) using the circa 170 billion word English-only [C4 dataset](https://huggingface.co/datasets/c4). Then, we do [pairwise contrastive training](https://arxiv.org/abs/1607.08085). This means taking pairs of texts that are known to be similar or dissimilar and adjusting the weights of the embedding model so that similar inputs are closer together, and dissimilar ones are farther apart. We used a new corpus of text pairs, curated by Jina AI, based on the one [used to train the Jina Embeddings 1 models](https://arxiv.org/abs/2307.11224).

Finally, we fine-tuned the model using [text triplets and negative mining](https://finetuner.jina.ai/advanced-topics/negative-mining/), with an in-house training dataset specially augmented with sentences of opposite grammatical polarity. Embedding models have typically had trouble with negative polarity sentences: A sentence like “The dog is in the car” will often have an embedding close to “The dog is outside the car,” even though these are naturally opposite in meaning.

We added a collection of positive and negative pairs like this to the training data, using the same methods [employed for the Jina Embeddings 1 models](https://arxiv.org/abs/2307.11224) to specifically improve performance on this kind of language.

## Three Models To Better Fit Your Use Case

The Jina Embeddings 2 models come in three sizes, providing high-quality embeddings for users with different requirements and capabilities. All three support 8,192 input tokens.

- <a href="https://huggingface.co/jinaai/jina-embeddings-v2-small-en" rel="noreferrer"><code>jina-embeddings-v2-small-en</code></a>: 33 million parameters, 512-dimension embeddings.
- <a href="https://huggingface.co/jinaai/jina-embeddings-v2-base-en" rel="noreferrer"><code>jina-embeddings-v2-base-en</code></a>: 137 million parameters, 768-dimension embeddings.
- `jina-embeddings-v2-large-en`: 435 million parameters, 1,024-dimension embeddings.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/11/image.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image.png 1000w, https://cms.jina.ai/content/images/2023/11/image.png 1296w" sizes="(min-width: 720px) 720px" width="1296" height="946" alt="Diagram illustrating hierarchical overlap of circles representing repositories: v2-base-en, v2-large-en, v2-small-en" />
</figure>

The `jina-embeddings-v2-large-en` model is not yet available to download but will be released in the immediate future.

## Bigger Inputs, Leaner Models, Peak Performance

We tested the Jina Embeddings 2 models against the [MTEB benchmark suite](https://arxiv.org/abs/2210.07316) and at the time of writing:

- `jina-embeddings-v2-base-en` scores roughly on par with the best models on most benchmarks, and generally better than similarly sized ones.
- `jina-embeddings-v2-small-en` ranks near the top for models with sizes under 100MB.

The `jina-embeddings-v2-large-en` model is not yet available for testing.

However, among models that take more than 512 tokens in input, there is only one that compares to the Jina Embeddings 2 models: OpenAI’s `text-embedding-ada-002`. This model is not publicly available and can only be accessed via a paid web-based API. Its size is unknown.

<figure class="kg-card kg-image-card kg-width-wide kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/11/image-14.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-14.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-14.png 1000w, https://cms.jina.ai/content/images/2023/11/image-14.png 1184w" width="1184" height="375" alt="Bar chart titled &quot;MYTEB Evaluation Metrics&quot; with metrics such as &quot;clustering&quot;, &quot;reranking&quot;, and &quot;sentence similarity&quot; evaluated by percentage" />
<figcaption><span style="white-space: pre-wrap;">jina-embeddings-v2-base-en compared with OpenAI’s text-embedding-ada-002 on the English MTEB benchmark</span></figcaption>
</figure>

`jina-embeddings-v2-base-en` is comparable in performance with `text-embedding-ada-002` on all benchmarks and even exceeds it in several tasks. Furthermore, the Jina Embeddings 2 models all produce smaller embedding vectors than `text-embedding-ada-002` which produces 1,536-dimensional output, compared to 512, 768, and 1,024 dimensions for our three model sizes respectively. This means considerable savings in computing time and memory for applications. Storing shorter vectors takes less space in memory and storage, speeds up database retrieval, and calculating the distance between them is proportionately fast.

<figure class="kg-card kg-image-card kg-width-wide kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/11/image-15.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-15.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-15.png 1000w, https://cms.jina.ai/content/images/2023/11/image-15.png 1204w" sizes="(min-width: 1200px) 1200px" width="1204" height="376" alt="Colorful bar chart of MTEB Evaluation Metrics with scores ranging from 0 to 100 for various classification and summarization tasks" />
<figcaption><span style="white-space: pre-wrap;">Jina Embeddings 2 compared to other leading AI embedding models</span></figcaption>
</figure>

Jina AI’s base and small model compared to other leading embedding models

Furthermore, `jina-embeddings-v2-small-en` is the only model under 100MB that supports more than 512 input tokens.

Even if we set aside support for larger inputs, Jina Embeddings offers performance on par with the most common embedding foundation models, while remaining roughly the same size or even significantly smaller.

<figure class="kg-card kg-image-card kg-width-wide">
<img src="https://cms.jina.ai/content/images/2023/11/image-16.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-16.png 600w, https://cms.jina.ai/content/images/2023/11/image-16.png 1000w" width="1000" height="433" alt="Bar chart comparing sizes of leading embedding models, labeled with model names and numerical values" />
</figure>

This gives Jina Embeddings 2 models an impressive advantage in terms of accessibility, economic use of computing power, and cost to users.

## Integration

Jina Embeddings 2 models are already integrated into:

- [HuggingFace Text Embeddings Inference API](https://github.com/huggingface/text-embeddings-inference#supported-models)
- [LlamaIndex](https://github.com/run-llama/llama_index/blob/main/docs/examples/embeddings/jina_embeddings.ipynb)
- [Transformers.js](https://twitter.com/xenovacom/status/1717904546481992094)
- [LLM](https://github.com/simonw/llm-embed-jina)

More integrations are coming soon, both from Jina AI and our open-source user community.

## Try It Out Yourself Right Now

Go to <https://jina.ai/#enterprises> to get an access key for Jina AI's online Embedding API with ten thousand free tokens for you to embed. You'll find the key on the upper right:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/11/image-4.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-4.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-4.png 1000w, https://cms.jina.ai/content/images/2023/11/image-4.png 1289w" sizes="(min-width: 720px) 720px" width="1289" height="712" alt="Webpage screenshot highlighting ForEnterprise&#39;s services, with call-to-actions urging to try embedding models and API key sign up" />
</figure>

You can access Jina Embeddings 2 models hosted at Jina AI via any standard HTTP interface. Use the drop-down menus to select between the `jina-embeddings-v2-base-en` and `jina-embeddings-v2-small-en` models, and to get code snippets to use the Embeddings API.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/11/image-6.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-6.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-6.png 1000w, https://cms.jina.ai/content/images/2023/11/image-6.png 1309w" sizes="(min-width: 720px) 720px" width="1309" height="737" alt="Screenshot of the ForEnterprise API integration page, highlighting world-class embedding models, key creation, and the announcement for future features" />
</figure>

You can also get example code snippets in a variety of languages and frameworks to help integrate Jina Embeddings directly into your project:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/11/image-7.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-7.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-7.png 1000w, https://cms.jina.ai/content/images/2023/11/image-7.png 1307w" sizes="(min-width: 720px) 720px" width="1307" height="972" alt="Dark mode web interface of &quot;ForEnterprise&quot; showing embedding models for technologies like Rust and Python with a free trial offer" />
</figure>

And if you need to add tokens to your API key, just click the "Top Up" tab.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/11/image-8.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/11/image-8.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/11/image-8.png 1000w, https://cms.jina.ai/content/images/2023/11/image-8.png 1281w" sizes="(min-width: 720px) 720px" width="1281" height="1155" alt="Web interface of For Enterprise embedding models offering token packages for search &amp; RAG systems and pricing details" />
</figure>

## Future Jina Embeddings Models

Jina AI will be rolling out a larger model, `jina-embeddings-v2-large-en`, in the immediate future, which we expect to exceed the performance of the other Jina Embeddings 2 models and compete with the highest-scoring large embedding models.

In the near future, we are expanding our offerings to include German and Chinese embedding models, which we expect will match or exceed state-of-the-art performance in both languages.

These benchmark results prove the robustness of Jina AI’s contrastive training methodology, and we are always investigating improved model design and AI techniques. Our mission is to put more intelligence and higher performance into more compact open-access models that you can affordably access via our API, or easily run on your hardware and in your cloud instances.
