---
title: "Using Jina Embeddings v2 with Haystack Pipelines"
slug: jina-embeddings-v2-and-deepset-haystack
url: https://cms.jina.ai/jina-embeddings-v2-and-deepset-haystack/
published_at: 2024-01-19T16:00:07.000+01:00
updated_at: 2024-01-24T16:11:10.000+01:00
reading_time: 1
authors: "Saahil Ognawala, Scott Martens"
tags: "Tech Blog"
excerpt: "Access Jina AI's state-of-the-art open-source embedding models in your Haystack application pipeline."
---

# Using Jina Embeddings v2 with Haystack Pipelines

<a href="https://www.deepset.ai/" rel="noreferrer">Deepset</a> has integrated <a href="https://jina.ai/embeddings/" rel="noreferrer">Jina Embeddings v2</a> into its industry-leading <a href="https://haystack.deepset.ai/" rel="noreferrer">Haystack</a> NLP framework. You can now access Jina AI's state-of-the-art open-source embedding models in your Haystack pipeline.

We have collaborated with Deepset to bring you a tutorial on using Jina Embeddings v2 in Haystack to analyze legal documents. Follow the link below to Deepset's blog to see how you can create a retrieval-augmented generation (RAG) application using Jina AI's industry-leading embeddings and Haystack!

<figure class="kg-card kg-bookmark-card">
<a href="https://haystack.deepset.ai/blog/using-jina-embeddings-haystack" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Using Jina Embeddings v2 with Haystack 2.0 pipelines to summarize legal documents | Haystack
</div>
<div class="kg-bookmark-description">
Learn how to use the Jina v2 Embedding models in a RAG pipeline with our new Haystack integration.
</div>
<div class="kg-bookmark-metadata">
<img src="https://haystack.deepset.ai/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Haystack</span><span class="kg-bookmark-publisher">Tilde Thurium Senior Developer Advocate</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://haystack.deepset.ai/blog/using-jina-embeddings-haystack/thumbnail.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Top-performing, 8192-token context length, $100 for 1.25B tokens, seamless OpenAI alternative, free trial
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
