---
title: "Jina Embeddings v2 and MongoDB Atlas"
slug: jina-embeddings-v2-and-mongodb-atlas
url: https://cms.jina.ai/jina-embeddings-v2-and-mongodb-atlas/
published_at: 2023-12-06T10:49:40.000+01:00
updated_at: 2024-01-24T16:13:17.000+01:00
reading_time: 1
authors: "Scott Martens, Saahil Ognawala"
tags: "Tech Blog"
excerpt: "Supercharge MongoDB Atlas multi-cloud vector search solutions with Jina AI’s industry-leading embeddings!"
---

# Jina Embeddings v2 and MongoDB Atlas

Jina AI and <a href="https://www.mongodb.com/" rel="noreferrer">MongoDB</a> have collaborated to bring you a tutorial on using <a href="https://jina.ai/embeddings/" rel="noreferrer">Jina Embeddings v2</a> to bring state-of-the-art semantic search to MongoDB Atlas. Follow the link below to MongoDB's website to see how you can supercharge MongoDB’s multi-cloud vector search solutions with Jina AI’s industry-leading embeddings!

<figure class="kg-card kg-bookmark-card">
<a href="https://www.mongodb.com/developer/products/atlas/jina-ai-semantic-search/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Semantic search with Jina Embeddings v2 and MongoDB Atlas | MongoDB
</div>
<div class="kg-bookmark-description">
Follow along with this tutorial on using Jina Embeddings v2 with MongoDB Atlas for vector search.
</div>
<div class="kg-bookmark-metadata">
<img src="https://www.mongodb.com/developer/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">MongoDB</span><span class="kg-bookmark-publisher">Scott Martens, Saahil Ognawala</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://images.contentstack.io/v3/assets/blt39790b633ee0d5a7/blt3d996d2aa8d9ece9/647a2f77f7b1280bb15174b7/Technical_SOFTWARE_Terminal(4)_Spot_BS_ForestGreen.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Top-performing, 8192-token length, $100 for 1.25B tokens, seamless OpenAI alternative, free trial
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
