---
model_name: "jina-embeddings-v2-base-es"
model_version: "v2"
model_type: "text-embeddings"
organization: "Jina AI"
license: "Apache-2.0"
parameter_size: "161M"
language:
  - en
  - es
input_type:
  - text
output_type:
  - vector
diagrams:
  - jina-embeddings-v2-es.svg
token_length: 8K
output_dimension: 768
release_date: "2024-02-14"
device: "cuda"
late_chunking: true
huggingface: "https://huggingface.co/jinaai/jina-embeddings-v2-base-es"
aws: "https://aws.amazon.com/marketplace/seller-profile/vendor/jinaai"
arxiv: "https://arxiv.org/abs/2310.19923"
api_link: "/?sui&model=jina-embeddings-v2-base-es"
release_blog: "/news/aqui-se-habla-espanol-top-quality-spanish-english-embeddings-and-8k-context"
related_models:
  - jina-embeddings-v2-base-en
  - jina-embeddings-v2-base-de
  - jina-embeddings-v2-base-zh
deprecated_by:
  - jina-embeddings-v3
tags:
  - spanish
  - bilingual
  - long-context
  - 8k-context
  - bert-based
  - production-ready
  - semantic-search
  - cross-lingual
  - text-embeddings
  - fine-tunable
endpoints:
  - embedding
  - fine-tuning
availability:
  - api
  - huggingface
  - aws
  - azure
---

## Overview

Jina Embeddings v2 Base Spanish is a groundbreaking bilingual text embedding model that addresses the critical challenge of cross-lingual information retrieval and analysis between Spanish and English content. Unlike traditional multilingual models that often show bias towards specific languages, this model delivers truly balanced performance across both Spanish and English, making it indispensable for organizations operating in Spanish-speaking markets or handling bilingual content. The model's most remarkable feature is its ability to generate geometrically aligned embeddings - when texts in Spanish and English express the same meaning, their vector representations naturally cluster together in the embedding space, enabling seamless cross-language search and analysis.

## Methods

At the heart of this model lies an innovative architecture based on symmetric bidirectional ALiBi (Attention with Linear Biases), a sophisticated approach that enables processing of sequences up to 8,192 tokens without traditional positional embeddings. The model utilizes a modified BERT architecture with 161M parameters, incorporating Gated Linear Units (GLU) and specialized layer normalization techniques. Training follows a three-stage process: initial pre-training on a massive text corpus, followed by fine-tuning with carefully curated text pairs, and finally, hard-negative training to enhance discrimination between similar but semantically distinct content. This approach, combined with 768-dimensional embeddings, allows the model to capture nuanced semantic relationships while maintaining computational efficiency.

## Performance

In comprehensive benchmark evaluations, the model demonstrates exceptional capabilities, particularly in cross-language retrieval tasks where it outperforms significantly larger multilingual models like E5 and BGE-M3 despite being only 15-30% of their size. The model achieves superior performance in retrieval and clustering tasks, showing particular strength in matching semantically equivalent content across languages. When tested on the MTEB benchmark, it exhibits robust performance across various tasks including classification, clustering, and semantic similarity. The extended context window of 8,192 tokens proves especially valuable for long-document processing, showing consistent performance even with documents spanning multiple pages - a capability most competing models lack.

## Guidance

To effectively utilize this model, organizations should ensure access to CUDA-capable GPU infrastructure for optimal performance. The model integrates seamlessly with major vector databases and RAG frameworks including MongoDB, Qdrant, Weaviate, and Haystack, making it readily deployable in production environments. It excels in applications such as bilingual document search, content recommendation systems, and cross-language document analysis. While the model shows impressive versatility, it's particularly optimized for Spanish-English bilingual scenarios and may not be the best choice for monolingual applications or scenarios involving other language pairs. For optimal results, input texts should be properly formatted in either Spanish or English, though the model handles mixed-language content effectively. The model supports fine-tuning for domain-specific applications, but this should be approached with careful consideration of the training data quality and distribution.
