---
model_name: "jina-embeddings-v4"
model_version: "v4"
model_type: "multimodal"
organization: "Jina AI"
license: "Qwen Research License"
parameter_size: "3.8B"
language:
  - multilingual
input_type:
  - text
  - image
  - pdf
output_type:
  - vector
  - multi-vector
diagrams:
token_length: 32K
image_size: 768×28×28
output_dimension: 2048
matryoshka_dimensions:
  - 128
  - 256
  - 512
  - 1024
  - 2048
quantized: true
release_date: "2025-06-24"
device: "cuda"
late_chunking: true
api_link: "/?sui&model=jina-embeddings-v4"
huggingface: "https://huggingface.co/jinaai/jina-embeddings-v4"
arxiv: "https://arxiv.org/abs/2506.18902"
aws: "https://aws.amazon.com/marketplace/pp/prodview-woadrus5knmjk"
azure: "https://azuremarketplace.microsoft.com/en-us/marketplace/apps/jinaai.jina-embeddings-v4?tab=Overview"
gcp: "https://console.cloud.google.com/marketplace/product/jinaai-public/jina-embeddings-v4?inv=1&invt=Ab23cA"
release_blog: "/news/jina-embeddings-v4-universal-embeddings-for-multimodal-multilingual-retrieval"
related_models:
  - jina-embeddings-v3
  - jina-clip-v2
diagrams:
  - jina-v4-3.svg
  - jina-v4-4.svg
  - jina-v4-1.svg
  - jina-v4-2.svg
tasks:
  - retrieval
  - text-matching
  - code
tags:
  - multimodal-embedding
  - document retrieval
  - multilingual
  - multi-vector
  - long-context
  - production
  - matryoshka
endpoints:
  - embedding
  - fine-tuning
  - late_chunking
availability:
  - api
  - huggingface
---

## Overview


## Methods


## Performance


## Guidance

