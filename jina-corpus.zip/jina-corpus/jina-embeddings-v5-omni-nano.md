---
model_name: "jina-embeddings-v5-omni-nano"
model_version: "v5"
model_type: "multimodal"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "1.0B"
language:
  - multilingual
input_type:
  - text
  - image
  - audio
  - video
  - pdf
output_type:
  - vector
diagrams:
  - jina-embeddings-v5-omni-nano-1.svg
  - jina-embeddings-v5-omni-nano-2.svg
  - jina-embeddings-v5-omni-nano-3.svg
  - jina-embeddings-v5-omni-nano-4.svg
token_length: 8K
quantized: true
mlx: true
output_dimension: 768
matryoshka_dimensions:
  - 32
  - 64
  - 128
  - 256
  - 512
  - 768
release_date: "2026-05-07"
device: "cuda"
late_chunking: false
api_link: "/?sui&model=jina-embeddings-v5-omni-nano"
huggingface: "https://huggingface.co/collections/jinaai/jina-embeddings-v5-omni-69f336b985c156b1d757029e"
arxiv: "https://arxiv.org/abs/2605.08384"
aws: ""
azure: ""
gcp: ""
release_blog: "/news/jina-embeddings-v5-omni-multimodal-embeddings-for-text-image-audio-and-video"
related_models:
  - jina-embeddings-v5-omni-small
  - jina-embeddings-v5-text-nano
  - jina-embeddings-v3
  - jina-clip-v2
tasks:
  - retrieval
  - text-matching
  - clustering
  - classification
tags:
  - multimodal-embedding
  - embeddings
  - multilingual
  - long-context
  - production
  - matryoshka
  - last-token-pooling
  - visual-document-retrieval
endpoints:
  - embedding
  - classify
availability:
  - elastic
  - api
  - aws
  - huggingface
---
## Overview

jina-embeddings-v5-omni-nano (~1.04B parameters) is the compact variant of the v5-omni family, designed for edge and commodity hardware. It extends jina-embeddings-v5-text-nano with the same multimodal capabilities: text, images, video, and audio inputs in a shared vector space. Text-only outputs are bit-identical to jina-embeddings-v5-text-nano. The model produces 768-dimensional embeddings with Matryoshka truncation down to 32 dimensions and supports 8K token context length.

## Methods

Follows the same third-stage training as omni-small, extending jina-embeddings-v5-text-nano. The EuroBERT-210M text backbone and LoRA adapters are frozen. Cross-modal projectors connect a SigLIP2 Base vision encoder and Whisper-large-v3 audio encoder to the text backbone. Training data and objectives mirror omni-small.

## Performance

Text-only performance is bit-identical to jina-embeddings-v5-text-nano. Multimodal performance is slightly below omni-small due to the narrower embedding space (768 vs 1024 dimensions) and smaller text backbone, but maintains strong cross-modal alignment. Optimized for CPU and edge hardware where the larger omni-small model cannot run.

## Guidance

Same usage pattern as omni-small with identical LoRA adapter selection and multimodal input handling. Key differences: 768-dimensional output space (Matryoshka truncation down to 32) and 8K context window. The nano variant runs on commodity hardware without GPU acceleration. Text-only embeddings are drop-in compatible with jina-embeddings-v5-text-nano.
