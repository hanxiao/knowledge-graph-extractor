---
model_name: "jina-embeddings-v5-omni-small"
model_version: "v5"
model_type: "multimodal"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "1.7B"
language:
  - multilingual
input_type:
  - text
  - image
  - audio
  - video
  - pdf
output_type:
  - vector
diagrams:
  - jina-embeddings-v5-omni-small-1.svg
  - jina-embeddings-v5-omni-small-2.svg
  - jina-embeddings-v5-omni-small-3.svg
  - jina-embeddings-v5-omni-small-4.svg
token_length: 32K
quantized: true
mlx: true
output_dimension: 1024
matryoshka_dimensions:
  - 32
  - 64
  - 128
  - 256
  - 512
  - 768
  - 1024
release_date: "2026-05-07"
device: "cuda"
late_chunking: false
api_link: "/?sui&model=jina-embeddings-v5-omni-small"
huggingface: "https://huggingface.co/collections/jinaai/jina-embeddings-v5-omni-69f336b985c156b1d757029e"
arxiv: "https://arxiv.org/abs/2605.08384"
aws: ""
azure: ""
gcp: ""
release_blog: "/news/jina-embeddings-v5-omni-multimodal-embeddings-for-text-image-audio-and-video"
related_models:
  - jina-embeddings-v5-omni-nano
  - jina-embeddings-v5-text-small
  - jina-embeddings-v3
  - jina-clip-v2
tasks:
  - retrieval
  - text-matching
  - clustering
  - classification
tags:
  - multimodal-embedding
  - embeddings
  - multilingual
  - long-context
  - production
  - matryoshka
  - last-token-pooling
  - visual-document-retrieval
endpoints:
  - embedding
  - classify
availability:
  - elastic
  - api
  - aws
  - huggingface
---
## Overview

jina-embeddings-v5-omni-small (~1.74B parameters) is a multimodal embedding model that accepts text, images, video, and audio and produces embeddings in a shared vector space aligned with jina-embeddings-v5-text-small. You can index with text and query with any modality, or vice versa, without reindexing. The text backbone and all four task-specific LoRA adapters are frozen during multimodal training, so text-only outputs are bit-identical to jina-embeddings-v5-text-small. The model produces 1024-dimensional embeddings with Matryoshka truncation down to 32 dimensions and supports 32K token context length.

## Methods

Trained in a third stage extending jina-embeddings-v5-text-small. The text backbone and all four task-specific LoRA adapters are frozen; only the cross-modal projectors are newly trained. A SigLIP2 So400m vision encoder handles images and video (32 uniformly sampled frames). A Whisper-large-v3 audio encoder handles audio input. PDF pages are rendered as images and processed through the vision pathway. Training uses contrastive loss with cross-modal hard negatives to align visual and audio representations with the existing text embedding space.

## Performance

Text-only performance is bit-identical to jina-embeddings-v5-text-small — the text backbone and LoRA adapters are untouched during multimodal training. On cross-modal retrieval, the model demonstrates strong alignment across text-image, text-audio, and text-video tasks. PDF page retrieval is handled through the vision pathway. The omni-small model offers the best accuracy-efficiency tradeoff among Jina multimodal embedding models for server deployment.

## Guidance

Same four LoRA adapters as v5-text-small: retrieval, text-matching, clustering, and classification. For multimodal inputs via the API, pass image URLs, audio file URLs, video file URLs, or PDF URLs directly — the model routes each modality through the appropriate encoder. Supported audio formats include WAV, MP3, FLAC, OGG, M4A, and Opus. Video inputs are processed as 32 uniformly sampled frames. Mix modalities freely within a single batch: the embedding space is shared across all modalities. Use cosine similarity for comparison. Matryoshka truncation from 1024 to 32 dimensions is supported. Text-only embeddings are drop-in compatible with jina-embeddings-v5-text-small — no reindexing needed when upgrading.
