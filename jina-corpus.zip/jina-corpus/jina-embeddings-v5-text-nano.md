---
model_name: "jina-embeddings-v5-text-nano"
model_version: "v5"
model_type: "text-embeddings"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "239M"
language:
  - multilingual
input_type:
  - text
output_type:
  - vector
diagrams:
  - jina-embeddings-v5-text-nano-1.svg
token_length: 8K
quantized: true
mlx: true
output_dimension: 768
matryoshka_dimensions:
  - 32
  - 64
  - 128
  - 256
  - 512
  - 768
release_date: "2026-02-18"
device: "cuda"
late_chunking: false
api_link: "/?sui&model=jina-embeddings-v5-text-nano"
huggingface: "https://huggingface.co/jinaai/jina-embeddings-v5-text-nano"
arxiv: "https://arxiv.org/abs/2602.15547"
aws: ""
azure: ""
gcp: ""
release_blog: "/news/jina-embeddings-v5-text-distilling-4b-quality-into-sub-1b-multilingual-embeddings"
related_models:
  - jina-embeddings-v3
  - jina-embeddings-v5-text-small
tasks:
  - retrieval
  - text-matching
  - clustering
  - classification
tags:
  - text-embedding
  - multilingual
  - long-context
  - production
  - matryoshka
  - last-token-pooling
endpoints:
  - embedding
  - classify
availability:
  - elastic
  - api
  - aws
  - huggingface
---

## Overview

jina-embeddings-v5-text-nano is a 239M parameter multilingual text embedding model built on the EuroBERT-210M backbone. It supports context lengths up to 8K tokens and produces 768-dimensional embeddings, with Matryoshka Representation Learning enabling flexible truncation to dimensions as low as 32. Designed for resource-constrained environments, it uses last-token pooling and supports retrieval, text-matching, clustering, and classification tasks.

## Methods

The model is built on EuroBERT-210M, a compact bidirectional encoder pretrained on multilingual data. It employs last-token pooling to generate embeddings from the final token representation. Matryoshka Representation Learning allows embedding dimensions to be truncated at any of the supported sizes (32, 64, 128, 256, 512, 768) while maintaining strong performance. The 8K context length enables processing of long documents without truncation.

## Performance

jina-embeddings-v5-text-nano delivers competitive performance across retrieval, text-matching, clustering, and classification benchmarks at just 239M parameters, making it the most efficient model in the Jina embeddings family for latency-sensitive and edge deployments.

## Guidance

Select the appropriate task type for your use case: retrieval, text-matching, clustering, or classification. For storage-constrained applications, use Matryoshka dimension truncation to reduce embedding size. The nano model is ideal for applications requiring low latency or deployment on limited hardware, while the 8K context window still supports long documents natively.
