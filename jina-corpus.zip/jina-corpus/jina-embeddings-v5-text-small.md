---
model_name: "jina-embeddings-v5-text-small"
model_version: "v5"
model_type: "text-embeddings"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "677M"
language:
  - multilingual
input_type:
  - text
output_type:
  - vector
diagrams:
  - jina-embeddings-v5-text-small-1.svg
token_length: 32K
quantized: true
mlx: true
output_dimension: 1024
matryoshka_dimensions:
  - 32
  - 64
  - 128
  - 256
  - 512
  - 1024
release_date: "2026-02-18"
device: "cuda"
late_chunking: false
api_link: "/?sui&model=jina-embeddings-v5-text-small"
huggingface: "https://huggingface.co/jinaai/jina-embeddings-v5-text-small"
arxiv: "https://arxiv.org/abs/2602.15547"
aws: ""
azure: ""
gcp: ""
release_blog: "/news/jina-embeddings-v5-text-distilling-4b-quality-into-sub-1b-multilingual-embeddings"
related_models:
  - jina-embeddings-v3
  - jina-embeddings-v5-text-nano
tasks:
  - retrieval
  - text-matching
  - clustering
  - classification
tags:
  - text-embedding
  - multilingual
  - long-context
  - production
  - matryoshka
  - last-token-pooling
endpoints:
  - embedding
  - classify
availability:
  - elastic
  - api
  - aws
  - huggingface
---

## Overview

jina-embeddings-v5-text-small is a 677M parameter multilingual text embedding model built on the Qwen3-0.6B-Base backbone. It supports context lengths up to 32K tokens and produces 1024-dimensional embeddings, with Matryoshka Representation Learning enabling flexible truncation to dimensions as low as 32. The model uses last-token pooling and supports retrieval, text-matching, clustering, and classification tasks.

## Methods

The model is built on Qwen3-0.6B-Base, a multilingual language model pretrained on 119 languages. It employs last-token pooling to generate embeddings from the final token representation. The training incorporates Matryoshka Representation Learning to allow embedding dimensions to be truncated at any of the supported sizes (32, 64, 128, 256, 512, 1024) while maintaining strong performance. The 32K context length enables processing of long documents without truncation.

## Performance

jina-embeddings-v5-text-small achieves strong performance across retrieval, text-matching, clustering, and classification benchmarks while maintaining a compact 677M parameter footprint, making it suitable for production deployments where efficiency is critical.

## Guidance

Select the appropriate task type for your use case: retrieval, text-matching, clustering, or classification. For storage-constrained applications, use Matryoshka dimension truncation to reduce embedding size while preserving most of the retrieval quality. The 32K context window supports long documents natively without chunking.
