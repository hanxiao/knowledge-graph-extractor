---
title: "Jina Reader for Search Grounding to Improve Factuality of LLMs"
slug: jina-reader-for-search-grounding-to-improve-factuality-of-llms
url: https://cms.jina.ai/jina-reader-for-search-grounding-to-improve-factuality-of-llms/
published_at: 2024-05-14T18:06:37.000+02:00
updated_at: 2024-05-15T13:06:08.000+02:00
reading_time: 5
authors: "Jina AI"
tags: "Press"
excerpt: "Grounding is essential for GenAI apps. Our new https://s.jina.ai/ allows LLMs to access the latest knowledge from the web, enabling search grounding and making responses more trustworthy."
---

# Jina Reader for Search Grounding to Improve Factuality of LLMs

Grounding is *absolutely* essential for GenAI applications.

You have probably seen many tools, prompts, and RAG pipelines designed to improve the factuality of LLMs since 2023. Why? Because the primary barrier preventing enterprises from deploying LLMs to millions of users is **the trust**: Is the answer genuine, or is it a mere hallucination from the model? This is an industry-wide problem, and Jina AI has been working very hard to solve it. Today, with the new Jina Reader search grounding feature, **you can simply use `https://s.jina.ai/YOUR_SEARCH_QUERY` to search the latest world-knowledge from the web.** With this, you are one step closer to improving the factuality of LLMs, making their responses more trustworthy and helpful.

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/reader" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Reader API
</div>
<div class="kg-bookmark-description">
Read URLs or search the web, get better grounding for LLMs.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-reader-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">API, demo can be found in the product page</span></p></figcaption>
</figure>

## The Factuality Problem of LLMs

We all know LLMs can make things up and harm user trust. LLMs may say things that are not factual (aka hallucinate), especially regarding topics they didn't learn about during training. This could be either new information created since training or niche knowledge that has been "marginalized" during training.

As a result, when it comes to questions like "What's the weather today?" or "Who won the Oscar for Best Actress this year?" the model will either respond with "I don't know" or give you outdated information.

<figure class="kg-card kg-image-card kg-card-hascaption">
<a href="https://jina.ai/reader/#demo"><img src="https://cms.jina.ai/content/images/2024/05/image-13.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-13.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/image-13.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/05/image-13.png 1600w, https://cms.jina.ai/content/images/2024/05/image-13.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="803" alt="Interactive web interface for querying Jina AI&#39;s founding details with input fields, navigation options, and informational no" /></a>
<figcaption><span style="white-space: pre-wrap;">An example of niche knowledge being "marginalized" during training can be seen when we asked </span><span><code spellcheck="false" style="white-space: pre-wrap;">GPT-3.5-turbo</code></span><span style="white-space: pre-wrap;"> "When was Jina AI founded?" and received an incorrect answer. However, when using Reader for search grounding, the same LLM was able to provide the correct answer. In fact, it was precise to the exact date.</span></figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<a href="https://jina.ai/reader/#demo"><img src="https://cms.jina.ai/content/images/2024/05/image-14.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/image-14.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/image-14.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/05/image-14.png 1600w, https://cms.jina.ai/content/images/2024/05/image-14.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="799" alt="Screen interface for inquiring about SpaceX launches with a query field and details about upcoming missions." /></a>
<figcaption><span style="white-space: pre-wrap;">An example of new information created since training. We asked </span><span><code spellcheck="false" style="white-space: pre-wrap;">GPT-3.5-turbo</code></span><span style="white-space: pre-wrap;"> "When will the next SpaceX launch be?" (today is May 14th 2024) and the model responded with old information back in 2021.</span></figcaption>
</figure>

## How Jina Reader Helps Better Grounding

Previously, users could easily prepend `https://r.jina.ai` to read text and image content from a particular URL into an LLM-friendly format and use it for check grounding and fact verification. Since its first release on April 15th, we have served over **18 million requests** from the world, suggesting its popularity.

Today we are excited to move the needle further by introducing the search grounding API `https://s.jina.ai`. By simply prepending it before your query, Reader will search the web and retrieve the top 5 results. Each result includes **a title, LLM-friendly markdown** (full content! not abstract), and **a URL** that allows you to attribute the source. Here is an example below, you are also encouraged to try [our live demo here](https://jina.ai/reader/#demo).

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled-4.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled-4.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Untitled-4.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/05/Untitled-4.jpg 1600w, https://cms.jina.ai/content/images/2024/05/Untitled-4.jpg 1686w" sizes="(min-width: 720px) 720px" width="1686" height="1846" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled-5.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled-5.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Untitled-5.jpg 1000w, https://cms.jina.ai/content/images/2024/05/Untitled-5.jpg 1338w" sizes="(min-width: 720px) 720px" width="1338" height="798" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">Left: Markdown mode (directly visit </span><a href="https://s.jina.ai/who+is+han+xiao" rel="noreferrer"><span style="white-space: pre-wrap;">https://s.jina.ai/who+is+han+xiao</span></a><span style="white-space: pre-wrap;">); Right JSON mode (using </span><span><code spellcheck="false" style="white-space: pre-wrap;">curl https://s.jina.ai/who+is+han+xiao -H 'accept: application/json'</code></span><span style="white-space: pre-wrap;">). Btw, an ego question like this always serves as a good test case.</span></p></figcaption>
</figure>

There are three principles when we designing the search grounding in the Reader:

- Improve factuality;
- Access up-to-date information, i.e., world knowledge;
- Connect an answer to its source.

Besides being extremely easy to use, `s.jina.ai` is also highly scalable and customizable as it leverages the existing flexible and scalable infrastructure of `r.jina.ai`. You can set parameters to control the image captioning, filter granularity, etc., via the request headers.

<figure class="kg-card kg-image-card kg-card-hascaption">
<a href="https://jina.ai/reader#apiform"><img src="https://cms.jina.ai/content/images/2024/05/6cf51d582e35abedd95e3272a0eaa7f1.gif" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/6cf51d582e35abedd95e3272a0eaa7f1.gif 600w, https://cms.jina.ai/content/images/2024/05/6cf51d582e35abedd95e3272a0eaa7f1.gif 1000w" sizes="(min-width: 720px) 720px" width="1000" height="636" alt="Configuration screen of Reader API with options for API behavior, proxy settings, and cookie forwarding against a dark backgr" /></a>
<figcaption><span style="white-space: pre-wrap;">Try the interactive code snippet for the advanced usage of Reader API</span></figcaption>
</figure>

## Jina Reader as a Comprehensive Grounding Solution

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/05/Heading--17-.svg" class="kg-image" loading="lazy" width="1200" height="630" alt="Technical flowchart on a black background illustrating the processing of knowledge through various AI-related URLs." />
</figure>

If we combine search grounding (`s.jina.ai`) and check grounding (`r.jina.ai`), we can build a very comprehensive grounding solution for LLMs, agents, and RAG systems. In a typical trustworthy RAG workflow, Jina Reader works as follows:

1.  User inputs a question;
2.  Retrieve the latest information from the web using `s.jina.ai`;
3.  Generate an initial answer with a citation to the search result from the last step;
4.  Use `r.jina.ai` to ground the answer with your own URL; or read the inline URLs from the source returned from step 3 to get deeper grounding;
5.  Final answer generation and highlight potentially ungrounded claims to the user.

## Higher Rate Limit with API Keys

Users can enjoy the new search grounding endpoint for free without authorization. Moreover, when providing a Jina AI API key in the request header (the same key can be used in the Embedding/Reranking API), you can immediately enjoy 200 requests per minute per IP for `r.jina.ai` and 40 requests per minute per IP for `s.jina.ai`. The details can be found in the table below:

| Endpoint | Description | Rate limit w/o API key | Rate limit with API key | Token counting scheme | Average latency |
|----|----|----|----|----|----|
| `r.jina.ai` | Read a URL return its content, useful for check grounding | 20 RPM | 200 RPM | Based on the output tokens | 3 seconds |
| `s.jina.ai` | Search on the web return top-5 results, useful for search grounding | 5 RPM | 40 RPM | Based on the output tokens for all 5 search results | 30 seconds |

## Conclusion

We believe grounding is essential for GenAI applications, and building grounded solutions should be easy for everyone. That's why we introduced the new search grounding endpoint, `s.jina.ai`, which allows developers to easily incorporate world knowledge into their GenAI applications. We want developers to establish user trust, provide explainable answers, and inspire curiosity in millions of users.
