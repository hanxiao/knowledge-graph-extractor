---
model_name: "jina-reranker-m0"
model_version: "m0"
model_type: "reranker"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "2.4B"
language:
  - multilingual
token_length: 10K
device: "cuda"
input_type:
  - text (query)
  - image (query)
  - text (document)
  - image (document)
output_type:
  - ranking
quantized: true
diagrams:
  - jina-reranker-m0-1.svg
  - jina-reranker-m0-2.svg
  - jina-reranker-m0-3.svg
  - jina-reranker-m0-4.svg
release_date: "2025-04-08"
huggingface: "https://huggingface.co/jinaai/jina-reranker-m0"
aws: "https://aws.amazon.com/marketplace/seller-profile/vendor/jinaai"
api_link: "/?sui=reranker&model=jina-reranker-m0"
release_blog: "/news/jina-reranker-m0-multilingual-multimodal-document-reranker"
related_models:
  - jina-reranker-v2-base-multilingual
image_size: 768×28×28
tags:
  - multimodal
  - multilingual
  - code-search
  - long-context
  - reranker
  - vlm
  - decoder-only
endpoints:
  - rank
availability:
  - api
  - license
  - huggingface
  - aws
  - azure
  - gcp
---

