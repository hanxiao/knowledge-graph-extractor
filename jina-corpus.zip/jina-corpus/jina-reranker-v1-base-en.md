---
model_name: "jina-reranker-v1-base-en"
model_version: "v1"
model_type: "reranker"
organization: "Jina AI"
huggingface: "https://huggingface.co/jina-ai/jina-reranker-v1-base-en"
release_blog: "/news/maximizing-search-relevancy-and-rag-accuracy-with-jina-reranker"
api_link: "/?sui&model=jina-reranker-v1-base-en"
aws: "https://aws.amazon.com/marketplace/pp/prodview-6dmufr42yb2hi"
license: "Apache-2.0"
parameter_size: "137M"
release_date: "2024-02-29"
input_type:
  - text (query)
  - text (document)
output_type:
  - ranking
diagrams:
  - jina-reranker-v1.svg
language:
  - en
token_length: 8K
device: "cuda"
related_models:
  - jina-reranker-v1-turbo-en
  - jina-reranker-v1-tiny-en
deprecated_by:
  - jina-reranker-v2-base-multilingual
tags:
  - reranker
  - english
  - base-model
  - high-precision
  - long-context
  - search-refinement
  - document-ranking
endpoints:
  - rank
availability:
  - api
  - huggingface
  - aws
  - azure
---

## Overview

Jina Reranker v1 Base English revolutionizes search result refinement by addressing a critical limitation in traditional vector search systems: the inability to capture nuanced relationships between queries and documents. While vector search with cosine similarity provides fast initial results, it often misses subtle relevance signals that human users intuitively understand. This reranker bridges that gap by performing sophisticated token-level analysis of both queries and documents, delivering a remarkable 20% improvement in search accuracy. For organizations struggling with search precision or implementing RAG systems, this model offers a powerful solution that significantly improves result quality without requiring a complete overhaul of existing search infrastructure.

## Methods

The model employs a BERT-based cross-attention architecture that fundamentally differs from traditional embedding-based approaches. Instead of comparing pre-computed document embeddings, it performs dynamic token-level interactions between queries and documents, enabling it to capture contextual nuances that simple similarity metrics miss. The architecture's 137M parameters are carefully structured to enable deep semantic understanding while maintaining computational efficiency. The model supports a context length of 1,024 tokens, with automatic chunking and max-pooling across chunks for longer documents - enabling effective processing of extended content while maintaining accurate relevance scoring.

## Performance


In comprehensive benchmarks, the model demonstrates exceptional improvements across key metrics, achieving an 8% increase in hit rate and a 33% boost in mean reciprocal rank compared to baseline vector search. On the BEIR benchmark, it achieves an average score of 0.5588, outperforming other rerankers from BGE (0.5032), BCE (0.4969), and Cohere (0.5141). Particularly impressive is its performance on the LoCo benchmark, where it scores 0.873 on average, significantly ahead of competitors in understanding local coherence and context-aware ranking. The model shows particular strength in technical content evaluation, achieving scores of 0.996 on qasper_abstract tasks and 0.962 on government report analysis, though it shows relatively lower performance (0.466) on meeting summarization tasks.

## Guidance

The model requires CUDA-capable hardware for optimal performance and is accessible through both API endpoints and AWS SageMaker deployment options. While it can process extremely long sequences, users should consider the trade-off between context length and processing time—the model's latency increases notably with longer documents, from 156ms for 256 tokens to 7068ms for 4096 tokens with a 512-token query. For production deployments, it's recommended to implement a two-stage pipeline where vector search provides initial candidates for reranking. The model is specifically optimized for English content and may not perform optimally on multilingual or code-heavy documents. When integrating with RAG systems, users should carefully tune the number of documents sent for reranking based on their latency requirements, with 100-200 documents typically providing a good balance between quality and performance.
