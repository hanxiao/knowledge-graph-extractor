---
model_name: "jina-reranker-v1-tiny-en"
model_version: "v1"
model_type: "reranker"
organization: "Jina AI"
license: "Apache-2.0"
parameter_size: "33M"
language:
  - en
token_length: 8K
device: "cuda"
input_type:
  - text (query)
  - text (document)
output_type:
  - ranking
diagrams:
  - jina-reranker-v1.svg
release_date: "2024-04-18"
huggingface: "https://huggingface.co/jinaai/jina-reranker-v1-tiny-en"
aws: "https://aws.amazon.com/marketplace/seller-profile/vendor/jinaai"
api_link: "/?sui&model=jina-reranker-v1-tiny-en"
release_blog: "/news/smaller-faster-cheaper-jina-rerankers-turbo-and-tiny"
related_models:
  - jina-reranker-v1-base-en
  - jina-reranker-v1-turbo-en
deprecated_by:
  - jina-reranker-v2-base-multilingual
tags:
  - reranker
  - english
  - long-context
  - memory-efficient
  - high-throughput
  - edge-optimized
  - bert-based
  - production-ready
  - lightweight
  - fast-inference
endpoints:
  - rank
availability:
  - api
  - huggingface
  - aws
  - azure
---

## Overview

Jina Reranker v1 Tiny English represents a breakthrough in efficient search refinement, designed specifically for organizations requiring high-performance reranking in resource-constrained environments. This model addresses the critical challenge of maintaining search quality while significantly reducing computational overhead and deployment costs. With just 33M parameters - a fraction of typical reranker sizes - it delivers remarkably competitive performance through innovative knowledge distillation techniques. The model's most surprising feature is its ability to process documents nearly five times faster than base models while maintaining over 92% of their accuracy, making enterprise-grade search refinement accessible to applications where computational resources are at a premium.

## Methods

The model employs a streamlined four-layer architecture based on JinaBERT with symmetric bidirectional ALiBi (Attention with Linear Biases), enabling efficient processing of long sequences. Its development leverages an advanced knowledge distillation approach where a larger, high-performance teacher model (jina-reranker-v1-base-en) guides the training process, allowing the smaller model to learn optimal ranking behaviors without requiring extensive real-world training data. This innovative training methodology, combined with architectural optimizations like reduced hidden layers and efficient attention mechanisms, enables the model to maintain high-quality rankings while significantly reducing computational requirements. The result is a model that achieves remarkable efficiency without compromising its ability to understand complex document relationships.

## Performance

In comprehensive benchmark evaluations, the model demonstrates exceptional capabilities that challenge the conventional trade-off between size and performance. On the BEIR benchmark, it achieves an NDCG@10 score of 48.54, retaining 92.5% of the base model's performance while being just a quarter of its size. Even more impressively, in LlamaIndex RAG benchmarks, it maintains an 83.16% hit rate, nearly matching larger models while processing documents significantly faster. The model particularly excels in throughput, processing documents almost five times faster than the base model while using 13% less memory than even the turbo variant. These metrics translate to real-world performance that rivals or exceeds much larger models like mxbai-rerank-base-v1 (184M parameters) and bge-reranker-base (278M parameters).

## Guidance

To effectively deploy this model, organizations should prioritize scenarios where processing speed and resource efficiency are critical considerations. The model is particularly well-suited for edge computing deployments, mobile applications, and high-throughput search systems where latency requirements are strict. While it performs exceptionally well across most reranking tasks, it's important to note that for applications requiring the absolute highest level of ranking precision, the base model might still be preferable. The model requires CUDA-capable GPU infrastructure for optimal performance, though its efficient architecture means it can run effectively on less powerful hardware than its larger counterparts. For deployment, the model integrates seamlessly with major vector databases and RAG frameworks, and it's available through both the Reranker API and AWS SageMaker. When fine-tuning for specific domains, users should carefully balance the training data quality with the model's compact architecture to maintain its performance characteristics.
