---
model_name: "jina-reranker-v1-turbo-en"
model_version: "v1"
model_type: "reranker"
organization: "Jina AI"
license: "Apache-2.0"
parameter_size: "37.8M"
language:
  - en
token_length: 8K
device: "cuda"
input_type:
  - text (query)
  - text (document)
output_type:
  - ranking
diagrams:
  - jina-reranker-v1.svg
release_date: "2024-04-18"
huggingface: "https://huggingface.co/jinaai/jina-reranker-v1-turbo-en"
aws: "https://aws.amazon.com/marketplace/seller-profile/vendor/jinaai"
api_link: "/?sui&model=jina-reranker-v1-turbo-en"
release_blog: "/news/smaller-faster-cheaper-jina-rerankers-turbo-and-tiny"
related_models:
  - jina-reranker-v1-base-en
  - jina-reranker-v1-tiny-en
deprecated_by:
  - jina-reranker-v2-base-multilingual
tags:
  - high-speed
  - memory-efficient
  - english
  - production-ready
  - reranker
  - rag-optimized
  - high-performance
  - cost-effective
endpoints:
  - rank
availability:
  - api
  - huggingface
  - aws
  - azure
---

## Overview

Jina Reranker v1 Turbo English addresses a critical challenge in production search systems: the trade-off between result quality and computational efficiency. While traditional rerankers offer improved search accuracy, their computational demands often make them impractical for real-time applications. This model breaks that barrier by delivering 95% of the base model's accuracy while processing documents three times faster and using 75% less memory. For organizations struggling with search latency or computational costs, this model offers a compelling solution that maintains high-quality search refinement while significantly reducing infrastructure requirements and operational costs.

## Methods

The model achieves its efficiency through an innovative six-layer architecture that compresses the sophisticated reranking capabilities of its larger counterpart into just 37.8 million parameters—a dramatic reduction from the base model's 137 million. This streamlined design employs knowledge distillation, where the larger base model acts as a teacher, training the turbo variant to match its behavior while using fewer resources. The architecture maintains the core BERT-based cross-attention mechanism for token-level interactions between queries and documents, but optimizes it for speed through reduced layer count and efficient parameter allocation. The model supports sequences up to 8,192 tokens, enabling comprehensive document analysis while maintaining fast inference speeds through sophisticated optimization techniques.

## Performance


In comprehensive benchmarks, the turbo variant demonstrates remarkable efficiency without significant accuracy trade-offs. On the BEIR benchmark, it achieves an NDCC@10 score of 49.60, retaining 95% of the base model's performance (52.45) while outperforming many larger competitors like bge-reranker-base (47.89, 278M parameters). In RAG applications, it maintains an impressive 83.51% hit rate and 0.6498 MRR, showing particular strength in practical retrieval tasks. The model's speed improvements are even more striking—it processes documents three times faster than the base model, with throughput scaling nearly linearly with reduced parameter count. However, users should note slightly lower performance on extremely nuanced ranking tasks where the full parameter count of larger models provides marginal advantages.

## Guidance

The model requires CUDA-capable hardware for optimal performance and can be deployed through AWS SageMaker or accessed via API endpoints. For production deployments, organizations should implement a two-stage pipeline where vector search provides initial candidates for reranking. While the model supports 8,192 tokens, users should consider the latency impact of longer sequences—processing time increases with document length. The sweet spot for most applications is reranking 100-200 candidates per query, which balances quality and speed. The model is specifically optimized for English content and may not perform optimally on multilingual documents. Memory requirements are significantly lower than the base model, typically requiring only 150MB of GPU memory compared to 550MB, making it suitable for deployment on smaller instances and enabling significant cost savings in cloud environments.
