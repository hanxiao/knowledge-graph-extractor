---
title: "Jina Reranker v3: 0.6B Listwise Reranker for SOTA Multilingual Retrieval"
slug: jina-reranker-v3-0-6b-listwise-reranker-for-sota-multilingual-retrieval
url: https://cms.jina.ai/jina-reranker-v3-0-6b-listwise-reranker-for-sota-multilingual-retrieval/
published_at: 2025-10-03T16:59:43.000+02:00
updated_at: 2025-10-06T08:37:48.000+02:00
reading_time: 7
authors: "Jina AI"
tags: "Press"
excerpt: "New 0.6B-parameter listwise reranker that considers the query and all candidate documents in a single context window."
---

# Jina Reranker v3: 0.6B Listwise Reranker for SOTA Multilingual Retrieval

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://huggingface.co/jinaai/jina-reranker-v3" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-reranker-v3 · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-48.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/jina-reranker-v3.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><a href="https://huggingface.co/jinaai/jina-reranker-v3-GGUF"><span style="white-space: pre-wrap;">GGUF quantizations</span></a><span style="white-space: pre-wrap;"> and </span><a href="https://huggingface.co/jinaai/jina-reranker-v3-mlx"><span style="white-space: pre-wrap;">MLX support</span></a><span style="white-space: pre-wrap;"> are available.</span></p></figcaption>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2509.25085" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jina-reranker-v3: Last but Not Late Interaction for Document Reranking
</div>
<div class="kg-bookmark-description">
jina-reranker-v3 is a 0.6B parameter multilingual document reranker that introduces a novel last but not late interaction. Unlike late interaction models such as ColBERT that perform separate encoding followed by multi-vector matching, our approach conducts causal self-attention between query and documents within the same context window, enabling rich cross-document interactions before extracting contextual embeddings from the last token of each document. This compact architecture achieves state-of-the-art BEIR performance with 61.94 nDCG@10 while being ten times smaller than generative listwise rerankers.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-47.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Feng Wang</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/arxiv-logo-fb-41.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

We're excited to release `jina-reranker-v3`, our latest-generation reranker that delivers state-of-the-art performance across multilingual retrieval benchmarks. This 0.6B-parameter document reranker introduces a novel *last but not late* interaction that takes a fundamentally different approach from existing methods. `jina-reranker-v3` works **listwise**: it applies causal attention between the query and *all* candidate documents within a single context window, enabling rich cross-document interactions before extracting contextual embeddings from each document's final token. Our new model achieves 61.94 nDCG@10 on BEIR outperforming `Qwen3-Reranker-4B` while being 6× smaller in size.

| Model                     | Size | BEIR      | MIRACL    | MKQA      | CoIR      |
|---------------------------|------|-----------|-----------|-----------|-----------|
| jina-reranker-v3          | 0.6B | **61.94** | 66.83     | 67.92     | 70.64     |
| jina-reranker-v2          | 0.3B | 57.06     | 63.65     | 67.90     | 56.14     |
| jina-reranker-m0          | 2.4B | 58.95     | 66.75     | **68.19** | 63.55     |
| bge-reranker-v2-m3        | 0.6B | 56.51     | **69.32** | 67.88     | 36.28     |
| mxbai-rerank-base-v2      | 0.5B | 58.40     | 55.32     | 64.24     | 65.71     |
| mxbai-rerank-large-v2     | 1.5B | 61.44     | 57.94     | 67.06     | 70.87     |
| Qwen3-Reranker-0.6B       | 0.6B | 56.28     | 57.70     | 65.34     | 65.18     |
| Qwen3-Reranker-4B         | 4.0B | 61.16     | 67.52     | 67.52     | 73.91     |
| jina-code-embeddings-0.5b | 0.5B | \-        | \-        | \-        | **73.94** |

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/10/image-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/10/image-1.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/10/image-1.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/10/image-1.png 1600w, https://cms.jina.ai/content/images/size/w2400/2025/10/image-1.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1425" alt="Graph presenting evaluation results for BEIR retrieval tasks, comparing multiple retrieval methods labeled along the x-axis a" />
<figcaption><span style="white-space: pre-wrap;">English retrieval performance on BEIR, measured by nDCG@10. All scores are our runs based on the top-100 results from </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v3</code></span><span style="white-space: pre-wrap;"> as the first stage retriever. We evaluate three variants of </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-reranker-v3</code></span><span style="white-space: pre-wrap;">: documents ordered by descending relevance scores, ascending scores, and random permutation. Evaluation shows that v3 maintains relatively stable performance across different input orderings, suggesting robust self-attention mechanisms that can effectively process documents regardless of their initial arrangement.</span></figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/10/miracl_boxplot.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/10/miracl_boxplot.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/10/miracl_boxplot.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/10/miracl_boxplot.png 1600w, https://cms.jina.ai/content/images/size/w2400/2025/10/miracl_boxplot.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1137" alt="Visual chart showing evaluation results for MIRACL retrieval tasks, comparing datasets and metrics like NDCG@10 and NDCG@80 a" />
<figcaption><span style="white-space: pre-wrap;">MIRACL evaluation across 18 diverse languages demonstrates </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-reranker-v3</code></span><span style="white-space: pre-wrap;"> cross-lingual consistency despite its compact architecture. The languages we evaluate include English, Chinese, Spanish, Arabic, French, Russian, German, Japanese, Indonesian, Hindi, Bengali, Korean, Swahili, Telugu, Thai, Persian/Farsi, Yoruba, and Finnish.</span></figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/10/mkqa_boxplot.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/10/mkqa_boxplot.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/10/mkqa_boxplot.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/10/mkqa_boxplot.png 1600w, https://cms.jina.ai/content/images/size/w2400/2025/10/mkqa_boxplot.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="848" alt="Graph displaying evaluation metrics for MKQA retrieval tasks, with Recall@10 on the vertical axis and models like jina-rerank" />
<figcaption><span style="white-space: pre-wrap;">Multilingual retrieval performance on the MKQA, measured by Recall@10. The languages we evaluate include English, Chinese (Simplified), Spanish, Arabic, Portuguese, Russian, Japanese, German, French, Korean, Vietnamese, Italian, Turkish, Polish, Thai, Dutch, Malay, Chinese (Traditional), Swedish, Hebrew, Hungarian, Chinese (Hong Kong), Danish, Norwegian, Finnish, and Khmer.</span></figcaption>
</figure>

## Model Architecture

`jina-reranker-v3` is built on the [Qwen3-0.6B](https://huggingface.co/Qwen/Qwen3-0.6B) backbone, a decoder-only transformer model with causal self-attention. The model processes multiple documents and query simultaneously, extracting contextual embeddings at designated token positions for efficient similarity computation.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/10/Heading--54-.svg" class="kg-image" loading="lazy" width="1200" height="630" alt="Diagram illustrating a hierarchical data structure with blocks labeled Query, Document 1, Document 2, and Document 3, showing" />
<figcaption><span style="white-space: pre-wrap;">Architecture of </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-reranker-v3</code></span><span style="white-space: pre-wrap;"> showing the transformer backbone with special token positions for embedding extraction. The model processes multiple documents and query in one context window, extracting contextual embeddings at designated token positions for similarity computation.</span></figcaption>
</figure>

| Parameter                | Value        |
|--------------------------|--------------|
| Total Parameters         | 0.6B         |
| Non-Embedding Parameters | 0.44B        |
| Hidden Size              | 1,024        |
| Number of Layers         | 28           |
| Attention Heads (Q/KV)   | 16/8 (GQA)   |
| Context Length           | 131,072      |
| MLP Projector            | 1024→512→256 |
| Final Embedding Size     | 256          |

Given a query and a set of candidate documents, `jina-reranker-v3` processes the reranking task with a specialized prompt template that enables cross-document interactions within a single forward pass. The input construction follows a specific format:

<figure class="kg-card kg-code-card">
<pre class="text"><code>&lt;|im_start|&gt;system
You are a search relevance expert who can determine
a ranking of passages based on their relevance to the query.
&lt;|im_end|&gt;

&lt;|im_start|&gt;user
I will provide you with k passages, each indicated by a numerical identifier.
Rank the passages based on their relevance to query: [QUERY]

&lt;passage id=&quot;1&quot;&gt;
[DOCUMENT_1]&lt;|doc_emb|&gt;
&lt;/passage&gt;
&lt;passage id=&quot;2&quot;&gt;
[DOCUMENT_2]&lt;|doc_emb|&gt;
&lt;/passage&gt;
...
&lt;passage id=&quot;k&quot;&gt;
[DOCUMENT_k]&lt;|doc_emb|&gt;
&lt;/passage&gt;

&lt;query&gt;
[QUERY]&lt;|query_emb|&gt;
&lt;/query&gt;
&lt;|im_end|&gt;

&lt;|im_start|&gt;assistant
&lt;think&gt;&lt;/think&gt;</code></pre>
<figcaption><p><span style="white-space: pre-wrap;">Each document is wrapped in passage tags with sequential IDs, enabling clear document boundaries within the shared context window. The model processes up to 64 documents simultaneously within its 131K token context capacity. For larger document collections, processing occurs in batches while maintaining query consistency across batches.</span></p></figcaption>
</figure>

The query appears **twice** in the input structure - once at the beginning for task instructions and once at the end for final attention processing. This dual placement enables the final query position to attend to all preceding documents through causal attention. Two critical special tokens mark embedding extraction positions: the `<|doc_emb|>` token is placed after each document to mark document embedding extraction points, while the `<|query_emb|>` token is placed after the final query to mark query embedding extraction point. These embeddings capture both local document semantics and global cross-document context through the shared causal self-attention mechanism.

**We call this query-document interaction "last but not late."** It's "last" because `<|doc_emb|>` is placed as the final token of each document. It's "not late" because, unlike [late interaction models such as ColBERT](https://jina.ai/news/what-is-colbert-and-late-interaction-and-why-they-matter-in-search/) that separately encode documents before multi-vector matching, we enable query-document and document-document interactions within the same context window during the forward pass.

Finally, a two-layer MLP projector with ReLU activation maps the 1024-dimensional hidden states to a 256-dimensional ranking space. Relevance scoring is computed using cosine similarity between the projected query embedding and each projected document embedding. This produces a relevance score for each document in the input set.

## Getting Started

### Via API

The easiest way to use `jina-reranker-v3` is via our Search Foundation API.

``` bash
curl -X POST \
  https://api.jina.ai/v1/rerank \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer JINA_API_KEY" \
  -d '{
  "model": "jina-reranker-v3",
  "query": "slm markdown",
  "documents": [
    ...
  ],
  "return_documents": false
}'
```

``` json
{
  "model":"jina-reranker-v3",
  "usage": {
    "total_tokens":2813
  },
  "results":[
    {
      "index":1,
      "relevance_score":0.9310624287463884
    },
    {
      "index":4,
      "relevance_score":0.8982678574191957
    },
    {
      "index":0,
      "relevance_score":0.890233167219021
    },
    ...
  ]
}
```

The `relevance_score` field indicates the relevance of each document to the query, with higher scores indicating greater relevance.

### Via `transformers`

``` python
from transformers import AutoModel

model = AutoModel.from_pretrained(
    'jinaai/jina-reranker-v3',
    dtype="auto",
    trust_remote_code=True,
)
model.eval()
```

Now you can use the model's `rerank` function to compute relevance scores for a query and a list of documents:

``` python
query = "What are the health benefits of green tea?"
documents = [
    "Green tea contains antioxidants called catechins that may help reduce inflammation and protect cells from damage.",
    "El precio del café ha aumentado un 20% este año debido a problemas en la cadena de suministro.",
    "Studies show that drinking green tea regularly can improve brain function and boost metabolism.",
    "Basketball is one of the most popular sports in the United States.",
    "绿茶富含儿茶素等抗氧化剂，可以降低心脏病风险，还有助于控制体重。",
    "Le thé vert est riche en antioxydants et peut améliorer la fonction cérébrale.",
]

# Rerank documents
results = model.rerank(query, documents)

# Results are sorted by relevance score (highest first)
for result in results:
    print(f"Score: {result['relevance_score']:.4f}")
    print(f"Document: {result['document'][:100]}...")
    print()
```

## Conclusion

`jina-reranker-v3` is a new 0.6B parameter multilingual listwise reranker that introduces *last but not late* interaction for efficient document reranking. Documents can attend to each other during encoding, establishing interaction that inform the final ranking.

One of the primary concerns is whether such interaction is resilient to input permutation—that is, if we shuffle the input order, will the rankings stay the same? We tested this with a query against 110 candidate documents using random permutation and plotted the variance at each rank position in the figure below.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/10/jina-reranker-v3-README_md.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/10/jina-reranker-v3-README_md.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/10/jina-reranker-v3-README_md.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/10/jina-reranker-v3-README_md.png 1600w, https://cms.jina.ai/content/images/size/w2400/2025/10/jina-reranker-v3-README_md.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="992" alt="Line graph titled &quot;Rank Position Stability Across 1000 Random Permutations (110 documents)&quot; showing stability variance peakin" />
<figcaption><span style="white-space: pre-wrap;">The rank stability graph visualizes how consistently documents appear at specific rank positions across 1,000 random input permutations. The y-axis represents stability variance as a percentage, where 0% indicates perfect stability (the exact same document always appears at this rank) and 100% indicates maximum variance (nearly all documents appeared at this rank across permutations). The x-axis shows rank positions from 1 to 110.</span></figcaption>
</figure>

The critical finding is that top-ranked positions show excellent stability. Ranks 1-10 exhibit minimal variance, with the most relevant documents consistently ranking at the top regardless of input order. This is crucial for nDCG@10 and similar top-k metrics. Irrelevant documents consistently stay at the bottom, creating clear separation between relevant and irrelevant content.

The middle section shows significant position swapping, which is expected and acceptable. The model uses causal self-attention and encodes different contextual information based on what appears before them in the sequence.

In practice, where we care about the top-most results, such behavior is completely acceptable. Our evaluation shows `jina-reranker-v3` outperforming our earlier generations, including `jina-reranker-v2-base-multilingual` and `jina-colbert-v2`, as well as much larger alternatives such as `Qwen3-Reranker-4B` and `jina-reranker-m0` further confirming this.
