---
model_name: "jina-reranker-v3"
model_version: "v3"
model_type: "reranker"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "597M"
language:
    - multilingual
input_type:
  - text (query)
  - text (document)
output_type:
  - ranking
diagrams:
  - jina-reranker-v3.svg
token_length: 131K
quantized: true
mlx: true
output_dimension: 256
release_date: "2025-10-01"
device: "cuda"
api_link: "/?sui&model=jina-reranker-v3"
arxiv: "https://arxiv.org/abs/2509.25085"
aws: ""
release_blog: "/news/jina-reranker-v3-0-6b-listwise-reranker-for-sota-multilingual-retrieval"
related_models:
  - jina-reranker-v2-base-multilingual
  - jina-reranker-m0
tags:
  - listwise
  - multilingual
  - code-search
  - long-context
  - reranker
  - decoder-only
endpoints:
  - rank
availability:
  - elastic
  - api
  - huggingface
  - aws
  - azure
  - gcp
---

## Overview


## Methods


## Performance


## Guidance