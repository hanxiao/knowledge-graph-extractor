---
model_name: "jina-vlm"
model_version: "v1"
model_type: "reader"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "2.4B"
language:
  - multilingual
token_length: 32K
image_size: 4096×4096
device: "cuda"
release_date: "2025-12-04"
mlx: true
api_link: "/news/jina-vlm-small-multilingual-vision-language-model#via-jina-api"
huggingface: "https://huggingface.co/jinaai/jina-vlm"
arxiv: "https://arxiv.org/abs/2512.04032"
release_blog: "/news/jina-vlm-small-multilingual-vision-language-model/"
aws: ""
input_type:
  - image
  - text
output_type:
  - text
diagrams:
  - jina-vlm.svg
  - jina-vlm-1.svg
related_models:
  - jina-embeddings-v4
  - jina-reranker-m0
tags:
  - reader
  - vlm
  - multilingual
  - vision-language
  - image-to-text
  - document-processing
  - ocr
endpoints:
  - read
availability:
  - api
  - license
  - huggingface
---

## Overview


## Methods


## Performance


## Guidance
