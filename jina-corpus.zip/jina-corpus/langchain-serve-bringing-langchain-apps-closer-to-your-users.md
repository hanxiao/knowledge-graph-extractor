---
title: "Langchain-serve: Bringing LangChain Apps Closer to Your Users"
slug: langchain-serve-bringing-langchain-apps-closer-to-your-users
url: https://cms.jina.ai/langchain-serve-bringing-langchain-apps-closer-to-your-users/
published_at: 2023-06-27T16:13:21.000+02:00
updated_at: 2024-01-24T18:21:42.000+01:00
reading_time: 7
authors: "Deepankar Mahapatro, Scott Martens"
tags: "Tech Blog"
excerpt: "Langchain-serve makes deployment and delivery of LangChain apps simple, taking one less hassle out of producing your AI applications."
---

# Langchain-serve: Bringing LangChain Apps Closer to Your Users

It is exciting to witness the growing community of developers building innovative, sophisticated LLM-powered applications using LangChain. This dynamic ecosystem promotes rapid development and innovation and also unveils unlimited potential for a wide array of use cases.

Amidst this, ****Langchain-serve**** plays an important role by making LangChain applications readily available and accessible to end-users. It streamlines deployment and delivery for LangChain applications and makes it easy for application developers to reach their target audience.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/087bd996b490447dee3e56163ebe3116d1a8f433589968ceae25747de28f6934/jina-ai/langchain-serve" />
</div>
</figure>

## Features

With Langchain-serve, deploying and distributing LangChain applications becomes a breeze. It has a feature set designed to streamline the deployment process:

- ****API Management****: Define your APIs in Python using the `@serving` decorator, ensuring a secure interaction with Bearer tokens. This seamlessly integrates your local LangChain applications with external applications, broadening its reach and functionality.
- ****LLM-powered Slack Bots****: Build, deploy, and distribute Slack bots thanks to the simple `@slackbot` decorator. This puts your LangChain application where your users are, providing them with access to your application within their Slack workspace.
- ****Interactivity and Collaboration****: Enable real-time interactions with LLMs via WebSockets, optionally keeping humans in the loop.
- ****FastAPI Integration****: Wrap your LangChain apps with FastAPI endpoints and deploy them with a single command.

Furthermore, **Langchain-serve takes care of all your infrastructure headaches**, enabling you to focus solely on developing and refining your applications.

- ****Secure and Scalable****: Enjoy secure, serverless, scalable, and highly available applications on <a href="https://cloud.jina.ai/" rel="noopener ugc nofollow">Jina AI Cloud</a>.
- ****Hardware Configuration****: Easily configure the hardware resources for your application with a single command.
- ****Persistent Storage****: Use the built-in persistent storage for LLM caching, file storage, and more.
- ****Observability****: Monitor your applications with built-in logs, metrics, and traces.
- **Availability:** Your app remains responsive and available, regardless of the traffic volume.

Alternatively, you can **s**elf-host your apps**.** With a single command, you can export your apps as Kubernetes or Docker Compose YAMLs so that you can host your applications on your own infrastructure.

## Langchain-serve in action

Before diving into the examples, please make sure you have the `langchain-serve` package installed. It is available as a PyPI package and you can install it with `pip`:

``` bash
pip install langchain-serve
```

Now, let’s see how to quickly deploy a simple LangChain agent as an HTTP endpoint with some examples of building and deploying Slack bots. These examples provide a practical demonstration of Langchain-serve's features and show you how straightforward it is to get your LangChain applications up and running.

## Wrap and deploy a simple agent as a RESTful API

Let’s start with a simple example using `ZeroShotAgent` with a `Search` tool to ask a question. We will use the `@serving` decorator to define a `POST /ask `endpoint that accepts an `input` parameter and returns an answer.

This involves four simple steps:

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/06/1_EGmaxmjPuQEOovOYrSD-4Q.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_EGmaxmjPuQEOovOYrSD-4Q.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_EGmaxmjPuQEOovOYrSD-4Q.webp 1000w, https://cms.jina.ai/content/images/size/w1600/2023/06/1_EGmaxmjPuQEOovOYrSD-4Q.webp 1600w, https://cms.jina.ai/content/images/size/w2400/2023/06/1_EGmaxmjPuQEOovOYrSD-4Q.webp 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1354" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/06/1_iHH2qCU0sOo1kOfNdJTYmA.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_iHH2qCU0sOo1kOfNdJTYmA.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_iHH2qCU0sOo1kOfNdJTYmA.webp 1000w, https://cms.jina.ai/content/images/size/w1600/2023/06/1_iHH2qCU0sOo1kOfNdJTYmA.webp 1600w, https://cms.jina.ai/content/images/size/w2400/2023/06/1_iHH2qCU0sOo1kOfNdJTYmA.webp 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1826" />
</div>
</div>
</div>
<figcaption>Before and After</figcaption>
</figure>

1.  Refactor your code to one or more functions in a new file `app.py` and add the `@serving` decorator. (See above for an example.)
2.  Create a `requirements.txt` file with all the dependencies.
3.  Run `lc-serve deploy local app` to deploy and use the app locally.
4.  Run `lc-serve deploy jcloud app` to deploy and use the app on <a href="https://cloud.jina.ai/" rel="noopener ugc nofollow">Jina AI Cloud</a>.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/06/1_P4l-Uo7FvLCJ1qXBDGvGsQ.webp" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_P4l-Uo7FvLCJ1qXBDGvGsQ.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_P4l-Uo7FvLCJ1qXBDGvGsQ.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_P4l-Uo7FvLCJ1qXBDGvGsQ.webp 1400w" sizes="(min-width: 720px) 720px" width="1400" height="748" />
<figcaption>Usage example</figcaption>
</figure>

The `@serving` decorator also enables real-time streaming and human-in-the-loop integration using WebSockets. Optionally, the endpoints can also be protected with bearer tokens for secure interactions. Follow the readme to go through more elaborate examples to deploy your LangChain APIs on Jina AI Cloud.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve#-langchain-apps-on-production-with-jina--fastapi-" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/087bd996b490447dee3e56163ebe3116d1a8f433589968ceae25747de28f6934/jina-ai/langchain-serve" />
</div>
</figure>

## Build, deploy, and distribute Slack bots

Slack has become an indispensable tool in many modern workplaces, helping teams to communicate and collaborate effectively. With the integration of LLM-powered Slack bots, you can infuse the reasoning power of LLMs into your workspace, providing rich contextual understanding and intelligent responses.

From moderator bots that enrich brainstorming sessions with the knowledge and reasoning capacity of LLMs, to project management bots that provide smart recommendations and summarize key points, the use cases for these Slack bots are endless. By leveraging LangChain and Langchain-serve, these bots can enhance the efficiency and productivity of digital workspaces.

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/06/1_sp10s1RCilbUSpztxA17NA.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_sp10s1RCilbUSpztxA17NA.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_sp10s1RCilbUSpztxA17NA.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_sp10s1RCilbUSpztxA17NA.webp 1333w" sizes="(min-width: 720px) 720px" width="1333" height="1985" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/06/1_xXvzwxqjyNjUgmU8X1hjNg.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_xXvzwxqjyNjUgmU8X1hjNg.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_xXvzwxqjyNjUgmU8X1hjNg.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_xXvzwxqjyNjUgmU8X1hjNg.webp 1333w" sizes="(min-width: 720px) 720px" width="1333" height="1985" />
</div>
</div>
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/06/1_mY2V90CD8C62bL5FarYS5A-1.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_mY2V90CD8C62bL5FarYS5A-1.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_mY2V90CD8C62bL5FarYS5A-1.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_mY2V90CD8C62bL5FarYS5A-1.webp 1333w" sizes="(min-width: 720px) 720px" width="1333" height="1985" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/06/1_HJY7n-GeIXJyEjhNUUArEQ-1.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_HJY7n-GeIXJyEjhNUUArEQ-1.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_HJY7n-GeIXJyEjhNUUArEQ-1.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_HJY7n-GeIXJyEjhNUUArEQ-1.webp 1333w" sizes="(min-width: 720px) 720px" width="1333" height="1985" />
</div>
</div>
</div>
<figcaption>A brainstorming bot having elaborate discussions with a team to decide their platform strategy. Reading order: Top-left (1), top-right (2), bottom-left (3), bottom-right (4).</figcaption>
</figure>

Langchain-serve provides a decorator `@slackbot` to help build and deploy Slack bots on <a href="https://cloud.jina.ai/" rel="noopener ugc nofollow">Jina AI Cloud</a>. Here’s a step-by-step guide that takes you through creating and configuring a Slack app and deploying a demo bot integrated with Langchain-serve:

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve/tree/main/lcserve/apps/slackbot" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
langchain-serve/lcserve/apps/slackbot at main · jina-ai/langchain-serve
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - langchain-serve/lcserve/apps/slackbot at main · jina-ai/langchain-serve
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/087bd996b490447dee3e56163ebe3116d1a8f433589968ceae25747de28f6934/jina-ai/langchain-serve" />
</div>
</figure>

Let’s delve deeper into the Slack bot demo code and understand how it works so you can modify it for custom applications. We’ll also go through the`@slackbot` decorator, as it shapes the bot’s behavior.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/06/1_j2ObJaLN_tZkfEupDyN_uw.webp" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_j2ObJaLN_tZkfEupDyN_uw.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_j2ObJaLN_tZkfEupDyN_uw.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_j2ObJaLN_tZkfEupDyN_uw.webp 1374w" sizes="(min-width: 720px) 720px" width="1374" height="1638" />
<figcaption>A function decorated by <code>@slackbot</code> defines the entry point for the bot. This is expected to listen to two types of events: “app-mention” and “DM”</figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/06/1_yeJTwz5SBMJeqWuDTNZvxw.webp" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_yeJTwz5SBMJeqWuDTNZvxw.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_yeJTwz5SBMJeqWuDTNZvxw.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_yeJTwz5SBMJeqWuDTNZvxw.webp 1400w" sizes="(min-width: 720px) 720px" width="1400" height="352" />
<figcaption>Slack bot decorator arguments</figcaption>
</figure>

****Prompt:**** We use a <a href="https://github.com/jina-ai/langchain-serve/blob/98a586254cfe0b01409a5ce7e6d4af23d57bff32/lcserve/backend/slackbot/slackbot.py#L303" rel="noopener ugc nofollow">predefined prompt template</a> to make the agent act as a Slack bot. This can be easily modified/extended to fit your application.

****Memory:**** Since Slack threads are routinely longer than the token limits for LLMs, we use `memory` modules defined in LangChain to store the conversation history. Langchain-serve's <a href="https://github.com/jina-ai/langchain-serve/blob/98a586254cfe0b01409a5ce7e6d4af23d57bff32/lcserve/backend/slackbot/memory.py#L29" rel="noopener ugc nofollow"><code>get_memory</code></a> function is designed to generate memory objects from a conversation history. However, you can also use custom memory objects like <a href="https://github.com/jerryjliu/llama_index/blob/main/examples/langchain_demo/LangchainDemo.ipynb" rel="noopener ugc nofollow">LlamaIndex's memory wrappers</a>.

****Tools:**** Likewise, we have a pre-defined tool for Slack: A <a href="https://github.com/jina-ai/langchain-serve/blob/98a586254cfe0b01409a5ce7e6d4af23d57bff32/lcserve/backend/slackbot/slackbot.py#L147" rel="noopener ugc nofollow">Slack thread parser</a> that extracts the conversation history from a thread URL. This is very useful when you share a different thread with the bot.

****Workspace:**** Every bot deployed on Jina AI Cloud gets a persistent storage path. This can be used to cache LLM calls to speed up the response time. This can also be used to store other files that the bot needs to access.

****Reply:**** The `reply` function is used to send a reply back to the user. It takes a single argument - `message` - which is the reply message to be sent to the user.

After customizing the bot to fit your needs, you can deploy it on Jina AI Cloud with the following command, where the `.env` should contain the Slack bot token, signing secret, and other required environment variables.

``` bash
lc-serve deploy jcloud app --env .env
```

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/06/1_Ffg_qCBzqFl3qnV0ns5coQ.webp" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/06/1_Ffg_qCBzqFl3qnV0ns5coQ.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/06/1_Ffg_qCBzqFl3qnV0ns5coQ.webp 1000w, https://cms.jina.ai/content/images/2023/06/1_Ffg_qCBzqFl3qnV0ns5coQ.webp 1400w" sizes="(min-width: 720px) 720px" width="1400" height="507" />
<figcaption>Jina AI Cloud deployment log. The Slack Events URL here denotes the URL to be used as “Requests URL” in the Slack app configuration to enable event subscriptions for your bot.</figcaption>
</figure>

Once the bot is integrated and tested in your workspace, it’s ready to be rolled out to the workspaces of your end users. For further information on how to distribute your bot globally, you can refer to this <a href="https://api.slack.com/start/distributing" rel="noopener ugc nofollow">guide</a>.

## Looking ahead

We’ve seen how Langchain-serve makes deploying LangChain applications a breeze. We’ve seen it in action, turning a simple agent into a RESTful API and transforming LLM-powered apps into interactive Slack bots. As we continue to evolve, our sights are set on the next milestone: bringing the intelligence of LangChain to Discord with `discordbot`.

We’re eager to see the diverse Slackbots and APIs you’ll be shipping for your users, bridging the gap between a local demo and practical, user-friendly applications that harness the full potential of LLMs in the real world.

## Learn more about Langchain-serve

For more information about Langchain-serve, visit the [project page at GitHub](https://github.com/jina-ai/langchain-serve), and visit the [Jina AI website](https://jina.ai) for more about the Jina ecosystem.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/087bd996b490447dee3e56163ebe3116d1a8f433589968ceae25747de28f6934/jina-ai/langchain-serve" />
</div>
</figure>

## Get in touch

Talk to us and keep the conversation going by joining the Jina AI Discord!

<div class="kg-card kg-button-card kg-align-center">

<a href="https://discord.com/channels/1106542220112302130/1106544066692390942" class="kg-btn kg-btn-accent">Jina AI Discord</a>

</div>

  
