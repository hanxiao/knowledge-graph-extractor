---
title: "LangChain-serve: Powering your Slack with LangChain"
slug: langchain-serve-powering-your-slack-with-langchain
url: https://cms.jina.ai/langchain-serve-powering-your-slack-with-langchain/
published_at: 2023-07-06T14:53:11.000+02:00
updated_at: 2024-01-24T18:18:48.000+01:00
reading_time: 7
authors: "Deepankar Mahapatro, Scott Martens"
tags: "Tech Blog"
excerpt: "Langchain-serve makes deployment and delivery of LangChain apps simple, taking one less hassle out of producing your AI applications."
---

# LangChain-serve: Powering your Slack with LangChain

Slack is an essential tool for business that has transformed the way teams communicate and collaborate. Introducing LangChain-powered chatbots adds a layer of intelligence to your Slack workspace. These bots don’t just passively respond to commands. They’re like virtual colleagues, capable of understanding context and providing useful feedback.

LangChain-powered chatbots are more than just message handlers. They are like an interactive consultant, fielding questions about your company’s internal data, and putting a wealth of information at your fingertips. The result? A workspace that’s not just connected, but also informed, fostering a more engaged and knowledgeable team.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/7342025836ed5851d33c2ae5fe8f11fe1c2ea6fd7981067f72b1e8faa4a9020b/jina-ai/langchain-serve" />
</div>
</figure>

As a starting point, you can download a demo chatbot from Langchain-serve's repository. Follow <a href="https://github.com/jina-ai/langchain-serve/tree/main/lcserve/apps/slackbot#-langchain-slack-bots-on-jina-ai-cloud" rel="noopener ugc nofollow">this step-by-step guide</a> to create an app in your workspace and deploy it to <a href="https://cloud.jina.ai/" rel="noopener ugc nofollow">Jina AI Cloud</a>.

``` bash
pip install langchain-serve
echo 'SLACK_SIGNING_SECRET=<your-signing-secret>' >> .env
echo 'SLACK_BOT_TOKEN=<your-bot-token>' >> .env
echo 'OPENAI_API_TOKEN=<your-openai-api-token>' >> .env
lc-serve deploy slackbot-demo --env .env
```

[In a previous article](https://jina.ai/news/langchain-serve-bringing-langchain-apps-closer-to-your-users/), we discussed how you can use the `@slackbot` decoration to customize and add functionality to your Slack chatbot. We also show a lengthy example interaction where the chatbot participates directly in a brainstorming session.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/langchain-serve-bringing-langchain-apps-closer-to-your-users/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Langchain-serve: Bringing LangChain Apps Closer to Your Users
</div>
<div class="kg-bookmark-description">
Langchain-serve makes deployment and delivery of LangChain apps simple, taking one less hassle out of producing your AI applications.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/android-icon-192x192.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/2023/06/1_3cN_qz9pICgmDlpubzMLIw.webp" />
</div>
</figure>

## Building an HR Slackbot

Let’s consider a hypothetical company: “FutureSight AI” (a name courtesy of ChatGPT). FutureSight has typical HR responsibilities, including onboarding new employees. The company is also deploying a chatbot for its HR department that we’ll call `langchain-bot`.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/image-13.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/image-13.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/image-13.png 1000w, https://cms.jina.ai/content/images/2023/07/image-13.png 1244w" sizes="(min-width: 720px) 720px" width="1244" height="477" />
</figure>

We'd like this chatbot to be about to answer basic questions like this, but also to do other, more menial HR tasks; like answering questions about company policies and taking notes about Slack discussions.

Now, we're going to show you how.

<div class="kg-card kg-callout-card kg-callout-card-grey">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

This code is also available as [an example in the langchain-serve repository](https://github.com/jina-ai/langchain-serve/tree/main/examples/hrbot). Follow the link below for the code and documentation.

</div>

</div>

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve/tree/main/examples/hrbot" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
langchain-serve/examples/hrbot at main · jina-ai/langchain-serve
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - langchain-serve/examples/hrbot at main · jina-ai/langchain-serve
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/7342025836ed5851d33c2ae5fe8f11fe1c2ea6fd7981067f72b1e8faa4a9020b/jina-ai/langchain-serve" />
</div>
</figure>

We’ll focus on constructing a Slack bot specifically designed to automate and streamline HR tasks and interactions. This chatbot, which draws on HR department PDF documents stored on Google Drive, can be an essential tool for both employees and the HR team, promoting efficiency and engagement in the workspace.

We will equip this bot with access to company policies, onboarding procedures, and related information. HR documents, stored as PDFs on the company’s Google Drive, serve as the bot’s knowledge source.

Here’s what we’d like our bot to accomplish:

Imagine an employee tagging the bot in a channel to ask a question. The chatbot should be competent enough to respond directly in the thread. For example, an employee asks:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/image-12.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/image-12.png 600w, https://cms.jina.ai/content/images/2023/07/image-12.png 640w" width="640" height="140" />
</figure>

FutureSight's `langchain-bot` should then search through the internal documents and directly answer in Slack.

Additionally, we’d like our bot to retain the memory of the conversation as context for follow-up interactions.

### Let’s get to building

Before starting to code, we need to create a Slack app and configure it. You can follow <a href="https://github.com/jina-ai/langchain-serve/blob/main/examples/hrbot/README.md#-step-1-install-langchain-serve" rel="noopener ugc nofollow">this readme</a> to get started.

Langchain-serve provides a simple-to-use decorator `@slackbot` which responds to commands and replies when tagged. You can read more about it [here](https://github.com/jina-ai/langchain-serve/tree/main/lcserve/apps/slackbot#-step-7-enhance-the-bot-to-suit-your-application).

The `@slackbot` decorator takes the following arguments:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/image-11.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/image-11.png 600w, https://cms.jina.ai/content/images/2023/07/image-11.png 738w" sizes="(min-width: 720px) 720px" width="738" height="252" />
</figure>

### Slash commands

We also need to define a couple of key commands for our bot.

- `/refresh-gdrive-index` indexes all PDF files from Google Drive, and saves them in the current workspace as [LangChain `Tool` instances](https://python.langchain.com/docs/modules/agents/tools/). ([See the code on GitHub](https://github.com/jina-ai/langchain-serve/blob/d6f934862dc2ed8ce8784295ff983a61e00bc19a/examples/hrbot/app.py#L59))
- `/remove-gdrive-index` erases all existing indexes from the workspace. ([See the code on GitHub](https://github.com/jina-ai/langchain-serve/blob/d6f934862dc2ed8ce8784295ff983a61e00bc19a/examples/hrbot/app.py#L46))

These functions are made available to the Slack chatbot by using the `@slackbot` decorator:

``` python
from lcserve import slackbot

@slackbot(
    commands={
        '/refresh-gdrive-index': refresh_gdrive_index,
        '/remove-gdrive-index': remove_gdrive_index,
    }
)
def hrbot(
    message: str,
    history: ChatMessageHistory,
    reply: Callable,
    workspace: str,
    **kwargs,
):
    llm = OpenAI(temperature=0, verbose=True)
    update_cache(workspace)
    tools = load_tools_from_disk(llm=llm, path=workspace)
    prompt = ConversationalAgent.create_prompt(
        tools=tools,
        prefix=get_hrbot_prefix(),
        suffix=SlackBot.get_agent_prompt_suffix(),
    )

    memory = get_memory(history)
    agent = ConversationalAgent(
        llm_chain=LLMChain(llm=llm, prompt=prompt),
        allowed_tools=[tool.name for tool in tools],
    )

    agent_executor = AgentExecutor.from_agent_and_tools(
        agent=agent,
        tools=tools,
        memory=memory,
        verbose=True,
        max_iterations=4,
        handle_parsing_errors=True,
    )
    reply(agent_executor.run(message))
```

And this makes them available in Slack:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/image-9.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/image-9.png 600w, https://cms.jina.ai/content/images/2023/07/image-9.png 930w" sizes="(min-width: 720px) 720px" width="930" height="288" />
</figure>

### Respond to tags

Enabling “respond to tags” is simple, thanks to all the tooling LangChain and Langchain-serve already provide.

- Load tools (added during index refresh) from disk.
- <a href="https://github.com/jina-ai/langchain-serve/blob/d6f934862dc2ed8ce8784295ff983a61e00bc19a/examples/hrbot/app.py#L31" rel="noopener ugc nofollow">Define a prompt template for the bot</a>.
- <a href="https://github.com/jina-ai/langchain-serve/blob/d6f934862dc2ed8ce8784295ff983a61e00bc19a/lcserve/backend/slackbot/memory.py#L32" rel="noopener ugc nofollow">Define a memory object</a> to track conversation history.
- Define an `AgentExecutor` from `ConversationalAgent` , tools & memory.
- Call `reply` on `agent_executor.run(message)` to send the response to the same Slack thread.

The app then can be deployed with the command:

``` bash
lc-serve deploy jcloud app --env .env
```

Make sure to follow the <a href="https://github.com/jina-ai/langchain-serve/tree/main/examples/hrbot#-step-6-deploy-the-app" rel="noopener ugc nofollow">example repo</a> to understand the setup, directory structure, etc., and modify the command above as needed to point to the right files and directories.

## Usage

Now, let’s dive into some examples to illustrate how useful this bot can be, especially to a new employee or someone who recently transferred to a new workgroup. The screenshots below show how the bot leverages the company’s HR policies — uploaded as PDFs on Google Drive — to provide useful information.

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/dpk_1.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/dpk_1.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/dpk_1.webp 1000w, https://cms.jina.ai/content/images/2023/07/dpk_1.webp 1196w" sizes="(min-width: 720px) 720px" width="1196" height="2013" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/dpk_2.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/dpk_2.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/dpk_2.webp 1000w, https://cms.jina.ai/content/images/2023/07/dpk_2.webp 1196w" sizes="(min-width: 720px) 720px" width="1196" height="2013" />
</div>
</div>
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/dpk_3.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/dpk_3.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/dpk_3.webp 1000w, https://cms.jina.ai/content/images/2023/07/dpk_3.webp 1196w" sizes="(min-width: 720px) 720px" width="1196" height="2013" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2023/07/dpk_4.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/dpk_4.webp 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/dpk_4.webp 1000w, https://cms.jina.ai/content/images/2023/07/dpk_4.webp 1196w" sizes="(min-width: 720px) 720px" width="1196" height="2013" />
</div>
</div>
</div>
<figcaption>Reading order: Top-left (1), top-right (2), bottom-left (3), bottom-right (4).</figcaption>
</figure>

You’ll see how, in instances where the bot doesn’t hit the mark with its responses, an HR team member gently guides it to refer to a specific document, enabling the bot to provide a more accurate response. Through this dynamic human interaction, the chatbot learns and progressively enhances its performance over time.

Adding to the intriguing interaction, a question from the new employee led the HR team to realize that an important document hadn’t been uploaded:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/07/image-10.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/07/image-10.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/07/image-10.png 1000w, https://cms.jina.ai/content/images/2023/07/image-10.png 1172w" sizes="(min-width: 720px) 720px" width="1172" height="814" />
</figure>

After rectifying the oversight by uploading the document and using the `/refresh-gdrive-index` slash command to update the bot’s knowledge, the bot was asked to address the query again. And voila! It successfully provided the information. This shows not only the bot’s utility but also its role in identifying gaps in the information available, thus helping keep the system updated and efficient.

To further demonstrate the bot’s ability to track and recall long threads, we’ve included a screenshot below. It showcases an instance where a user requested the bot to summarize a lengthy conversation. Impressively, the bot was up to the task and delivered a succinct summary, affirming its proficiency in managing complex interactions.

<figure class="kg-card kg-image-card">
<img src="https://miro.medium.com/v2/resize:fit:700/1*AALszyHpNgs_HER4rBJP4w.png" class="kg-image" loading="lazy" width="700" height="255" />
</figure>

## Exploring further possibilities

We've shown that LangChain-based chatbots have an immense range of applications, from a bot that assists in project management by deciphering the subtleties of your team’s work and proposing efficiency-enhancing insights, to a bot that neatly captures and summarizes the key points and action items from meetings.

## Learn more

Langchain-serve ensures that LangChain-powered applications are always accessible to end-users. It empowers developers to build advanced Slack bots and REST/WebSocket APIs, that offer high availability, scalability, and observability. All of this, in tandem with the powerful <a href="https://cloud.jina.ai/" rel="noopener ugc nofollow">Jina AI Cloud</a> platform, provides a robust ecosystem for creating sophisticated, real-time applications that cater to diverse needs and use cases.

To learn more about Langchain-serve, [check out the GitHub repository](https://github.com/jina-ai/langchain-serve) and read [this article from Jina AI](https://jina.ai/news/langchain-serve-bringing-langchain-apps-closer-to-your-users/).

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/langchain-serve-bringing-langchain-apps-closer-to-your-users/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Langchain-serve: Bringing LangChain Apps Closer to Your Users
</div>
<div class="kg-bookmark-description">
Langchain-serve makes deployment and delivery of LangChain apps simple, taking one less hassle out of producing your AI applications.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/android-icon-192x192.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/2023/06/1_3cN_qz9pICgmDlpubzMLIw.webp" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/langchain-serve" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-description">
⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀 - GitHub - jina-ai/langchain-serve: ⚡ Langchain Apps on Production with Jina &amp; FastAPI 🚀
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.com/fluidicon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/7342025836ed5851d33c2ae5fe8f11fe1c2ea6fd7981067f72b1e8faa4a9020b/jina-ai/langchain-serve" />
</div>
</figure>

## Get in touch

Talk to us and keep the conversation going by joining the Jina AI Discord!

<div class="kg-card kg-button-card kg-align-center">

<a href="https://discord.com/channels/1106542220112302130/1106544066692390942" class="kg-btn kg-btn-accent">Jina AI Discord</a>

</div>
