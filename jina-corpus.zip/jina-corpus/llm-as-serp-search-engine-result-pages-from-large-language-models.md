---
title: "LLM-as-SERP: Search Engine Result Pages from Large Language Models"
slug: llm-as-serp-search-engine-result-pages-from-large-language-models
url: https://cms.jina.ai/llm-as-serp-search-engine-result-pages-from-large-language-models/
published_at: 2025-02-27T13:36:57.000+01:00
updated_at: 2025-02-28T09:05:05.000+01:00
reading_time: 5
authors: "Han Xiao"
tags: "Tech Blog"
excerpt: "This idea either extremely smart or extremely stupid—no in-between. Read till the end and find out why this could be useful."
---

# LLM-as-SERP: Search Engine Result Pages from Large Language Models

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jina.ai/llm-serp-demo" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
LLM as SERP
</div>
<div class="kg-bookmark-description">
Large language model as search result page
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-19.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">LLMSERP</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/banner-llm-serp.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">Try the interactive demo and see how your site appears in LLM SERP.</span></p></figcaption>
</figure>

Since RAG, the trend has been using LLMs to improve search. From Perplexity to DeepSearch and DeepResearch, the idea of injecting search engine results into the generation process has become de-facto. Many users also claim they no longer use Google as often as before, finding its classic pagination design lame, overwhelming or tedious. Instead, they've grown accustomed to the high precision and recall of QA-style result from a chat-like search UI, suggesting this design philosophy may be the way forward.

**But what if the LLM itself *is* the search engine?**

What if you could explore the knowledge embedded within LLMs as though you were Googling? Pagination, links and everything - just like the old days you are familiar with - ***but are completely generated***. If you're unsure what I mean, check the demo below first.

<figure class="kg-card kg-video-card kg-width-regular kg-card-hascaption" data-kg-thumbnail="https://cms.jina.ai/content/media/2025/02/llmserp2-1_thumb.jpg" data-kg-custom-thumbnail="">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjMuMTQgMTAuNjA4IDIuMjUzLjE2NEExLjU1OSAxLjU1OSAwIDAgMCAwIDEuNTU3djIwLjg4N2ExLjU1OCAxLjU1OCAwIDAgMCAyLjI1MyAxLjM5MkwyMy4xNCAxMy4zOTNhMS41NTcgMS41NTcgMCAwIDAgMC0yLjc4NVoiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPg==" />
</div>
<div class="kg-video-player-container kg-video-hide">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration">1:04</span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz4=" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">The links, titles, and snippets are completely generated by an LLM. You can visit </span><a href="https://jina.ai/llm-serp-demo"><span style="white-space: pre-wrap;">https://jina.ai/llm-serp-demo</span></a><span style="white-space: pre-wrap;"> and try some queries yourself! </span></p></figcaption>
</figure>

Before raising concerns about hallucinations, let's first explain why this idea has *some* merit: LLMs are trained on vast repositories of web knowledge. Models like DeepSeek-R1, GPT-4, Claude-3.7, and Gemini-2.0 have been trained on trillions of tokens from across the public internet. A rough estimate is that **\<1% to ~5% of high-quality, publicly accessible web text** has been used to train leading models.

If you think this number seems too small, consider this comparison: if we use Google's index as the benchmark (representing 100% of user-accessible data in the world), then Bing's index is approximately 30-50% of Google's. Baidu covers about 5-10%, and Yandex covers 3-5%. Brave Search indexes less than 1%. So if an LLM is trained on 1-5% of high-quality public data, it potentially equals the same amount of data a decent small search engine can provide.

Since these models have effectively "remembered" this web data, we simply need to prompt them in a way that "activates" their memory, allowing them to function as search engines and generate results similar to a search engine results page (SERP).

So yes, hallucination is a challenge, but as model capabilities improve with each iteration, we can reasonably expect this issue to alleviate. On X, people are often obsessed with generating SVGs from scratch whenever a new model is released, hoping each version produces better illustration than the last. This search engine idea follows similar hope of incremental improvement of LLM's understanding the digital world.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/02/Gk0YZPJaoAAh2Dr.jpeg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/02/Gk0YZPJaoAAh2Dr.jpeg 600w, https://cms.jina.ai/content/images/size/w1000/2025/02/Gk0YZPJaoAAh2Dr.jpeg 1000w, https://cms.jina.ai/content/images/size/w1600/2025/02/Gk0YZPJaoAAh2Dr.jpeg 1600w, https://cms.jina.ai/content/images/size/w2400/2025/02/Gk0YZPJaoAAh2Dr.jpeg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1122" alt="Browser-based coding environment showing a detailed SVG creation of a pink pig, along with descriptive text and code snippets" />
<figcaption><a href="https://x.com/aidan_mclau/status/1895204299040530794"><span style="white-space: pre-wrap;">Aidan McLaughlin</span></a><span style="white-space: pre-wrap;"> showing GPT's ability on drawing a self-portrait SVG in one-shot evolving over time</span></figcaption>
</figure>

Knowledge cutoff dates present another limitation. Search engines should return near-real-time information, but since LLM weights are frozen after training, they cannot provide accurate information beyond their cutoff date. Generally, the closer a query is to this cutoff date, the more likely hallucinations become. Since older information has likely been cited and rephrased more frequently, potentially increasing its weights in training data. (This assumes information is uniformly weighted; breaking news may receive disproportionate attention regardless of recency.) **However, this limitation actually defines precisely where this approach could be most useful—for information well within the model's knowledge timeframe.**

## Where LLM-as-SERP Can Be Useful?

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/a-practical-guide-to-implementing-deepsearch-deepresearch" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
A Practical Guide to Implementing DeepSearch/DeepResearch
</div>
<div class="kg-bookmark-description">
QPS out, depth in. DeepSearch is the new norm. Find answers through read-search-reason loops. Learn what it is and how to build it.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-20.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Han Xiao</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/a-practical-guide-to-implementing-deepsearch-deepresearch.webp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

In DeepSearch/RAG or any search grounding systems, a core challenge is determining whether a question needs external information or can be answered from the model's knowledge. Current systems typically use prompt-based routing with instructions like:

    - For greetings, casual conversation, or general knowledge questions, answer directly without references.
    - For all other questions, provide a verified answer with external knowledge. Each reference must include exactQuote and url.

This approach fails in both directions - sometimes triggering unnecessary searches, other times missing critical information needs. Especially with newer reasoning models, it's often not obvious until mid-generation whether external data is needed.

What if we simply ran search anyway? We could make one call to a real search API and another to an LLM-as-search system. This eliminates the upfront routing decision and moves it downstream where we have actual results to compare - recent data from real search, knowledge within the model's training cutoff, and potentially some incorrect information.

<figure class="kg-card kg-video-card kg-width-regular kg-card-hascaption" data-kg-thumbnail="https://cms.jina.ai/content/media/2025/02/should-I-Search--1-_thumb.jpg" data-kg-custom-thumbnail="">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjMuMTQgMTAuNjA4IDIuMjUzLjE2NEExLjU1OSAxLjU1OSAwIDAgMCAwIDEuNTU3djIwLjg4N2ExLjU1OCAxLjU1OCAwIDAgMCAyLjI1MyAxLjM5MkwyMy4xNCAxMy4zOTNhMS41NTcgMS41NTcgMCAwIDAgMC0yLjc4NVoiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPg==" />
</div>
<div class="kg-video-player-container kg-video-hide">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration">0:05</span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz4=" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">LLM-SERP gives search results that blend true knowledge with made-up information. However, since the real search engine provide grounded content, the next reasoning step can naturally prioritize the true knowledge.</span></p></figcaption>
</figure>

The next reasoning step can then identify inconsistencies and weigh sources based on recency, reliability, and consensus across results, which we don't have to explicitly code in—this is already what LLMs excel at. One can also visit each URL in the search results (e.g., with Jina Reader) to further validate the sources. In practical implementations, this verification step is always necessary anyway; you should never rely solely on excerpts from search engines, regardless real or fake search engines they are.

## Conclusion

By using LLM-as-SERP, **we transform the binary question of "is this within the model's knowledge or not?" into a more robust evidence-weighing process.** This eliminates the need of prompt-based routing and may improve the search grounding in DeepSearch-like systems. The logical chain for this assumes:

1.  The training data for LLMs effectively serves as a small, high-quality search engine.
2.  As LLMs continue to evolve, the hallucination problem will diminish. Knowledge cutoff dates and hallucinations are relatively independent issues - meaning an ideal perfect LLMs should have zero hallucinations when answering questions about topics before its knowledge cutoff date. Hallucinations *only* occur when answering questions about events after the cutoff date.
3.  Information retrieved from Google exists in varying degrees of truth and falsehood, just as information from LLMs contains both accurate information and hallucinations.
4.  When implementing search grounding, we don't need to overly worry about distinguishing between true and false information, but rather focus on recall rates. The task of pushing precision and factuality can be left to the LLM itself.

We provide <a href="https://jina.ai/llm-serp-demo" rel="noreferrer">a playground</a> as well as <a href="https://jina.ai/api-dashiboard/llm-serp" rel="noreferrer">an API endpoint hosted by us</a> that you can experiment with. Also feel free integrate into your own DeepSearch/DeepResearch implementations to see any improvement firsthand.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/node-serp" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/node-serp: LLMs-as-SERPs
</div>
<div class="kg-bookmark-description">
LLMs-as-SERPs. Contribute to jina-ai/node-serp development by creating an account on GitHub.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-3.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/node-serp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

The API mimics a full SERP endpoint where you can define the number of results, pagination, country, language etc. You can find its implementation on GitHub. We're eager to hear your feedback on this interesting approach.
