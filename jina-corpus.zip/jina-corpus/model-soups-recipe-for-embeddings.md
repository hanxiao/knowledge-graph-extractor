---
title: "Model Soup’s Recipe for Embeddings"
slug: model-soups-recipe-for-embeddings
url: https://cms.jina.ai/model-soups-recipe-for-embeddings/
published_at: 2025-05-07T18:43:10.000+02:00
updated_at: 2025-05-07T20:23:04.000+02:00
reading_time: 9
authors: "Bo Wang, Scott Martens"
tags: "Tech Blog"
excerpt: "Boost robustness and performance with model soups: averaging weights. No extra cost, better results."
---

# Model Soup’s Recipe for Embeddings

In these difficult times, nothing beats a nice, warm bowl of soup.

Minestrone is one of the classic Italian soups: thick, hearty, flavorful, combining beans, hearty vegetables, and rice or pasta. Its taste is a product of assembling diverse ingredients. It’s a bit like borscht in Eastern Europe, casseroles in America, or a homemade stir-fry in Pacific Asia in that it combines available, inexpensive ingredients into a beloved dish.

We can use much the same kind of recipe for neural network models, according to a line of papers starting with [Wortsman et al. (2022)](https://proceedings.mlr.press/v162/wortsman22a.html).

“Model soups” (alas, not “model casseroles” or “model stir-fries”) are a class of model ensembling techniques designed to mitigate the cost of optimizing training data and model hyperparameters. When training a neural network, you typically try different data and hyperparameter values and train multiple times, looking for the best-performing result. Training is very computationally expensive, and costs add up quickly.

<figure class="kg-card kg-bookmark-card">
<a href="https://proceedings.mlr.press/v162/wortsman22a.html" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Model soups: averaging weights of multiple fine-tuned models improves accuracy without increasing inference time
</div>
<div class="kg-bookmark-description">
The conventional recipe for maximizing model accuracy is to (1) train multiple models with various hyperparameters and (2) pick the individual model which performs best on a held-out validation set…
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-pmlr.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">PMLR</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://proceedings.mlr.press/v162/assets/images/logo-pmlr.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Instead, model soups involve training multiple models with different hyperparameters and training data choices — the same as you usually would — but then combining them. The result is a higher-performing and more robust model than the single best performer. It doesn’t save costs because you still train multiple models, but you can get a better result for the same price.

The model soup approach has already proven useful for text-image multimodal embedding models [(Wortsman et al. 2022)](https://proceedings.mlr.press/v162/wortsman22a.html) and generative large language models. ([Takuya et al. 2025](https://doi.org/10.1038/s42256-024-00975-8)) At Jina AI, we’ve begun using this technique to train our own models, and `jina-embeddings-v3` and `ReaderLM-v2` both incorporate model soups.

In this article, we’re going to look at model soups and show the results of some of our work with them. Specifically:

1.  Can we use model soups to improve performance by merging models at different points in their training?
2.  Can we merge models trained with different datasets and for different tasks to obtain better performance and higher training efficiency than by training a single model?

This has important potential benefits:

- Model soups can have better and more robust performance.
- Multilingual embedding models often suffer from biases and performance failures caused by unequal amounts of training data. It would be a boon to be able to train the best model we can on each task or dataset individually and then combine them equally.
- We may be able to do better continuous learning and model updating by making changes to our models in a modular way, updating one component model at a time, and then remerging it with the others.

## How Does it Work?

Merging the outputs of multiple models is an old technique in statistical decision theory. For example, it's common practice in weather forecasting to create multiple models, often made by different people with different assumptions, and then use a variety of mechanisms to average their predictions. If each model’s errors are randomly distributed, then averaging the models will lead to answers with fewer errors.

For example, if you have three different models that output a binary “yes” or “no”, and each is wrong 10% of the time, then two out of the three will be wrong only 2.8% of the time. Five models, with a majority decision criterion, will only be wrong 0.856% of the time.

Averaging models works on the same principle, but instead of combining the outputs of different models, it combines the models themselves.

The approach used is an extension of *stochastic weight averaging* ([Izmailov et al. 2018](https://auai.org/uai2018/proceedings/papers/313.pdf)), which relies on insights into the loss landscapes of neural networks to show that simple weight averaging can improve model generalization performance under common conditions.

The actual mechanics of averaging the models is disturbingly simple: You just average the weights of multiple models.

<figure class="kg-card kg-image-card kg-width-wide kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/05/image.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/05/image.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/05/image.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/05/image.png 1600w, https://cms.jina.ai/content/images/size/w2400/2025/05/image.png 2400w" sizes="(min-width: 1200px) 1200px" width="2000" height="380" alt="Colorful visual representations of neural networks labeled with types like &quot;fully connected,&quot; &quot;residual unit,&quot; and &quot;dilated l" />
<figcaption><span style="white-space: pre-wrap;">How models are merged to make a model soup. This example is very small and simple, but still shows the procedure: Sum the weights and divide by the number of models being merged.</span></figcaption>
</figure>

If this seems too easy, it’s important to note that there are limitations when merging models this way. You can’t just merge the weights of any two neural networks and expect it to work.

Model averaging only works on very similar models, i.e., models whose weights are not very different from each other to begin with. The way to ensure this is to pre-train one model and then create multiple variants of that model by fine-tuning them with different hyperparameters or different data. These models will typically be similar enough to average.

In more technical terms, pre-training usually produces a model whose weights are near the bottom of a loss basin, and fine-tuning doesn’t easily lead to escaping that loss basin. If all the models to be merged have weights in the same loss basin, then their weights will be fairly close to the same, and averaging them is likely to work. This is not guaranteed, but empirically, it seems to be true often enough to be useful.

## Experimental Setup

**Base Model**: For the experiments described here, we used [`xlm-roberta-base` from FacebookAI](https://huggingface.co/FacebookAI/xlm-roberta-base) ([Conneau et al. 2020](https://aclanthology.org/2020.acl-main.747/)) as our pre-trained base model. This model has 280 million parameters and has been pre-trained on 2.5TB of Common Crawl data containing text in roughly 100 languages.

We fine-tuned [`xlm-roberta-base`](https://huggingface.co/FacebookAI/xlm-roberta-base) on our curated sentence pair training set for embeddings training, before performing our experiments.

**Training Data**: Jina AI maintains custom-curated datasets for training. For the first experiment, we used sentence triplets specifically curated for contrastive training in six languages: English, Arabic, German, Spanish, Japanese, and Chinese. For the second experiment, we used task-specific training datasets in English.

**Evaluation**: We used relevant parts of the [MMTEB benchmark set](https://github.com/embeddings-benchmark/mteb/tree/main/docs/mmteb) ([Enevoldsen et al. 2025](https://arxiv.org/abs/2502.13595)) and [MIRACL benchmark](https://project-miracl.github.io/) ([Zhang et al. 2023](https://direct.mit.edu/tacl/article/doi/10.1162/tacl_a_00595/117438/MIRACL-A-Multilingual-Retrieval-Dataset-Covering)) to evaluate the models produced by our training and merging.

### Experiment 1: Single-Run Averaging

For this experiment, we used contrastive sentence triplets in all six languages, mixed together, for a total of 6,000 training steps with a batch size of 1,024 items. At every 2,000 steps, we saved the model state for averaging, producing 3 models, each reflecting a different point in the training process.

We averaged the three models to produce a final model. We then tested the merged model and the three saved checkpoints against the MMTEB-STS and MIRACL benchmark sets.

Our results are summarized in the table below:

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr>
<th>Model</th>
<th>MIRACL<br />
(avg 6 languages)</th>
<th>MMTEB-STS English<br />
(avg 8 benchmarks)</th>
<th>MMTEB-STS Multilingual<br />
(avg 6 benchmarks)</th>
<th>Average of 20 benchmarks</th>
</tr>
</thead>
<tbody>
<tr>
<td>No triplet training</td>
<td>0.3163</td>
<td>0.7859</td>
<td>0.7322</td>
<td>0.6276</td>
</tr>
<tr>
<td>Step 2000</td>
<td>0.4631</td>
<td><strong>0.7924</strong></td>
<td>0.7561</td>
<td>0.6813</td>
</tr>
<tr>
<td>Step 4000</td>
<td>0.4639</td>
<td>0.7902</td>
<td><strong>0.7583</strong></td>
<td>0.6812</td>
</tr>
<tr>
<td>Step 6000 (final)</td>
<td><strong>0.4680</strong></td>
<td>0.7891</td>
<td>0.7575</td>
<td>0.6818</td>
</tr>
<tr>
<td>Merged model<br />
(all 3 stored checkpoints)</td>
<td>0.4669</td>
<td>0.7910</td>
<td>0.7579</td>
<td><strong>0.6823</strong></td>
</tr>
</tbody>
</table>

Merging with previous checkpoints did not generally produce a better-performing model than the best performer among the stored checkpoints on individual benchmarks or on any of the three batteries of benchmarks used. However, it did produce the best model on all benchmarks averaged together.

In individual benchmarks, the difference between the merged model and the best-performing checkpoint is in every case less than 0.01. This is true not only for the averages in the table above but for each individual test.

This demonstrates that merging different training checkpoints can produce a more robust model at very little performance cost.

Furthermore, by merging the different checkpoints, we can effectively guard against overtraining. Overtraining has recently become an important topic in neural networks. ([Springer et al., 2025](https://arxiv.org/abs/2503.19206v2)) A network can be trained in a way that makes it harder and worse performing after further fine-tuning.

Since the best-performing checkpoint in our experiment is often not the last one, we have likely overtrained our model at 6,000 training steps. The merged model comes very close to matching the performance of the best checkpoint in all tests, removing the defects of overtraining.

### Experiment 2: Averaging Models Trained for Different Tasks

For this experiment, we trained three models, each for a different common embedding task:

- **Semantic similarity**: Measuring the relative overlap or similarity in meaning between two texts, typically of comparable length.
- **Document retrieval based on textual queries**: Finding the documents that best satisfy a query. Queries are generally much shorter texts than the documents they match.
- **Question answering**: Finding the document that best answers a natural language question. Questions are also generally much shorter than the texts they match.

Training models for all three tasks at once is quite difficult because the goals are very dissimilar, and we hope that model soups will improve the process.

Based on previous experience, we knew that each task required a different number of training epochs. The training is summarized below:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th>Task</th>
<th>Training Steps<br />
(batchsize = 1,024)</th>
<th>Training Dataset Size<br />
(in items)</th>
</tr>
</thead>
<tbody>
<tr>
<td>Question Answering (QA)</td>
<td>2,000</td>
<td>256,000</td>
</tr>
<tr>
<td>Document Retrieval</td>
<td>3,000</td>
<td>384,000</td>
</tr>
<tr>
<td>Semantic Similarity (STS)</td>
<td>1,000</td>
<td>128,000</td>
</tr>
</tbody>
</table>

This produced three models, which we then merged into a single model. We tested the resulting model against the portions of the MMTEB benchmark set relevant to those three tasks: [MIRACL](https://project-miracl.github.io/), [NanoBEIR](https://huggingface.co/collections/zeta-alpha-ai/nanobeir-66e1a0af21dfd93e620cd9f6), and STSEval (English and Multilingual parts of MMTEB).

<table style="width:100%;">
<colgroup>
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
</colgroup>
<thead>
<tr>
<th></th>
<th>MIRACL<br />
(avg 6 languages)</th>
<th>NanoBEIR<br />
(avg 13 benchmarks)</th>
<th>MMTEB-STS English<br />
(avg 9 benchmarks)</th>
<th>MMTEB-STS Multilingual<br />
(avg 6 benchmarks)</th>
<th>Average 34 benchmarks</th>
</tr>
</thead>
<tbody>
<tr>
<td>No triplet training</td>
<td>0.3163</td>
<td>0.5089</td>
<td>0.7859</td>
<td>0.7322</td>
<td>0.5876</td>
</tr>
<tr>
<td>QA training</td>
<td><strong>0.4489</strong></td>
<td>0.5332</td>
<td>0.7843</td>
<td>0.7535</td>
<td>0.6237</td>
</tr>
<tr>
<td>Retrieval training</td>
<td>0.4272</td>
<td><strong>0.5360</strong></td>
<td>0.7766</td>
<td>0.7340</td>
<td>0.6154</td>
</tr>
<tr>
<td>STS training</td>
<td>0.1779</td>
<td>0.4519</td>
<td><strong>0.7994</strong></td>
<td><strong>0.7651</strong></td>
<td>0.5508</td>
</tr>
<tr>
<td>Merged model</td>
<td>0.4246</td>
<td>0.5309</td>
<td>0.7981</td>
<td>0.7640</td>
<td><strong>0.6240</strong></td>
</tr>
</tbody>
</table>

We see here that the task-specific trained models have the best performance on each task. MIRACL is primarily a question-answering benchmark, even if it’s called a retrieval one, and the QA-trained model outperforms all others on it, including the merged model. NanoBEIR is a more conventional information retrieval benchmark set, and we see the retrieval-trained model is the top performer on it. The semantic similarity (STS) model scores quite poorly on those benchmarks, but beats the others on explicitly STS tasks. For each category, the merged model performs more poorly than the single-task trained model.

But once again, if we average over all benchmarks, the merged model outperforms the others, although its score represents only a very small improvement over the QA-trained model, and it is a very poor performer on STS tasks.

We also merged just the QA and retrieval models and scored the resulting model on the same benchmarks:

<table>
<colgroup>
<col style="width: 12%" />
<col style="width: 12%" />
<col style="width: 12%" />
<col style="width: 12%" />
<col style="width: 12%" />
<col style="width: 12%" />
<col style="width: 12%" />
<col style="width: 12%" />
</colgroup>
<thead>
<tr>
<th></th>
<th>MIRACL<br />
(avg 6 languages)</th>
<th>NanoBEIR<br />
(avg 13 benchmarks)</th>
<th>MMTEB-STS English<br />
(avg 9 benchmarks)</th>
<th>MMTEB-STS Multilingual<br />
(avg 6 benchmarks)</th>
<th>Average 34 tests</th>
<th>Average<br />
QA &amp; IR<br />
(19 tests)</th>
<th>Average STS<br />
(15 tests)</th>
</tr>
</thead>
<tbody>
<tr>
<td>Best task-trained model</td>
<td>0.4489</td>
<td>0.5360</td>
<td><strong>0.7994</strong></td>
<td><strong>0.7651</strong></td>
<td>0.6237</td>
<td>0.5066</td>
<td><strong>0.7857</strong></td>
</tr>
<tr>
<td>Merged model</td>
<td>0.4246</td>
<td>0.5309</td>
<td>0.7981</td>
<td>0.7640</td>
<td>0.6240</td>
<td>0.4973</td>
<td>0.7845</td>
</tr>
<tr>
<td>QA+Retrieval merged model</td>
<td><strong>0.4610</strong></td>
<td><strong>0.5404</strong></td>
<td>0.7878</td>
<td>0.7498</td>
<td><strong>0.6288</strong></td>
<td><strong>0.5153</strong></td>
<td>0.7726</td>
</tr>
</tbody>
</table>

We see here that while we can improve performance on both question-answering and retrieval by merging trained models for the two tasks, adding STS-trained models reduces task-specific performance in all categories. This suggests that semantic similarity is, in some important respects, unlike QA and retrieval, and an STS-trained model is unsuited to merge with the other two.

This is likely because question-answering and retrieval involve matching short texts — questions and queries — to longer documents, while semantic similarity involves comparing documents of more similar length.

[Wortsman et al. (2022)](https://proceedings.mlr.press/v162/wortsman22a.html) describe a selective approach to averaging that they call “greedy” merging. It involves taking one model, usually the best performing of a set of models, and then only adding those models to it that individually improve performance. With just three models, there was little point in using greedy merging for this experiment. However, we might imagine a case with more models and using a technique like this as a basis for determining the degree of similarity between tasks. We found here that semantic similarity is unlike the other two. We could then evaluate when one model can perform many tasks and when it’s more cost-effective to use a different model.

## Soup’s on!

Model soups blend diversity into something greater than the sum of their parts. The value of this approach is in its ability to offer greater consistency, robustness, and to act as a safeguard against overtraining at no additional training cost. Our experiments show that merging checkpoints or task-specialized models can enhance overall performance, even if it occasionally comes at the cost of task-specific peaks.

In the end, model soups offer a practical and very simple way to build more adaptable models, although it comes with some caveats. It’s not a panacea, and it’s applicable only when models are already very similar.

As they say on the internet, *Your Mileage May Vary*. But it’s cheap and easy to find out if model soups can help when you train your models.
