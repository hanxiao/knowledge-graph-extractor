---
title: "MyScale & Jina AI: Unleashing Great Potential for Your AI Applications"
slug: myscale-jina-ai-unleashing-great-potential-for-your-ai-applications
url: https://cms.jina.ai/myscale-jina-ai-unleashing-great-potential-for-your-ai-applications/
published_at: 2024-01-29T16:00:29.000+01:00
updated_at: 2024-12-16T03:50:38.000+01:00
reading_time: 1
authors: "Scott Martens"
tags: "Tech Blog"
excerpt: "With full integration of Jina Embeddings v2 models, MyScale allows users to harness the capabilities of Jina AI within an SQL database."
---

# MyScale & Jina AI: Unleashing Great Potential for Your AI Applications

<a href="https://myscale.com/" rel="noreferrer">MyScale</a> has integrated <a href="https://jina.ai/embeddings/" rel="noreferrer">Jina Embeddings v2</a> into its AI-focused SQL vector database. You can now use Jina AI's cutting-edge embedding models in conjunction with powerful and time-tested SQL database technologies to bring precise text matching and efficient semantic similarity to your data-driven applications.

Follow the link below to MyScale's website to see how you can supercharge your SQL with Jina Embeddings.

<figure class="kg-card kg-bookmark-card">
<a href="https://myscale.com/blog/myscale-integration-jinaai/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
MyScale &amp; Jina AI: Unleashing Great Potential for Your AI Applications
</div>
<div class="kg-bookmark-description">
MyScale is fully integrated with Jina Embeddings v2 in the EmbedText function, allowing users to process text with an input length of up to 8K using the standard SQL syntax.
</div>
<div class="kg-bookmark-metadata">
<img src="https://myscale.com/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://d3lhz231q7ogjd.cloudfront.net/blog/myscale-and-jinaai-2.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Top-performing, 8192-token context length, $100 for 1.25B tokens, seamless OpenAI alternative, free trial
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
