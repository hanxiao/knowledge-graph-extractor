---
title: "Multi-Task Contrastive Learning for 8192-Token Bilingual Text Embeddings"
link: https://arxiv.org/abs/2402.17016
date: 2024/02/26
source_url: https://arxiv.org/pdf/2402.17016
type: paper
---

Title: Multi-Task Contrastive Learning for 8192-Token Bilingual Text Embeddings

URL Source: https://arxiv.org/pdf/2402.17016

Published Time: Wed, 28 Feb 2024 03:29:56 GMT

Number of Pages: 17

Markdown Content:
# Multi-Task Contrastive Learning for 8192-Token Bilingual Text Embeddings 

## Isabelle Mohr, Markus Krimmel, Saba Sturua, Mohammad Kalim Akram, Andreas Koukounas , Michael Günther , Georgios Mastrapas , Vinit Ravishankar ,

## Joan Fontanals Martínez , Feng Wang , Qi Liu , Ziniu Yu , Jie Fu , Saahil Ognawala ,

## Susana Guzman , Bo Wang , Maximilian Werk , Nan Wang and Han Xiao 

## Jina AI GmbH, Ohlauer Str. 43, 10999 Berlin, Germany 

## research@jina.ai 

## Abstract 

We introduce a novel suite of state-of-the-art bilingual text embedding models that are de-signed to support English and another target language. These models are capable of process-ing lengthy text inputs with up to 8192 tokens, making them highly versatile for a range of natural language processing tasks such as text retrieval, clustering, and semantic textual simi-larity (STS) calculations. By focusing on bilingual models and intro-ducing a unique multi-task learning objective, we have significantly improved the model per-formance on STS tasks, which outperforms the capabilities of existing multilingual mod-els in both target language understanding and cross-lingual evaluation tasks. Moreover, our bilingual models are more efficient, requiring fewer parameters and less memory due to their smaller vocabulary needs. Furthermore, we have expanded the Massive Text Embedding Benchmark (MTEB) to include benchmarks for German and Spanish embedding models. This integration aims to stimulate further research and advancement in text embedding technolo-gies for these languages. 

## 1 Introduction 

Text embedding models allow NLP practitioners to encode a text snippet of arbitrary length into a vector in the semantic space. Such embedding mod-els have evolved into core components within the domains of neural information retrieval and found wide adoption and integration into various other facets of Natural Language Processing research and applications. In particular, they became specif-ically popular for building Retrieval-Augmented Generation pipelines. Currently, such dense text embedding models fall into two categories: monolingual and multi-lingual. Monolingual models are usually limited to processing English text exclusively. In contrast, most of the multilingual text embedding models support tens of languages. This is achieved by fine-tuning pre-existing multilingual backbones like XLM-RoBERTa [Conneau et al., 2020] on mainly English data. 1 Alternatively, multilingual knowl-edge distillation can be applied to align embed-ding models across various languages using par-allel data [Reimers and Gurevych, 2020] to cope with the scarcity of high-quality semantic pairs or triplets in the target languages. Despite these efforts, training data with such an extremely un-balanced distribution between different languages leads to inferior performance in the target language. Moreover, compared to monolingual English mod-els, the performance of multilingual models falls short in the English tasks, i.e., the multilingual ver-sion of the E5 model [Wang et al., 2022] achieves a significantly lower average score compared to its monolingual variant on the Massive Text Em-bedding Benchmark (MTEB) [Muennighoff et al., 2023]. Furthermore, to support tens of languages, most of the multilingual models have a large token vocabulary. In practice, only two or three languages are used in the industry use cases, which means the parameters due to the large vocabulary are never used. To address these shortcomings of multilingual models, we introduce a new family of embedding models namely bilingual text embeddings , that fo-cus on handling two languages effectively. Each of our bilingual language models consistently sup-ports a target language (e.g., German, Chinese, or Spanish) alongside English. Instead of relying on existing multilingual backbone models, we train backbone models that support these specific lan-guage pairs, thus reducing the model size com-pared to multilingual alternatives. We show that these models can be fine-tuned more effectively on embedding tasks than multilingual models. For         

> 1e.g., multilingual-e5 is fine-tuned with >99% English data: https://huggingface.co/intfloat/ multilingual-e5-large
> arXiv:2402.17016v1 [cs.CL] 26 Feb 2024

fine-tuning the models on the text-embedding tasks, we introduce a novel multi-task learning strategy that increases the performance of the embedding models on STS and retrieval tasks. Addition-ally, our bilingual models support large context lengths (up to 8192 tokens), as we are utilizing the same architecture used for our long context length model [Günther et al., 2023a]. As there is only limited work done in evaluating embedding mod-els in German and Spanish, we collect evaluation datasets for integrating them into the existing Mas-sive Text Embedding Benchmark (MTEB) to build up a standard for benchmarking text embedding models in these languages. Our efforts result in a suite of bilingual text em-bedding models 2 that achieve superior or compara-ble performance on various embedding tasks com-pared to multilingual state-of-the-art models and specifically excel in cross-lingual retrieval settings while retaining a significantly smaller model size. Section 2 starts with an exploration of related research on training embedding models, multilin-gual models, and multi-task learning. We continue with an overview of the training (Section 3), a de-scription of the pre-training phase (Section 4), and the fine-tuning phase (Section 5). In the evalua-tion in Section 6, we compare the bilingual mod-els to other state-of-the-art models and conduct ablation studies of the backbone training and the multi-task learning. Finally, we draw conclusions in Section 7. 

## 2 Related Work 

While lots of research focuses on embedding train-ing techniques, little research has been conducted on training bilingual embedding models. Some research papers focus on multilingual models, for example, Reimers and Gurevych [2020] propose a method to distill monolingual teacher embedding models to multilingual student language models and the embedding training technique proposed for the E5 model [Wang et al., 2022] has been success-fully transferred to train a multilingual E5 model 3

that achieves better performance than many mono- 

> 2de-en: https://huggingface.co/jinaai/ jina-embeddings-v2-base-de
> zh-en: https://huggingface.co/jinaai/ jina-embeddings-v2-base-zh
> es-en: https://huggingface.co/jinaai/ jina-embeddings-v2-base-es
> API: https://jina.ai/embeddings
> 3https://huggingface.co/intfloat/ multilingual-e5-large

lingual models of the same size on non-English tasks of the MTEB benchmark [Muennighoff et al., 2023]. In a more recent work, [Chen et al., 2024], the authors propose M3, a single model for dense retrieval, multi-vector retrieval, and sparse retrieval for multiple languages. 

2.1 Multilingual Language Models 

For training a bilingual embedding model, we use a backbone language model that can handle multi-ple languages. One of the first multilingual trans-former models is the multilingual BERT (mBERT) model developed by Devlin et al. [2019], which is trained for 104 languages. XLM [Conneau and Lample, 2019] and XLM-R [Conneau et al., 2020] continue this line of work, leveraging parallel data during pre-training in their translation language modeling objective. Various authors note diffi-culties in training massively multilingual models, owing to a phenomenon called the curse of mul-tilinguality [Conneau et al., 2020]: while some level of multilinguality leads to positive transfer between languages, model capacity becomes "di-luted" across languages, eventually leading to per-formance degradations [Conneau et al., 2020, Ari-vazhagan et al., 2019, Blevins et al., 2022, Wang et al., 2020]. Some works address this issue via language-specific network components [Pfeiffer et al., 2022, 2020], optimized per-language vocab-ulary capacity [Zheng et al., 2021], and a tempo-rary capacity increase during pre-training [Chung et al., 2021]. However, other authors argue in favor of tri- and bilingual models that can sig-nificantly outperform their multilingual counter-parts [Xu et al., 2021, Chang et al., 2020, Ulcar and Robnik-Sikonja, 2020]. 

2.2 Multi-Task Learning 

For training a general-purpose embedding model, we adopt the concept of multi-task learning [Caru-ana, 1997, Crawshaw, 2020]. Multi-task learners use shared representations to solve several related downstream tasks at once. Since they share model parameters across tasks, a training signal from di-verse task objectives may lead to inductive trans-fers [Baxter, 2000]. Early relevant works in this direction include Subramanian et al. [2018], where sentence representations were learned in a multi-task fashion over a range of tasks, and Luong et al. [2015], where multiple sequence-to-sequence tasks were learned simultaneously. Within this paradigm, therefore, parameters may be shared either in a hard fashion through com-mon network components or softly via an objective that incentivizes the similarity of task-specific net-works [Duong et al., 2015]. The overall loss of the multi-task network is usually formulated as a weighted sum of task losses, where the weights may change dynamically during training to emphasize underperforming tasks [Guo et al., 2018], balance learning speeds between tasks [Chen et al., 2018] or maximize the observed data likelihood when tak-ing into account per-task uncertainty [Kendall et al., 2018]. In our work, we adopt a hard parameter-sharing approach but deviate from the usual loss formulation. Instead of forming the overall loss as a sum of task losses, we sample a task in each forward pass and backpropagate the corresponding task loss. 

## 3 Training Paradigm Overview 

For training each of the bilingual embedding mod-els, we follow a procedure which consists of three stages: I Pre-training a JinaBERT model: The back-bone model has the same implementation as the Jina BERT model introduced in [Günther et al., 2023a]. To reduce the number of pa-rameters, we use a different tokenizer in each bilingual model that is trained to encode the specific pair of languages. As with Jina BERT ,those bilingual models are able to encode up to 8192 tokens. For training the model from scratch, we conduct a standard masked lan-guage modeling training with a combination of large full-text corpora in both languages. II Fine-tuning with Text Pairs: To encode a text passage into a single vector repre-sentation, we employ the previously used method [Günther et al., 2023a], which fine-tunes a model on text pairs. III Fine-tuning with Multi-Task Objective: In the last stage, training with a multi-task ob-jective is done to specifically improve the model’s performance on STS, retrieval, and classification tasks. 

## 4 Pre-training a Modified BERT 

4.1 Model Architecture 

For our bilingual text embedding models, we use the same BERT architecture described in our pre-                

> Model Layers Dim. Param. Tokens
> Jina BERT
> Base (en) 12 768 137M 30,528
> Jina BERT
> Base (bilingual) 12 768 161M [60,516, 61,056] multilingual-e5-base 12 768 278M 250,000
> Table 1: Architecture specifications of different mono-lingual, bilingual and multilingual models

vious work [Günther et al., 2023a]. This archi-tecture modifies the original BERT model with ALiBi [Press et al., 2022] to support long context lengths during model inference. For the Spanish model, we additionally introduce a normalization of key and query vectors to address training in-stabilities. In each self-attention layer, we use layer normalization [Ba et al., 2016] to normal-ize keys and queries before computing the dot-product attention. For the purpose of normalization, we decide to treat the head axis as an additional layer axis. This normalization is loosely related to QK-normalization [Henry et al., 2020], in which keys and queries are ℓ2-normalized. In contrast to [Henry et al., 2020], we do not perform normal-ization in each head separately, but instead flatten the head axis into the layer axis. Another modification to the model architecture has to do with the tokenizer and the vocabulary size. We train BPE tokenizers [Sennrich et al., 2016] for all the language pairs and double the vocabulary size compared to the original monolingual variant to provide room for the token representation of two languages instead of one. This increase in the vocabulary results in a larger input embedding matrix, thus increasing the number of parameters for our bilingual models, as is apparent in Table 1. 

4.2 Training Data 

We collect a comprehensive set of data from var-ious high-quality sources like CulturaX [Nguyen et al., 2023], Wikipedia 4, and Opus [Tiedemann, 2016]. CulturaX is a combination of mC4 [Raffel et al., 2019] (version 3.1.0) and OSCAR [Jansen et al., 2022] aggregating all accessible corpora up to 23.01.2024. The Opus collection consists of translated texts harvested from the Web and is pub-licly available. To ensure the high quality of the dataset, the original creator of the data source con- 

> 4https://dumps.wikimedia.org (Accessed: 2024-02-20)

ducted a thorough cleaning process, wherein vari-ous filtering rules and heuristics were applied along with multiple stages of deduplication. We amass a corpus of approximately 250M English text doc-uments and an equivalent number of German and Spanish text documents for each of the respective bilingual models, amounting to a total of 256B tokens for each model. This meticulous curation maintains a 1:1 ratio between English and target language text documents, ensuring balance and rel-evance for their respective bilingual models in our study. We earmark 1% of the dataset exclusively for the assessment of the model performance dur-ing training, i.e. calculating the validation loss and measuring accuracy in masked token prediction. 

4.3 Training Algorithm 

The training algorithm largely remains the same as in our previous work [Günther et al., 2023a]. We optimize for the Masked Language Modeling (MLM) objective, omitting the Next Sentence Pre-diction (NSP) task [Liu et al., 2019]. We employ whole word masking with a masking rate of 30% .Experiments with dynamic masking rate schedul-ing [Ankner et al., 2024] did not show any benefits on downstream task performance for our use case. Given the fact that our training dataset is bilin-gual, we alternate between batches containing data from a single language. All other parameters and mechanics of our train-ing algorithm, e.g., optimizer, learning rate, sched-ulers, and hyperparameters are identical to our monolingual model and are presented extensively in our previous work [Günther et al., 2023a]. 

## 5 Fine-Tuning for the Embedding Task 

After pre-training the Jina BERT models, we train the models to encode a text sequence into a sin-gle vector representation. Following the Sentence-BERT [Reimers and Gurevych, 2019] approach, each model is augmented by a mean pooling layer to consolidate the semantic encoded in all the out-put token vectors into a single vector. Therefore, we conduct generic embedding training in stage II, which is followed by stage III, where the model learns to solve specific embedding tasks. To increase the run-time performance and reduce the consumption of GPU memory to support larger batch sizes (high batch sizes are crucial for effec-tive embedding training [Li et al., 2023]), we apply various optimizations explained in detail in [Gün-ther et al., 2023a]. 

5.1 Fine-tuning with Text Pairs 

In stage II, we train the models for general embed-ding tasks on a corpus of text pairs (q, p ), compris-ing a query string q and a target string p.

Training Data We construct a collection of 211 million German, 111 million Spanish, and 518 mil-lion English text pairs. The dataset predominantly consists of monolingual pairs (97.5%), which in-clude varied relational types like titles with articles, questions with answers, and texts with their sum-maries. The rest are bilingual pairs that consist of identical texts in two different languages, forming a parallel dataset that bridges English with the other two. To assemble our dataset, we start with curated datasets such as MQA [De Bruyn et al., 2021], XL-Sum [Hasan et al., 2021], XNLI [Conneau et al., 2018], MLSum [Scialom et al., 2020], and Eu-roparl [Tiedemann, 2012]. Seeking further diver-sity and volume, we utilize Common Crawl data to create two types of pairs: one from web page titles and their contents, and another by mining question-answer pairs from FAQ and support-related pages. Additionally, we pair paragraphs with their section titles from Wikipedia. We improve the data quality by implementing a two-stage processing strategy: filtering and re-finement. In the filtering stage, texts are eliminated based on a variety of quality checks, e.g., very short texts, lengthy texts, and text with excessive repe-tition of lines or n-grams are removed [Rae et al., 2021]. Then the refinement process is applied to improve the remaining texts’ quality without dis-carding them. This includes stripping site-specific metadata, and removing unfinished lines, or lines with only one word. To further improve our dataset, we use near-deduplication [Lee et al., 2022] to remove dupli-cates and consistency filtering [Alberti et al., 2019, Dai et al., 2022] to filter out inconsistent pairs. These techniques have proven effective in our past studies [Günther et al., 2023b,a]. 

Loss Function Following our previous work, we utilize a bi-directional InfoNCE [van den Oord et al., 2018] function Lpairs with a temperature value of τ = 0 .05 :

Lpairs (B) := LNCE (B) + LNCE (B†) (1) where B = (( p1, q 1), . . . , (pk, q k)) is a batch of 

k pairs, B† = (( q1, p 1), . . . , (qk, p k)) is obtained from B by swapping the order of pairs and LNCE 

is defined via: 

LNCE (B) := − X

> (xi,y i)∈B

ln es(xi,y i)/τ kP

> i′=1

es(xi,y i′ )/τ 

(2) 

5.2 Fine-tuning with Multi-Task Objective 

Previous work [Wang et al., 2022, Li et al., 2023, Günther et al., 2023a] found that models trained with the training paradigm in stage I and stage II have sub-optimal ranking capabilities that can be improved by continuing training with hard nega-tives and different contrastive loss functions. We generalize from this concept to a multi-task training stage. For different tasks, datasets come with different formats. For example, STS tasks [Cer et al., 2017] usually contain triplets (q, p, t ) of two texts q and 

p associated with their defined similarity score t

while retrieval datasets usually contain a text query 

q and one or several relevant documents p and op-tionally non-relevant documents n. For each task, we define a specific loss function. For this work, we only focus on retrieval and STS tasks, but plan to include more tasks in our training in the future. Similar to the training in stage II, for the construc-tion of each batch, a dataset is sampled. Depending on the task this dataset aims to solve, we choose the respective loss function. 

Training Data For retrieval tasks, we prepare several datasets like MSMarco [Bajaj et al., 2016] and Natural Questions (NQ) [Kwiatkowski et al., 2019] into a format of tuples with one positive and multiple negatives: (q, p, n 1, . . . , n m) similar to previous work [Li et al., 2023, Günther et al., 2023a]. The STS datasets contain triplets of two text values q and p as well as a similarity score t:

(q, p, t ) like the training datasets of SemEval 5.Since there is much more high-quality data avail-able in English, we use machine translation to trans-late some of the datasets into the other target lan-guages. For translating the datasets to German, we employ FAIR’s compute-efficient WMT19 model [Ng et al., 2019], whereas we utilize the mul-tilingual MADLAD-3B model of Kudugunta et al. [2023] for generating Spanish datasets. In both 

> 5https://ixa2.si.ehu.eus/stswiki/index.php/ STSbenchmark

cases, translations are performed at the sentence level. Translated documents containing truncations, either originating from tokenization of the original text or generation, are removed from the dataset. To increase the diversity of the training data and mitigate problems caused by training only on trans-lations, we also select various datasets in the target language that we prepare for the final training stage. We make use of GerDaLIR [Wrzalik and Krechel, 2021], which is a German Dataset for legal infor-mation retrieval, as well as GermanDPR [Möller et al., 2021], which is a German training dataset for dense passage retrieval. For Spanish, we use the SQAC dataset [Gutiérrez-Fandiño et al., 2022], which is an extrac-tive QA dataset for Spanish, as well as the Spanish subset of XL-Sum [Hasan et al., 2021], which is a multilingual summarization dataset consisting of BBC news articles. We also use the Spanish subset of the MIRACL dataset [Zhang et al., 2022]. This is a multilingual information retrieval dataset, which we also use to prepare new multilingual retrieval and re-ranking tasks in the MTEB. See Section 6.2 for more details. 

Loss Function For each batch, the type of task is determined and a respective loss function is se-lected. For retrieval tasks, we follow previous work and use a bi-directional InfoNCE loss function: 

Ltriplet (B) := 

Er∼B

"

− ln es(q,p )/τ kP

> i=1

h

es(q,p i)/τ + mP

> j=1

es(q,n j,i )/τ 

i#

+ Er∼B

"

− ln es(p,q )/τ kP

> i=1

es(p,q i)/τ 

#

with r = ( q, p, n 1, . . . , n m). (3) If the sampled batch comes from an STS dataset, we employ the negative Pearson’s sample correla-tion [Pearson, 1895] as a loss function. Assuming that the batch B consists of text pairs (q, p ) and corresponding relevance scores t, we compute it as: 

LSTS (B) := − cov (q,p,t )∼B (s(q, p ), t )

σs(B)σt(B) (4) Here, σs and σt are the estimated standard devia-tions of s(q, p ) and t, respectively, computed over batch B. Analogously, the covariance in the numer-ator of (4) is computed across batch B.The correlation-based loss is suitable because it takes into account the magnitudes of the similarity scores instead of binary relevance as considered by the InfoNCE. Moreover, we choose to use a Pear-son correlation loss over the mean squared error (MSE) loss function which is typically used with STS datasets [Reimers and Gurevych, 2019] since the Pearson correlation is invariant to the scale of the similarity values. We presume that this makes multi-task training that involves the InfoNCE loss function for retrieval datasets more stable. The ablation study in Section 6.4 provides empirical evidence for this claim. 

## 6 Evaluation 

In our evaluation, we aim to not only evaluate the resulting models on a wide range of tasks, but also evaluate our novel approach. We start evaluating the bilingual backbone models on general language modeling tasks in Section 6.1. Then, we conduct a comprehensive evaluation concerning embedding tasks in Section 6.2 and finally conduct two ab-lation studies to show that bilingual models per-form better after training on embedding tasks with the same amount of pair-wise training data (Sec-tion 6.3) and prove the effectiveness of the multi-task learning (Section 6.4). 

6.1 Performance of Backbone Models 

To assess the proficiency of our bilingual backbone models, we conduct evaluations on two distinct benchmarks for language models. The GLUE (Gen-eral Language Understanding Evaluation) [Wang et al., 2019] benchmark is used to examine the model’s capabilities in the English language. It comprises nine datasets designed to evaluate natu-ral language understanding specifically in English. For measuring the cross-lingual performance of our model, we utilize the XTREME (Cross-lingual TRansfer Evaluation of Multilingual Encoders) benchmark [Hu et al., 2020]. XTREME is a com-prehensive multi-task benchmark designed to eval-uate the cross-lingual generalization capabilities of multilingual representations. For both benchmarks, the training, development, and test data splits are provided. It is worth noting that the test splits do not include labels, and the participants can evalu-ate their systems by submitting predictions on the test set via the designated submission servers. 6,7

In our study, we conduct a comparative analysis of our models against established multilingual mod-els, specifically mBERT [Devlin et al., 2019] and XLM-RoBERTa [Conneau et al., 2020], which are commonly used as backbones for multilingual em-bedding models. The evaluation is performed on the development sets of the two benchmarks. For evaluation on the GLUE benchmark, we fol-low the methodology of [Phang et al., 2018], for RTE, STS, and MRPC, and start fine-tuning from models trained on GLUE’s MNLI task, rather than utilizing the pre-trained models directly. For the XTREME benchmark, our experiments involve two distinct settings. Firstly, we concen-trate on zero-shot cross-lingual transfer, employing English as the source language and German and Spanish as the target languages. In the second set-ting, translated train splits are available to conduct an evaluation where we train our models on the German and Spanish translations. In both benchmarks, we train for 10 epochs with a batch size of 32 and a learning rate of 2e −5. For each task, we report the best performance on the development set. Table 2, and Table 3 report the results of the GLUE and XTREME benchmarks. Across both benchmarks our bilingual models perform on aver-age better than the multilingual ones. Notably, our Spanish model exhibits the highest performance on the GLUE benchmark, while the German model slightly surpasses the XLM-RoBERTa model. On the XTREME benchmark, our bilingual models exhibit a noteworthy advantage in the zero-shot cross-lingual evaluation setup. Particularly, they outperform multilingual models in cross-lingual sentence retrieval tasks of BUCC [Zweigenbaum et al., 2017] and Tatoeba [Artetxe and Schwenk, 2019]. This difference margin decreases after train-ing on the translated data. 

6.2 Embedding Model Evaluation 

To get a comprehensive overview of our models on a broad range of tasks, we evaluate them on the MTEB [Muennighoff et al., 2023] which consists of more than 50 embedding evaluation tasks. Al-though the MTEB boasts a large variety of tasks and languages, not all languages are adequately rep-resented across the existing task categories, such as                                               

> 6https://gluebenchmark.com
> 7https://sites.research.google/xtreme Model Params MNLI QQP QNLI SST-2 CoLa STS-B MRPC RTE WNLI Average
> Jina BERT Base-de 161M 84.4/85.1 89.8 91.3 92.6 57.9 89.1 87.5 79.6 56.3 81.0
> Jina BERT Base-es 161M 86.3/86.2 90.2 91.2 93.6 61.7 90.1 89.2 82.3 53.3 82.0
> XLM-RoBERTa 279M 84.7/84.7 90.1 90.6 93.1 56.9 88.7 88.2 76.2 56.3 80.8 mBERT Base 179M 82.5/82.4 89.5 91.3 90.1 42.6 89.9 87.0 79.0 54.9 78.2

Table 2: Performance of Jina BERT models and multilingual models on GLUE dev set                                                                                            

> Lang. Model XNLI PAWS-X NER XQuAD MLQA BUCC Tatoeba Metrics Acc. Acc. F1 F1/EM F1/EM F1 Acc.
> Cross-lingual zero-shot transfer (models are trained on English data)
> de
> Jina BERT Base-de 79.8 85.8 77.3 75.4/58.7 62.5/46.3 72.5 86.2
> XLM-RoBERTa 77.6 87.7 75.8 75.5/59.9 61.9/45.7 17.9 51.6 mBERT 72.8 84.6 79.3 73.2/56.9 56.7/39.2 65.8 60.9 es
> Jina BERT Base-es 82.6 89.6 73.2 78.2/60.1 72.7/50.2 -76.6
> XLM-RoBERTa 78.9 89.8 72.0 77.0/58.5 70.3/49.2 -32.2 mBERT 75.5 87.3 76.3 71.2/53.5 67.6/46.8 -57.1
> Translate-train (models are trained on English training data translated to the target language)
> de
> Jina BERT Base-de 81.4 87.4 88.7 75.6/59.8 63.0/45.5 --XLM-RoBERTa 80.6 86.6 88.9 76.7/60.3 62.2/47.1 --mBERT 76.9 85.4 90.4 76.3/60.8 59.9/44.4 --es
> Jina BERT Base-es 84.2 90.3 90.3 80.0/61.5 72.8/49.2 --XLM-RoBERTa 80.9 89.0 90.5 79.6/62.6 71.1/48.6 --mBERT 79.4 88.8 91.9 80.6/62.8 72.6/51.2 --

Table 3: Performance of Jina BERT models and multilingual models on XTREME dev set 

retrieval, classification, and reranking. The lack of tasks for German and Spanish hinders a comprehen-sive evaluation of our bilingual models trained on these languages. Consequently, we address these gaps by integrating new tasks into the MTEB frame-work, using existing publicly available datasets for the aforementioned languages, to ensure a more inclusive and representative assessment of model performance across diverse languages and cross-lingual combinations. Using the MTEB framework, others can easily reproduce the results and evaluate other new and existing embedding models. We add a total of ten tasks for Spanish, which are comprised of six retrieval tasks (XMarket [Bonab et al., 2021], SpanishPassageRetievalS2P and SpanishPassageRetrievalS2S [Kamateri et al., 2019], MIRACLRetrieval [Zhang et al., 2022], MintakaRetrieval [Sen et al., 2022], and XQPARe-trieval [Shen et al., 2023]), two clustering tasks (FloresClusteringS2S Goyal et al. [2022] and Span-ishNewsClusteringP2P 8), as well as one rerank-ing task (MIRACLReranking [Zhang et al., 2022]) and one STS task (STSES [Agirre et al., 2014, 2015]. Additionally, we integrate the PAWS-X 

> 8https://www.kaggle.com/datasets/kevinmorgado/spanish-news-classification

dataset [Yang et al., 2019] as a multilingual pair-classification task for seven different languages, including German and Spanish. Table 4 shows the averages across task cate-gories per model. Our Spanish model outperforms multilingual-e5 on average on the Spanish cluster-ing, retrieval, and reranking tasks, while slightly underperforming in the classification domain. How-ever, our bilingual Spanish model also has an ad-vantage over multilingual-e5 on cross-lingual STS tasks (see Table 9). Details on the evaluation re-sults of our Spanish bilingual model on all Spanish tasks in the MTEB are presented in Table 7 in the appendix. We also integrate five new tasks for Ger-man, namely a reranking task (MIRACLRerank-ing [Zhang et al., 2022]), an STS task (Ger-manSTSBenchmark 9), and three retrieval tasks (GerDaLIR [Wrzalik and Krechel, 2021], Ger-manDPR [Möller et al., 2021] and XMarket [Bonab et al., 2021]). Looking to Table 4 for average scores across task categories, our bilingual German model out-performs the multilingual-e5 model on the German                                                                   

> 9https://github.com/t-systems-on-site-services-gmbh/german-STSbenchmark Lang. Model CF CL PC RR RT STS** SM en
> jina-de-base 0.688 0.403 0.835 0.549 0.441 0.820 0.318*
> jina-es-base 0.690 0.405 0.846 0.553 0.464 0.835 0.299*
> multilingual-e5-base 0.730 0.400 0.836 0.548 0.489 0.803 0.301* de jina-de-base 0.665 0.299 0.583* 0.639 0.387 0.714 –
> multilingual-e5-base 0.687 0.328 0.541* 0.648 0.342 0.674 –es jina-es-base 0.671 0.440 0.583* 0.739 0.511 0.788 –
> multilingual-e5-base 0.685 0.413 0.541* 0.736 0.478 0.783 –CF: Classification Accuracy CL: Clustering Vmeasure PC: Pair Classification Average Precision RR: Reranking MAP RT: Retrieval nDCG@10 STS: Sentence Similarity Spearman Correlation SM: Summarization Spearman Correlation * Values are the average over a single task. ** Includes an MTEB datasets (STSBenchmark) that evaluates partly on train data.

Table 4: Evaluation of the Jina models on MTEB tasks. We consider the subsets of English (en), German (de), and Spanish (es) tasks separately. 

retrieval tasks, as well as on the STS tasks, and achieves relatively comparable results on the clas-sification, clustering, and reranking tasks. The full results for these tasks can be found in Table 8, to-gether with all other German tasks in the MTEB. Table 10 reports the performance on cross-lingual German-English tasks, showing that our German bilingual model either matches or outperforms that of multilingual-e5. In our efforts to enhance our model with bilin-gual functionalities without sacrificing its effi-ciency in monolingual English tasks, it is impor-tant to observe the performance of our German and Spanish bilingual models across all English tasks, as detailed in Table 11. Consistency in average scores across task domains is maintained among the diverse bilingual models, with the bilingual Span-ish model securing the highest average scores in various tasks. It is only in the domains of classifica-tion and retrieval tasks that the multilingual-e5 base model outperforms others on average. This indi-cates a balanced expansion of bilingual capabilities in our model, ensuring enhanced performance with-out compromising its efficiency in English-specific tasks. 

6.3 Comparing Bilingual to Multilingual Models 

One motivation for training bilingual models in-stead of multilingual embedding models is the as-sumption that bilingual models achieve greater per-formance in both languages. To obtain empirical evidence for this claim, we evaluate two German-English bilingual and two multilingual transformer models on embedding tasks after fine-tuning with a small set of German and English text pairs. In                                                                                  

> Datasets JinaBert BiBERT mBERT XLM-R
> German Tasks
> Ger.DPR RT 0.738 0.772 0.760 0.719 Ger.STSBenchmark STS 0.768 0.788 0.716 0.751 MIRACL RR 0.600 0.615 0.593 0.570 PawsX PC 0.598 0.606 0.604 0.599 STS22 STS 0.527 0.574 0.476 0.498 XMarket RT 0.193 0.251 0.172 0.167 DE Average 0.571 0.601 0.553 0.551
> Cross-lingual Tasks
> STS22 (de-en) STS 0.575 0.554 0.530 0.536 STS17 (en-de) STS 0.784 0.793 0.704 0.731 CL Average 0.679 0.673 0.617 0.633
> EN Tasks
> QuoraRetrieval RT 0.850 0.863 0.832 0.846 STS12 STS 0.703 0.714 0.725 0.714 STS13 STS 0.793 0.834 0.793 0.811 STS14 STS 0.736 0.760 0.737 0.738 STS15 STS 0.831 0.842 0.832 0.839 STS16 STS 0.796 0.805 0.785 0.792 STS17 STS 0.860 0.857 0.842 0.833 STS22 STS 0.675 0.671 0.661 0.663 TRECCOVID RT 0.585 0.527 0.529 0.525 EN Average 0.759 0.764 0.748 0.751

Table 5: Evaluation of multilingual and bilingual models after short embedding training on pairs 

particular, we use our German-English model, the bilingual BiBERT model [Xu et al., 2021] as well as the multilingual mBERT [Devlin et al., 2019] and XLM-RoBERTa [Conneau et al., 2020] mod-els. We use the same stage II training setup as described in Section 5.1, however, we restrict the training to 1000 steps and a single GPU node which involves roughly 2M pairs in the training. We omit multi-task learning from this training. The results presented in Table 5 show that the bilingual models perform clearly better on the German and cross-lingual tasks and also slightly outperform their mul-Lang. Variant BIOSSES SICK-R* STS12* STS13 STS14 STS15 STS16 STS17 STS22 de Pearson 0.780 0.811 0.801 0.851 0.811 0.878 0.836 0.893 0.682                                              

> MSE 0.784 0.793 0.797 0.849 0.812 0.874 0.842 0.892 0.677 No STS data 0.797 0.791 0.792 0.847 0.810 0.876 0.839 0.890 0.676 es Pearson 0.830 0.830 0.816 0.868 0.836 0.887 0.860 0.886 0.656 MSE 0.825 0.801 0.810 0.867 0.834 0.887 0.860 0.884 0.657 No STS data 0.825 0.792 0.801 0.866 0.831 0.882 0.855 0.882 0.662
> * Corresponding training datasets used during the training

Table 6: Spearman correlation on English STS tasks after triplet-tuning 

tilingual counterparts on the English tasks. 

6.4 Performance of Multi-Task Learning 

To investigate the effectiveness of our multi-task learning strategy (see Section 5.2), we analyze the contribution of including STS training data with an additional loss function. We study three fine-tuned model variants of the Spanish and German models obtained from the stage II training. The first variant (Pearson) is obtained as described in Section 5.2 by using the Lcorr loss defined in Equation (4) during the multi-task learning for STS datasets. The sec-ond variant instead uses a standard mean squared er-ror (MSE) loss, which follows the work of Reimers and Gurevych [2019]. Additionally, there is a third variant that does not make use of the STS data. The STS data consists of rows with two text values com-plemented by scores in different ranges between 0 and 5. Since cosine similarity values can not ex-press scores beyond 1.0, we re-scaled those scores to fit on the interval [0 , 1] . Table 6 shows the Spear-man correlation between the ground truth similarity scores of various STS test datasets and the cosine similarity scores produced by the model variants. Both in the German and Spanish settings, we ob-serve that the Pearson variant outperforms the other two models. The effect is especially strong for SICK-R [Marelli et al., 2014] and STS12 [Agirre et al., 2012], where the corresponding STS datasets are included in our training data and less visible for out-of-domain evaluation. While the Pearson sample correlation loss seems most suitable for in-corporating STS training data into stage III, we also find that using a simple MSE regression loss is beneficial over using no STS data at all. 

## 7 Conclusion 

This paper introduces a set of state-of-the-art bilin-gual models that support English and one other tar-get language. Alongside this, we compose bench-marks for German and Spanish embedding mod-els and integrate them into the Massive Text Em-bedding Benchmark (MTEB) to foster research on German and Spanish text embedding models. Our evaluation results show that those models achieve superior or competitive results compared to related multilingual models while having a lower num-ber of parameters. For training these models, we apply a novel multi-task learning objective that specifically improves the models’ performance on semantic text similarity tasks. Moreover, we con-duct ablation studies to verify our hypothesis that bilingual models achieve better results than multi-lingual models when fine-tuned on an embedding task. 

## References 

Alexis Conneau, Kartikay Khandelwal, Naman Goyal, Vishrav Chaudhary, Guillaume Wenzek, Francisco Guzmán, Edouard Grave, Myle Ott, Luke Zettle-moyer, and Veselin Stoyanov. Unsupervised cross-lingual representation learning at scale. In Dan Ju-rafsky, Joyce Chai, Natalie Schluter, and Joel R. Tetreault, editors, Proceedings of the 58th An-nual Meeting of the Association for Computational Linguistics, ACL 2020, Online, July 5-10, 2020 ,pages 8440–8451. Association for Computational Linguistics, 2020. doi:10.18653/V1/2020.ACL-MAIN.747. URL https://doi.org/10.18653/ v1/2020.acl-main.747 .Nils Reimers and Iryna Gurevych. Making monolingual sentence embeddings multilingual using knowledge distillation. In Proceedings of the 2020 Conference on Empirical Methods in Natural Language Process-ing (EMNLP) , pages 4512–4525, 2020. Liang Wang, Nan Yang, Xiaolong Huang, Binx-ing Jiao, Linjun Yang, Daxin Jiang, Rangan Ma-jumder, and Furu Wei. Text embeddings by weakly-supervised contrastive pre-training. arXiv preprint arXiv:2212.03533 , 2022. Niklas Muennighoff, Nouamane Tazi, Loïc Magne, and Nils Reimers. MTEB: massive text embed-ding benchmark. In Andreas Vlachos and Is-abelle Augenstein, editors, Proceedings of the 17th Conference of the European Chapter of the As-sociation for Computational Linguistics, EACL 2023, Dubrovnik, Croatia, May 2-6, 2023 , pages 2006–2029. Association for Computational Lin-guistics, 2023. doi:10.18653/V1/2023.EACL-MAIN.148. URL https://doi.org/10.18653/ v1/2023.eacl-main.148 .Michael Günther, Jackmin Ong, Isabelle Mohr, Alaed-dine Abdessalem, Tanguy Abel, Mohammad Kalim Akram, Susana Guzman, Georgios Mastrapas, Saba Sturua, Bo Wang, et al. Jina embeddings 2: 8192-token general-purpose text embeddings for long doc-uments. arXiv preprint arXiv:2310.19923 , 2023a. Jianlv Chen, Shitao Xiao, Peitian Zhang, Kun Luo, Defu Lian, and Zheng Liu. Bge m3-embedding: Multi-lingual, multi-functionality, multi-granularity text embeddings through self-knowledge distillation, 2024. Jacob Devlin, Ming-Wei Chang, Kenton Lee, and Kristina Toutanova. Bert: Pre-training of deep bidi-rectional transformers for language understanding, 2019. Alexis Conneau and Guillaume Lample. Cross-lingual language model pretraining. In Hanna M. Wallach, Hugo Larochelle, Alina Beygelzimer, Florence d’Alché-Buc, Emily B. Fox, and Roman Garnett, editors, Advances in Neural Information Process-ing Systems 32: Annual Conference on Neural Information Processing Systems 2019, NeurIPS 2019, December 8-14, 2019, Vancouver, BC, Canada , pages 7057–7067, 2019. URL https: //proceedings.neurips.cc/paper/2019/hash/ c04c19c2c2474dbf5f7ac4372c5b9af1-Abstract. html .Naveen Arivazhagan, Ankur Bapna, Orhan Firat, Dmitry Lepikhin, Melvin Johnson, Maxim Krikun, Mia Xu Chen, Yuan Cao, George F. Foster, Colin Cherry, Wolfgang Macherey, Zhifeng Chen, and Yonghui Wu. Massively multilingual neural ma-chine translation in the wild: Findings and chal-lenges. CoRR , abs/1907.05019, 2019. URL http: //arxiv.org/abs/1907.05019 .Terra Blevins, Hila Gonen, and Luke Zettlemoyer. Analyzing the mono- and cross-lingual pretrain-ing dynamics of multilingual language models. In Yoav Goldberg, Zornitsa Kozareva, and Yue Zhang, editors, Proceedings of the 2022 Con-ference on Empirical Methods in Natural Lan-guage Processing, EMNLP 2022, Abu Dhabi, United Arab Emirates, December 7-11, 2022 , pages 3575–3590. Association for Computational Lin-guistics, 2022. doi:10.18653/V1/2022.EMNLP-MAIN.234. URL https://doi.org/10.18653/ v1/2022.emnlp-main.234 .Zirui Wang, Zachary C. Lipton, and Yulia Tsvetkov. On negative interference in multilingual models: Find-ings and A meta-learning treatment. In Bonnie Webber, Trevor Cohn, Yulan He, and Yang Liu, editors, Proceedings of the 2020 Conference on Empirical Methods in Natural Language Process-ing, EMNLP 2020, Online, November 16-20, 2020 ,pages 4438–4450. Association for Computational Linguistics, 2020. doi:10.18653/V1/2020.EMNLP-MAIN.359. URL https://doi.org/10.18653/ v1/2020.emnlp-main.359 .Jonas Pfeiffer, Naman Goyal, Xi Victoria Lin, Xian Li, James Cross, Sebastian Riedel, and Mikel Artetxe. Lifting the curse of multilinguality by pre-training modular transformers. In Marine Carpuat, Marie-Catherine de Marneffe, and Iván Vladimir Meza Ruíz, editors, Proceedings of the 2022 Conference of the North American Chapter of the Association for Computational Linguistics: Hu-man Language Technologies, NAACL 2022, Seat-tle, WA, United States, July 10-15, 2022 , pages 3479–3495. Association for Computational Lin-guistics, 2022. doi:10.18653/V1/2022.NAACL-MAIN.255. URL https://doi.org/10.18653/ v1/2022.naacl-main.255 .Jonas Pfeiffer, Ivan Vulic, Iryna Gurevych, and Se-bastian Ruder. MAD-X: an adapter-based frame-work for multi-task cross-lingual transfer. In Bon-nie Webber, Trevor Cohn, Yulan He, and Yang Liu, editors, Proceedings of the 2020 Conference on Empirical Methods in Natural Language Process-ing, EMNLP 2020, Online, November 16-20, 2020 ,pages 7654–7673. Association for Computational Linguistics, 2020. doi:10.18653/V1/2020.EMNLP-MAIN.617. URL https://doi.org/10.18653/ v1/2020.emnlp-main.617 .Bo Zheng, Li Dong, Shaohan Huang, Saksham Singhal, Wanxiang Che, Ting Liu, Xia Song, and Furu Wei. Allocating large vocabulary capacity for cross-lingual language model pre-training. In Marie-Francine Moens, Xuanjing Huang, Lucia Specia, and Scott Wen-tau Yih, ed-itors, Proceedings of the 2021 Conference on Em-pirical Methods in Natural Language Processing, EMNLP 2021, Virtual Event / Punta Cana, Do-minican Republic, 7-11 November, 2021 , pages 3203–3215. Association for Computational Lin-guistics, 2021. doi:10.18653/V1/2021.EMNLP-MAIN.257. URL https://doi.org/10.18653/ v1/2021.emnlp-main.257 .Hyung Won Chung, Thibault Févry, Henry Tsai, Melvin Johnson, and Sebastian Ruder. Rethinking embed-ding coupling in pre-trained language models. In 

9th International Conference on Learning Repre-sentations, ICLR 2021, Virtual Event, Austria, May 3-7, 2021 . OpenReview.net, 2021. URL https: //openreview.net/forum?id=xpFFI_NtgpW .Haoran Xu, Benjamin Van Durme, and Kenton W. Murray. Bert, mbert, or bibert? A study on con-textualized embeddings for neural machine transla-tion. In Marie-Francine Moens, Xuanjing Huang, Lucia Specia, and Scott Wen-tau Yih, editors, 

Proceedings of the 2021 Conference on Empir-ical Methods in Natural Language Processing, EMNLP 2021, Virtual Event / Punta Cana, Do-minican Republic, 7-11 November, 2021 , pages 6663–6675. Association for Computational Lin-guistics, 2021. doi:10.18653/V1/2021.EMNLP-MAIN.534. URL https://doi.org/10.18653/ v1/2021.emnlp-main.534 .Li-Hsin Chang, Sampo Pyysalo, Jenna Kanerva, and Filip Ginter. Towards fully bilingual deep language modeling. CoRR , abs/2010.11639, 2020. URL 

https://arxiv.org/abs/2010.11639 .Matej Ulcar and Marko Robnik-Sikonja. Finest BERT and crosloengual BERT - less is more in multilingual models. In Petr Sojka, Ivan Kopecek, Karel Pala, and Ales Horák, editors, Text, Speech, and Dialogue - 23rd International Conference, TSD 2020, Brno, Czech Republic, September 8-11, 2020, Proceedings ,volume 12284 of Lecture Notes in Computer Science ,pages 104–111. Springer, 2020. doi:10.1007/978-3-030-58323-1_11. URL https://doi.org/10. 1007/978-3-030-58323-1_11 .Rich Caruana. Multitask learning. Mach. Learn. , 28(1): 41–75, 1997. doi:10.1023/A:1007379606734. URL 

https://doi.org/10.1023/A:1007379606734 .Michael Crawshaw. Multi-task learning with deep neu-ral networks: A survey. CoRR , abs/2009.09796, 2020. URL https://arxiv.org/abs/2009. 09796 .Jonathan Baxter. A model of inductive bias learning. 

Journal of artificial intelligence research , 12:149– 198, 2000. Sandeep Subramanian, Adam Trischler, Yoshua Bengio, and Christopher J Pal. Learning general purpose dis-tributed sentence representations via large scale multi-task learning. arXiv preprint arXiv:1804.00079 ,2018. Minh-Thang Luong, Quoc V Le, Ilya Sutskever, Oriol Vinyals, and Lukasz Kaiser. Multi-task sequence to sequence learning. arXiv preprint arXiv:1511.06114 ,2015. Long Duong, Trevor Cohn, Steven Bird, and Paul Cook. Low resource dependency parsing: Cross-lingual parameter sharing in a neural network parser. In Proceedings of the 53rd Annual Meeting of the Association for Computational Linguistics and the 7th International Joint Conference on Natural Lan-guage Processing of the Asian Federation of Nat-ural Language Processing, ACL 2015, July 26-31, 2015, Beijing, China, Volume 2: Short Papers , pages 845–850. The Association for Computer Linguis-tics, 2015. doi:10.3115/V1/P15-2139. URL https: //doi.org/10.3115/v1/p15-2139 .Michelle Guo, Albert Haque, De-An Huang, Serena Yeung, and Li Fei-Fei. Dynamic task prioritiza-tion for multitask learning. In Vittorio Ferrari, Martial Hebert, Cristian Sminchisescu, and Yair Weiss, editors, Computer Vision - ECCV 2018 - 15th European Conference, Munich, Germany, Septem-ber 8-14, 2018, Proceedings, Part XVI , volume 11220 of Lecture Notes in Computer Science , pages 282–299. Springer, 2018. doi:10.1007/978-3-030-01270-0_17. URL https://doi.org/10.1007/ 978-3-030-01270-0_17 .Zhao Chen, Vijay Badrinarayanan, Chen-Yu Lee, and Andrew Rabinovich. Gradnorm: Gradient normal-ization for adaptive loss balancing in deep multitask networks. In Jennifer G. Dy and Andreas Krause, editors, Proceedings of the 35th International Con-ference on Machine Learning, ICML 2018, Stock-holmsmässan, Stockholm, Sweden, July 10-15, 2018 ,volume 80 of Proceedings of Machine Learning Re-search , pages 793–802. PMLR, 2018. URL http: //proceedings.mlr.press/v80/chen18a.html .Alex Kendall, Yarin Gal, and Roberto Cipolla. Multi-task learning using uncertainty to weigh losses for scene geometry and semantics. In 2018 IEEE Conference on Computer Vision and Pattern Recognition, CVPR 2018, Salt Lake City, UT, USA, June 18-22, 2018 , pages 7482–7491. Computer Vision Foundation / IEEE Computer Society, 2018. doi:10.1109/CVPR.2018.00781. URL 

http://openaccess.thecvf.com/content_ cvpr_2018/html/Kendall_Multi-Task_ Learning_Using_CVPR_2018_paper.html .Ofir Press, Noah A. Smith, and Mike Lewis. Train short, test long: Attention with linear biases enables input length extrapolation, 2022. Jimmy Lei Ba, Jamie Ryan Kiros, and Geoffrey E. Hin-ton. Layer normalization, 2016. Alex Henry, Prudhvi Raj Dachapally, Shubham Shan-taram Pawar, and Yuxuan Chen. Query-key normal-ization for transformers. In Findings of the Associ-ation for Computational Linguistics: EMNLP 2020 ,pages 4246–4253, 2020. Rico Sennrich, Barry Haddow, and Alexandra Birch. Neural machine translation of rare words with sub-word units, 2016. Thuat Nguyen, Chien Van Nguyen, Viet Dac Lai, Hieu Man, Nghia Trung Ngo, Franck Dernoncourt, Ryan A. Rossi, and Thien Huu Nguyen. Culturax: A cleaned, enormous, and multilingual dataset for large language models in 167 languages, 2023. Jörg Tiedemann. OPUS – parallel corpora for everyone. In Proceedings of the 19th Annual Conference of the European Association for Machine Translation: Projects/Products , Riga, Latvia, May 30–June 1 2016. Baltic Journal of Modern Computing. URL https: //aclanthology.org/2016.eamt-2.8 .Colin Raffel, Noam Shazeer, Adam Roberts, Katherine Lee, Sharan Narang, Michael Matena, Yanqi Zhou, Wei Li, and Peter J. Liu. Exploring the limits of trans-fer learning with a unified text-to-text transformer. 

arXiv e-prints , 2019. Tim Jansen, Yangling Tong, Victoria Zevallos, and Pe-dro Ortiz Suarez. Perplexed by Quality: A Perplexity-based Method for Adult and Harmful Content De-tection in Multilingual Heterogeneous Web Data. 

arXiv e-prints , art. arXiv:2212.10440, December 2022. doi:10.48550/arXiv.2212.10440. Yinhan Liu, Myle Ott, Naman Goyal, Jingfei Du, Man-dar Joshi, Danqi Chen, Omer Levy, Mike Lewis, Luke Zettlemoyer, and Veselin Stoyanov. Roberta: A robustly optimized bert pretraining approach, 2019. Zachary Ankner, Naomi Saphra, Davis Blalock, Jonathan Frankle, and Matthew L. Leavitt. Dynamic masking rate schedules for mlm pretraining, 2024. Nils Reimers and Iryna Gurevych. Sentence-bert: Sen-tence embeddings using siamese bert-networks. In 

Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing and the 9th International Joint Conference on Natural Lan-guage Processing (EMNLP-IJCNLP) , pages 3982– 3992, 2019. Zehan Li, Xin Zhang, Yanzhao Zhang, Dingkun Long, Pengjun Xie, and Meishan Zhang. Towards general text embeddings with multi-stage contrastive learn-ing, 2023. Maxime De Bruyn, Ehsan Lotfi, Jeska Buhmann, and Walter Daelemans. Mfaq: a multilingual faq dataset. In Proceedings of the 3rd Workshop on Machine Reading for Question Answering , pages 1–13, 2021. Tahmid Hasan, Abhik Bhattacharjee, Md. Saiful Is-lam, Kazi Mubasshir, Yuan-Fang Li, Yong-Bin Kang, M. Sohel Rahman, and Rifat Shahriyar. XL-sum: Large-scale multilingual abstractive summarization for 44 languages. In Chengqing Zong, Fei Xia, Wenjie Li, and Roberto Navigli, editors, Findings of the Association for Computational Linguistics: ACL-IJCNLP 2021 , pages 4693–4703, Online, Au-gust 2021. Association for Computational Linguistics. doi:10.18653/v1/2021.findings-acl.413. URL https: //aclanthology.org/2021.findings-acl.413 .Alexis Conneau, Ruty Rinott, Guillaume Lample, Adina Williams, Samuel Bowman, Holger Schwenk, and Veselin Stoyanov. Xnli: Evaluating cross-lingual sen-tence representations. In Proceedings of the 2018 Conference on Empirical Methods in Natural Lan-guage Processing , pages 2475–2485, 2018. Thomas Scialom, Paul-Alexis Dray, Sylvain Lamprier, Benjamin Piwowarski, and Jacopo Staiano. Mlsum: The multilingual summarization corpus. In Proceed-ings of the 2020 Conference on Empirical Methods in Natural Language Processing (EMNLP) , pages 8051–8067, 2020. Jörg Tiedemann. Parallel data, tools and interfaces in opus. In Proceedings of the Eighth International Conference on Language Resources and Evaluation (LREC’12) , pages 2214–2218, 2012. Jack W Rae, Sebastian Borgeaud, Trevor Cai, Katie Millican, Jordan Hoffmann, Francis Song, John Aslanides, Sarah Henderson, Roman Ring, Susan-nah Young, et al. Scaling language models: Meth-ods, analysis & insights from training gopher. arXiv preprint arXiv:2112.11446 , 2021. Katherine Lee, Daphne Ippolito, Andrew Nystrom, Chiyuan Zhang, Douglas Eck, Chris Callison-Burch, and Nicholas Carlini. Deduplicating training data makes language models better. In Proceedings of the 60th Annual Meeting of the Association for Compu-tational Linguistics (Volume 1: Long Papers) , pages 8424–8445, 2022. Chris Alberti, Daniel Andor, Emily Pitler, Jacob Devlin, and Michael Collins. Synthetic qa corpora genera-tion with roundtrip consistency. In Proceedings of the 57th Annual Meeting of the Association for Com-putational Linguistics , pages 6168–6173, 2019. Zhuyun Dai, Vincent Y Zhao, Ji Ma, Yi Luan, Jianmo Ni, Jing Lu, Anton Bakalov, Kelvin Guu, Keith B Hall, and Ming-Wei Chang. Promptagator: Few-shot dense retrieval from 8 examples. arXiv preprint arXiv:2209.11755 , 2022. Michael Günther, Louis Milliken, Jonathan Geuter, Georgios Mastrapas, Bo Wang, and Han Xiao. Jina embeddings: A novel set of high-performance sentence embedding models. arXiv preprint arXiv:2307.11224 , 2023b. Aäron van den Oord, Yazhe Li, and Oriol Vinyals. Representation learning with contrastive predictive coding. CoRR , abs/1807.03748, 2018. URL http: //arxiv.org/abs/1807.03748 .Daniel Cer, Mona Diab, Eneko Agirre, Iñigo Lopez-Gazpio, and Lucia Specia. Semeval-2017 task 1: Semantic textual similarity multilingual and crosslin-gual focused evaluation. In Proceedings of the 11th International Workshop on Semantic Evaluation (SemEval-2017) , pages 1–14, 2017. Payal Bajaj, Daniel Campos, Nick Craswell, Li Deng, Jianfeng Gao, Xiaodong Liu, Rangan Majumder, Andrew McNamara, Bhaskar Mitra, Tri Nguyen, et al. Ms marco: A human generated machine reading comprehension dataset. arXiv preprint arXiv:1611.09268 , 2016. Tom Kwiatkowski, Jennimaria Palomaki, Olivia Red-field, Michael Collins, Ankur Parikh, Chris Alberti, Danielle Epstein, Illia Polosukhin, Matthew Kelcey, Jacob Devlin, Kenton Lee, Kristina N. Toutanova, Llion Jones, Ming-Wei Chang, Andrew Dai, Jakob Uszkoreit, Quoc Le, and Slav Petrov. Natural ques-tions: a benchmark for question answering research. 

Transactions of the Association of Computational Linguistics , 2019. Nathan Ng, Kyra Yee, Alexei Baevski, Myle Ott, Michael Auli, and Sergey Edunov. Facebook fair’s WMT19 news translation task submission. In Ondrej Bojar, Rajen Chatterjee, Christian Federmann, Mark Fishel, Yvette Graham, Barry Haddow, Matthias Huck, Antonio Jimeno-Yepes, Philipp Koehn, An-dré Martins, Christof Monz, Matteo Negri, Aurélie Névéol, Mariana L. Neves, Matt Post, Marco Turchi, and Karin Verspoor, editors, Proceedings of the Fourth Conference on Machine Translation, WMT 2019, Florence, Italy, August 1-2, 2019 - Volume 2: Shared Task Papers, Day 1 , pages 314–319. Association for Computational Linguistics, 2019. doi:10.18653/V1/W19-5333. URL https://doi. org/10.18653/v1/w19-5333 .Sneha Kudugunta, Isaac Caswell, Biao Zhang, Xavier Garcia, Christopher A. Choquette-Choo, Kather-ine Lee, Derrick Xin, Aditya Kusupati, Romi Stella, Ankur Bapna, and Orhan Firat. MADLAD-400: A multilingual and document-level large audited dataset. CoRR , abs/2309.04662, 2023. doi:10.48550/ARXIV.2309.04662. URL https:// doi.org/10.48550/arXiv.2309.04662 .Marco Wrzalik and Dirk Krechel. GerDaLIR: A German dataset for legal information retrieval. In Nikolaos Aletras, Ion Androutsopoulos, Leslie Bar-rett, Catalina Goanta, and Daniel Preotiuc-Pietro, editors, Proceedings of the Natural Legal Lan-guage Processing Workshop 2021 , pages 123– 128, Punta Cana, Dominican Republic, Novem-ber 2021. Association for Computational Linguis-tics. doi:10.18653/v1/2021.nllp-1.13. URL https: //aclanthology.org/2021.nllp-1.13 .Timo Möller, Julian Risch, and Malte Pietsch. Ger-manquad and germandpr: Improving non-english question answering and passage retrieval, 2021. Asier Gutiérrez-Fandiño, Jordi Armengol-Estapé, Marc Pàmies, Joan Llop-Palao, Joaquin Silveira-Ocampo, Casimiro Pio Carrino, Carme Armentano-Oller, Car-los Rodriguez-Penagos, Aitor Gonzalez-Agirre, and Marta Villegas. Maria: Spanish language models. 

Procesamiento del Lenguaje Natural , page 39–60, 2022. ISSN 1989-7553. doi:10.26342/2022-68-3. URL https://doi.org/10.26342/2022-68-3 .Xinyu Zhang, Nandan Thakur, Odunayo Ogundepo, Ehsan Kamalloo, David Alfonso-Hermelo, Xi-aoguang Li, Qun Liu, Mehdi Rezagholizadeh, and Jimmy Lin. Making a miracl: Multilingual informa-tion retrieval across a continuum of languages, 2022. Karl Pearson. Note on regression and inheritance in the case of two parents. Proceedings of the Royal Soci-ety of London , 58:240–242, 1895. ISSN 03701662. URL http://www.jstor.org/stable/115794 .Alex Wang, Amanpreet Singh, Julian Michael, Felix Hill, Omer Levy, and Samuel R. Bowman. GLUE: A multi-task benchmark and analysis platform for natural language understanding. In 7th International Conference on Learning Representations, ICLR 2019, New Orleans, LA, USA, May 6-9, 2019 . OpenRe-view.net, 2019. URL https://openreview.net/ forum?id=rJ4km2R5t7 .Junjie Hu, Sebastian Ruder, Aditya Siddhant, Graham Neubig, Orhan Firat, and Melvin Johnson. Xtreme: a massively multilingual multi-task benchmark for evaluating cross-lingual generalization. In Proceed-ings of the 37th International Conference on Machine Learning , pages 4411–4421, 2020. Jason Phang, Thibault Févry, and Samuel R. Bow-man. Sentence encoders on stilts: Supplementary training on intermediate labeled-data tasks. CoRR ,abs/1811.01088, 2018. URL http://arxiv.org/ abs/1811.01088 .Pierre Zweigenbaum, Serge Sharoff, and Reinhard Rapp. Overview of the second bucc shared task: Spotting parallel sentences in comparable corpora. In Pro-ceedings of the 10th Workshop on Building and Using Comparable Corpora , pages 60–67, 2017. Mikel Artetxe and Holger Schwenk. Massively multilin-gual sentence embeddings for zero-shot cross-lingual transfer and beyond. Transactions of the Association for Computational Linguistics , 7:597–610, 2019. Hamed Bonab, Mohammad Aliannejadi, Ali Vardasbi, Evangelos Kanoulas, and James Allan. Cross-market product recommendation. In Proceedings of the 30th ACM International Conference on Information & Knowledge Management . ACM, 2021. Eleni Kamateri, Theodora Tsikrika, Spyridon Symeoni-dis, Stefanos Vrochidis, Wolfgang Minker, and Ioan-nis Kompatsiaris. A test collection for passage re-trieval evaluation of spanish health-related resources. In European Conference on Information Retrieval ,2019. Priyanka Sen, Alham Fikri Aji, and Amir Saffari. Mintaka: A complex, natural, and multilingual dataset for end-to-end question answering. In Nico-letta Calzolari, Chu-Ren Huang, Hansaem Kim, James Pustejovsky, Leo Wanner, Key-Sun Choi, Pum-Mo Ryu, Hsin-Hsi Chen, Lucia Donatelli, Heng Ji, Sadao Kurohashi, Patrizia Paggio, Nian-wen Xue, Seokhwan Kim, Younggyun Hahm, Zhong He, Tony Kyungil Lee, Enrico Santus, Francis Bond, and Seung-Hoon Na, editors, Proceedings of the 29th International Conference on Computational Linguis-tics , pages 1604–1619, Gyeongju, Republic of Korea, October 2022. International Committee on Compu-tational Linguistics. URL https://aclanthology. org/2022.coling-1.138 .Xiaoyu Shen, Akari Asai, Bill Byrne, and Adrià de Gis-pert. xpqa: Cross-lingual product question answering across 12 languages, 2023. Naman Goyal, Cynthia Gao, Vishrav Chaudhary, Peng-Jen Chen, Guillaume Wenzek, Da Ju, Sanjana Krish-nan, Marc’Aurelio Ranzato, Francisco Guzmán, and Angela Fan. The flores-101 evaluation benchmark for low-resource and multilingual machine transla-tion. Trans. Assoc. Comput. Linguistics , 10:522– 538, 2022. doi:10.1162/TACL_A_00474. URL 

https://doi.org/10.1162/tacl_a_00474 .Eneko Agirre, Carmen Banea, Claire Cardie, Daniel M Cer, Mona T Diab, Aitor Gonzalez-Agirre, Weiwei Guo, Rada Mihalcea, German Rigau, and Janyce Wiebe. Semeval-2014 task 10: Multilingual semantic textual similarity. In SemEval@ COLING , pages 81– 91, 2014. Eneko Agirre, Carmen Banea, Claire Cardie, Daniel Cer, Mona Diab, Aitor Gonzalez-Agirre, Weiwei Guo, Inigo Lopez-Gazpio, Montse Maritxalar, Rada Mi-halcea, et al. Semeval-2015 task 2: Semantic textual similarity, english, spanish and pilot on interpretabil-ity. In Proceedings of the 9th international workshop on semantic evaluation (SemEval 2015) , pages 252– 263, 2015. Yinfei Yang, Yuan Zhang, Chris Tar, and Jason Baldridge. PAWS-X: A Cross-lingual Adversarial Dataset for Paraphrase Identification. In Proc. of EMNLP , 2019. Marco Marelli, Stefano Menini, Marco Baroni, Luisa Bentivogli, Raffaella Bernardi, and Roberto Zampar-elli. A SICK cure for the evaluation of composi-tional distributional semantic models. In Nicoletta Calzolari, Khalid Choukri, Thierry Declerck, Hrafn Loftsson, Bente Maegaard, Joseph Mariani, Asun-cion Moreno, Jan Odijk, and Stelios Piperidis, editors, 

Proceedings of the Ninth International Conference on Language Resources and Evaluation (LREC’14) ,pages 216–223, Reykjavik, Iceland, May 2014. Eu-ropean Language Resources Association (ELRA). URL http://www.lrec-conf.org/proceedings/ lrec2014/pdf/363_Paper.pdf .Eneko Agirre, Daniel Cer, Mona Diab, and Aitor Gonzalez-Agirre. Semeval-2012 task 6: A pilot on semantic textual similarity. In * SEM 2012: The First Joint Conference on Lexical and Computational Semantics–Volume 1: Proceedings of the main con-ference and the shared task, and Volume 2: Proceed-ings of the Sixth International Workshop on Semantic Evaluation (SemEval 2012) , pages 385–393, 2012. A Appendix 

jina-es-base multilingual-e5-base 

Retrieval Average [nDCG@10] 0.511 0.478 MIRACLRetrieval (es) 0.809 0.820 

MintakaESRetrieval (es) 0.283 0.299 

SpanishPassageRetrievalS2P (es) 0.421 0.394 SpanishPassageRetrievalS2S (es) 0.704 0.654 XMarketES (es) 0.197 0.119 XPQAESRetrieval (es) 0.654 0.583 

Clustering Average [v-measure] 0.440 0.413 FloresClusteringS2S (es) 0.398 0.367 SpanishNewsClusteringP2P (es) 0.483 0.458 

Reranking Average [mAP] 0.739 0.736 MIRACL (es) 0.739 0.736 

Classification Average [acc.] 0.671 0.685 

AmazonReviewsClassification (es) 0.387 0.405 

MTOPDomainClassification (es) 0.899 0.906 

MTOPIntentClassification (es) 0.688 0.713 

MassiveIntentClassification (es) 0.669 0.684 

MassiveScenarioClassification (es) 0.712 0.715 Pair-Classification Average [AveP] 0.590 0.551 PawsX (es) 0.590 0.551 

STS Average [Spearman] 0.788 0.783 STS17 (es) 0.882 0.867 STS22 (es) 0.680 0.666 STSES (es) 0.802 0.816 

Table 7: Performance of jina-es-base and multilingual-e5-base on Spanish MTEB tasks. jina-de-base multilingual-e5-base 

Retrieval Average [nDCG@10] 0.387 0.342 GerDaLIR (de) 0.172 0.069 GermanDPR (de) 0.795 0.795 

XMarket (de) 0.195 0.163 

Clustering Average [v-measure] 0.299 0.328 

BlurbsClusteringP2P (de) 0.349 0.394 

BlurbsClusteringS2S (de) 0.167 0.157 TenKGnadClusteringP2P (de) 0.431 0.439 

TenKGnadClusteringS2S (de) 0.250 0.320 Reranking Average [mAP] 0.639 0.648 

MIRACL (de) 0.639 0.648 Classification Average [acc.] 0.665 0.687 

AmazonCounterfactualClassification (de) 0.692 0.717 

AmazonReviewsClassification (de) 0.385 0.418 

MTOPDomainClassification (de) 0.892 0.896 

MTOPIntentClassification (de) 0.653 0.712 

MassiveIntentClassification (de) 0.650 0.661 

MassiveScenarioClassification (de) 0.718 0.720 Pair-Classification Average [AveP] 0.583 0.541 PawsX (de) 0.583 0.541 

STS Average [Spearman] 0.714 0.674 GermanSTSBenchmark* (de) 0.845 0.789 STS22 (de) 0.583 0.560 * Contains some STS train data 

Table 8: Performance of jina-de-base and multilingual-e5-base on German MTEB tasks. 

jina-es-base multilingual-e5-base 

STS Average [Spearman] 0.826 0.752 STS17 (es-en) 0.865 0.765 STS22 (es-en) 0.788 0.740 

Table 9: Performance of jina-es-base and multilingual-e5-base on Spanish-English cross-lingual tasks 

jina-de-base multilingual-e5-base 

STS Average [Pearson] 0.718 0.685 STS17 (en-de) 0.865 0.821 STS22 (de-en) 0.570 0.549 

Bitext Mining Average [F1] 0.990 0.991 

BUCC (de-en) 0.990 0.991 

Table 10: Performance of jina-de-base and multilingual-e5-base on German-English cross-lingual tasks jina-de-base jina-es-base multilingual-e5-base 

Retrieval Average [mDCG@10] 0.441 0.464 0.489 

ArguAna (en) 0.495 0.501 0.442 CQADupstackRetrieval (en) 0.368 0.388 0.385 ClimateFEVER (en) 0.222 0.271 0.239 DBPedia (en) 0.320 0.326 0.404 

FEVER (en) 0.712 0.784 0.794 

FiQA2018 (en) 0.339 0.370 0.382 

HotpotQA (en) 0.548 0.595 0.686 

MSMARCO (en) 0.345 0.355 0.423 

NFCorpus (en) 0.280 0.303 0.325 

NQ (en) 0.481 0.507 0.600 

QuoraRetrieval (en) 0.877 0.881 0.876 SCIDOCS (en) 0.167 0.174 0.172 SciFact (en) 0.609 0.627 0.693 

TRECCOVID (en) 0.648 0.674 0.698 

Touche2020 (en) 0.205 0.198 0.214 Clustering Average [v-measure] 0.403 0.405 0.400 ArxivClusteringP2P (en) 0.419 0.415 0.403 ArxivClusteringS2S (en) 0.325 0.322 0.354 

BigPatentClustering (en) 0.230 0.204 0.240 

BiorxivClusteringP2P (en) 0.344 0.352 0.350 BiorxivClusteringS2S (en) 0.290 0.289 0.295 

MedrxivClusteringP2P (en) 0.316 0.322 0.289 MedrxivClusteringS2S (en) 0.294 0.288 0.284 RedditClustering (en) 0.479 0.483 0.424 RedditClusteringP2P (en) 0.549 0.560 0.552 StackExchangeClustering (en) 0.555 0.554 0.553 StackExchangeClusteringP2P (en) 0.328 0.336 0.305 TwentyNewsgroupsClustering (en) 0.405 0.402 0.360 WikiCitiesClustering (en) 0.703 0.733 0.796 

reranking average 0.549 0.553 0.548 AskUbuntuDupQuestions (en) 0.612 0.612 0.582 MindSmallReranking (en) 0.303 0.306 0.310 

SciDocsRR (en) 0.786 0.793 0.807 

StackOverflowDupQuestions (en) 0.496 0.502 0.494 

Classification Average [acc.] 0.688 0.690 0.730 

AmazonCounterfactualClassification (en) 0.740 0.743 0.790 

AmazonPolarityClassification (en) 0.802 0.783 0.906 

AmazonReviewsClassification (en) 0.395 0.383 0.445 

Banking77Classification (en) 0.839 0.853 0.827 EmotionClassification (en) 0.452 0.466 0.452 ImdbClassification (en) 0.699 0.675 0.855 

MTOPDomainClassification (en) 0.903 0.904 0.931 

MTOPIntentClassification (en) 0.686 0.720 0.753 

MassiveIntentClassification (en) 0.696 0.708 0.721 

MassiveScenarioClassification (en) 0.741 0.738 0.771 

ToxicConversationsClassification (en) 0.695 0.700 0.698 TweetSentimentExtractionClassification (en) 0.613 0.611 0.613 Pair-Classification [AveP] 0.835 0.846 0.836 SprintDuplicateQuestions (en) 0.940 0.956 0.930 TwitterSemEval2015 (en) 0.705 0.716 0.722 

TwitterURLCorpus (en) 0.860 0.864 0.855 

STS Average [Spearman] 0.820 0.835 0.803 BIOSSES (en) 0.780 0.830 0.851 

SICK-R (en) 0.811 0.830 0.785 STS12 (en) 0.801 0.816 0.767 STS13 (en) 0.851 0.868 0.780 STS14 (en) 0.811 0.836 0.766 STS15 (en) 0.878 0.887 0.882 STS16 (en) 0.836 0.860 0.843 STS17 (en) 0.893 0.886 0.878 STS22 (en) 0.682 0.656 0.618 STSBenchmark* (en) 0.862 0.878 0.856 

Summarization Average [Spearman] 0.318 0.299 0.301 SummEval (en) 0.318 0.299 0.301 * Contains some STS train data 

Table 11: Performance of Jina models and multilingual-e5-base on English MTEB tasks.
