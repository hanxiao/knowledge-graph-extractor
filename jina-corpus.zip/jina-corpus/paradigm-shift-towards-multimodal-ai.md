---
title: "The Paradigm Shift Towards Multimodal AI"
slug: paradigm-shift-towards-multimodal-ai
url: https://cms.jina.ai/paradigm-shift-towards-multimodal-ai/
published_at: 2022-10-09T14:43:15.000+02:00
updated_at: 2025-08-13T00:51:07.000+02:00
reading_time: 8
authors: "Han Xiao"
tags: "Insights"
excerpt: "We are on the cusp of a new era in AI, one in which multimodal AI will be the norm. At Jina AI, our MLOps platform helps businesses and developers win while they're right at the starting line of this paradigm shift, and build the applications of the future today."
---

# The Paradigm Shift Towards Multimodal AI

Every time I introduce Jina AI and explain what we do, I switch up my narrative depending on who I'm talking to:

<div class="kg-card kg-callout-card kg-callout-card-white">

<div class="kg-callout-emoji">

1️⃣

</div>

<div class="kg-callout-text">

Jina AI is the MLOps platform for ****cross-modal and multimodal**** data.

</div>

</div>

<div class="kg-card kg-callout-card kg-callout-card-white">

<div class="kg-callout-emoji">

2️⃣

</div>

<div class="kg-callout-text">

Jina AI is the MLOps platform for ****neural search and generative AI**** applications.

</div>

</div>

The first narrative is data-driven and academic-oriented, aimed at AI researchers. The second is more application-driven and intuitive for practitioners and industry partners. Whatever the narrative, four terms are new to most people:

- Cross-modal
- Multimodal
- Neural search
- Generative AI (sometimes as Creative AI)

Some people have heard of unstructured data, but what's *multimodal* data? Some have heard of semantic search, but what on Earth is *neural* search?

Most confusingly of all, why lump these four terms together, and why is Jina AI working on one MLOps platform to cover them all?

This article answers those questions. But I'm impatient. Let's fast-forward to the conclusion: **The AI industry has shifted away from single-modal AI and has entered the era of multimodal AI**, as illustrated below:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-drawing.svg" class="kg-image" loading="lazy" width="300" height="129" alt="Colorful, geometric kite or paper airplane diagram with a gold arrow, isolated on a black background." />
<figcaption><span style="white-space: pre-wrap;">Jina AI spectrum on future AI applications</span></figcaption>
</figure>

At Jina AI, our spectrum encompasses cross-modal, multimodal, neural search, and generative AI, covering a significant portion of future AI applications. Our MLOps platform gives businesses and developers the edge while they're right at the starting line of this paradigm shift, and build the applications of the future today.

In the next sections, we'll review the development of single-modal AI and see how this paradigm shift is happening right beneath our noses.

## Single-Modal AI

In computer science, "modality" roughly means "data type". When we talk about single-modal AI, we're talking about applying AI to one specific type of data. Most early machine learning works fall into this category. Even today, when you open any machine learning literature, single-modal AI is still the majority of the content.

### Natural Language Processing

We'll start our look back with natural language processing (NLP). Back in 2010, I published a paper about an improved Gibbs sampling algorithm for the Latent Dirichlet Allocation (LDA) model:

<figure class="kg-card kg-image-card kg-card-hascaption">
<a href="http://proceedings.mlr.press/v13/xiao10a/xiao10a.pdf"><img src="https://cms.jina.ai/content/images/2022/10/image.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image.png 1000w, https://cms.jina.ai/content/images/2022/10/image.png 1214w" sizes="(min-width: 720px) 720px" width="1214" height="946" alt="Screenshot of research paper &quot;Efficient Collapsed Gibbs Sampling For Latent Dirichlet Allocation,&quot; from ACMl2010." /></a>
<figcaption><span style="white-space: pre-wrap;">Efficient Collapsed Gibbs Sampling For Latent Dirichlet Allocation, 2010</span></figcaption>
</figure>

Some old machine learning researchers may still remember LDA: a parametric Bayesian model for modeling text corpora. It "clusters" words into topics and represents each document as a combination of topics. For this reason, some people called it a "topic model".

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2022/10/image-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-1.png 600w, https://cms.jina.ai/content/images/2022/10/image-1.png 887w" sizes="(min-width: 720px) 720px" width="887" height="616" alt="Overview of funding initiatives for the arts, children, and education, detailing the Hearst Foundation&#39;s grants, including $1" />
</figure>

From 2008 to 2012, the topic model was one of the most effective and popular models in the NLP community – it was the BERT/Transformer of its day. Every year at top-tier ML/NLP conferences, many papers would extend or improve the original model. But looking back on it today, it was a pretty "shallow learning" model with a very ad-hoc language modeling approach. It assumed words were generated from a mixture of multinomial distributions. This makes sense for certain specific tasks but isn't general enough for other tasks, domains, or modalities.

Back in 2010-2020, ad-hoc approaches like this were the norm in NLP. Researchers and engineers developed specialist algorithms, each of which was good at solving one task, and one task only:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-drawing--1-.svg" class="kg-image" loading="lazy" width="300" height="103" alt="Table of natural language processing topics labeled &#39;Textual Modality&#39; on yellow grid boxes, including sentiment analysis and" />
<figcaption><span style="white-space: pre-wrap;">Top 20 most common NLP tasks</span></figcaption>
</figure>

### Computer Vision

Compared to NLP, I came to the field of computer vision (CV) pretty late. While at Zalando in 2017, I published a paper on the [Fashion-MNIST dataset](https://github.com/zalandoresearch/fashion-mnist). This dataset is a drop-in replacement of [Yann LeCun's original MNIST dataset](http://yann.lecun.com/exdb/mnist/) from 1990 (a set of simple handwritten digits for benchmarking computer vision algorithms.) The original MNIST dataset was too trivial for many algorithms – shallow learning algorithms such as logistic regression, decision trees, and support vector machines could easily hit 90% accuracy, leaving little room for deep learning algorithms to shine.

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://lh5.googleusercontent.com/_r7f8YZjr7Dmn5UkPTApEQ5ErBUfjdctkvrU8NnoKUZMSNShK5slLbhiuGXTkaOg6j881kOxpLHO2GPFQDkkoWoM5mdRzD4JaG6HYszUs8zuHW8kA0VKN4dwcRyHGlPklAGYmv9oOSuuRsjeUpnnYv9aSRPwa07Y2TVwWp5XhTUBnPsYSSIjj9bcgq2k" loading="lazy" width="401" height="401" />
</div>
<div class="kg-gallery-image">
<img src="https://lh5.googleusercontent.com/DtjaYApP26Red20WgncOFbfCzjmJVP_nBVhtIFP7AJhzvZNrbvri2VUyYZj01bkhi1LArlROqovoYhfHOc9dMI64I5R89TMaSSNF9lFdwnb3fiaKXExnsv6wUtE94jqJrvyDWhC_xUWEZFwlTqJ2qbcVa-yJZes6jEeKPBYYimaMsW6_ueRAvcQCMrkU" loading="lazy" width="454" height="324" />
</div>
</div>
</div>
<figcaption><p><a href="https://scholar.google.com/citations?view_op=view_citation&amp;hl=en&amp;user=jp7swwIAAAAJ&amp;sortby=pubdate&amp;citation_for_view=jp7swwIAAAAJ:IWHjjKOFINEC"><span style="white-space: pre-wrap;">Fashion-mnist: a novel image dataset for benchmarking machine learning algorithms</span></a><span style="white-space: pre-wrap;">, 2017</span></p></figcaption>
</figure>

Fashion-MNIST provided a more challenging dataset, allowing researchers to explore, test, and benchmark their algorithms. Today, over 5,000 academic papers have cited Fashion-MNIST in their research on classification, regression, denoising, generation, etc.

Just as the topic model was only good for NLP, Fashion-MNIST was only good for computer vision. There was almost no information in the dataset that you could leverage for studying other modalities. If you look at common tasks in the CV community between 2010-2020, practically all were single-modality. Like NLP, they all covered one task, and one task only:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-drawing--2-.svg" class="kg-image" loading="lazy" width="300" height="118" alt="Color-coded diagram of computer vision concepts, including object classification, 3D reconstruction, and more." />
<figcaption><span style="white-space: pre-wrap;">Top 20 most common CV tasks</span></figcaption>
</figure>

### Speech & Audio

Speech and audio machine learning followed the same pattern: Algorithms were designed for ad-hoc tasks around the audio modality. They each performed (all together now!) one task, and one task only:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-drawing--3-.svg" class="kg-image" loading="lazy" width="300" height="118" alt="Table categorizing acoustic modalities with tasks like speech recognition and music genre classification." />
<figcaption><span style="white-space: pre-wrap;">Top 20 most common acoustic tasks</span></figcaption>
</figure>

One of my earliest attempts at multimodal AI was a paper I published in 2010, where I built a Bayesian model that jointly modeled visual, textual, and acoustic modalities. Once trained, it accomplished two *cross-modal* retrieval tasks: finding the best-matching images from a sound snippet and vice-versa. I gave these two tasks a very sci-fi name: "artificial synesthesia".

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://lh3.googleusercontent.com/YXodVhMFpju-zkNTw-5kWskHnO5kHpNLFHItAvLGp7wyyqdOlO-0E2Qcpz01nAL7qPdJLP-1hav3voNWyc86TctMHZk5KgD44t-dCAS8dGoL5Kdo3DjfM6tR2iUHN8PhCQrBYFMSgMubjd2DWeypgKOQ23w7mqJDSLMtX_0fORNDOUZQnmT_SoKnZnf3" loading="lazy" width="387" height="303" />
</div>
<div class="kg-gallery-image">
<img src="https://lh3.googleusercontent.com/D9eKjn8RwIMF44Ctg1iruWX6rREbhv62Jfc1NT8f3-M7ZNNbYIOECuslvdPiBuVDXooJVeuSZUFV1GB-R2JPqPrrQzoGTZTeKj_KCxl_f7iAeH27Xk-FvUjuIHzZTNEv0gBkkpJagOiFAg7L2ZTkBLvjFOtN5mbqF-1c2aJOhyuNqGVjQdsh3gbLP2XY" loading="lazy" width="386" height="138" />
</div>
</div>
</div>
<figcaption><p><a href="http://lear.inrialpes.fr/~verbeek/nips10workshop/2010-Whistler-NIPS-Xiao-Paper.pdf"><span style="white-space: pre-wrap;">Toward Artificial Synesthesia: Linking Images and Sounds via Words</span></a><span style="white-space: pre-wrap;">, 2010</span></p></figcaption>
</figure>

<figure class="kg-card kg-image-card">
<img src="https://lh6.googleusercontent.com/vQwxXg_ewRUZ45YDCKf5dR8_1PlT8QishzlgRc9YiXmbeTHNnLXsWGXj9d9JTXC-WE7nSWkKjiHoN0RmG8FLJtMe2CX4Gzbn792SZFcshvDDTOHCNIwPaHfQBAfrANd6MqiBwRQ3gFHwfzQsekR8so6wqlYEqcNX5SDRcNEPwa8QNNQq4iMp2YbmBJkK" class="kg-image" loading="lazy" width="554" height="401" alt="Flowchart of a probabilistic framework for image composition and sound illustration with training and testing modules." />
</figure>

## Towards Multimodal AI

From the examples above, we can see that all single-modal AI algorithms have two things in common:

- Tasks are specific to just one modality (e.g. textual, visual, acoustic, etc).
- Knowledge is learned from and applied to only one modality (i.e. a visual algorithm can only learn from and be applied to images).

So far I have talked about text, image, audio. There are other modalities such as 3D, video, time series which should be considered as well. If we visualize all tasks from different modalities: We get a cube, where modalities are arranged orthogonally:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-drawing--4-.svg" class="kg-image" loading="lazy" width="300" height="139" alt="Three-dimensional cube labeled with &quot;Textual,&quot; &quot;Visual,&quot; and &quot;Acoustic&quot; on a black background, representing a research model." />
<figcaption><span style="white-space: pre-wrap;">Single-modal AI, you can assume the other facets represent the tasks from other modalities </span></figcaption>
</figure>

On the other hand, multimodal AI is like molding this cube into a sphere, erasing boundaries between different modalities, where:

- Tasks are shared and transferred between multiple modalities (so one algorithm can work with images *and* text *and* audio).
- Knowledge is learned from and applied to multiple modalities (so an algorithm can learn from *textual* data and apply that to *visual* data).

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Textual.svg" class="kg-image" loading="lazy" width="1920" height="1080" alt="Gradient circle divided into three sections labeled &quot;Textual,&quot; &quot;Acoustic,&quot; and &quot;Visual&quot; representing different senses." />
<figcaption><span style="white-space: pre-wrap;">Multimodal AI</span></figcaption>
</figure>

**The rise of multimodal AI can be attributed to advances in two machine learning techniques: Representation learning and transfer learning.**

- *Representation learning* lets models create common representations for all modalities.
- *Transfer learning* lets models first learn fundamental knowledge, and then fine-tune on specific domains.

Without these techniques, multimodal AI on generic data types would be unfeasible or merely a toy, just like my sound-image paper from back in 2010.

In 2021 we saw CLIP, a model that captures the alignment between image and text; in 2022, we saw DALL·E 2 and Stable Diffusion generate high-quality images from text prompts.

The paradigm shift has already started: **In the future we'll see more and more AI applications move beyond one data modality and leverage relationships between different modalities.** Ad-hoc approaches are dying out as boundaries between data modalities become fuzzy and meaningless:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-drawing--8-.svg" class="kg-image" loading="lazy" width="300" height="126" alt="Comparative image with a &quot;Before&quot; section in white with yellow accents and &quot;After&quot; in blue with yellow, both featuring arrows" />
<figcaption><span style="white-space: pre-wrap;">The paradigm shift from single-modal AI to multimodal AI</span></figcaption>
</figure>

##  The Duality of Search & Creation

Search and creation are two essential tasks in multimodal AI. Here, search means *neural search*, namely searching using deep neural networks. For most people, these two tasks are entirely isolated, and they have been independently studied for many years. Let me point out this: **search and creation are strongly connected and share a duality**. To understand this, let's look at the following examples.

With multimodal AI, it's simple to use a text or image query to search a dataset of images:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-2.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-2.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-2.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-2.png 1600w, https://cms.jina.ai/content/images/size/w2400/2022/10/image-2.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="602" alt="Diagram showing a text and image-based search for &quot;Mona Lisa, fan art&quot;, resulting in diverse Mona Lisa interpretations." />
<figcaption><span style="white-space: pre-wrap;">Search: </span><em><em>find</em></em><span style="white-space: pre-wrap;"> what you need</span></figcaption>
</figure>

Creation is similar. You create a new image from a text prompt or by enriching/inpainting from an existing image:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-4.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-4.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-4.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-4.png 1600w, https://cms.jina.ai/content/images/size/w2400/2022/10/image-4.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="610" alt="A grid of Mona Lisa images, some in Van Gogh&#39;s style, illustrating artistic transformations via an OpenCV `create` function." />
<figcaption><span style="white-space: pre-wrap;">Create: </span><em><em>make</em></em><span style="white-space: pre-wrap;"> what you need</span></figcaption>
</figure>

When grouping these two tasks together and masking out their function names, you can see the two tasks are indistinguishable: Both receive and output the same data type(s). The only difference is that search *finds* what you need, whereas creation *makes* what you need:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2022/10/image-5.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-5.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-5.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-5.png 1600w, https://cms.jina.ai/content/images/size/w2400/2022/10/image-5.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1065" alt="Series of six images depicting the transformation of the Mona Lisa into Van Gogh&#39;s style, possibly an art style transfer demo" />
</figure>

DNA is a good analogy: Once you have an organism's DNA, you can build a phylogenetic tree and *search* for the oldest and most primitive known ancestor. On the other hand, you could inject the DNA into an egg and *create* something new, just as David creates his own alien creature:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/Untitled-design--1--1.gif" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/Untitled-design--1--1.gif 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/Untitled-design--1--1.gif 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/Untitled-design--1--1.gif 1600w, https://cms.jina.ai/content/images/2022/10/Untitled-design--1--1.gif 1700w" sizes="(min-width: 720px) 720px" width="1700" height="500" alt="Futuristic banner divided into three sections with a blue globe, connected &quot;Search&quot; and &quot;Create&quot; labels, and imagery of human" />
<figcaption><span style="white-space: pre-wrap;">The duality of search and creation under the multimodal AI framework. Movie poster from "</span><em><em>Alien: Covenant</em></em><span style="white-space: pre-wrap;">"</span></figcaption>
</figure>

Or think of Doraemon and Rick. Both help their sidekick with out-of-this-world items to solve their problems. The difference is that Doraemon *searches* through his pocket for an existing item, whereas Rick *creates* something new from his garage workshop.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/10/image-7.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/10/image-7.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/10/image-7.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/10/image-7.png 1600w, https://cms.jina.ai/content/images/2022/10/image-7.png 2366w" sizes="(min-width: 720px) 720px" width="2000" height="817" alt="Illustration with Doraemon and a &#39;Search: find what you need&#39; caption on the left, Rick and Morty with &#39;Create: make what you" />
<figcaption><span style="white-space: pre-wrap;">Doraemon represent neural search, whereas Rick represents generative AI/creative AI</span></figcaption>
</figure>

The duality of search and creation also poses an interesting thought experiment. Imagine living in a world where all images are created by AI rather than humans. Do we still need (neural) search? Namely, do we need to embed images into vectors and then use a vector database to index and sort them? The answer is NO. As the seed and prompts that uniquely represent the image are known before observing the image, **the consequence now becomes the cause**. Contrast this to the classic representation, where learning an image is the cause and representation is the consequence. To search images, we can simply store the seed (an integer) and the prompt (a string), which is nothing more than a good old BM25 or binary search. Of course, we humans appreciate photography and human-made artworks, so that parallel Earth is not our reality (yet). Nonetheless, this thought experiment gives a good reason why neural searchers should care about advances in generative AI, as the old way of handling multimodal data may become obsolete.

## Summary

We are on the frontier of a new era in AI, where multimodal learning will soon dominate. This type of learning, combining multiple data types and modalities, has the potential to revolutionize the way we interact with machines. So far, multimodal AI has had great success in fields like computer vision and natural language processing. In future, expect multimodal AI to have an even greater impact. For instance, developing systems that understand the nuances of human communication, or creating more lifelike virtual assistants. The possibilities are endless, and we're just beginning to scratch the surface. So strap in and buckle up for the future, because the best is yet to come!

Want to work on multimodal AI, neural search, and generative AI? Join us and help lead the revolution!

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://jobs.jina.ai" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina AI jobs
</div>
<div class="kg-bookmark-description">
Job openings at Jina AI
</div>
<div class="kg-bookmark-metadata">
<img src="https://jobs.jina.ai/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI logo</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://lever-client-logos.s3.us-west-2.amazonaws.com/4347e16d-b068-4137-be7c-fedb5d3d7a9a-1662540212135.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">Check out all jobs at Jina AI</span></p></figcaption>
</figure>
