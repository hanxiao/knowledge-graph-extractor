---
title: "Query Expansion with LLMs: Searching Better by Saying More"
slug: query-expansion-with-llms-searching-better-by-saying-more
url: https://cms.jina.ai/query-expansion-with-llms-searching-better-by-saying-more/
published_at: 2025-02-18T03:24:20.000+01:00
updated_at: 2025-02-18T19:10:56.000+01:00
reading_time: 9
authors: "Michael Günther, Scott Martens"
tags: "Tech Blog"
excerpt: "Search has changed a lot since embedding models were introduced. Is there still a role for lexical techniques like query expansion in AI? We think so."
---

# Query Expansion with LLMs: Searching Better by Saying More

Query expansion has long been a go-to technique for supercharging search systems, though it's taken a backseat since semantic embeddings came onto the scene. While some might think it as outdated in our current landscape of RAG and agentic search, don't count it out just yet. In this deep dive, we'll explore how combining automatic query expansion with `jina-embeddings-v3` and LLMs can level up your search game and deliver results that really hit the mark.

## What is Query Expansion?

Query expansion was developed for search systems that judge relevance by matching words from queries with documents that contain them, like [tf-idf](https://en.wikipedia.org/wiki/Tf%E2%80%93idf) or other “sparse vector” schemes. That has some obvious limitations. Variant forms of words interfere with matching, like “ran” and “running”, or “optimise” vs. “optimize.” Language-aware preprocessing can mitigate some of these problems, but not all of them. Technical terms, synonyms, and related words are much harder to address. For example, a query for medical research about “coronavirus” will not automatically identify documents that talk about “COVID” or “SARS-CoV-2”, even though those would be very good matches.

Query expansion was invented as a solution.

The idea is to add additional words and phrases to queries to increase the likelihood of identifying good matches. This way, a query for “coronavirus” might have the terms “COVID” and “SARS-CoV-2” added to it. This can dramatically improve search performance.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/02/QueryExpansion1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/02/QueryExpansion1.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/02/QueryExpansion1.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/02/QueryExpansion1.png 1600w, https://cms.jina.ai/content/images/2025/02/QueryExpansion1.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="700" alt="Flowchart outlining a search engine&#39;s query expansion process, featuring a user&#39;s coronavirus query and related terms." />
<figcaption><span style="white-space: pre-wrap;">Figure 1: Query Expansion Flowchart with Thesaurus</span></figcaption>
</figure>

It’s not easy to decide what terms should be added to a query, and there’s been a lot of work on how to identify good terms and how to weight them for tf-idf-style retrieval. Common approaches include:

- Using a human-curated thesaurus.
- Data-mining large text corpora for related words.
- Identifying other terms used in similar queries taken from a query log.
- Learning what words and phrases make good query expansions [from user feedback](https://en.wikipedia.org/wiki/Rocchio_algorithm).

However, semantic embedding models are supposed to eliminate the need for query expansion. Good text embeddings for “coronavirus”, "COVID" and “SARS-CoV-2” should be very close to each other in the embedding vector space. They should naturally match without any augmentation.

But, while this should be true in theory, real embeddings made by real models often fall short. Words in embeddings may be ambiguous and adding words to a query can nudge it towards better matches if you use the right words. For example, an embedding for “skin rash” might identify documents about “behaving rashly” and “skin creme” while missing a medical journal article that talks about “dermatitis.” Adding relevant terms will likely nudge the embedding away from unrelated matches toward better ones.

## LLM Query Expansion

Instead of using a thesaurus or doing lexical data mining, we looked at using an LLM to do query expansion. LLMs have some important potential advantages:

- **Broad lexical knowledge**: Because they’re trained on large, diverse datasets, there is less concern about selecting an appropriate thesaurus or getting the right data.
- **Capacity for judgment**: Not all proposed expansion terms are necessarily appropriate to a specific query. LLMs may not make perfect judgments about topicality, but the alternatives can’t really make judgments at all.
- **Flexibility**: You can adjust your prompt to the needs of the retrieval task, while other approaches are rigid and may require a lot of work to adapt to new domains or data sources.

Once the LLM has proposed a list of terms, query expansion for embeddings operates the same way as traditional query expansion schemes: We add terms to the query text and then use an embedding model to create a query embedding vector.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/02/QueryExpansion2.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/02/QueryExpansion2.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/02/QueryExpansion2.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/02/QueryExpansion2.png 1600w, https://cms.jina.ai/content/images/2025/02/QueryExpansion2.png 2000w" sizes="(min-width: 720px) 720px" width="2000" height="850" alt="Flowchart detailing the query expansion process for coronavirus surface stability, with labeled sections and connecting arrow" />
<figcaption><span style="white-space: pre-wrap;">Figure 2: Query Expansion of Embeddings with an LLM</span></figcaption>
</figure>

To make this work, you need:

- Access to an LLM.
- A prompt template to solicit expansion terms from the LLM.
- A text embedding model.

## Trying It Out

We’ve done some experiments to see if this approach adds value to text information retrieval. Our tests used:

- One LLM: [Gemini 2.0 Flash](https://deepmind.google/technologies/gemini/flash/) from Google.
- Two embedding models to see if LLM query expansion generalizes across models: `jina-embeddings-v3` and [`all-MiniLM-L6-v2`](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2).
- A subset of the [BEIR benchmarks](https://github.com/beir-cellar/beir) for information retrieval.

We performed our experiments under two prompting conditions:

- Using a general prompt template to solicit expansion terms.
- Using task-specific prompt templates.

Finally, we wrote our prompts to solicit different numbers of terms to add: 100, 150, and 250.

Our code and results are [available on GitHub](https://github.com/jina-ai/llm-query-expansion/) for reproduction.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/llm-query-expansion/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - jina-ai/llm-query-expansion: Query Expension for Better Query Embedding using LLMs
</div>
<div class="kg-bookmark-description">
Query Expension for Better Query Embedding using LLMs - jina-ai/llm-query-expansion
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-1.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/llm-query-expansion" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Results

### Using a General Prompt

After some trial and error, we found that the following prompt worked well enough with Gemini 2.0 Flash:


    Please provide additional search keywords and phrases for 
    each of the key aspects of the following queries that make 
    it easier to find the relevant documents (about {size} words 
    per query):
    {query}

    Please respond in the following JSON schema:
    Expansion = {"qid": str, "additional_info": str}
    Return: list [Expansion]

This prompt enables us to batch our queries in bundles of 20-50, giving an ID to each one, and getting back a JSON string that connects each query to a list of expansion terms. If you use a different LLM, you may have to experiment to find a prompt that works for it.

We applied this setup with `jina-embeddings-v3` using the [asymmetric retrieval adapter](https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model). Using this approach, queries and documents are encoded differently — using the same model but different LoRA extensions — to optimize the resulting embeddings for information retrieval.

Our results on various BEIR benchmarks are in the table below. Scores are nDCG@10 ([normalized Discounted Cumulative Gain](https://en.wikipedia.org/wiki/Discounted_cumulative_gain) on the top ten items retrieved).

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr>
<th>Benchmark</th>
<th>No Expansion</th>
<th>100 terms</th>
<th>150 terms</th>
<th>250 terms</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>SciFact</strong><br />
(Fact Checking Task)</td>
<td>72.74</td>
<td>73.39</td>
<td>74.16</td>
<td><strong>74.33</strong></td>
</tr>
<tr>
<td><strong>TRECCOVID</strong><br />
(Medical Retrieval Task)</td>
<td>77.55</td>
<td>76.74</td>
<td>77.12</td>
<td><strong>79.28</strong></td>
</tr>
<tr>
<td><strong>FiQA</strong><br />
(Financial Option Retrieval)</td>
<td>47.34</td>
<td><strong>47.76</strong></td>
<td>46.03</td>
<td>47.34</td>
</tr>
<tr>
<td><strong>NFCorpus</strong><br />
(Medical Information Retrieval)</td>
<td>36.46</td>
<td><strong>40.62</strong></td>
<td>39.63</td>
<td>39.20</td>
</tr>
<tr>
<td><strong>Touche2020</strong><br />
(Argument Retrieval Task)</td>
<td>26.24</td>
<td>26.91</td>
<td>27.15</td>
<td><strong>27.54</strong></td>
</tr>
</tbody>
</table>

We see here that query expansion has in almost all cases resulted in improved retrieval.

To test the robustness of this approach, we repeated the same tests with `all-MiniLM-L6-v2`, a much smaller model that produces smaller embedding vectors.

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
sentence-transformers/all-MiniLM-L6-v2 · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-29.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/all-MiniLM-L6-v2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

The results are in the table below:

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr>
<th>Benchmark</th>
<th>No Expansion</th>
<th>100 terms</th>
<th>150 terms</th>
<th>250 terms</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>SciFact</strong><br />
(Fact Checking Task)</td>
<td>64.51</td>
<td><strong>68.72</strong></td>
<td>66.27</td>
<td>68.50</td>
</tr>
<tr>
<td><strong>TRECCOVID</strong><br />
(Medical Retrieval Task)</td>
<td>47.25</td>
<td>67.90</td>
<td><strong>70.18</strong></td>
<td>69.60</td>
</tr>
<tr>
<td><strong>FiQA</strong><br />
(Financial Option Retrieval)</td>
<td><strong>36.87</strong></td>
<td>33.96</td>
<td>32.60</td>
<td>31.84</td>
</tr>
<tr>
<td><strong>NFCorpus</strong><br />
(Medical Information Retrieval)</td>
<td>31.59</td>
<td><strong>33.76</strong></td>
<td>33.76</td>
<td>33.35</td>
</tr>
<tr>
<td><strong>Touche2020</strong><br />
(Argument Retrieval Task)</td>
<td>16.90</td>
<td><strong>25.31</strong></td>
<td>23.52</td>
<td>23.23</td>
</tr>
</tbody>
</table>

We see here an even larger improvement in retrieval scores. Overall, the smaller model profited more from query expansion. The average improvement over all tasks is summarized in the table below:

| Model                | 100 terms | 150 terms | 250 terms |
|----------------------|-----------|-----------|-----------|
| `jina-embeddings-v3` | +1.02     | +0.75     | **+1.48** |
| `all-MiniLM-L6-v2`   | **+6.51** | +5.84     | +5.88     |

The large difference in net improvement between the two models is likely due to `all-MiniLM-L6-v2` starting from a lower level of performance. The query embeddings produced by `jina-embeddings-v3` in asymmetric retrieval mode are better able to capture key semantic relationships, and thus there is less room for query expansion to add information. But this result shows how much query expansion can improve the performance of more compact models that may be preferable in some use cases to large models.

Nonetheless, query expansion brought meaningful improvement to retrieval even for high-performance models like `jina-embeddings-v3`, but this result is not perfectly consistent across all tasks and conditions.

For `jina-embeddings-v3`, adding more than 100 terms to a query was counterproductive for the FiQA and NFCorpus benchmarks. We can’t say that more terms are always better, but the results on the other benchmarks indicate that more terms are at least sometimes better.

For `all-MiniLM-L6-v2`, adding more than 150 terms was always counterproductive, and on three tests, adding more than 100 didn’t improve scores. On one test (FiQA) adding even 100 terms produced significantly lower results. We believe this is because `jina-embeddings-v3` does a better job of capturing semantic information in long query texts.

Both models showed less response to query expansion on the FiQA and NFCorpus benchmarks.

## Using Task-Specific Prompting

The pattern of results reported above suggests that while query expansion is helpful, using LLMs risks adding unhelpful query terms that reduce performance. This might be caused by the generic nature of the prompt.

We took two benchmarks — SciFact and FiQA — and created more domain-specific prompts, like the one below:


    Please provide additional search keywords and phrases for 
    each of the key aspects of the following queries that make
    it easier to find the relevant documents scientific document 
    that supports or rejects the scientific fact in the query 
    field (about {size} words per query):
    {query}
    Please respond in the following JSON schema:
    Expansion = {"qid": str, "additional_info": str}
    Return: list [Expansion]

This approach improved retrieval performance almost across the board:

<table style="width:100%;">
<colgroup>
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
</colgroup>
<thead>
<tr>
<th>Benchmark</th>
<th>Model</th>
<th>No Expansion</th>
<th>100<br />
terms</th>
<th>150<br />
terms</th>
<th>250<br />
terms</th>
</tr>
</thead>
<tbody>
<tr>
<td>SciFact</td>
<td><code>jina-embeddings-v3</code></td>
<td>72.74</td>
<td><strong>75.85 (+2.46)</strong></td>
<td>75.07 (+0.91)</td>
<td>75.13 (+0.80)</td>
</tr>
<tr>
<td>SciFact</td>
<td><code>all-MiniLM-L6-v2</code></td>
<td>64.51</td>
<td><strong>69.12 (+0.40)</strong></td>
<td>68.10 (+1.83)</td>
<td>67.83 (-0.67)</td>
</tr>
<tr>
<td>FiQA</td>
<td><code>jina-embeddings-v3</code></td>
<td>47.34</td>
<td>47.77 (+0.01)</td>
<td><strong>48.20 (+1.99)</strong></td>
<td>47.75 (+0.41)</td>
</tr>
<tr>
<td>FiQA</td>
<td><code>all-MiniLM-L6-v2</code></td>
<td><strong>36.87</strong></td>
<td>34.71 (+0.75)</td>
<td>34.68 (+2.08)</td>
<td>34.50 (+2.66)</td>
</tr>
</tbody>
</table>

Scores improved under all conditions except adding 250 terms to SciFact queries with `all-MiniLM-L6-v2`. Furthermore, this improvement was not enough to make `all-MiniLM-L6-v2` beat its own baseline on FiQA.

For `jina-embeddings-v3`, we see that the best results came with 100 or 150 added terms. Adding 250 terms was counterproductive. This supports our intuition that you can add too many terms to your query, especially if their meaning begins to drift from the target.

## Key Considerations in Query Expansion

Query expansion clearly can bring gains to embeddings-based search, but comes with some caveats:

### Expense

Interacting with an LLM adds latency and computational costs to information retrieval, and may add actual costs if you use a commercial LLM. The moderate improvement it brings may not justify the expense.

### Prompt Engineering

Designing good prompt templates is an empirical and experimental art. We make no representation that the ones we used for this work are optimal or portable to other LLMs. Our experiments with task-specific prompting show that changing your prompts can have very significant effects on the quality of the outcome. Results also vary considerably between domains.

These uncertainties add to the cost of development and undermine maintainability. Any change to the system — changing LLMs, embedding models, or information domain — means rechecking and possibly reimplementing the entire process.

### Alternatives

We see here that query expansion added the greatest improvement to the embedding model with the poorest initial performance. Query expansion, at least in this experiment, was not able to close the performance gap between `all-MiniLM-L6-v2` and `jina-embeddings-v3`, while `jina-embeddings-v3` saw more modest improvements from query expansion.

Under the circumstances, a user of `all-MiniLM-L6-v2` would get better results at a lower cost by adopting `jina-embeddings-v3` rather than pursuing query expansion.

## Future Directions

We’ve shown here that query expansion can improve query embeddings, and that LLMs offer a simple and flexible means of getting good query expansion terms. But the relatively modest gains suggest more work to be done. We’re looking at a number of directions for future research:

- Testing the value of terminological enhancement in generating document embeddings.
- Looking at the possibilities for query enhancement in other AI search techniques like reranking.
- Comparing LLM-based query expansion to older and computationally less expensive sources of terms, like a thesaurus.
- Training language models specifically to be better at query expansion and providing them with more domain-specific training.
- Limiting the number of terms added. 100 may be too many to start with.
- Finding ways to identify helpful and unhelpful expansion terms. Any fixed number we impose on query expansion is not going to be a perfect fit and if we could dynamically evaluate suggested terms and keep only the good ones, the result would likely be a lift in performance.

This is very preliminary research, and we’re optimistic that techniques like this will bring further improvements to Jina AI’s search foundation products.
