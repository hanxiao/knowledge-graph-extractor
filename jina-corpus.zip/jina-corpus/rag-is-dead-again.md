---
title: "RAG is Dead, Again?"
slug: rag-is-dead-again
url: https://cms.jina.ai/rag-is-dead-again/
published_at: 2024-05-24T12:37:18.000+02:00
updated_at: 2024-05-24T20:12:12.000+02:00
reading_time: 4
authors: "Han Xiao"
tags: "Insights"
excerpt: "RAG is just one algorithmic pattern you can use. But if you make it *the* algorithm and idolize it, then you are living in a bubble you created, and the bubble will burst."
---

# RAG is Dead, Again?

It is hard to tell if people hate to love RAG or love to hate RAG.

According to recent discussions on X and [HN](https://t.co/Q1QithBNj6), RAG *should* be dead, **again**. This time, critics are focusing on the over-engineering of most RAG frameworks, which, as [@jeremyphoward](https://x.com/jeremyphoward) [@HamelHusain](https://x.com/HamelHusain) [@Yampeleg](https://x.com/Yampeleg) demonstrated, could be accomplished with 20 lines of Python code.

<figure class="kg-card kg-embed-card">
<blockquote>
<p>T H A N K Y O U ! ! !<br />
(v 2.0)<br />
<br />
Full RAG in 20 lines.<br />
<br />
This is how you implement semantic search in ~10 lines<br />
<br />
Replace 𝚌𝚘𝚗𝚝𝚎𝚡𝚝𝚜 &amp; 𝚚𝚞𝚎𝚜𝚝𝚒𝚘𝚗 with your own.<br />
<br />
* the blurred code is for loading example contexts<br />
<br />
(Everything from FastAI's guide:<a href="https://t.co/qBpU6T2Fd1">https://t.co/qBpU6T2Fd1</a>) <a href="https://t.co/Or3eJEbSt9">https://t.co/Or3eJEbSt9</a> <a href="https://t.co/e2q70H6QaY">pic.twitter.com/e2q70H6QaY</a></p>
<p>— Yam Peleg (@Yampeleg) <a href="https://twitter.com/Yampeleg/status/1793698848616960393?ref_src=twsrc%5Etfw">May 23, 2024</a></p>
</blockquote>
</figure>

The last time we had this vibe was shortly after the release of Claude/Gemini with a super long context window. What makes this time worse is that even Google's RAG generates funny results as [@icreatelife](https://x.com/icreatelife) [@mark_riedl](https://x.com/mark_riedl) showed, which is ironic because back in April, at Google Next in Las Vegas, Google presented RAG as the grounding solution.

<figure class="kg-card kg-embed-card">
<blockquote>
<p>I couldn’t believe it before I tried it. Google needs to fix this asap.. <a href="https://t.co/r3FyOfxiTK">pic.twitter.com/r3FyOfxiTK</a></p>
<p>— Kris Kashtanova (@icreatelife) <a href="https://twitter.com/icreatelife/status/1793781850923823144?ref_src=twsrc%5Etfw">May 23, 2024</a></p>
</blockquote>
</figure>

<figure class="kg-card kg-embed-card">
<blockquote>
<p>Yes! My website poisoning attack works on Google's new LLM-powered AI overviews! <a href="https://t.co/nWyMtl7nMj">pic.twitter.com/nWyMtl7nMj</a></p>
<p>— Mark Riedl (@mark_riedl) <a href="https://twitter.com/mark_riedl/status/1793375699967054334?ref_src=twsrc%5Etfw">May 22, 2024</a></p>
</blockquote>
</figure>

## Two problems of RAG

I see two problems with the RAG frameworks and solutions we have today.

## Feed-forward only

First, nearly all RAG frameworks **implement only a "feed-forward" path and lack a "back-propagation" path**. It is an *incomplete* system. I remember [@swyx](https://x.com/swyx), in one of the episodes of [@latentspacepod](https://x.com/latentspacepod), arguing that RAG will *not* be killed by the long context window of LLMs since:

1.  long context is expensive for devs and
2.  long context is hard to debug and lacks decomposability.

But if all RAG frameworks focus only on the forwarding path, how is it easier to debug than an LLM? It is also interesting how many people get overexcited by the auto-magical results of RAG from some random POCs and completely forget that adding more forward layers without backward tuning is a terrible idea. We all know that adding one more layer to your neural networks expands its parametric space and hence representation ability, enabling it to do more potential things, **but without training, this is nothing.** There are quite some startups in the Bay Area working on evaluation—essentially trying to evaluate the loss of a feed-forward system. Is it useful? Yes. But does it help close the loop of RAG? No.  
  
So who is working on the back-propagation of RAG? Afaik not many. I am mostly familiar with DSPy, a library from [@stanfordnlp](https://x.com/stanfordnlp) [@lateinteraction](https://x.com/lateinteraction) that sets its mission on that.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/stanfordnlp/dspy" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
GitHub - stanfordnlp/dspy: DSPy: The framework for programming—not prompting—foundation models
</div>
<div class="kg-bookmark-description">
DSPy: The framework for programming—not prompting—foundation models - stanfordnlp/dspy
</div>
<div class="kg-bookmark-metadata">
<img src="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">stanfordnlp</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://opengraph.githubassets.com/0d188663ed7e46ec4bb66d2eb8c5a9417e63343bc566e659a691978ae3df0b3e/stanfordnlp/dspy" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

But even for DSPy, the main focus is on optimizing few-shot demonstrations, not the full system (or at least from community usage). But why is this problem difficult? Because the signal is very sparse, and optimizing a non-differentiable pipeline system is essentially a combinatorial problem—in other words, **extremely hard**. I learned some submodular optimization during my PhD, and I have a feeling that this technique will be put to good use in RAG optimization.

## Grounding in the wild is hard

I do agree that RAG is for grounding, despite the funny search results from Google. There are two types of grounding: **search grounding**, which uses search engines to extend the world knowledge of LLMs, and **check grounding**, which uses private knowledge (e.g. proprietary data) to do fact-checking.

In both cases, it cites external knowledge to improve the factuality of the result, provided that these external resources are trustworthy. In Google's funny search result, one can easily see that not everything on the web is trustworthy (yeah, big surprise, who would thought!), which makes search grounding look bad. But I do believe you can only laugh at it for now. There are some **implicit feedback mechanisms** behind the Google Search UI that collect users' reactions to those results and weight the credibility of the website for better grounding. In general, it should be pretty temporary, as this RAG just needs to get past **the cold start**, and results will improve over time.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/05/Heading--32-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Heading--32-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Heading--32-.png 1000w, https://cms.jina.ai/content/images/2024/05/Heading--32-.png 1500w" sizes="(min-width: 720px) 720px" width="1500" height="787" alt="Diagram of Jina AI&#39;s search process with &quot;Search Grounding,&quot; &quot;Private Knowledge,&quot; and &quot;Check Grounding&quot; blocks, and related U" />
<figcaption><span style="white-space: pre-wrap;">Two types of grounding that inspire </span><a href="https://jina.ai/reader/"><span style="white-space: pre-wrap;">Jina Reader</span></a></figcaption>
</figure>

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/05/GOVSJD9XEAAf2kK.jpeg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/GOVSJD9XEAAf2kK.jpeg 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/GOVSJD9XEAAf2kK.jpeg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/05/GOVSJD9XEAAf2kK.jpeg 1600w, https://cms.jina.ai/content/images/size/w2400/2024/05/GOVSJD9XEAAf2kK.jpeg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="955" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/05/Untitled.jpg" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/05/Untitled.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/05/Untitled.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/05/Untitled.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2024/05/Untitled.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="975" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">RAG was presented as a grounding solution in the Google Next conference.</span></p></figcaption>
</figure>

## My Take

RAG is neither dead nor alive; so stop arguing about it. RAG is just one algorithmic pattern you can use. But if you make it ***the*** algorithm and idolize it, then you are living in a bubble you created, and the bubble will burst.
