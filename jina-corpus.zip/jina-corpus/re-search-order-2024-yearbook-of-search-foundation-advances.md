---
title: "Re·Search: Order 2024 Yearbook of Search Foundation Advances"
slug: re-search-order-2024-yearbook-of-search-foundation-advances
url: https://cms.jina.ai/re-search-order-2024-yearbook-of-search-foundation-advances/
published_at: 2024-12-16T15:35:49.000+01:00
updated_at: 2024-12-17T19:16:29.000+01:00
reading_time: 2
authors: "Jina AI"
tags: "Press"
excerpt: "Discover Re·Search, our premium yearbook showcasing our best research articles and search foundation models in 2024. Featuring spot UV-coated hardcover, 160 full-color pages, and meticulous design throughout. Available worldwide at $35, shipping included."
---

# Re·Search: Order 2024 Yearbook of Search Foundation Advances

We're excited to announce the release of *Re·Search*, our 2024 yearbook—a carefully curated collection showcasing our most impactful technical achievements and breakthroughs in search foundation models. Whether you're a longtime follower of our tech blog or new to the search technology, this compilation represents the pinnacle of our research and development in 2024. This beautifully designed, 160-page volume brings together our most influential technical articles, featuring:

- Comprehensive coverage of Jina AI's multilingual multimodal **embeddings**, **rerankers** and **small LMs**, including `jina-embeddings-v3`, `jina-clip-v2`, `jina-reranker-v2-base`, `reader-lm` and `jina-colbert-v2`
- Critical insights into ColBERT late interaction and late chunking
- Technical deep dives into modality and linguality gaps
- Empirical studies exploring zero-shot classification and embeddings & rerankers vibes

Each of the 14 selected articles has been thoughtfully edited and enhanced with high-quality graphics, ensuring both clarity and depth of technical understanding.

<figure class="kg-card kg-image-card">
<a href="https://buy.stripe.com/5kA6rC6IF4AX2aYbIY"><img src="https://cms.jina.ai/content/images/2024/12/IMG_0688.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/IMG_0688.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/IMG_0688.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/IMG_0688.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2024/12/IMG_0688.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1622" alt="Open book on AI showcasing Jina CLIP v2, with diagrams and details on multilingual support, high-res image handling, and mode" /></a>
</figure>

<figure class="kg-card kg-image-card">
<a href="https://buy.stripe.com/5kA6rC6IF4AX2aYbIY"><img src="https://cms.jina.ai/content/images/2024/12/IMG_0687.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/IMG_0687.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/IMG_0687.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/IMG_0687.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2024/12/IMG_0687.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="2667" alt="Open book with page displaying &quot;Foundation Models&quot; and tech-related model names, indicating an innovative tech resource." /></a>
</figure>

<figure class="kg-card kg-image-card">
<a href="https://buy.stripe.com/5kA6rC6IF4AX2aYbIY"><img src="https://cms.jina.ai/content/images/2024/12/IMG_0587.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/IMG_0587.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/IMG_0587.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/IMG_0587.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2024/12/IMG_0587.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1500" alt="Open book page on &quot;Human-Computer Interaction&quot; with text about chunking strategy and diagrams indicating performance improvem" /></a>
</figure>

## What's Inside

- 14 carefully selected technical articles from 2024
- A complete model tree of all Jina AI models so far
- 160 full-color pages with premium spot UV-coated hardcover (510g)
- Complimentary digital copy for instant access
- International shipping included, we ship globally with the following estimated delivery times:

| Country       | Delivery Time       |
|---------------|---------------------|
| United States | 7-9 business days   |
| Germany       | 7-11 business days  |
| Singapore     | 4-5 business days   |
| Netherlands   | 8-12 business days  |
| Japan         | 3-6 business days   |
| China         | 3-5 business days   |
| Others        | 15-30 business days |

<figure class="kg-card kg-image-card">
<a href="https://buy.stripe.com/5kA6rC6IF4AX2aYbIY"><img src="https://cms.jina.ai/content/images/2024/12/IMG_0828.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/IMG_0828.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/IMG_0828.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/IMG_0828.jpg 1600w, https://cms.jina.ai/content/images/2024/12/IMG_0828.jpg 2382w" sizes="(min-width: 720px) 720px" width="2000" height="2667" alt="Red book titled &quot;Re:Search 24&quot; with abstract black design on a white background, featuring texts about search optimization." /></a>
</figure>

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2024/12/IMG_0829--1-.jpg" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/IMG_0829--1-.jpg 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/IMG_0829--1-.jpg 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/IMG_0829--1-.jpg 1600w, https://cms.jina.ai/content/images/size/w2400/2024/12/IMG_0829--1-.jpg 2400w" sizes="(min-width: 720px) 720px" width="2000" height="1500" alt="Two red books titled &quot;RESEARCH&quot; stacked on a white background, with &quot;2024 Volume&quot; visible, creating a minimalist aesthetic." />
</figure>

## Order Your Copy

**Price: \$35 USD** (shipping included, VAT/GST excluded). The final price may be shown in your local currency and additional taxes, customs duties, or import fees may apply depending on your country of residence. All applicable taxes will be calculated at checkout.

We're proud to share our 2024 journey in search foundation models through *Re·Search*. As you explore these pages, we hope they inspire new ideas and deepen your interest in search technology. Follow our continued innovations in 2025 through our website and [X](https://twitter.com/JinaAI_) as we push the boundaries of what's possible in search.
