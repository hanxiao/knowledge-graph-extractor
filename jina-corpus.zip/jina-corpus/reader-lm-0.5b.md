---
model_name: "reader-lm-0.5b"
model_version: "v1"
model_type: "reader"
organization: "Jina AI"
license: "CC-BY-NC-4.0"
parameter_size: "494M"
language:
  - multilingual
token_length: 256K
device: "cuda"
input_type:
  - text (html)
output_type:
  - text (markdown)
diagrams:
  - reader-lm.svg
deprecated_by:
  - ReaderLM-v2
huggingface: "https://huggingface.co/jinaai/reader-lm-0.5b"
aws: "https://aws.amazon.com/marketplace/seller-profile/vendor/jinaai"
release_blog: "/news/reader-lm-small-language-models-for-cleaning-and-converting-html-to-markdown"
related_models:
  - reader-lm-1.5b
release_date: "2024-08-11"
tags:
  - text-understanding
  - multilingual
  - document-processing
  - resource-efficient
  - long-context
  - base-model
  - language-model
endpoints:
  - read
availability:
  - license
  - huggingface
  - aws
  - azure
---

## Overview

Reader LM 0.5B is a specialized language model designed to solve the complex challenge of converting HTML documents into clean, structured markdown text. This model addresses a critical need in modern data processing pipelines: efficiently transforming messy web content into a format that's ideal for LLMs and documentation systems. Unlike general-purpose language models that require massive computational resources, Reader LM 0.5B achieves professional-grade HTML processing with just 494M parameters, making it accessible to teams with limited computing resources. Organizations dealing with web content processing, documentation automation, or building LLM-powered applications will find this model particularly valuable for streamlining their content preparation workflows.

## Methods

The model employs an innovative "shallow-but-wide" architecture specifically optimized for selective-copy operations rather than creative text generation. Built on a decoder-only foundation with 24 layers and 896 hidden dimensions, the model uses specialized attention mechanisms with 14 query heads and 2 key-value heads to efficiently process input sequences. The training process involved two distinct stages: first with shorter, simpler HTML (32K tokens) to learn basic conversion patterns, then with complex, real-world HTML (128K tokens) to handle challenging cases. The model incorporates contrastive search during training and implements a repetition detection mechanism to prevent degeneration issues like token loops. A unique aspect of its architecture is the zigzag-ring-attention mechanism, which enables the model to handle extremely long sequences up to 256K tokens while maintaining stable performance.

## Performance

In real-world testing, Reader LM 0.5B demonstrates impressive efficiency-to-performance ratios across multiple metrics. The model achieves a ROUGE-L score of 0.56, indicating strong content preservation, and maintains a low token error rate of 0.34, showing minimal hallucination. In qualitative evaluations across 22 diverse HTML sources including news articles, blog posts, and e-commerce pages in multiple languages, it shows particular strength in structure preservation and markdown syntax usage. The model excels at handling complex modern web pages where inline CSS and scripts can expand to hundreds of thousands of tokens - a scenario where traditional rule-based approaches often fail. However, it's important to note that while the model performs exceptionally well on straightforward HTML-to-markdown conversion tasks, it may require additional processing for highly dynamic or JavaScript-heavy pages.

## Guidance

To effectively deploy Reader LM 0.5B, teams should ensure their infrastructure can handle the model's CUDA requirements, though its efficient architecture means it can run on consumer-grade GPUs. The model works best with raw HTML input and doesn't require special prefixes or instructions. For optimal performance, implement the provided repetition detection mechanism to prevent potential token loops in output generation. While the model supports multiple languages and various HTML structures, it's specifically designed for content extraction and markdown conversion - it shouldn't be used for tasks like text generation, summarization, or direct question answering. The model is available through AWS SageMaker for production deployment, and a Google Colab notebook is provided for testing and experimentation. Teams should be aware that while the model can handle extremely long documents up to 256K tokens, processing such large inputs may require additional memory management strategies.
