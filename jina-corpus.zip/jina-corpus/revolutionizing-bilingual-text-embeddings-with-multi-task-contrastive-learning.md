---
title: "Revolutionizing Bilingual Text Embeddings with Multi-Task Contrastive Learning"
slug: revolutionizing-bilingual-text-embeddings-with-multi-task-contrastive-learning
url: https://cms.jina.ai/revolutionizing-bilingual-text-embeddings-with-multi-task-contrastive-learning/
published_at: 2024-02-28T16:00:41.000+01:00
updated_at: 2024-03-03T01:55:04.000+01:00
reading_time: 3
authors: "Jina AI"
tags: "Press"
excerpt: "Our new paper explores how our Spanish-English and German-English models use multi-task contrastive learning and a sophisticated data pipeline to master language understanding and cross-lingual efficiency for texts up to 8192 tokens"
---

# Revolutionizing Bilingual Text Embeddings with Multi-Task Contrastive Learning

In our recent paper, [Multi-Task Contrastive Learning for 8192-Token Bilingual Text Embeddings](https://arxiv.org/abs/2402.17016), we detailed our development of [German-English](https://jina.ai/news/ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length/) and [Spanish-English](https://jina.ai/news/aqui-se-habla-espanol-top-quality-spanish-english-embeddings-and-8k-context) bilingual text embedding models.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2402.17016" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Multi-Task Contrastive Learning for 8192-Token Bilingual Text Embeddings
</div>
<div class="kg-bookmark-description">
We introduce a novel suite of state-of-the-art bilingual text embedding models that are designed to support English and another target language. These models are capable of processing lengthy text inputs with up to 8192 tokens, making them highly versatile for a range of natural language processing tasks such as text retrieval, clustering, and semantic textual similarity (STS) calculations. By focusing on bilingual models and introducing a unique multi-task learning objective, we have significantly improved the model performance on STS tasks, which outperforms the capabilities of existing multilingual models in both target language understanding and cross-lingual evaluation tasks. Moreover, our bilingual models are more efficient, requiring fewer parameters and less memory due to their smaller vocabulary needs. Furthermore, we have expanded the Massive Text Embedding Benchmark (MTEB) to include benchmarks for German and Spanish embedding models. This integration aims to stimulate further research and advancement in text embedding technologies for these languages.
</div>
<div class="kg-bookmark-metadata">
<img src="https://arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Isabelle Mohr</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/embeddings" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Embedding API
</div>
<div class="kg-bookmark-description">
Start with 1M free tokens. Top-performing, 8192 context length bilingual embeddings for your search and RAG systems.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-embedding-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Our approach utilizes multi-task contrastive learning and advanced data curation pipeline, focusing on bilingual capabilities while extending to support 8192 tokens in length. This method allows our models to excel in understanding target languages and in conducting cross-lingual evaluations efficiently.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/aqui-se-habla-espanol-top-quality-spanish-english-embeddings-and-8k-context" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Aquí Se Habla Español: Top-Quality Spanish-English Embeddings and 8k Context
</div>
<div class="kg-bookmark-description">
Jina AI’s new bilingual Spanish-English embedding model brings the state-of-the-art in AI to half a billion Spanish speakers.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">GitHub</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2024/02/1334.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/ich-bin-ein-berliner-german-english-bilingual-embeddings-with-8k-token-length" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Ich bin ein Berliner: German-English Bilingual Embeddings with 8K Token Length
</div>
<div class="kg-bookmark-description">
Jina AI introduces a German/English bilingual embedding model, featuring an extensive 8,192-token length, specifically designed to support German businesses thriving in the U.S. market.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">GitHub</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2024/01/Explore-image-storytelling-beyond-pixels--33-.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

In addition to the bilingual models covered in the paper, we have also developed bilingual [Chinese-English](https://jina.ai/news/8k-token-length-bilingual-embeddings-break-language-barriers-in-chinese-and-english) and <a href="https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai" rel="noreferrer">monolingual English</a> models. These additions showcase our commitment to covering a broad spectrum of linguistic needs and furthering our capabilities in language processing.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/8k-token-length-bilingual-embeddings-break-language-barriers-in-chinese-and-english" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
8K Token-Length Bilingual Embeddings Break Language Barriers in Chinese and English
</div>
<div class="kg-bookmark-description">
The first bilingual Chinese-English embedding model with 8192 token-length.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">Discord</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2024/01/jina-embeddings-v2-base-zh.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/jina-ai-launches-worlds-first-open-source-8k-text-embedding-rivaling-openai" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina AI Launches World’s First Open-Source 8K Text Embedding, Rivaling OpenAI
</div>
<div class="kg-bookmark-description">
Jina AI introduces jina-embeddings-v2, the world’s first open-source model boasting an 8K context length. Matching the prowess of OpenAI’s proprietary models, this innovation is now publicly accessible on Huggingface, signaling a significant milestone in the landscape of text embeddings.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2023/10/Explore-image-storytelling-beyond-pixels--11-.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Our bilingual models are characterized by their efficiency, operating with optimized vocabulary sizes to require fewer parameters and less memory. This efficiency underscores our dedication to creating powerful yet resource-efficient tools for language processing.

Following the release of our paper, we expanded the [Massive Text Embedding Benchmark (MTEB)](https://huggingface.co/spaces/mteb/leaderboard) to include benchmarks for our English-German and English-Spanish embedding models. This expansion is part of our effort to stimulate further research and advancements in text embedding technologies for non-English languages.

At Jina AI, our aim is to enhance the processing and understanding of multiple languages, contributing to the NLP field with our developments in bilingual and monolingual text embedding models.
