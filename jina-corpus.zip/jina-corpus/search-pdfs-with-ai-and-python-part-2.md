---
title: "Search PDFs with AI and Python: Part 2"
slug: search-pdfs-with-ai-and-python-part-2
url: https://cms.jina.ai/search-pdfs-with-ai-and-python-part-2/
published_at: 2022-11-01T21:15:14.000+01:00
updated_at: 2022-11-01T22:39:41.000+01:00
reading_time: 7
authors: "Alex C-G"
tags: "Tech Blog"
excerpt: "In our previous post we looked at how (and how not) to break down PDF files into usable chunks so we could build a search engine for them. In this article, we continue our journey."
---

# Search PDFs with AI and Python: Part 2

In our previous post we looked at how (and how not) to break down PDF files into usable chunks so we could build a search engine for them.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/search-pdfs-with-ai-and-python-part-1/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Search PDFs with AI and Python: Part 1
</div>
<div class="kg-bookmark-description">
I know several folks already building PDF search engines powered by AI, so I figured I’d give it a stab too. How hard could it possibly be? Part I
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/android-icon-192x192.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/2022/11/Jina-AI-Website-Banners-Templates--14-.png" />
</div>
</figure>

We also looked at a few footguns you may encounter along the way.

<img src="https://miro.medium.com/max/1400/0*B6RRc6a0YwSzKcON.jpg" class="kg-image" loading="lazy" width="200" />

This is what happens when you use a vanilla sentencizer. Apparently there are no GIFs of people shooting themselves in the feet.

Now we’re going to take those chunks and:

- Encode them into vector embeddings using the <a href="https://openai.com/blog/clip/" rel="noopener ugc nofollow">CLIP</a> model.
- Store them in an index for easy searching.

## Encoding our chunks

By encoding our chunks we convert them into something our model (in this case CLIP) can understand. While many models are uni-modal (i.e. only work with one type of data, like text or image or audio), CLIP is multi-modal, meaning it can embed different data types into the same vector space.

This means we can search image-to-image, text-to-image, image-to-text or text-to-text. Or you could throw audio into there too. I’d rather not right now since:

- Typing all those option combinations takes way too long.
- The PDFs we’re using (thankfully) don’t contain audio (though I’m sure the PDF spec contains some functionality for that because PDF doesn’t just throw in the kitchen sink but also the machine that builds the kitchen sink).

Of course, if you only plan to search one type of modality (text or images), Jina AI Executor Hub has specific models just for those:

- Text: <a href="https://openai.com/blog/clip/" rel="noopener ugc nofollow">TransformerTorchEncoder</a>, <a href="https://hub.jina.ai/executor/nh1ucuki" rel="noopener ugc nofollow">TransformerSentenceEncoder</a>, <a href="https://hub.jina.ai/executor/u7h7cuh2" rel="noopener ugc nofollow">SpacyTextEncoder</a>
- Image: <a href="https://hub.jina.ai/executor/lb8dbppn" rel="noopener ugc nofollow">ImageTorchEncoder</a>

## Adding the encoder Executor

Previously we built a <a href="https://docs.jina.ai/fundamentals/flow/" rel="noopener ugc nofollow">Flow</a> to:

- Extract text <a href="https://docarray.jina.ai/fundamentals/document/nested/" rel="noopener ugc nofollow">chunks</a> and images.
- Break down our text chunks into sentences.
- Move all text chunks to the same level so things are nice and tidy.
- Normalize our images ready for encoding.

Our code looked something like this (including loading PDFs into <a href="https://docarray.jina.ai/fundamentals/documentarray/" rel="noopener ugc nofollow">DocumentArray</a>, etc):

``` python
from docarray import DocumentArray
from executors import ChunkSentencizer, ChunkMerger, ImageNormalizer
from jina import Flow

docs = DocumentArray.from_files("data/*.pdf", recursive=True)

flow = (
    Flow()
    .add(uses="jinahub+sandbox://PDFSegmenter", install_requirements=True, name="segmenter")
    .add(uses=ChunkSentencizer, name="chunk_sentencizer")
    .add(uses=ChunkMerger, name="chunk_merger")
    .add(uses=ImageNormalizer, name="image_normalizer")
)

with flow:
  indexed_docs = flow.index(docs)
```

Now we just need to add our <a href="https://hub.jina.ai/executor/29r2b26t" rel="noopener ugc nofollow">CLIPEncoder</a>. Again, we can add this <a href="https://docs.jina.ai/fundamentals/executor/" rel="noopener ugc nofollow">Executor</a> straight from <a href="https://hub.jina.ai/" rel="noopener ugc nofollow">Jina Hub</a>, without having to worry about how to integrate the model manually. Let’s do it in a <a href="https://docs.jina.ai/how-to/sandbox/?highlight=sandbox#start-a-flow-using-jina-sandbox" rel="noopener ugc nofollow">sandbox</a> so we don’t have to worry about using our own compute:

``` python
from docarray import DocumentArray
from executors import ChunkSentencizer, ChunkMerger, ImageNormalizer
from jina import Flow

docs = DocumentArray.from_files("data/*.pdf", recursive=True)

flow = (
    Flow()
    .add(uses="jinahub+sandbox://PDFSegmenter", name="segmenter")
    .add(uses=ChunkSentencizer, name="chunk_sentencizer")
    .add(uses=ChunkMerger, name="chunk_merger")
    .add(uses=ImageNormalizer, name="image_normalizer")
    .add(uses="jinahub+sandbox://CLIPEncoder", name="encoder")
)

with flow:
  indexed_docs = flow.index(docs)
```

So far, so good. Let’s run the Flow, and see some summary info about:

- Our top-level Document.
- Each chunk-level of our top-level Document (i.e. the images and sentences).

``` python
with flow:
    indexed_docs = flow.index(docs, show_progress=True)

# See summary of indexed Documents
indexed_docs.sumamry()

# See summary of all the chunks of indexed Documents
indexed_docs[0].chunks.summary()
```

But if we run this code it’s going to choke:

- Errors like `encoder/rep-0@113300[E]:UnidentifiedImageError(‘cannot identify image file <_io.BytesIO object at 0x7fdc143e9810>’)`
- No mention of any `embedding` in our summaries.

So something somewhere failed.

Why? Because by default, Jina indexes on the Document level, not the chunk level. In our case, the top level PDF is largely meaningless — it’s the chunks (images and sentences) we want to work with. But even worse than that, CLIP is trying to read our PDF as an image (since that’s its default assumption) and choking on it!

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://media.tenor.com/YSGsAipI9E4AAAAC/sigh-smh.gif" class="kg-image" loading="lazy" width="498" height="387" />
<figcaption>It’s funny because the hairball is the PDF and the cat is CLIP and the human is me</figcaption>
</figure>

So let’s add a `traversal_path` so we can <a href="https://docarray.jina.ai/fundamentals/documentarray/access-elements/?highlight=delete&amp;utm_source=docarray#index-by-nested-structure" rel="noopener ugc nofollow">search within our nested structure</a> and ignore that big old scary PDF:

``` python
flow = (
    Flow()
    .add(uses="jinahub+sandbox://PDFSegmenter", name="segmenter")
    .add(uses=ChunkSentencizer, name="chunk_sentencizer")
    .add(uses=ChunkMerger, name="chunk_merger")
    .add(uses=ImageNormalizer, name="image_normalizer")
    .add(
        uses="jinahub+sandbox://CLIPEncoder",
        name="encoder",
        uses_with={"traversal_paths": "@c"},
    )
)
```

With a `traversal_path` of `"@c"` we’re traversing the first level of chunks in the Document. The <a href="https://docarray.jina.ai/fundamentals/documentarray/access-elements/?utm_source=docarray#index-by-nested-structure" rel="noopener ugc nofollow">syntax</a> for which level of chunks to traverse is quite straightforward:

- `"@c"` : Traverse first level of chunks
- `"@cc"` : Traverse second level chunks (third level is `"@ccc"` and so on…)
- `"@c, cc"` : Traverse first and second level chunks
- `[...]`: Traverse all chunks

This could come in handy if we wanted to segment, say, Animal Farm, because we could go by:

- Top-level `Document` : `animal_farm.pdf` .
- `"@c"` : chapter-level chunks.
- `"@cc"` : paragraph-level chunks.
- `"@ccc"` : sentence-level chunks.
- `"@cccc"` : word-level chunks.
- `"@ccccc"` : letter-level chunks (though why you’d want to do this is anyone’s guess).
- `[...]` : all of the above chunk-levels

Then we could choose what levels of input/output to give it (e.g. input a sentence, get matching paragraphs).

(Just to be clear, I’m an uncultured swine who hasn’t actually read Animal Farm. I assume it’s got chapters, paragraphs, etc, about lovely fluffy farm animals and is a charming book for children).

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://media.tenor.com/5jNGFRx4ZE4AAAAC/barnyard-hands-up.gif" class="kg-image" loading="lazy" width="498" height="278" />
<figcaption>This really was the first GIF result for “Animal Farm”</figcaption>
</figure>

Since we only have one level of chunks in our processed PDFs (i.e. sentences or images), we can stick with `"@c"` .

Now we can once again run our Flow and check our output with:

``` python
with flow:
    indexed_docs = flow.index(docs, show_progress=True)

# See summary of indexed Documents
indexed_docs.sumamry()

# See summary of all the chunks of indexed Documents
indexed_docs[0].chunks.summary()
```

For our top-level Document:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://miro.medium.com/max/1400/1*m9FcA2IcGZxRnaJPMwT8GQ.png" class="kg-image" loading="lazy" width="700" height="402" />
<figcaption>Great! We see one top-level Document with all the right attributes (lots of chunks, no embeddings)</figcaption>
</figure>

And now our chunks:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://miro.medium.com/max/1400/1*JepXwG0Sjj0LaB5Y0R3g1Q.png" class="kg-image" loading="lazy" width="700" height="349" />
<figcaption>It’s difficult to read, but that’s 1,326 chunks, and 1,336 embeddings</figcaption>
</figure>

Looks like we encoded those chunks successfully!

# Storing our chunks in an index

If we don’t store our chunks and embeddings in an index, they’ll just disappear into the ether when our program exits. All that effort will have been for nothing:

<figure class="kg-card kg-image-card">
<img src="https://media.tenor.com/mNDbnUmRCVcAAAAC/its-gone-chrisley-knows-best.gif" class="kg-image" loading="lazy" width="498" height="280" />
</figure>

In our case we’ll use <a href="https://hub.jina.ai/executor/zb38xlt4" rel="noopener ugc nofollow">SimpleIndexer</a> since we’re just building out the basics. For a real-world use case we might use a <a href="https://docarray.jina.ai/advanced/document-store/weaviate/?utm_source=docarray" rel="noopener ugc nofollow">Weaviate</a> or <a href="https://docarray.jina.ai/advanced/document-store/qdrant/?utm_source=docarray" rel="noopener ugc nofollow">Qdrant</a> backend, or a more powerful indexer (like <a href="https://hub.jina.ai/executor/pn1qofsj" rel="noopener ugc nofollow">PQLiteIndexer</a>) from Jina Hub.

Let’s add SimpleIndexer to our Flow. But first of all, one thing to note: we still need to bear our chunk-level in mind, so we’ll add a `traversal_right` parameter:

``` python
flow = (
    Flow()
    .add(uses="jinahub+sandbox://PDFSegmenter", name="segmenter")
    .add(uses=ChunkSentencizer, name="chunk_sentencizer")
    .add(uses=ChunkMerger, name="chunk_merger")
    .add(uses=ImageNormalizer, name="image_normalizer")
    .add(
        uses="jinahub+sandbox://CLIPEncoder",
        name="encoder",
        uses_with={"traversal_paths": "@c"},
    )
    .add(
        uses="jinahub://SimpleIndexer",
        install_requirements=True,
        name="indexer",
        uses_with={"traversal_right": "@c"},
    )
)
```

Now when we run our Flow we’ll see a `workspace` folder on our disk. If we run `tree workspace` we can see the structure:

``` text
workspace
└── SimpleIndexer
    └── 0
        └── index.db
2 directories, 1 file
```

And if we run `file workspace/SimpleIndexer/0/index.db` we can see that that’s just a SQLite file:

``` text
workspace/SimpleIndexer/0/index.db: SQLite 3.x database, last written using SQLite version 3038002, file counter 11, database pages 25110, cookie 0x2, schema 4, UTF-8, version-valid-for 11
```

Cool. That means it’s just using the DocArray <a href="https://docarray.jina.ai/advanced/document-store/sqlite/" rel="noopener ugc nofollow">SQLite Document Store</a>. So if we needed to we could write a few lines of code to load it direct from disk in future (and I mean future — we’re not getting sidetracked in this blog post, except for memes).

# Next time

We’ll leave searching through our data for our next post. Because:

- This post is already getting long.
- I still need to work out how best to skip several Executors when dealing with queries as input. Or use different Flows with one endpoint. Or something.

The latter point is important, because right now our Flow assumes our input is a PDF file and tries to break that down. If I send a text string to that same Flow it’s going to have difficulties:

<figure class="kg-card kg-image-card">
<img src="https://miro.medium.com/max/800/0*2t0_p39Tx8Mwmcuk.gif" class="kg-image" loading="lazy" width="400" height="225" />
</figure>

The precise difficulty being:

``` python
indexer/rep-0@124659[E]:ValueError('Empty ndarray. Did you forget to set .embedding/.tensor value and now you are operating on it?')
```

Because it’s expecting a PDF file. It doesn’t get that, so it just passes…nothingness down the Flow I guess. And since it’s nothing, there’s no embedding to work with.

Join me next time as I try to make something out of nothing. This will either mean:

- I single-handedly reverse entropy and nudge the universe towards a golden age.
- I start getting headaches from working with multiple Flows or weird switching.

Either way, fun to watch! In a schadenfreude way at least.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://miro.medium.com/max/1400/1*ZMwmcz2wcODi1x1KCC8aeQ.png" class="kg-image" loading="lazy" width="700" height="247" />
<figcaption>The song is better</figcaption>
</figure>

If you want to lend a hand (or a shoulder to cry on), or just talk with us about PDF search engines, join <a href="https://slack.jina.ai/" rel="noopener ugc nofollow">our community Slack</a> and get chatting!
