---
title: "Smaller, Faster, Cheaper: Introducing Jina Rerankers Turbo and Tiny"
slug: smaller-faster-cheaper-jina-rerankers-turbo-and-tiny
url: https://cms.jina.ai/smaller-faster-cheaper-jina-rerankers-turbo-and-tiny/
published_at: 2024-04-18T16:00:26.000+02:00
updated_at: 2024-07-08T21:11:05.000+02:00
reading_time: 7
authors: "Yuting Zhang, Scott Martens"
tags: "Press"
excerpt: "Jina AI announces new reranker models: Jina Rerankers Turbo (jina-reranker-v1-turbo-en) and Tiny (jina-reranker-v1-tiny-en), now available on AWS Sagemaker and Hugging Face, offering faster, memory-efficient, high-performance reranking."
---

# Smaller, Faster, Cheaper: Introducing Jina Rerankers Turbo and Tiny

Jina AI is announcing new models in its [family of state-of-the-art reranker models](https://jina.ai/reranker/), now available on AWS Sagemaker and Hugging Face: [`jina-reranker-v1-turbo-en`](https://huggingface.co/jinaai/jina-reranker-v1-turbo-en) and [`jina-reranker-v1-tiny-en`](https://huggingface.co/jinaai/jina-reranker-v1-tiny-en). These models prioritize speed and size while maintaining high performance on standard benchmarks, offering a faster and more memory-efficient reranking process for environments where response time and resource use are critical.

<figure class="kg-card kg-bookmark-card">
<a href="https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
AWS Marketplace: Jina AI
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://d32gc0xr2ho6pa.cloudfront.net/img/general/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://d32gc0xr2ho6pa.cloudfront.net/img/general/v2/socialPreview.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-reranker-v1-turbo-en" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-reranker-v1-turbo-en · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-reranker-v1-turbo-en.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-reranker-v1-tiny-en" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-reranker-v1-tiny-en · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-reranker-v1-tiny-en.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Reranker Turbo and Tiny are optimized for blazing-fast response times in information retrieval applications. Like our embedding models, they use the [JinaBERT architecture](https://jina.ai/news/jina-embeddings-2-the-best-solution-for-embedding-long-documents/), a variant of the BERT architecture enhanced with a [symmetric bidirectional variant of ALiBi](https://arxiv.org/abs/2310.19923v3). This architecture enables support for long text sequences, with our models accepting up to 8,192 tokens, ideal for deep analysis of larger documents and complex queries requiring detailed language understanding.

The Turbo and Tiny models draw on insights gained from [Jina Reranker v1](https://jina.ai/news/maximizing-search-relevancy-and-rag-accuracy-with-jina-reranker/). Reranking can be a major bottleneck for information retrieval applications. Traditional search applications are a very mature technology whose performance is well-understood. Rerankers add a great deal of precision to text-based retrieval, but AI models are large and can be slow and expensive to run.

Many users would prefer a smaller, faster, cheaper model, even if it comes at some cost to accuracy. Having a single goal – reranking search results – makes it possible to streamline the model and bring users competitive performance in much more compact models. **By using fewer hidden layers, we speed up processing and reduce model size.** These models cost less to run, and the greater speed makes them more useful for applications that can't tolerate much latency, while retaining nearly all of the performance of larger models.

In this article, we'll show you the architecture of Reranker Turbo and Reranker Tiny, measure its performance, and show you how to get started with them.

## Streamlined Architecture

Jine Reranker Turbo (`jina-reranker-v1-turbo-en`) uses a **six-layer architecture, with a total of 37.8 million parameters**, in contrast to the 137 million parameters and twelve layers of the base reranker model `jina-reranker-v1-base-en`. This represents a reduction in model size of three-quarters and as much as a tripling of processing speed.

Reranker Tiny (`jina-reranker-v1-tiny-en`) uses **four layers with 33 million parameters**, providing even greater parallel processing and faster speeds – almost five times as fast as the base Reranker model – while saving 13% of memory costs over the Turbo model.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/04/barchart_1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/04/barchart_1.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/04/barchart_1.png 1000w, https://cms.jina.ai/content/images/2024/04/barchart_1.png 1102w" sizes="(min-width: 720px) 720px" width="1102" height="675" alt="Graph comparing performance of Jina Reranker versions with bars representing documents processed per 50ms." />
<figcaption><span style="white-space: pre-wrap;">Document throughput for Jina Reranker models</span></figcaption>
</figure>

## Knowledge Distillation

We've trained Reranker Turbo and Tiny using [knowledge distillation](https://jina.ai/news/distilled-ai-using-large-models-to-teach-smaller-ones/). This is a technique for using an existing AI model to train another one to match its behavior. Instead of using external data sources, we use an existing model to generate data for training. We used the Jina Reranker base model to rank collections of documents and then used those results to train both Turbo and Tiny. This way, we can bring much more data into the training process because we aren't limited by available real-world data.

This is a bit like a student learning from a teacher: The already trained, high-performance model – the Jina Reranker Base model – "teaches" the untrained Jina Turbo and Jina Tiny models by generating new training data. This technique is widely used to create small models from large ones. At its best, the difference in task performance between the "teacher" model and the "student" can be very small.

## Evaluation on BEIR

The benefits of streamlining and knowledge distillation come at relatively little cost to performance quality. On the [BEIR benchmark](https://github.com/beir-cellar/beir) for information retrieval, `jina-reranker-v1-turbo-en` scores just under 95% of the accuracy of `jina-reranker-v1-base-en`, and `jina-reranker-v1-tiny-en` scores 92.5% of the base model's score.

All Jina Reranker models are competitive with other popular reranker models, most of which have much larger sizes.

| Model                       | BEIR Score (NDCC@10) | Parameters |
|-----------------------------|----------------------|------------|
| **Jina Reranker models**    |                      |            |
| `jina-reranker-v1-base-en`  | 52.45                | 137M       |
| `jina-reranker-v1-turbo-en` | 49.60                | 38M        |
| `jina-reranker-v1-tiny-en`  | 48.54                | 33M        |
| **Other reranking models**  |                      |            |
| `mxbai-rerank-base-v1`      | 49.19                | 184M       |
| `mxbai-rerank-xsmall-v1`    | 48.80                | 71M        |
| `ms-marco-MiniLM-L-6-v2`    | 48.64                | 23M        |
| `bge-reranker-base`         | 47.89                | 278M       |
| `ms-marco-MiniLM-L-4-v2`    | 47.81                | 19M        |

*NDCC@10*: Scores calculated using [Normalized Discounted Cumulative Gain](https://en.wikipedia.org/wiki/Discounted_cumulative_gain) for the top 10 results.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/04/beir_graph.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/04/beir_graph.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/04/beir_graph.png 1000w, https://cms.jina.ai/content/images/2024/04/beir_graph.png 1292w" sizes="(min-width: 720px) 720px" width="1292" height="753" alt="Chart displaying BEIR scores for various reranker projects, assessing model performance over documents processed per 50ms." />
<figcaption><span style="white-space: pre-wrap;">BEIR Benchmark: Throughput (x-axis) vs Score (y-axis)</span><em><em>(Note that the y-axis is not on the origin. We start with a higher BIER score value to enhance the readability of the graph.)</em></em></figcaption>
</figure>

Only [MiniLM-L6](https://huggingface.co/cross-encoder/ms-marco-MiniLM-L-6-v2) (`ms-marco-MiniLM-L-6-v2`) and [MiniLM-L4](https://huggingface.co/cross-encoder/ms-marco-MiniLM-L-4-v2) (`ms-marco-MiniLM-L-4-v2`) have comparable sizes and speeds, with `jina-reranker-v1-turbo-en` and `jina-reranker-v1-tiny-en` performing comparably or significantly better.

We get similar results on the [LlamaIndex RAG Benchmark](https://docs.llamaindex.ai/en/stable/examples/llama_dataset/labelled-rag-datasets/). We tested all three Jina Rerankers in a RAG setup using three embedding models for vector search (`jina-embeddings-v2-base-en`, `bge-base-en-v1.5`, and `Cohere-embed-english-v3.0`) and averaged the scores.

| Reranker Model              | Avg. Hit Rate | Avg. MRR |
|-----------------------------|---------------|----------|
| **Jina Reranker models**    |               |          |
| `jina-reranker-v1-base-en`  | 0.8439        | 0.7006   |
| `jina-reranker-v1-turbo-en` | 0.8351        | 0.6498   |
| `jina-reranker-v1-tiny-en`  | 0.8316        | 0.6761   |
| **Other reranking models**  |               |          |
| `mxbai-rerank-base-v1`      | 0.8105        | 0.6583   |
| `mxbai-rerank-xsmall-v1`    | 0.8193        | 0.6673   |
| `ms-marco-MiniLM-L-6-v2`    | 0.8052        | 0.6121   |
| `bge-reranker-base`         | 0.8175        | 0.6480   |
| `ms-marco-MiniLM-L-4-v2`    | 0.8246        | 0.6354   |

*MRR*: [Mean Reciprocal Rank](https://en.wikipedia.org/wiki/Mean_reciprocal_rank)

For retrieval-augmented generation (RAG) tasks, losses in result quality are even less than on the BEIR pure information retrieval benchmark. And when RAG performance is put up next to processing speed, we see that only `ms-marco-MiniLM-L-4-v2` provides significantly more throughput, at a significant cost in result quality.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/04/LlRag_graph.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/04/LlRag_graph.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/04/LlRag_graph.png 1000w, https://cms.jina.ai/content/images/2024/04/LlRag_graph.png 1291w" sizes="(min-width: 720px) 720px" width="1291" height="753" alt="Scatter plot showing hit rate versus document speed for language models, with highlighted ones like &quot;jina-reranker&quot; and &quot;ms-m" />
<figcaption><span style="white-space: pre-wrap;">LlamaIndex RAG Benchmark: Throughput (x-axis) vs Hit Rate (y-axis)</span><em><em>(Note that the y-axis is not on the origin. We start with a higher hit rate value to enhance the readability of the graph.)</em></em></figcaption>
</figure>

## Cost Savings on AWS

Using Reranker Turbo and Reranker Tiny provides large savings for AWS and Azure users who pay for memory usage and CPU time. Although the degree of savings varies for different use cases, the roughly 75% reduction in memory usage alone directly corresponds to a 75% savings for cloud systems charging for memory.

Furthermore, the faster throughput means that you can run more queries on cheaper AWS instances.

## Getting Started

Jina Reranker models are easy to use and integrate into your applications and workflow. To get started, you can visit the [Reranker API page](https://jina.ai/reranker/) to see how to use our service and get 1 million free tokens of access to try it out yourself.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/reranker/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Reranker API
</div>
<div class="kg-bookmark-description">
Maximize the search relevancy and RAG accuracy at ease
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina.ai/banner-reranker-api.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Our models are also [available in AWS SageMaker](https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy). For more information, see our [tutorial on how to set up a retrieval-augmented generation system in AWS](https://jina.ai/news/next-level-cloud-ai-jina-embeddings-and-rerankers-on-amazon-sagemaker).

<figure class="kg-card kg-bookmark-card">
<a href="https://aws.amazon.com/marketplace/seller-profile?id=seller-stch2ludm6vgy" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
AWS Marketplace: Jina AI
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://d32gc0xr2ho6pa.cloudfront.net/img/general/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://d32gc0xr2ho6pa.cloudfront.net/img/general/v2/socialPreview.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/next-level-cloud-ai-jina-embeddings-and-rerankers-on-amazon-sagemaker/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Next-Level Cloud AI: Jina Embeddings and Rerankers on Amazon SageMaker
</div>
<div class="kg-bookmark-description">
Learn to use Jina Embeddings and Reranking models in a full-stack AI application on AWS, using only components available in Amazon SageMaker and the AWS Marketplace.
</div>
<div class="kg-bookmark-metadata">
<img src="https://jina.ai/icons/favicon-128x128.png" class="kg-bookmark-icon" /><span class="kg-bookmark-publisher">Signup</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://jina-ai-gmbh.ghost.io/content/images/2024/03/Blog-images--27-.jpg" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

Jina Reranker models are also available for download under the <a href="https://www.apache.org/licenses/LICENSE-2.0" rel="noreferrer">Apache 2.0 license</a> from Hugging Face:

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-reranker-v1-turbo-en" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-reranker-v1-turbo-en · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-reranker-v1-turbo-en.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai/jina-reranker-v1-tiny-en" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai/jina-reranker-v1-tiny-en · Hugging Face
</div>
<div class="kg-bookmark-description">
We’re on a journey to advance and democratize artificial intelligence through open source and open science.
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/models/jinaai/jina-reranker-v1-tiny-en.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
