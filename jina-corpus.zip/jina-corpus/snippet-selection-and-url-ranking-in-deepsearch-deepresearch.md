---
title: "Snippet Selection and URL Ranking in DeepSearch/DeepResearch"
slug: snippet-selection-and-url-ranking-in-deepsearch-deepresearch
url: https://cms.jina.ai/snippet-selection-and-url-ranking-in-deepsearch-deepresearch/
published_at: 2025-03-12T14:20:43.000+01:00
updated_at: 2025-03-13T07:48:01.000+01:00
reading_time: 11
authors: "Han Xiao"
tags: "Tech Blog"
excerpt: "Nailing these two details takes your DeepSearch from mid to GOAT: selecting the best snippets from lengthy webpages and ranking URLs before crawling."
---

# Snippet Selection and URL Ranking in DeepSearch/DeepResearch

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/a-practical-guide-to-implementing-deepsearch-deepresearch" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
A Practical Guide to Implementing DeepSearch/DeepResearch
</div>
<div class="kg-bookmark-description">
QPS out, depth in. DeepSearch is the new norm. Find answers through read-search-reason loops. Learn what it is and how to build it.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-22.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Han Xiao</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/a-practical-guide-to-implementing-deepsearch-deepresearch-1.webp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

If you've already read our DeepSearch/DeepResearch implementation guide, let's dive deeper into some details that can *greatly* improve quality. In this post, we'll focus on two key challenges: **using** [**late-chunking**](https://jina.ai/news/late-chunking-in-long-context-embedding-models) **embeddings for snippet selection from lengthy webpages** and **using rerankers to prioritize URLs before crawling.**

Some might recall our previous conclusion stating that "embeddings were only useful for query deduplication like STS tasks (semantic textual similarity), while rerankers weren't even part of our original DeepSearch implementation." Well, it turns out both are still quite valuable - just not in the conventional way one might expect. We've always followed the *leanest* possible path. We don't add components just to justify their existence or our value as an embedding & reranker provider. **We're based - about what search really needs at its foundation.**

So after weeks iterations, we've discovered uncommon yet effective uses for both in DeepSearch/DeepResearch systems. By applying them, we've significantly improved the quality of <a href="https://search.jina.ai" rel="noreferrer">Jina DeepSearch</a> (feel free to try it). We'd like to share these insights with fellow practitioners working in this space.

## Select Snippet From Long Content

The problem is this: after [using Jina Reader to read webpage content](https://jina.ai/reader), we need to add it as a knowledge item to the agent's context for reasoning. While dumping the full content into the LLM's context is the simplest way, it's not optimal when considering token costs and generation speed. In practice, we need to identify which parts of the content are most relevant to the question and selectively add only those parts as knowledge to the agent's context.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

We're talking about the cases where content remains too lengthy even after Jina Reader's markdown cleaning. This occurs often with long pages like GitHub issues, Reddit threads, forum discussions, and blog posts (including many of our own from jina.ai/news).

</div>

</div>

LLM-based filtering has the same cost and latency issues, so let's find solutions of smaller models: we need smaller and cheaper, **yet still multilingual models** – a crucial factor since we can't guarantee either the query or the documents will always be in English.

We have a question on one side (either the original query or a gap question) and a large markdown content on the other side, where most content is irrelevant. We need to select the most relevant snippets for the query. This resembles the chunking problem the RAG community has grappled with since 2023 - retrieving only relevant chunks using retriever models to place in the context window for summarization. However, there are two key differences in our case:

1.  Limited chunks from limited number of documents. If each chunk contains roughly 500 tokens, then a typical long web document has around 200,000 tokens (p50) to 1,000,000 tokens (p99), and we use Jina Reader to fetch 4-5 URLs each step, this would yield approximately hundreds of chunks - meaning hundreds of embedding vectors and hundreds of cosine similarities. This is easily manageable with in-memory JavaScript without a vector database.
2.  We need consecutive chunks to form effective knowledge snippets. We can't accept snippets combining scattered sentences like `[1-2, 6-7, 9, 14, 17, ...].` A more useful knowledge snippet would follow patterns like `[3-15, 17-24, ...]` - always maintaining consecutive text. This makes it easier for the LLM to copy and cite from the knowledge source and reduces hallucination.

The rest is all the caveats practitioners complained about: each chunk can't be too long since embedding models can't handle long context well; chunking introduces context loss and makes chunk embeddings i.i.d; and how to even find the best boundary cues that maintain both readability and semantics? If you know what we're talking about, then you've likely been haunted by these issues in your RAG implementations.

But long story short - **late-chunking with `jina-embeddings-v3` beautifully solves all three problems.** Late chunking maintains the context info for each chunk, is [insensitive to boundary cues](https://jina.ai/news/what-late-chunking-really-is-and-what-its-not-part-ii#late-chunking-is-resilient-to-poor-boundary-cues), and `jina-embeddings-v3` itself is SOTA in *asymmetric* multilingual retrieval tasks. Interested readers can follow our blog posts or papers for details, but here's the overall implementation.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/Untitled-design--14-.svg" class="kg-image" loading="lazy" width="1200" height="1000" alt="Flow chart for &quot;Snippet Selection with Late Chunking&quot; outlining steps 1-5, including embedding with Jina and similarity scori" />
<figcaption><span style="white-space: pre-wrap;">This diagram illustrates the snippet selection algorithm, which works similarly to </span><span><code spellcheck="false" style="white-space: pre-wrap;">Conv1D</code></span><span style="white-space: pre-wrap;">. The process begins by splitting a long document into fixed-length chunks, which are then embedded with </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v3</code></span><span style="white-space: pre-wrap;"> with late-chunking toggle on. After calculating similarity scores between each chunk and the query, a sliding window moves across the similarity scores to find the window with the highest average value.</span></figcaption>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/what-late-chunking-really-is-and-what-its-not-part-ii" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
What Late Chunking Really Is &amp; What It’s Not: Part II
</div>
<div class="kg-bookmark-description">
Part 2 of our exploration of Late Chunking, a deep dive into why it is the best method for chunk embeddings and improving search/RAG performance.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-23.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span><span class="kg-bookmark-publisher">Han Xiao</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/what-late-chunking-really-is-and-what-its-not-part-ii.webp" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2409.10173" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jina-embeddings-v3: Multilingual Embeddings With Task LoRA
</div>
<div class="kg-bookmark-description">
We introduce jina-embeddings-v3, a novel text embedding model with 570 million parameters, achieves state-of-the-art performance on multilingual data and long-context retrieval tasks, supporting context lengths of up to 8192 tokens. The model includes a set of task-specific Low-Rank Adaptation (LoRA) adapters to generate high-quality embeddings for query-document retrieval, clustering, classification, and text matching. Evaluation on the MTEB benchmark shows that jina-embeddings-v3 outperforms the latest proprietary embeddings from OpenAI and Cohere on English tasks, while achieving superior performance compared to multilingual-e5-large-instruct across all multilingual tasks. With a default output dimension of 1024, users can flexibly reduce the embedding dimensions to as low as 32 without compromising performance, enabled by Matryoshka Representation Learning.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-9.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Saba Sturua</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/arxiv-logo-fb-5.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2409.04701" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Late Chunking: Contextual Chunk Embeddings Using Long-Context Embedding Models
</div>
<div class="kg-bookmark-description">
Many use cases require retrieving smaller portions of text, and dense vector-based retrieval systems often perform better with shorter text segments, as the semantics are less likely to be over-compressed in the embeddings. Consequently, practitioners often split text documents into smaller chunks and encode them separately. However, chunk embeddings created in this way can lose contextual information from surrounding chunks, resulting in sub-optimal representations. In this paper, we introduce a novel method called late chunking, which leverages long context embedding models to first embed all tokens of the long text, with chunking applied after the transformer model and just before mean pooling - hence the term late in its naming. The resulting chunk embeddings capture the full contextual information, leading to superior results across various retrieval tasks. The method is generic enough to be applied to a wide range of long-context embedding models and works without additional training. To further increase the effectiveness of late chunking, we propose a dedicated fine-tuning approach for embedding models.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-10.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Michael Günther</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/arxiv-logo-fb-6.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode javascript"><code class="sourceCode javascript"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="kw">function</span> <span class="fu">cherryPick</span>(question<span class="op">,</span> longContext<span class="op">,</span> options) {</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>  <span class="cf">if</span> (longContext<span class="op">.</span><span class="at">length</span> <span class="op">&lt;</span> options<span class="op">.</span><span class="at">snippetLength</span> <span class="op">*</span> options<span class="op">.</span><span class="at">numSnippets</span>)</span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>    <span class="cf">return</span> longContext<span class="op">;</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>  </span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> chunks <span class="op">=</span> <span class="fu">splitIntoChunks</span>(longContext<span class="op">,</span> options<span class="op">.</span><span class="at">chunkSize</span>)<span class="op">;</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>  </span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> chunkEmbeddings <span class="op">=</span> <span class="fu">getEmbeddings</span>(chunks<span class="op">,</span> <span class="st">&quot;retrieval.passage&quot;</span>)<span class="op">;</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> questionEmbedding <span class="op">=</span> <span class="fu">getEmbeddings</span>([question]<span class="op">,</span> <span class="st">&quot;retrieval.query&quot;</span>)[<span class="dv">0</span>]<span class="op">;</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>  </span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> similarities <span class="op">=</span> chunkEmbeddings<span class="op">.</span><span class="fu">map</span>(embed <span class="kw">=&gt;</span> </span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>    <span class="fu">cosineSimilarity</span>(questionEmbedding<span class="op">,</span> embed))<span class="op">;</span></span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>  </span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> chunksPerSnippet <span class="op">=</span> <span class="bu">Math</span><span class="op">.</span><span class="fu">ceil</span>(options<span class="op">.</span><span class="at">snippetLength</span> <span class="op">/</span> options<span class="op">.</span><span class="at">chunkSize</span>)<span class="op">;</span></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> snippets <span class="op">=</span> []<span class="op">;</span></span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a>  <span class="kw">const</span> similaritiesCopy <span class="op">=</span> [<span class="op">...</span>similarities]<span class="op">;</span></span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a>  </span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a>  <span class="cf">for</span> (<span class="kw">let</span> i <span class="op">=</span> <span class="dv">0</span><span class="op">;</span> i <span class="op">&lt;</span> options<span class="op">.</span><span class="at">numSnippets</span><span class="op">;</span> i<span class="op">++</span>) {</span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a>    <span class="kw">let</span> bestStartIndex <span class="op">=</span> <span class="dv">0</span><span class="op">;</span></span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a>    <span class="kw">let</span> bestScore <span class="op">=</span> <span class="op">-</span><span class="kw">Infinity</span><span class="op">;</span></span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a>    </span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a>    <span class="cf">for</span> (<span class="kw">let</span> j <span class="op">=</span> <span class="dv">0</span><span class="op">;</span> j <span class="op">&lt;=</span> similarities<span class="op">.</span><span class="at">length</span> <span class="op">-</span> chunksPerSnippet<span class="op">;</span> j<span class="op">++</span>) {</span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a>      <span class="kw">const</span> windowScores <span class="op">=</span> similaritiesCopy<span class="op">.</span><span class="fu">slice</span>(j<span class="op">,</span> j <span class="op">+</span> chunksPerSnippet)<span class="op">;</span></span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a>      <span class="kw">const</span> windowScore <span class="op">=</span> <span class="fu">average</span>(windowScores)<span class="op">;</span></span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a>      </span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a>      <span class="cf">if</span> (windowScore <span class="op">&gt;</span> bestScore) {</span>
<span id="cb1-26"><a href="#cb1-26" aria-hidden="true" tabindex="-1"></a>        bestScore <span class="op">=</span> windowScore<span class="op">;</span></span>
<span id="cb1-27"><a href="#cb1-27" aria-hidden="true" tabindex="-1"></a>        bestStartIndex <span class="op">=</span> j<span class="op">;</span></span>
<span id="cb1-28"><a href="#cb1-28" aria-hidden="true" tabindex="-1"></a>      }</span>
<span id="cb1-29"><a href="#cb1-29" aria-hidden="true" tabindex="-1"></a>    }</span>
<span id="cb1-30"><a href="#cb1-30" aria-hidden="true" tabindex="-1"></a>    </span>
<span id="cb1-31"><a href="#cb1-31" aria-hidden="true" tabindex="-1"></a>    <span class="kw">const</span> startIndex <span class="op">=</span> bestStartIndex <span class="op">*</span> options<span class="op">.</span><span class="at">chunkSize</span><span class="op">;</span></span>
<span id="cb1-32"><a href="#cb1-32" aria-hidden="true" tabindex="-1"></a>    <span class="kw">const</span> endIndex <span class="op">=</span> <span class="bu">Math</span><span class="op">.</span><span class="fu">min</span>(startIndex <span class="op">+</span> options<span class="op">.</span><span class="at">snippetLength</span><span class="op">,</span> longContext<span class="op">.</span><span class="at">length</span>)<span class="op">;</span></span>
<span id="cb1-33"><a href="#cb1-33" aria-hidden="true" tabindex="-1"></a>    snippets<span class="op">.</span><span class="fu">push</span>(longContext<span class="op">.</span><span class="fu">substring</span>(startIndex<span class="op">,</span> endIndex))<span class="op">;</span></span>
<span id="cb1-34"><a href="#cb1-34" aria-hidden="true" tabindex="-1"></a>    </span>
<span id="cb1-35"><a href="#cb1-35" aria-hidden="true" tabindex="-1"></a>    <span class="cf">for</span> (<span class="kw">let</span> k <span class="op">=</span> bestStartIndex<span class="op">;</span> k <span class="op">&lt;</span> bestStartIndex <span class="op">+</span> chunksPerSnippet<span class="op">;</span> k<span class="op">++</span>)</span>
<span id="cb1-36"><a href="#cb1-36" aria-hidden="true" tabindex="-1"></a>      similaritiesCopy[k] <span class="op">=</span> <span class="op">-</span><span class="kw">Infinity</span><span class="op">;</span></span>
<span id="cb1-37"><a href="#cb1-37" aria-hidden="true" tabindex="-1"></a>  }</span>
<span id="cb1-38"><a href="#cb1-38" aria-hidden="true" tabindex="-1"></a>  </span>
<span id="cb1-39"><a href="#cb1-39" aria-hidden="true" tabindex="-1"></a>  <span class="cf">return</span> snippets<span class="op">.</span><span class="fu">join</span>(<span class="st">&quot;</span><span class="sc">\n\n</span><span class="st">&quot;</span>)<span class="op">;</span></span>
<span id="cb1-40"><a href="#cb1-40" aria-hidden="true" tabindex="-1"></a>}</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Using late chunking and Conv1D-like mean pooling for selecting the best snippet w.r.t. the question.</span></p></figcaption>
</figure>

Make sure you call Jina Embeddings API with retrieval `task` , `late_chunking` and `truncate` set as bellow:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode javascript"><code class="sourceCode javascript"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="cf">await</span> axios<span class="op">.</span><span class="fu">post</span>(</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>  <span class="st">&#39;https://api.jina.ai/v1/embeddings&#39;</span><span class="op">,</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>  {</span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>    <span class="dt">model</span><span class="op">:</span> <span class="st">&quot;jina-embeddings-v3&quot;</span><span class="op">,</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>    <span class="dt">task</span><span class="op">:</span> <span class="st">&quot;retrieval.passage&quot;</span><span class="op">,</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>    <span class="dt">late_chunking</span><span class="op">:</span> <span class="kw">true</span><span class="op">,</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>    <span class="dt">input</span><span class="op">:</span> chunks<span class="op">,</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>    <span class="dt">truncate</span><span class="op">:</span> <span class="kw">true</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>  }<span class="op">,</span> </span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>  { headers })<span class="op">;</span> </span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">For embedding question, make sure to change </span><span><code spellcheck="false" style="white-space: pre-wrap;">task</code></span><span style="white-space: pre-wrap;"> to </span><span><code spellcheck="false" style="white-space: pre-wrap;">retrieval.query</code></span><span style="white-space: pre-wrap;"> and toggle off </span><span><code spellcheck="false" style="white-space: pre-wrap;">late_chunking</code></span></p></figcaption>
</figure>

The full implementation can be found on Github:

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/node-DeepResearch/blob/main/src/tools/jina-latechunk.ts" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
node-DeepResearch/src/tools/jina-latechunk.ts at main · jina-ai/node-DeepResearch
</div>
<div class="kg-bookmark-description">
Keep searching, reading webpages, reasoning until it finds the answer (or exceeding the token budget) - jina-ai/node-DeepResearch
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-5.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/0921e515-0139-4540-bca4-52042b49328c-2" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## Rank URL for Next Read

The problem is this: during a DeepSearch session, you'll likely collect a lot of URLs from search engine result pages (SERP) and discover even more every time you read individual webpages (those on-page links). The total count of unique URLs can easily reach the hundreds. Again, simply dumping all URLs directly into the LLM's context is inefficient - it wastes valuable context-length and more problematically, **we found LLMs essentially pick URLs at random.** It's crucial to guide the LLM toward URLs that have the highest probability of containing the answer you need.

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode bash"><code class="sourceCode bash"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="ex">curl</span> https://r.jina.ai/https://example.com <span class="dt">\</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>  <span class="at">-H</span> <span class="st">&quot;Accept: application/json&quot;</span> <span class="dt">\</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>  <span class="at">-H</span> <span class="st">&quot;Content-Type: application/json&quot;</span> <span class="dt">\</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>  <span class="at">-H</span> <span class="st">&quot;X-Retain-Images: none&quot;</span> <span class="dt">\</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>  <span class="at">-H</span> <span class="st">&quot;X-Md-Link-Style: discarded&quot;</span> <span class="dt">\</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>  <span class="at">-H</span> <span class="st">&quot;X-Timeout: 20&quot;</span> <span class="dt">\</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>  <span class="at">-H</span> <span class="st">&quot;X-With-Links-Summary: all&quot;</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Best option for using Jina Reader to crawl a page in DeepSearch. This will collect all on-page links in a separate </span><span><code spellcheck="false" style="white-space: pre-wrap;">links</code></span><span style="white-space: pre-wrap;"> field, and removing them from the </span><span><code spellcheck="false" style="white-space: pre-wrap;">content</code></span><span style="white-space: pre-wrap;"> field.</span></p></figcaption>
</figure>

Think of this problem as an in-context PageRank where we need to weight hundreds of URLs during a session. We rank URLs based on multiple factors that combine last update time, domain frequency, path structure, and most importantly, semantic relevance to the query to create a composite score. Remember we can only use the information that's available *before* actually visiting the URL:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2025/03/url-ranking-illustration--2-.svg" class="kg-image" loading="lazy" width="199" height="150" alt="Infographic detailing a URL ranking system in deep search, including updated time, frequency signals, path structure, and opt" />
</figure>

**Frequency Signals**: URLs that appear multiple times across different sources receive additional weight. URLs from domains that appear frequently in search results receive a boost, as popular domains often contain authoritative content.

**Path Structure**: We analyze URL paths to identify content clusters. URLs within common path hierarchies receive higher scores, with a decay factor applied to deeper paths.

**Semantic Relevance**: We use `jina-reranker-v2-base-multilingual` to assess the semantic relevance between the question and the textual info of each URL, which is <a href="https://jina.ai/reranker/#what_reranker" rel="noreferrer">a classic reranking problem</a>. The textual info of each URL comes from:

- Title & snippets from SERP API results (`https://s.jina.ai/` with `'X-Respond-With': 'no-content'`)
- Anchor text of on-page URLs (`https://r.jina.ai` with `'X-With-Links-Summary': 'all'`)

**Last Updated Time**: Some DeepSearch queries are time-sensitive, so recently updated URLs are more valuable than older ones. Without being a major search engine like Google, reliably determining last update time is challenging. We've implemented a multi-layered approach that combines the following signal and provide a confidence-scored timestamp that prioritize fresher content when needed.

- SERP API filters (such as s.jina.ai's `tbs` parameter for filtering by recency)
- HTTP header analysis (Last-Modified, ETag)
- Metadata extraction (meta tags, Schema.org timestamps)
- Content pattern recognition (visible dates in HTML)
- CMS-specific indicators for platforms like WordPress, Drupal, and Ghost

**Gated Content:** Some content on social media platforms is gated or simply behind paywalls, and without logging in or violating their ToS, there's no legitimate way to fetch this content. We should actively maintain a list of problematic URLs and hostnames to lower their rankings, preventing wasted time on unaccessible content.

**Domain Diversity:** In some cases, the highest-weighted URLs all come from the same hostnames, which can trap DeepSearch in a local optimum and reduce the final quality of results. Check the above examples where all top URLs are from StackOverflow. To improve diversity, we can implement an explore-exploit approach by selecting the top-k highest-ranked URLs from each hostname.

The full implementation of ranking URLs can be found on our Github.

<figure class="kg-card kg-bookmark-card">
<a href="https://github.com/jina-ai/node-DeepResearch/blob/main/src/utils/url-tools.ts#L192" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
node-DeepResearch/src/utils/url-tools.ts at main · jina-ai/node-DeepResearch
</div>
<div class="kg-bookmark-description">
Keep searching, reading webpages, reasoning until it finds the answer (or exceeding the token budget) - jina-ai/node-DeepResearch
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/pinned-octocat-093da3e6fa40-6.svg" class="kg-bookmark-icon" /><span class="kg-bookmark-author">GitHub</span><span class="kg-bookmark-publisher">jina-ai</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/0921e515-0139-4540-bca4-52042b49328c-3" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode xml"><code class="sourceCode xml"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>&lt;<span class="kw">action-visit</span>&gt;</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>- Crawl and read full content from URLs, you can get the fulltext, last updated datetime etc of any URL.  </span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>- Must check URLs mentioned in &lt;<span class="kw">question</span>&gt; if any</span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>- Choose and visit relevant URLs below for more knowledge. higher weight suggests more relevant:</span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>&lt;<span class="kw">url-list</span>&gt;</span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>  + weight: 0.20 &quot;https://huggingface.co/docs/datasets/en/loading&quot;: &quot;Load - Hugging FaceThis saves time because instead of waiting for the Dataset builder download to time out, Datasets will look directly in the cache. Set the environment ...Some datasets may have more than one version based on Git tags, branches, or commits. Use the revision parameter to specify the dataset version you want to load ...&quot;</span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>  + weight: 0.20 &quot;https://huggingface.co/docs/datasets/en/index&quot;: &quot;Datasets - Hugging Face🤗 Datasets is a library for easily accessing and sharing datasets for Audio, Computer Vision, and Natural Language Processing (NLP) tasks. Load a dataset in a ...&quot;</span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>  + weight: 0.17 &quot;https://github.com/huggingface/datasets/issues/7175&quot;: &quot;[FSTimeoutError] load_dataset · Issue #7175 · huggingface/datasetsWhen using load_dataset to load HuggingFaceM4/VQAv2, I am getting FSTimeoutError. Error TimeoutError: The above exception was the direct cause of the following ...&quot;</span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>  + weight: 0.15 &quot;https://github.com/huggingface/datasets/issues/6465&quot;: &quot;`load_dataset` uses out-of-date cache instead of re-downloading a ...When a dataset is updated on the hub, using load_dataset will load the locally cached dataset instead of re-downloading the updated dataset.&quot;</span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>  + weight: 0.12 &quot;https://stackoverflow.com/questions/76923802/hugging-face-http-request-on-data-from-parquet-format-when-the-only-way-to-get-i&quot;: &quot;Hugging face HTTP request on data from parquet format when the ...I&#39;ve had to get the data from their data viewer using the parquet option. But when I try to run it, there is some sort of HTTP error. I&#39;ve tried downloading ...&quot;</span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>&lt;/<span class="kw">url-list</span>&gt;</span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>&lt;/<span class="kw">action-visit</span>&gt;</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Remember to put URL weights in the agent's context and instruct LLMs to respect the weights.</span></p></figcaption>
</figure>

## Conclusion

Since our DeepSearch release on February 2nd 2025, we've discovered two implementation details that greatly improved quality. In both cases, multilingual embeddings and rerankers are used in an *"in-context"* manner - operating at a much smaller scale than the traditional pre-computed indices these models typically require.

This points to a polarization in search engineering future. Consider a framework analogous to Kahneman's dual-process theory:

- Fast-think (grep, BM25, SQL): Quick, rule-governed pattern matching with minimal computational demands.
- Slow-think (LLM): Comprehensive reasoning with deep contextual understanding, requiring significant computation.
- Mid-think (embeddings, rerankers): Caught in limbo? Too "advanced"/semantic for simple pattern matching yet lacking true reasoning capabilities to achieve best precision@1.

As a consequence, we may be witnessing the popularity of a bifurcated architecture where lightweight, efficient SQL/BM25 handles content retrieval on the left hand side, feeding *directly* into LLMs for deep processing on the right hand side. The remaining role for mid-think models shifts to in-context tasks only such as filtering, deduplication, and sorting where full reasoning would be inefficient.

Nevertheless, selecting critical snippets and ranking URLs remain fundamental components with direct impact on DeepSearch/DeepResearch system quality. We hope our insights spark improvements in your own implementations.

Query expansion continues to be another crucial quality determinant. We're actively evaluating multiple approaches—ranging from basic prompt-based rewrites to small language models and reasoning-based methods. Look for our upcoming findings on this front soon. Stay tuned.
