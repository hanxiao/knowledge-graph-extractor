---
title: "Still Need Chunking When Long-Context Models Can Do It All?"
slug: still-need-chunking-when-long-context-models-can-do-it-all
url: https://cms.jina.ai/still-need-chunking-when-long-context-models-can-do-it-all/
published_at: 2024-12-05T00:55:21.000+01:00
updated_at: 2024-12-09T09:51:11.000+01:00
reading_time: 13
authors: "Michael Günther, Alex C-G"
tags: "Tech Blog"
excerpt: "Comparing how long-context embedding models perform with different chunking strategies to find the optimal approach for your needs."
---

# Still Need Chunking When Long-Context Models Can Do It All?

In October 2023, we introduced `jina-embeddings-v2`, the first open-source embedding model family capable of handling inputs up to 8,192 tokens. Building on this, this year we launched `jina-embeddings-v3`, offering the same extensive input support with further enhancements.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings v3: A Frontier Multilingual Embedding Model
</div>
<div class="kg-bookmark-description">
jina-embeddings-v3 is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-14.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/v3banner-4.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

In this post we’ll dig into long context embeddings and answer some questions: When is it practical to consolidate such a large volume of text into a single vector? Does segmentation enhance retrieval, and if so, how? How can we preserve context from different parts of a document while segmenting the text?

To answer these questions, we’ll compare several methods for generating embeddings:

- Long context embedding (encoding up to 8,192 tokens in a document) vs short context (i.e. truncating at 192 tokens).
- No chunking vs. naive chunking vs. [late chunking](https://jina.ai/news/late-chunking-in-long-context-embedding-models/).
- Different chunk sizes with both naive and late chunking.

## Is Long Context Even Useful?

With the ability to encode up to ten pages of text in a single embedding, long context embedding models open up possibilities for large-scale text representation. Is that even useful though? According to a lot of people…no.

<figure class="kg-card kg-gallery-card kg-width-wide kg-card-hascaption">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/12/image--15-.png" loading="lazy" width="559" height="88" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/12/image--16-.png" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--16-.png 600w, https://cms.jina.ai/content/images/2024/12/image--16-.png 610w" width="610" height="117" />
</div>
</div>
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/12/image--14-.png" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--14-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image--14-.png 1000w, https://cms.jina.ai/content/images/2024/12/image--14-.png 1430w" sizes="(min-width: 720px) 720px" width="1430" height="140" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/12/image--13-.png" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--13-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image--13-.png 1000w, https://cms.jina.ai/content/images/2024/12/image--13-.png 1506w" sizes="(min-width: 720px) 720px" width="1506" height="136" />
</div>
</div>
</div>
<figcaption><p><span style="white-space: pre-wrap;">Sources: </span><a href="https://www.youtube.com/watch?v=xKR08kDY2q4"><span style="white-space: pre-wrap;">Quote from Nils Reimer in How AI Is Built podcast</span></a><span style="white-space: pre-wrap;">, </span><a href="https://x.com/brainlag/status/1717221138483331158"><span style="white-space: pre-wrap;">brainlag tweet</span></a><span style="white-space: pre-wrap;">, </span><a href="https://news.ycombinator.com/item?id=38026784"><span style="white-space: pre-wrap;">egorfine Hacker News comment</span></a><span style="white-space: pre-wrap;">, </span><a href="https://news.ycombinator.com/item?id=38020753"><span style="white-space: pre-wrap;">andy99 Hacker News comment</span></a></p></figcaption>
</figure>

We’re going to address all of these concerns with a detailed investigation of long-context capabilities, when long context is helpful, and when you should (and shouldn’t) use it. But first, let’s hear those skeptics out and look at some of the issues long-context embedding models face.

## Problems with Long-Context Embeddings

Imagine we’re building a document search system for articles, like those on our [Jina AI blog](https://jina.ai/news). Sometimes a single article may cover multiple topics, like the [report about our visit to the ICML 2024 conference](https://jina.ai/news/what-we-learned-at-icml2024-ft-plag-xrm-tinybenchmark-magiclens-prompt-sketching-etc), which contains:

- An introduction, capturing general information about ICML (number of participants, location, scope, etc).
- The presentation of our work (`jina-clip-v1`).
- Summaries of other interesting research papers presented at ICML.

If we create just a single embedding for this article, that one embedding represents a mixture of three disparate topics:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/image.png 1600w, https://cms.jina.ai/content/images/2024/12/image.png 2048w" sizes="(min-width: 720px) 720px" width="2000" height="778" alt="Scientific diagram illustrating the process of incorporating semantic models, including elements like &#39;Embedding Models&#39; and " />
<figcaption><span style="white-space: pre-wrap;">Figure 1: When embedding a document that covers multiple topics, the resulting vector represents a blend of all paragraphs, potentially losing the distinct, specific information contained in each individual paragraph.</span></figcaption>
</figure>

This leads to several problems:

- **Representation Dilution:** While all topics in a given text *could* be related, only one may be relevant to a user’s search query. However, a single embedding (in this case, that of the whole blog post) is just one point in the vector space. As more text is added to the model’s input, the embedding shifts to capture the overall topic of the article, making it less effective in representing content covered in specific paragraphs.
- **Limited Capacity:** Embedding models produce vectors of a fixed size, independent of input length. As more content is added to the input, it gets harder for the model to represent all this information in the vector. Think of it like scaling an image down to 16×16 pixels — If you scale an image of something simple, like an apple, you can still derive meaning from the scaled image. Scaling down a street map of Berlin? Not so much.
- **Information Loss:** In some cases, even long-context embedding models hit their limits; Many models support text encoding with up to 8,192 tokens. Longer documents need to be truncated before embedding, leading to information loss. If the information relevant to the user is located at the end of the document, it won’t be captured by the embedding at all.
- **You May *Need* Text Segmentation:** Some applications require embeddings for specific segments of the text but not for the entire document, like identifying the relevant passage in a text.

## Long Context vs. Truncation

To see whether long context is worthwhile at all, let’s look at the performance of two retrieval scenarios:

- Encoding documents up to 8,192 tokens (about 10 pages of text).
- Truncating documents at 192 tokens and encoding up to there.

We’ll compare results using `jina-embeddings-v3` with the nDCG@10 retrieval metric. We tested the following datasets:

| Dataset | Description | Query Example | Document Example | Mean Document Length (characters) |
|----|----|----|----|----|
| [**NFCorpus**](https://www.cl.uni-heidelberg.de/statnlpgroup/nfcorpus/) | A full-text medical retrieval dataset with 3,244 queries and documents mostly from PubMed. | "Using Diet to Treat Asthma and Eczema" | "Statin Use and Breast Cancer Survival: A Nationwide Cohort Study from Finland Recent studies have suggested that \[...\]" | 326,753 |
| [**QMSum**](https://github.com/Yale-LILY/QMSum) | A query-based meeting summarization dataset requiring summarization of relevant meeting segments. | "The professor was the one to raise the issue and suggested that a knowledge engineering trick \[...\]" | "Project Manager: Is that alright now ? {vocalsound} Okay . Sorry ? Okay , everybody all set to start the meeting ? \[...\]" | 37,445 |
| [**NarrativeQA**](https://paperswithcode.com/dataset/narrativeqa) | QA dataset featuring long stories and corresponding questions about specific content. | "What kind of business Sophia owned in Paris?" | "ï»¿The Project Gutenberg EBook of The Old Wives' Tale, by Arnold Bennett\n\nThis eBook is for the use of anyone anywhere \[...\]" | 53,336 |
| [**2WikiMultihopQA**](https://github.com/Alab-NII/2wikimultihop) | A multi-hop QA dataset with up to 5 reasoning steps, designed with templates to avoid shortcuts. | "What is the award that the composer of song The Seeker (The Who Song) earned?" | "Passage 1:\nMargaret, Countess of Brienne\nMarguerite d'Enghien (born 1365 - d. after 1394), was the ruling suo jure \[...\]" | 30,854 |
| [**SummScreenFD**](https://arxiv.org/abs/2104.07091) | A screenplay summarization dataset with TV series transcripts and summaries requiring dispersed plot integration. | "Penny gets a new chair, which Sheldon enjoys until he finds out that she picked it up from \[...\]" | "\[EXT. LAS VEGAS CITY (STOCK) - NIGHT\]\n\[EXT. ABERNATHY RESIDENCE - DRIVEWAY -- NIGHT\]\n(The lamp post light over the \[...\]" | 1,613 |

As we can see, encoding more than 192 tokens can give notable performance improvements:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image-1.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image-1.png 1000w, https://cms.jina.ai/content/images/2024/12/image-1.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="600" alt="Bar chart titled &#39;Jina-Embeddings-V3&#39; comparing performance of embedding tools with metrics plotted on the y-axis against a b" />
<figcaption><span style="white-space: pre-wrap;">Figure 2: Comparison of Long-Context Embedding Performance and Short Text Embedding Performance</span></figcaption>
</figure>

However, on some datasets, we see bigger improvements than on others:

- For **NFCorpus**, truncation barely makes a difference. This is because the titles and abstracts are right at the start of the documents, and these are highly relevant to typical user search terms. Whether truncated or not, the most pertinent data remains within the token limit.
- **QMSum** and **NarrativeQA** are considered "reading comprehension" tasks, where users typically search for specific facts within a text. These facts are often embedded in details scattered across the document, and may fall outside the truncated 192-token limit. For instance, in the NarrativeQA document *Percival Keene*, the question "Who is the bully that steals Percival's lunch?" is answered well beyond this limit. Similarly, in **2WikiMultiHopQA**, relevant information is dispersed throughout entire documents, requiring models to navigate and synthesize knowledge from multiple sections to answer queries effectively.
- **SummScreenFD** is a task aimed at identifying the screenplay corresponding to a given summary. Because the summary encompasses information distributed across the screenplay, encoding more of the text improves the accuracy of matching the summary to the correct screenplay.

## Segmenting Text for Better Retrieval Performance

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

Moving forwards, we discuss three similar concepts. To avoid confusion, we refer them as follows:  
• ****Segmentation****: Detecting boundary cues in an input text, for example, sentences or a fixed number of tokens.  
• ****Naive chunking****: Breaking the text into chunks based on segmentation cues, prior to encoding it.  
• [****Late chunking****](https://jina.ai/news/late-chunking-in-long-context-embedding-models/): Encoding the document first and then segmenting it (preserving context between chunks).

</div>

</div>

Instead of embedding an entire document into one vector, we can use various methods to first segment the document by assigning boundary cues:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/chunking-animation.gif" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/chunking-animation.gif 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/chunking-animation.gif 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/chunking-animation.gif 1600w, https://cms.jina.ai/content/images/size/w2400/2024/12/chunking-animation.gif 2400w" sizes="(min-width: 720px) 720px" width="2000" height="492" alt="Black background image featuring the poem &quot;Books are like doors to new worlds...&quot; with different text processing styles label" />
<figcaption><span style="white-space: pre-wrap;">Figure 3: Applying “Fixed-Size”, “Sentence-Based”, and “Semantic” chunking method to a text passage</span></figcaption>
</figure>

Some common methods include:

- **Segmenting by fixed size:** The document is divided into segments of a fixed number of tokens, determined by the embedding model’s tokenizer. This ensures the tokenization of the segments corresponds to the tokenization of the entire document (segmenting by a specific number of characters could lead to a different tokenization).
- **Segmenting by sentence:** The document is segmented into sentences, and each chunk consists of *n* number of sentences.
- **Segmenting by semantics:** Each segment corresponds to multiple sentences and an embedding model determines the similarity of consecutive sentences. Sentences with high embedding similarities are assigned to the same chunk.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

You can easily perform segmentation with [Jina Segmenter](https://jina.ai/segmenter/), our free API for segmenting long text into chunks and tokenization based on the structure of the document.

</div>

</div>

For simplicity, we use fixed-size segmentation in this article.

### Document Retrieval Using Naive Chunking

Once we’ve performed fixed-size segmentation, we can naively chunk the document according to those segments:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/Sharing-Chunking-Blog-Post-Images--1---1-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/Sharing-Chunking-Blog-Post-Images--1---1-.png 600w, https://cms.jina.ai/content/images/2024/12/Sharing-Chunking-Blog-Post-Images--1---1-.png 960w" sizes="(min-width: 720px) 720px" width="960" height="540" alt="Screenshot showing comparative analysis between text excerpts in &quot;Document 1&quot; and annotations, focused on themes of books and" />
<figcaption><span style="white-space: pre-wrap;">Figure 4: Naive chunking based on boundary cues detected during segmentation.</span></figcaption>
</figure>

Using `jina-embeddings-v3`, we encode each chunk into an embedding that accurately captures its semantics, then store those embeddings in a vector database.

At runtime, the model encodes a user’s query to a query vector. We compare this against our vector database of chunk embeddings to find the chunk with the highest cosine similarity, and then return the corresponding document to the user:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image--17-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--17-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image--17-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/image--17-.png 1600w, https://cms.jina.ai/content/images/size/w2400/2024/12/image--17-.png 2400w" sizes="(min-width: 720px) 720px" width="2000" height="847" alt="Diagram showcasing document embedding process with blocks for &#39;Doc ID&#39;, &#39;Chunk ID&#39;, and &#39;Embedding&#39;." />
<figcaption><span style="white-space: pre-wrap;">Figure 5: Document retrieval implemented with naive chunking: (1) The documents in the collection are split into chunks based on boundary cues, (2) the embedding model encodes all chunks and we store the resulting embeddings in a database, (3) when a query comes in, the embedding model encodes it and the database determines the most similar chunk. At the end we identify the relevant document from the document ID stored for the chunk in the database and return it to the user.</span></figcaption>
</figure>

### Problems with Naive Chunking

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image--18-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--18-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image--18-.png 1000w, https://cms.jina.ai/content/images/size/w1600/2024/12/image--18-.png 1600w, https://cms.jina.ai/content/images/2024/12/image--18-.png 1774w" sizes="(min-width: 720px) 720px" width="1774" height="456" alt="Text excerpt from a Wikipedia article about Berlin highlighting its status as Germany&#39;s capital and its demographic details." />
<figcaption><span style="white-space: pre-wrap;">Figure 6: When chunking a text into sentences, references to earlier parts of the text cannot be resolved.</span></figcaption>
</figure>

While naive chunking addresses some of the limitations of long-context embedding models, it also has its downsides:

- **Missing the Bigger Picture:** When it comes to document retrieval, multiple embeddings of smaller chunks may fail to capture the document’s overall topic. Think of not being able to see the forest for the trees.
- **Missing Context Problem:** Chunks can’t be interpreted accurately as context information is missing, as illustrated in Figure 6.
- **Efficiency:** More chunks require more storage and increase retrieval time.

## Late Chunking Solves the Context Problem

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

To solve the problem of missing context, we introduced a novel method called “late chunking”, described in our previous blog posts: [****part I****](https://jina.ai/news/late-chunking-in-long-context-embedding-models/), [****part II****](https://jina.ai/news/what-late-chunking-really-is-and-what-its-not-part-ii/), [****part III****](https://jina.ai/news/finding-optimal-breakpoints-in-long-documents-using-small-language-models), [****research paper****](https://arxiv.org/abs/2409.04701).

</div>

</div>

Late chunking works in two main steps:

1.  First, it uses the model's long-context capabilities to encode the entire document into token embeddings. This preserves the full context of the document.
2.  Then, it creates chunk embeddings by applying mean pooling to specific sequences of token embeddings, corresponding to the boundary cues identified during segmentation.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image--19-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--19-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image--19-.png 1000w, https://cms.jina.ai/content/images/2024/12/image--19-.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="865" alt="Diagram comparing &#39;Naive Chunking&#39; and &#39;Late Chunking&#39;, depicting algorithm steps with labels, and emphasizing the &#39;Late&#39; app" />
<figcaption><span style="white-space: pre-wrap;">Figure 7: Late vs naive chunking.</span></figcaption>
</figure>

The key advantage of this approach is that the token embeddings are contextualized - meaning they naturally capture references and relationships to other parts of the document. Since the embedding process happens before chunking, each chunk retains awareness of the broader document context, solving the missing context problem that plagues naive chunking approaches.

For documents that exceed the model's maximum input size, we can use "long late chunking":

1.  First, we break the document into overlapping "macro-chunks." Each macro-chunk is sized to fit within the model's maximum context length (for example, 8,192 tokens).
2.  The model processes these macro-chunks to create token embeddings.
3.  Once we have the token embeddings, we proceed with standard late chunking - applying mean pooling to create the final chunk embeddings.

This approach allows us to handle documents of any length while still preserving the benefits of late chunking. Think of it as a two-stage process: first making the document digestible for the model, then applying the regular late chunking procedure.

In short:

- **Naive chunking:** Segment the document into small chunks, then encode each chunk separately.
- **Late chunking:** Encode the entire document at once to create token embeddings, then create chunk embeddings by pooling the token embeddings based on segment boundaries.
- **Long late chunking:** Split large documents into overlapping macro-chunks that fit the model's context window, encode these to get token embeddings, then apply late chunking as normal.

For a more extensive description of the idea, take a look at our [paper](https://arxiv.org/abs/2409.04701) or the blog posts mentioned above.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2409.04701" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Late Chunking: Contextual Chunk Embeddings Using Long-Context Embedding Models
</div>
<div class="kg-bookmark-description">
Many use cases require retrieving smaller portions of text, and dense vector-based retrieval systems often perform better with shorter text segments, as the semantics are less likely to be over-compressed in the embeddings. Consequently, practitioners often split text documents into smaller chunks and encode them separately. However, chunk embeddings created in this way can lose contextual information from surrounding chunks, resulting in sub-optimal representations. In this paper, we introduce a novel method called late chunking, which leverages long context embedding models to first embed all tokens of the long text, with chunking applied after the transformer model and just before mean pooling - hence the term late in its naming. The resulting chunk embeddings capture the full contextual information, leading to superior results across various retrieval tasks. The method is generic enough to be applied to a wide range of long-context embedding models and works without additional training. To further increase the effectiveness of late chunking, we propose a dedicated fine-tuning approach for embedding models.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-6.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Michael Günther</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/arxiv-logo-fb-2.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## To Chunk or Not to Chunk?

We’ve already seen that long-context embedding generally outperforms shorter text embeddings, and given an overview of both naive and late chunking strategies. The question now is: Is chunking better than long-context embedding?

To conduct a fair comparison, we truncate text values to the maximum sequence length of the model (8,192 tokens) before starting to segment them. We use fixed-size segmentation with 64 tokens per segment (for both naive segmentation and late chunking). Let's compare three scenarios:

- **No segmentation:** We encode each text into a single embedding. This leads to the same scores as the previous experiment (see Figure 2), but we include them here to better compare them.
- **Naive chunking:** We segment the texts, then apply naive chunking based on the boundary cues.
- **Late chunking:** We segment the texts, then use late chunking to determine embeddings.

For both late chunking and naive segmentation, we use chunk retrieval to determine the relevant document (as shown in Figure 5, earlier in this post).

The results show no clear winner:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image-3.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image-3.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image-3.png 1000w, https://cms.jina.ai/content/images/2024/12/image-3.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="600" alt="Bar chart showcasing performance comparison of methods like No Chucking and Naive Chunking based on NDCG@10%, with a dynamic " />
<figcaption><span style="white-space: pre-wrap;">Figure 8: No chunking vs naive chunking vs late chunking</span></figcaption>
</figure>

- **For fact retrieval, naive chunking performs better:** For the QMSum, NarrativeQA, and 2WikiMultiHopQA datasets, the model has to identify relevant passages in the document. Here, naive chunking is clearly better than encoding everything into a single embedding, as likely only a few chunks include relevant information, and said chunks capture it much better than a single embedding of the whole document.
- **Late chunking works best with coherent documents and relevant context:** For documents covering a coherent topic where users search for overall themes rather than specific facts (like in NFCorpus), late chunking slightly outperforms no chunking, as it balances document-wide context with local detail. However, while late chunking generally performs better than naive chunking by preserving context, this advantage can become a liability when searching for isolated facts within documents containing mostly irrelevant information - as seen in the performance regressions for NarrativeQA and 2WikiMultiHopQA, where the added context becomes more distracting than helpful.

### Does Chunk Size Make a Difference?

The effectiveness of chunking methods really depends on the dataset, highlighting how content structure plays a crucial role:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/12/image--21-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/12/image--21-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/12/image--21-.png 1000w, https://cms.jina.ai/content/images/2024/12/image--21-.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="1800" alt="Three comparative graphs displaying performance metrics for datasets NFCorpus, QMSum, and NarrativeQA using Naive and Late Ch" />
<figcaption><span style="white-space: pre-wrap;">Figure 9: Comparison of chunk sizes with naive and late chunking.</span></figcaption>
</figure>

As we can see, late chunking generally beats naive chunking at smaller chunk sizes, since smaller naive chunks are too small to contain much context, while smaller late chunks retain the context of the entire document, making them more semantically meaningful. The exception to this is the NarrativeQA dataset where there is simply so much irrelevant context that late chunking falls behind. At larger chunk sizes, naive chunking shows marked improvement (occasionally beating late chunking) due to the increased context, while late chunking’s performance gradually decreases.

## Takeaways: When To Use What?

In this post, we’ve looked at different types of document retrieval tasks to better understand when to use segmentation and when late chunking helps. So, what we have learned?

### When Should I use Long-Context Embedding?

In general, it doesn’t harm retrieval accuracy to include as much text of your documents as you can to the input of your embedding model. However, long-context embedding models often focus on the beginning of documents, as they contain content like titles and introduction which are more important for judging relevance, but the models might miss content in the middle of the document.

### When Should I use Naive Chunking?

When documents cover multiple aspects, or user queries target specific information within a document, chunking generally improves retrieval performance.

Eventually, segmentation decisions depend on factors like the need to display partial text to users (e.g. as Google presents the relevant passages in the previews of the search results), which makes segmentation essential, or constraints on compute and memory, where segmentation may be less favorable due to increased retrieval overhead and resource usage.

### When Should I use Late Chunking?

By encoding the full document before creating chunks, late chunking solves the problem of text segments losing their meaning due to missing context. This works particularly well with coherent documents, where each part relates to the whole. Our experiments show that late chunking is especially effective when dividing text into smaller chunks, as demonstrated in our [paper](https://arxiv.org/abs/2409.04701). However, there's one caveat: if parts of the document are unrelated to each other, including this broader context can actually make retrieval performance worse, as it adds noise to the embeddings.

## Conclusion

The choice between long-context embedding, naive chunking, and late chunking depends on the specific requirements of your retrieval task. Long-context embeddings are valuable for coherent documents with general queries, while chunking excels in cases where users seek specific facts or information within a document. Late chunking further enhances retrieval by retaining contextual coherence within smaller segments. Ultimately, understanding your data and retrieval goals will guide the optimal approach, balancing accuracy, efficiency, and contextual relevance.

If you're exploring these strategies, consider trying out `jina-embeddings-v3`—its advanced long-context capabilities, late chunking, and flexibility make it an excellent choice for diverse retrieval scenarios.

<figure class="kg-card kg-bookmark-card">
<a href="https://jina.ai/news/jina-embeddings-v3-a-frontier-multilingual-embedding-model/" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings v3: A Frontier Multilingual Embedding Model
</div>
<div class="kg-bookmark-description">
jina-embeddings-v3 is a frontier multilingual text embedding model with 570M parameters and 8192 token-length, outperforming the latest proprietary embeddings from OpenAI and Cohere on MTEB.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-128x128-15.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">Jina AI</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/v3banner-5.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>
