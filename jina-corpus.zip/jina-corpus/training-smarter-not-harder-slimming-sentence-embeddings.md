---
title: "Training Smarter, Not Harder: Slimming Down Sentence Embeddings"
slug: training-smarter-not-harder-slimming-sentence-embeddings
url: https://cms.jina.ai/training-smarter-not-harder-slimming-sentence-embeddings/
published_at: 2023-08-23T15:37:37.000+02:00
updated_at: 2024-10-22T07:55:44.000+02:00
reading_time: 4
authors: "Engineering Group"
tags: "Tech Blog"
excerpt: "Jina AI trains top-tier sentence embeddings with 20% of the data. How? Maniacal filtering and shrewd sampling unmask the waste in Big Tech's data-hungry doctrine. Our streamlined embeddings rival titans' with meticulous curation, not mindless consumption. Technical ingenuity, not gluttony."
---

# Training Smarter, Not Harder: Slimming Down Sentence Embeddings

At Jina AI, sentence embedding models are a critical component of many natural language processing and multimodal AI systems we develop. By encoding semantic information into vector representations, these models equip systems to assess similarity, retrieve relevant passages, and even generate embeddings tailored to specific downstream tasks.

However, a lingering concern around sentence embedding models has been their immense appetite for training data. Models like [Sentence-BERT](https://arxiv.org/abs/1908.10084) and [Sentence-T5](https://arxiv.org/abs/2104.08821) are trained on billions of sentence pairs, demanding substantial computational resources. This causes both financial and environmental strains that limit access and adoption of these models.

In our new paper, we demonstrate that with careful data filtering and training methodology, compelling sentence embeddings can be attained using far less data than previously assumed. Our newly developed **`JINA EMBEDDINGS`** models deliver performance rivaling state-of-the-art models while reducing training samples by over 80%.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2307.11224" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Jina Embeddings: A Novel Set of High-Performance Sentence Embedding Models
</div>
<div class="kg-bookmark-description">
Jina Embeddings constitutes a set of high-performance sentence embedding models adept at translating various textual inputs into numerical representations, thereby capturing the semantic essence of the text. The models excel in applications such as dense retrieval and semantic textual similarity. Th…
</div>
<div class="kg-bookmark-metadata">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/icons/apple-touch-icon.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Michael Günther</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://static.arxiv.org/static/browse/0.3.4/images/arxiv-logo-fb.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/jinaai" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
jinaai (Jina AI)
</div>
<div class="kg-bookmark-description">
machine-learning, deep-learning, semantic-search, creative-ai, multimodal machine-learning, neural-search, vector-search, crossmodal machine-learning
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/jinaai.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## The Power of Preprocessing

Many datasets for training sentence embedding models contain duplicates, non-English samples, and low-quality pairs with minimal semantic similarity. By meticulously removing such cases, we condensed our initial dataset from 1.5 billion pairs down to a refined 385 million high-quality samples.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2023/08/image-7.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/08/image-7.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/08/image-7.png 1000w, https://cms.jina.ai/content/images/2023/08/image-7.png 1408w" sizes="(min-width: 720px) 720px" width="1408" height="510" alt="Two labeled pie charts showing data distribution across platforms like Reddit and Stack Exchange, with percentages." />
<figcaption>The composition of 385 million pairwise data</figcaption>
</figure>

We applied a multi-step filtering process encompassing:

- **De-duplication**: Removing duplicate entries.
- **Language filtering**: Eliminating non-English sentences.
- **Consistency filtering**: Excluding pairs with low embedding similarity based on an auxiliary model. This screened out 84.3% of the Reddit dataset.

An ablation study on the impact of these steps showed consistency filtering, in particular, gave significant gains on retrieval tasks. This indicates that training on a smaller set of truly relevant pairs trumps indiscriminate exposure to billions of noisy examples.

## Shrewd Sampling During Training

In addition to filtering the data itself, we employed smart sampling strategies when creating training batches. Our parallelized approach trains on all datasets simultaneously, but ensures each batch contains examples from just one dataset.

The sampling rates for drawing datasets are weighted based on their relative sizes and quality. This prevents overfitting on smaller datasets while ensuring sufficient exposure to key high-value datasets.

Together with filtering, the weighted sampling reduces the actual number of training pairs encountered to only 180 million. This frugal fine-tuning strategy departs drastically from the data-hungry doctrines of Big Tech.

## Triplet Training Targets Specificity

After pre-training on paired data, we incorporate a triplet training phase using smaller datasets. Here, each sample contains a query, positive match, and negative match. The model learns to embed the query closer to the positive than the negative.

This second stage exposes models to hard negatives, making embeddings more discriminative. It also incorporates custom negation data to help distinguish contradictory statements. Our jina-large-v1 model saw accuracy on hard negations improve from 16.6% to 65.4% after this triplet training.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/08/image-8.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/08/image-8.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/08/image-8.png 1000w, https://cms.jina.ai/content/images/2023/08/image-8.png 1296w" sizes="(min-width: 720px) 720px" width="1296" height="610" alt="A table listing models and their performance on a Negation Dataset with parameters and training samples, referencing Huggingf" />
</figure>

Adding triplet training atop strong pre-training on filtered pairs gives embeddings with strong generalizability *and* fine-grained specificity.

## Proof is in the Benchmarks

We benchmarked our **`JINA EMBEDDINGS`** against models like Sentence-T5 and competitors on established datasets including MTEB and BEIR.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/08/image-9.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/08/image-9.png 600w, https://cms.jina.ai/content/images/2023/08/image-9.png 760w" sizes="(min-width: 720px) 720px" width="760" height="712" alt="Table displaying scores for models on RR, RT, and STS tasks with numerical data indicating performance." />
</figure>

Remarkably, our 110 million parameter **jina-base-v1** model matched or exceeded the performance of the 330 million parameter **sentence-t5-large** on numerous retrieval and reranking tasks. Even the small 35 million parameter **jina-small-v1** showed competitive scores, demonstrating the data and training efficiencies unlock smaller yet powerful models.

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2023/08/image-10.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2023/08/image-10.png 600w, https://cms.jina.ai/content/images/size/w1000/2023/08/image-10.png 1000w, https://cms.jina.ai/content/images/size/w1600/2023/08/image-10.png 1600w, https://cms.jina.ai/content/images/2023/08/image-10.png 1842w" sizes="(min-width: 720px) 720px" width="1842" height="520" alt="Table showing performance comparison of machine learning models based on nDCG@10 score for retrieval tasks." />
</figure>

<figure class="kg-card kg-bookmark-card">
<a href="https://huggingface.co/spaces/mteb/leaderboard" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
MTEB Leaderboard - a Hugging Face Space by mteb
</div>
<div class="kg-bookmark-description">
Discover amazing ML apps made by the community
</div>
<div class="kg-bookmark-metadata">
<img src="https://huggingface.co/favicon.ico" class="kg-bookmark-icon" /><span class="kg-bookmark-author">a Hugging Face Space by mteb</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cdn-thumbnails.huggingface.co/social-thumbnails/spaces/mteb/leaderboard.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

## The Bigger Picture

With meticulous data curation and an inventive training approach, we push state-of-the-art sentence embedding performance while slashing the data demand by over 80%. This carries profound implications:

- **Reduced resources:** Lower data requirements cut computing infrastructure and energy needs for training.
- **Increased accessibility:** Efficient data usage unlocks performant small models, expanding access for organizations without massive compute budgets.
- **Responsible AI:** Judicious data usage and smaller models align with principles of responsible AI by limiting wasteful resource consumption.

Our work signifies masterful model development need not equate to mindless data consumption. Our technical ingenuity in creating the `JINA EMBEDDINGS` sets an important precedent - great NLP results can be achieved while exercising data frugality.
