---
title: "Using DeepSeek R1 Reasoning Model in DeepSearch"
slug: using-deepseek-r1-reasoning-model-in-deepsearch
url: https://cms.jina.ai/using-deepseek-r1-reasoning-model-in-deepsearch/
published_at: 2025-04-01T09:38:45.000+02:00
updated_at: 2025-04-01T20:11:23.000+02:00
reading_time: 17
authors: "Andrei Ungureanu, Alex C-G"
tags: "Tech Blog"
excerpt: "Standard LLM or reasoning model, which is better for DeepSearch? In this post, we explored using DeepSeek-R1 in the DeepSearch implementation for choosing the next action."
---

# Using DeepSeek R1 Reasoning Model in DeepSearch

[In our view, DeepSearch is essentially a big while-loop.](https://jina.ai/news/a-practical-guide-to-implementing-deepsearch-deepresearch) Given maximum token budgets, it cycles between searching, reading, and thinking until it finds the best answer. One of the LLM's key tasks is determining which action to take next based on the current memory state. Should it continue searching? Read the webpage? Or answer the question directly?

In our [node-deepresearch](https://github.com/jina-ai/node-DeepResearch) implementation, we use a *standard* LLM (`gemini-2.0-flash`) for choosing the action. We call it "standard" as the reasoning process is explicitly outlined via prompt engineering, and then operates as sequence-in, sequence-out with the chosen action returned in a JSON object. So a natural question arises: would replacing this decision step with a dedicated reasoning model improve DeepSearch performance?

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/04/Heading--91-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/04/Heading--91-.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/04/Heading--91-.png 1000w, https://cms.jina.ai/content/images/2025/04/Heading--91-.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="630" alt="Diagram comparing Gemini 2.0 Flash algorithm and standard LLM, showing budget, next actions, and flow of reasoning with color" />
<figcaption><span style="white-space: pre-wrap;">The action-decision step of the big while-loop in our DeepSearch implementation determines, based on the current context and memory, what the next action should be.</span></figcaption>
</figure>

In this post, we explore using [DeepSeek R1](https://github.com/deepseek-ai/DeepSeek-R1) 671b, a reasoning LLM to replace `gemini-2.0-flash` for this decision step. We believe that R1’s reasoning skills will help it solve the complex problems in searching the web and analyzing the results.

To test this concept, we set it loose on a practical example: planning a comprehensive three-day holiday itinerary, and then evaluate how it performed. Agent performing deep search tasks are likely to encounter the same kind of problems as humans, so in our holiday task the model may encounter some of the following issues:

- **Knowledge gaps (information dependent on other information)**: For example, you want to visit the Eiffel Tower, but don't know if it's open on public holidays. You need to find out both the tower's holiday schedule and the dates of French public holidays.
- **Wrong or outdated information**: A travel blog from 2020 suggests a specific restaurant in Rome is open on Sundays, but upon arrival, you find it has changed its hours and is now closed on Sundays.
- **Contradictory information**: One travel website claims that a particular hotel in New York offers free breakfast, while another site states that breakfast is not included in the room rate.
- **Ambiguous information**: A travel forum post mentions "a great beach near Barcelona" without specifying which beach or providing clear directions, making it difficult to pinpoint the exact location.

R1 can break down complex tasks into actionable steps, identify gaps and inconsistencies, and navigate hurdles like blocked websites and subscriber walls. It has the reasoning abilities to gather the required knowledge and synthesize an answer. However, it can’t plan a holiday for us alone — that requires searching the web and understanding the results it gets back. We have to soup it up, putting in a framework and enhancing its abilities, before it’s up to the job.

## Implementation

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://colab.research.google.com/drive/18sqU8_eWqFleKqpd-SnGDNmZ_P1KLfXw?usp=sharing#scrollTo=2jFWdbnp_6ws" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Google Colab
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-32.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/colab_favicon_256px-7.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">To run the notebook, you’ll need free </span><a href="https://jina.ai"><span style="white-space: pre-wrap;">Jina AI</span></a><span style="white-space: pre-wrap;"> and </span><a href="https://openrouter.ai"><span style="white-space: pre-wrap;">OpenRouter</span></a><span style="white-space: pre-wrap;"> API keys.</span></p></figcaption>
</figure>

While R1 is the engine of our agent, we also add some tools, a state object, and, of course, a (rather large) prompt. Here’s a simplified representation:

<figure class="kg-card kg-image-card">
<img src="https://cms.jina.ai/content/images/2025/03/image-29.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-29.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/03/image-29.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/03/image-29.png 1600w, https://cms.jina.ai/content/images/2025/03/image-29.png 1639w" sizes="(min-width: 720px) 720px" width="1639" height="2256" alt="Technical flowchart of an AGENT SYSTEM illustrating stages like response, tool execution, and status checks." />
</figure>

- **The tools** can be called by the model to search and scrape the web, and results are stored in the state.
- **The state** keeps track of tool results, task status, and knowledge. It’s stored in the prompt itself.
- **A single prompt** provides instructions, specifying the task and how to go about it, as well as storing the state.

We’ll go over each of these in more detail later in the post, especially the prompt. But, in short, the system works as follows:

We start with the prompt with an unpopulated state object. While the task is in progress (i.e. trying to produce an answer) the agent runs through the following loop until it produces an answer:

1.  The model examines the task and its state from the prompt, and reasons how best to use its tools to get an answer.
2.  The model outputs a JSON object specifying its status (`IN PROGRESS` or `DONE`), memory updates, tool calls, and the answer (initially `null`).
3.  The agent calls tools asynchronously and results are embedded back into the prompt, as well as the JSON object from step 3.
4.  The prompt (containing this new information) is fed back into the model to run for another loop.

As soon as the model provides an answer in its output, the task ends and the answer is delivered.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

To get a better idea for how the agent works in action, we suggest you try [the notebook](https://colab.research.google.com/drive/18sqU8_eWqFleKqpd-SnGDNmZ_P1KLfXw?usp=sharing#scrollTo=2jFWdbnp_6ws) yourself and examine the output at each iteration.

</div>

</div>

Now that we’ve got a high-level overview, let’s look at the tools, state, and prompt in turn:

## Tools

Since R1 can't search or scrape the web by itself, we access Jina’s Reader API to expand its capabilities. This includes two modes:

- **Search mode**: searches the web for relevant terms and return search engine results (including URLs, titles, and descriptions of each result).
- **Read mode**: scrapes pages from search results and returns them in Markdown format.

Due to R1’s limited context window, we can’t just dump the a whole page into the `Tool Results` section of the prompt. We need extra tooling to select just the most relevant information before passing it to the model:

- [**LangChain recursive character text splitter**](https://python.langchain.com/docs/concepts/text_splitters/): We break long outputs into segments with `RecursiveCharacterTextSplitter`, recursively splitting on paragraphs and sentences until we get the desired segment size. This ensures output is easily digestible by R1's limited context window.
- [**Jina Reranker**](https://jina.ai/reranker): We rerank the segments with `jina-reranker-v2-base-multilingual` and combines the top-ranked segments into one result.

Unfortunately, DeepSeek R1 doesn’t support tool use in the same way as `o3-mini` does. For example, with `o3-mini`, we could use something like the following:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode python"><code class="sourceCode python"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="kw">def</span> scrape_page(url: <span class="bu">str</span>):</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>    <span class="co">&quot;&quot;&quot;Scrape a web page with Jina Reader&quot;&quot;&quot;</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>tools <span class="op">=</span> [</span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>    {</span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>        <span class="st">&quot;type&quot;</span>: <span class="st">&quot;function&quot;</span>,</span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>        <span class="st">&quot;function&quot;</span>: {</span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>            <span class="st">&quot;name&quot;</span>: <span class="st">&quot;scrape_page&quot;</span>,</span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>            <span class="st">&quot;description&quot;</span>: <span class="st">&quot;Scrape the content of a webpage&quot;</span>,</span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a>            <span class="st">&quot;parameters&quot;</span>: {</span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>                <span class="st">&quot;url&quot;</span>: {<span class="st">&quot;type&quot;</span>: <span class="st">&quot;string&quot;</span>, <span class="st">&quot;description&quot;</span>: <span class="st">&quot;The URL to scrape&quot;</span>}</span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>            }</span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a>        }</span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a>    }</span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a>]</span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a>client <span class="op">=</span> OpenAI()</span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a>response <span class="op">=</span> client.completions.create(</span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a>    model<span class="op">=</span><span class="st">&quot;o3-mini&quot;</span>,</span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a>    prompt<span class="op">=</span><span class="ss">f&quot;Scrape www.skyscanner.net/routes/gr/de/germany-to-crete.html&quot;</span>,</span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a>    tools<span class="op">=</span>tools</span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a>)</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Example o3-mini code to support tool use</span></p></figcaption>
</figure>

But this isn’t so easy with R1: It doesn’t have a `tools` parameter that we can pass to the API, and it won’t return structured `tool_calls` as part of its response. Simply put, it wasn’t trained to make use of tools ([and it won’t support them any time soon](https://github.com/deepseek-ai/DeepSeek-R1/issues/9)). At least, it doesn’t support them in the traditional sense. However, we *can* still ask R1 to output tool calls in JSON format, and feed the tool call results back into the model to analyze:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="an">You must respond with a valid JSON object containing:</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a><span class="in">```json</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="fu">{</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;tool_calls&quot;</span><span class="fu">:</span> <span class="ot">[</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>    <span class="fu">{</span><span class="dt">&quot;tool&quot;</span><span class="fu">:</span> <span class="st">&quot;search&quot;</span><span class="fu">,</span> <span class="dt">&quot;input&quot;</span><span class="fu">:</span> <span class="st">&quot;Cheapest flights from Germany to Crete May 2025&quot;</span><span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>    <span class="fu">{</span><span class="dt">&quot;tool&quot;</span><span class="fu">:</span> <span class="st">&quot;scrape&quot;</span><span class="fu">,</span> <span class="dt">&quot;input&quot;</span><span class="fu">:</span> <span class="st">&quot;&lt;https://www.skyscanner.net/routes/gr/de/germany-to-crete.html&gt;&quot;</span><span class="fu">}</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a>  <span class="ot">]</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a><span class="fu">}</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Tool calls as part of R1's prompt</span></p></figcaption>
</figure>

After the model outputs tool calls in iteration *n*, the tools are called, and results are embedded into the `Tool Results` section of the prompt for the model to reason with on iteration *n+1*:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="an">Tool Results:</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>Source 1️: search: Cheapest flights from Germany to Crete May 2025</span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>Result:</span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a><span class="in">Title: Affordable flights: Germany - Heraklion (Crete) (HER) | Eurowings URL Source: https://www.eurowings.com/en/booking/offers/flights-from/DE/to/GR/HER.html Description: Affordable flights from Germany to Heraklion (Crete) ✈ Eurowings brings you closer to your dream destination from as little as €89.99*. Book now and enjoy.</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a><span class="in">Title: Are you a person or a robot? URL Source: https://www.skyscanner.com/routes/fran/her/frankfurt-to-crete-heraklion.html Description: Book a one-way ticket from Frankfurt to Heraklion Airport from $78 or travel return from just $154. The prices shown are based on availability and could change ...</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Tool results, showing search results for Germany-Crete flights</span></p></figcaption>
</figure>

## State

The state keeps track of task status (`Status`) and knowledge (`Memory`) which the model needs to analyze and update. In short, it’s the system’s working memory and memory banks. This is stored in a section of the prompt called `{{ workspace }}` and it starts off as a blank slate:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="an">Status:</span><span class="co"> IN_PROGRESS</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a><span class="an">Memory:</span><span class="co"> </span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>... no memory blocks ..</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Empty state object</span></p></figcaption>
</figure>

As the model reasons about the task, runs tools, and gathers output, the state is populated with memory blocks (derived from tool output), each with their own randomly-assigned ID. For our holiday planning example, the state might look like this after we run one iteration of the agent:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="an">Status:</span><span class="co"> IN_PROGRESS</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a><span class="an">Memory:</span><span class="co"> </span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;</span><span class="kw">nuz-032</span><span class="dt">&gt;</span>Potential warm May destinations: Malaga (Spain), Crete (Greece), Algarve (Portugal)<span class="dt">&lt;/</span><span class="kw">nuz-032</span><span class="dt">&gt;</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;</span><span class="kw">xwj-969</span><span class="dt">&gt;</span>URL to scrape for Crete hotel details: <span class="ot">&lt;https://www.tripadvisor.com/HotelsList-Crete-Beachfront-Cheap-Hotels-zfp13280541.html&gt;</span><span class="dt">&lt;/</span><span class="kw">xwj-969</span><span class="dt">&gt;</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a><span class="dt">&lt;</span><span class="kw">vsc-583</span><span class="dt">&gt;</span>URL to scrape for flight details: <span class="ot">&lt;https://www.expedia.com/lp/flights/fra/her/frankfurt-to-heraklion&gt;</span><span class="dt">&lt;/</span><span class="kw">vsc-583</span><span class="dt">&gt;</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">State populated by DeepSeek R1</span></p></figcaption>
</figure>

The memory blocks are updated by including a list of `memory_updates` in the model’s JSON response:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode json"><code class="sourceCode json"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="fu">{</span></span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>    <span class="dt">&quot;memory_updates&quot;</span><span class="fu">:</span> <span class="ot">[</span></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span><span class="dt">&quot;operation&quot;</span><span class="fu">:</span> <span class="st">&quot;add&quot;</span><span class="fu">,</span> <span class="dt">&quot;content&quot;</span><span class="fu">:</span> <span class="st">&quot;Round-trip flight from Berlin to Tenerife in May 2025 ranges from €59.99 to €200 round-trip as per the Skyscanner and Iberia sources.&quot;</span><span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>      <span class="fu">{</span><span class="dt">&quot;operation&quot;</span><span class="fu">:</span> <span class="st">&quot;delete&quot;</span><span class="fu">,</span> <span class="dt">&quot;id&quot;</span><span class="fu">:</span> <span class="st">&quot;nuz-032&quot;</span><span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>      <span class="er">...</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a>    <span class="ot">]</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a><span class="fu">}</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Memory updates as part of R1's JSON output</span></p></figcaption>
</figure>

- The **`add` operation** adds a memory block and can be used to store important information such as leads, findings, information gaps, and actions its already taken.
- The **`delete` operation** deletes a memory block, allowing the model to delete old, unnecessary, or false information and maintain a clean workspace.

<div class="kg-card kg-callout-card kg-callout-card-yellow">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

We also tested a `replace` operation, but we found the model generated large blocks of information (overly relying on `replace`), and decided to remove this option.

</div>

</div>

Compared to issuing tool calls, R1 is less familiar with managing its own memory. While the model was specifically trained to reason through complex math problems and coding tasks—training that enables it to produce accurate JSON objects and execute tool calls—it wasn't trained to manage memory-like states (nor was any other model we know of).

Storing information using a compact memory-like state provides several advantages over storing the entire output from the model each round. This approach condenses information within the prompt, preventing context overflow while enhancing the model's focus on relevant knowledge. We keep as JSON because it’s easy to update but the JSON gets rendered in a human readable format in the prompt itself.

Even so, memory management still falls outside R1’s core domain; we needed to implement multiple instructions to guide the model in properly handling memory operations. Here’s the part of our prompt that deals with that:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>... other contents of the prompt ...</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="fu">## Memory Block Usage</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Each memory block has a unique ID in format <span class="dt">&lt;</span><span class="kw">abc-123</span><span class="dt">&gt;</span>content<span class="dt">&lt;/</span><span class="kw">abc-123</span><span class="dt">&gt;</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Create separate blocks for distinct pieces of information:</span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Discovered URLs (both explored and pending)</span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Information gaps that need investigation</span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Actions already taken (to avoid repetition)</span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Promising leads for future exploration</span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Key facts and findings</span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Contradictions or inconsistencies found</span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Keep each block focused on a single idea or piece of information</span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Always cite sources when recording information from tool results</span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Use IDs to track and manage your knowledge (e.g., deleting outdated information)</span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Make sure to store sources (URLs) for the facts and findings you store</span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a><span class="fu">## Lead Management</span></span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Since you can only make 3 tool calls per round, store promising leads for later</span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Create dedicated memory blocks for URLs to scrape later</span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Maintain blocks for potential search queries to explore in future rounds</span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Prioritize leads based on relevance to the task</span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a>... other contents of the prompt ...</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Memory handling instructions in prompt</span></p></figcaption>
</figure>

## Prompt

We created the prompt using the [Jinja template format](https://jinja.palletsprojects.com/en/stable/templates/). It consists of several sections:

- **Context** (in this case, the current date).
- **Instructions**, covering how everything works, and telling the model which tools are available.
- **State**, discussed above.
- **Tool outputs**, from the `search` and `scrape` tools.

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>{% macro format_tool_results(tool_records) %}</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>{% for to in tool_records %}</span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>Source {{ loop.index }}️: {{ to.tool }}: {{ to.input }}</span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a>Result:</span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="in">{{ to.output }}</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>{% endfor %}</span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a>{% endmacro %}</span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a>The date: <span class="in">`{{ current_date }}`</span>.</span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a>You are an information analysis and exploration agent that builds solutions through systematic investigation.</span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a><span class="fu">## Investigation Cycle</span></span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a>You operate in a continuous investigation cycle:</span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a><span class="ss">1. </span>Review current workspace (your memory blocks)</span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a><span class="ss">2. </span>Analyze new tool results (or initial task if first round)</span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a><span class="ss">3. </span>Update memory with new insights and track investigation progress</span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a><span class="ss">4. </span>Decide on next tools to call based on identified leads and information gaps</span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a><span class="ss">5. </span>Repeat until task completion</span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a><span class="fu">## Memory Structure</span></span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a>Your memory persists between investigation cycles and consists of:</span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**Status**: Always the first line, indicates if the task is IN_PROGRESS or DONE</span>
<span id="cb1-26"><a href="#cb1-26" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**Memory**: A collection of discrete information blocks, each with a unique ID</span>
<span id="cb1-27"><a href="#cb1-27" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-28"><a href="#cb1-28" aria-hidden="true" tabindex="-1"></a><span class="fu">## Memory Block Usage</span></span>
<span id="cb1-29"><a href="#cb1-29" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Each memory block has a unique ID in format <span class="dt">&lt;</span><span class="kw">abc-123</span><span class="dt">&gt;</span>content<span class="dt">&lt;/</span><span class="kw">abc-123</span><span class="dt">&gt;</span></span>
<span id="cb1-30"><a href="#cb1-30" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Create separate blocks for distinct pieces of information:</span>
<span id="cb1-31"><a href="#cb1-31" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Discovered URLs (both explored and pending)</span>
<span id="cb1-32"><a href="#cb1-32" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Information gaps that need investigation</span>
<span id="cb1-33"><a href="#cb1-33" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Actions already taken (to avoid repetition)</span>
<span id="cb1-34"><a href="#cb1-34" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Promising leads for future exploration</span>
<span id="cb1-35"><a href="#cb1-35" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Key facts and findings</span>
<span id="cb1-36"><a href="#cb1-36" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Contradictions or inconsistencies found</span>
<span id="cb1-37"><a href="#cb1-37" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Keep each block focused on a single idea or piece of information</span>
<span id="cb1-38"><a href="#cb1-38" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Always cite sources when recording information from tool results</span>
<span id="cb1-39"><a href="#cb1-39" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Use IDs to track and manage your knowledge (e.g., deleting outdated information)</span>
<span id="cb1-40"><a href="#cb1-40" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Make sure to store sources (URLs) for the facts and findings you store</span>
<span id="cb1-41"><a href="#cb1-41" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-42"><a href="#cb1-42" aria-hidden="true" tabindex="-1"></a><span class="fu">## Lead Management</span></span>
<span id="cb1-43"><a href="#cb1-43" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Since you can only make 3 tool calls per round, store promising leads for later</span>
<span id="cb1-44"><a href="#cb1-44" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Create dedicated memory blocks for URLs to scrape later</span>
<span id="cb1-45"><a href="#cb1-45" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Maintain blocks for potential search queries to explore in future rounds</span>
<span id="cb1-46"><a href="#cb1-46" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Prioritize leads based on relevance to the task</span>
<span id="cb1-47"><a href="#cb1-47" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-48"><a href="#cb1-48" aria-hidden="true" tabindex="-1"></a><span class="fu">## Available Tools</span></span>
<span id="cb1-49"><a href="#cb1-49" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**search**: Use for broad information gathering on new topics or concepts</span>
<span id="cb1-50"><a href="#cb1-50" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Example: {&quot;tool&quot;: &quot;search&quot;, &quot;input&quot;: &quot;renewable energy statistics 2023&quot;}</span>
<span id="cb1-51"><a href="#cb1-51" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**scrape**: Use for extracting specific details from discovered URLs</span>
<span id="cb1-52"><a href="#cb1-52" aria-hidden="true" tabindex="-1"></a><span class="ss">  * </span>Example: {&quot;tool&quot;: &quot;scrape&quot;, &quot;input&quot;: &quot;https://example.com/energy-report&quot;}</span>
<span id="cb1-53"><a href="#cb1-53" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-54"><a href="#cb1-54" aria-hidden="true" tabindex="-1"></a><span class="fu">## Tool Usage Guidelines</span></span>
<span id="cb1-55"><a href="#cb1-55" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**When to use search**: For new concepts, filling knowledge gaps, or exploring new directions</span>
<span id="cb1-56"><a href="#cb1-56" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**When to use scrape**: For URLs discovered that likely contain detailed information</span>
<span id="cb1-57"><a href="#cb1-57" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**Maximum 3 tool calls per round**</span>
<span id="cb1-58"><a href="#cb1-58" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**Never repeat the exact same tool call**</span>
<span id="cb1-59"><a href="#cb1-59" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>**Always record valuable information from tool results in memory blocks**</span>
<span id="cb1-60"><a href="#cb1-60" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-61"><a href="#cb1-61" aria-hidden="true" tabindex="-1"></a><span class="fu">## Response Format</span></span>
<span id="cb1-62"><a href="#cb1-62" aria-hidden="true" tabindex="-1"></a>You must respond with a valid JSON object containing:</span>
<span id="cb1-63"><a href="#cb1-63" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-64"><a href="#cb1-64" aria-hidden="true" tabindex="-1"></a><span class="in">```json</span></span>
<span id="cb1-65"><a href="#cb1-65" aria-hidden="true" tabindex="-1"></a><span class="fu">{</span></span>
<span id="cb1-66"><a href="#cb1-66" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;status_update&quot;</span><span class="fu">:</span> <span class="st">&quot;IN_PROGRESS or DONE&quot;</span><span class="fu">,</span></span>
<span id="cb1-67"><a href="#cb1-67" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;memory_updates&quot;</span><span class="fu">:</span> <span class="ot">[</span></span>
<span id="cb1-68"><a href="#cb1-68" aria-hidden="true" tabindex="-1"></a>    <span class="fu">{</span><span class="dt">&quot;operation&quot;</span><span class="fu">:</span> <span class="st">&quot;add&quot;</span><span class="fu">,</span> <span class="dt">&quot;content&quot;</span><span class="fu">:</span> <span class="st">&quot;New insight or lead to investigate&quot;</span><span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-69"><a href="#cb1-69" aria-hidden="true" tabindex="-1"></a>    <span class="fu">{</span><span class="dt">&quot;operation&quot;</span><span class="fu">:</span> <span class="st">&quot;delete&quot;</span><span class="fu">,</span> <span class="dt">&quot;id&quot;</span><span class="fu">:</span> <span class="st">&quot;abc-123&quot;</span><span class="fu">}</span></span>
<span id="cb1-70"><a href="#cb1-70" aria-hidden="true" tabindex="-1"></a>  <span class="ot">]</span><span class="fu">,</span></span>
<span id="cb1-71"><a href="#cb1-71" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;tool_calls&quot;</span><span class="fu">:</span> <span class="ot">[</span></span>
<span id="cb1-72"><a href="#cb1-72" aria-hidden="true" tabindex="-1"></a>    <span class="fu">{</span><span class="dt">&quot;tool&quot;</span><span class="fu">:</span> <span class="st">&quot;search&quot;</span><span class="fu">,</span> <span class="dt">&quot;input&quot;</span><span class="fu">:</span> <span class="st">&quot;specific search query&quot;</span><span class="fu">}</span><span class="ot">,</span></span>
<span id="cb1-73"><a href="#cb1-73" aria-hidden="true" tabindex="-1"></a>    <span class="fu">{</span><span class="dt">&quot;tool&quot;</span><span class="fu">:</span> <span class="st">&quot;scrape&quot;</span><span class="fu">,</span> <span class="dt">&quot;input&quot;</span><span class="fu">:</span> <span class="st">&quot;https://discovered-url.com&quot;</span><span class="fu">}</span></span>
<span id="cb1-74"><a href="#cb1-74" aria-hidden="true" tabindex="-1"></a>  <span class="ot">]</span><span class="fu">,</span></span>
<span id="cb1-75"><a href="#cb1-75" aria-hidden="true" tabindex="-1"></a>  <span class="dt">&quot;answer&quot;</span><span class="fu">:</span> <span class="st">&quot;Your final, comprehensive answer when status is DONE&quot;</span></span>
<span id="cb1-76"><a href="#cb1-76" aria-hidden="true" tabindex="-1"></a><span class="fu">}</span></span>
<span id="cb1-77"><a href="#cb1-77" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-78"><a href="#cb1-78" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-79"><a href="#cb1-79" aria-hidden="true" tabindex="-1"></a><span class="fu">## Important Rules</span></span>
<span id="cb1-80"><a href="#cb1-80" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>The &quot;add&quot; operation creates a new memory block</span>
<span id="cb1-81"><a href="#cb1-81" aria-hidden="true" tabindex="-1"></a>    You do not need to specify an ID, it will be added automatically by the system.</span>
<span id="cb1-82"><a href="#cb1-82" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>The &quot;delete&quot; operation requires the specific ID of the block to remove</span>
<span id="cb1-83"><a href="#cb1-83" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Never invent or fabricate information - only use facts from your memory or tool results</span>
<span id="cb1-84"><a href="#cb1-84" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Never make up URLs - only use URLs discovered through tool results</span>
<span id="cb1-85"><a href="#cb1-85" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>CRITICAL: Any information not recorded in your memory blocks will be lost in the next round</span>
<span id="cb1-86"><a href="#cb1-86" aria-hidden="true" tabindex="-1"></a>  For example, if you find a potential webpage to scrap, you must store the URL and your intention</span>
<span id="cb1-87"><a href="#cb1-87" aria-hidden="true" tabindex="-1"></a>  Example: <span class="in">`{&quot;operation&quot;: &quot;add&quot;, &quot;content&quot;: &quot;Found relevant URL: https://... to scrape ...&quot;}`</span></span>
<span id="cb1-88"><a href="#cb1-88" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Set status to &quot;DONE&quot; only when you have fully addressed the task</span>
<span id="cb1-89"><a href="#cb1-89" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Only include the &quot;answer&quot; field when status is &quot;DONE&quot;</span>
<span id="cb1-90"><a href="#cb1-90" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-91"><a href="#cb1-91" aria-hidden="true" tabindex="-1"></a>Task:</span>
<span id="cb1-92"><a href="#cb1-92" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-93"><a href="#cb1-93" aria-hidden="true" tabindex="-1"></a><span class="in">{{ task }}</span></span>
<span id="cb1-94"><a href="#cb1-94" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-95"><a href="#cb1-95" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-96"><a href="#cb1-96" aria-hidden="true" tabindex="-1"></a>Current workspace:</span>
<span id="cb1-97"><a href="#cb1-97" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-98"><a href="#cb1-98" aria-hidden="true" tabindex="-1"></a><span class="in">{{ workspace }}</span></span>
<span id="cb1-99"><a href="#cb1-99" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-100"><a href="#cb1-100" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-101"><a href="#cb1-101" aria-hidden="true" tabindex="-1"></a>Tool Results:</span>
<span id="cb1-102"><a href="#cb1-102" aria-hidden="true" tabindex="-1"></a>{{ format_tool_results(tool_records) if tool_records else &#39;... no previous tool results ...&#39;}}</span>
<span id="cb1-103"><a href="#cb1-103" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-104"><a href="#cb1-104" aria-hidden="true" tabindex="-1"></a>IMPORTANT: Generate a valid JSON response following the format above.</span>
<span id="cb1-105"><a href="#cb1-105" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-106"><a href="#cb1-106" aria-hidden="true" tabindex="-1"></a>Think carefully about:</span>
<span id="cb1-107"><a href="#cb1-107" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>what information do you need to preserve</span>
<span id="cb1-108"><a href="#cb1-108" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>which tools to call next</span>
<span id="cb1-109"><a href="#cb1-109" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>how to build your answer systematically with focused memory blocks</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Entire prompt used in our deep search system</span></p></figcaption>
</figure>

<div class="kg-card kg-callout-card kg-callout-card-yellow">

<div class="kg-callout-emoji">

💡

</div>

<div class="kg-callout-text">

The Jinja macro function at the top of the prompt just renders tool results in a cleaner format.

</div>

</div>

## Evaluation

We put our system to the test with our holiday planning example. Here’s the task embedded into the prompt:

``` text
Help me plan a 3 day holiday in Europe in May for under 2000 EUR
1. I need specific flight and hotel recommendations.
2. I want the destination to be warm.
3. I want to have a beach nearby the hotel.
I live in Germany.
```

Here’s the final result (after five iterations of the loop):

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>**3-Day Crete Holiday Plan (Total ≈ €600-800)**</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>✈️ *Flights (From Frankfurt):*  </span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Skyscanner: €154 round trip (May 2025 dates)  </span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>  Source: <span class="ot">&lt;https://www.skyscanner.com/routes/fran/her/frankfurt-to-crete-heraklion.html&gt;</span>  </span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Backup: Eurowings €180 round trip  </span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a>🏨 *Beachfront Hotels:*  </span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a><span class="ss">1. </span>**Georgioupolis Beach Hotel**  </span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a><span class="ss">   - </span>Direct beach access, bike rentals €10  </span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a><span class="ss">   - </span>Source: <span class="ot">&lt;https://www.tripadvisor.com/HotelsList-Crete-Beachfront-Cheap-Hotels-zfp13280541.html&gt;</span>  </span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a><span class="ss">2. </span>**JT Apartments**  </span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a><span class="ss">   - </span>€57/night, 9.5/10 rating, 5-min walk to beach  </span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a><span class="ss">   - </span>Source: <span class="ot">&lt;https://www.booking.com/region/gr/crete.html&gt;</span>  </span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a><span class="ss">3. </span>**FNK Apartments**  </span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a><span class="ss">   - </span>Sea views, 9.6/10 rating  </span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a>💰 *Budget Breakdown:*  </span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Flights: €154  </span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Hotel (3 nights): €171-250  </span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a><span class="ss">- </span>Remaining: €1,600+ for meals/activities  </span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a>*Note:* All hotels are &lt;5 mins from beaches. Crete averages 25°C in May (Source: TravelSupermarket).</span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Result for holiday search task, after five iterations</span></p></figcaption>
</figure>

That answer *looks* legitimate. But is it really? After all, models are known to hallucinate, and with a system of multiple moving parts, it’s likely something could go wrong. Let’s verify a few details in R1's output:

### Destination and Total budget

The calculations for each item all add up (we'll go into whether each item is accurate below). After all, R1 was trained on math problems. The destination also checks out; Crete is a popular location.

### Flights

Flight prices *almost* add up, but let’s see where things went wrong. First of all, here are the actual prices from *Skyscanner* from Frankfurt to Heraklion, for May 2025, round-trip:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2025/03/image-25.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2025/03/image-25.png 600w, https://cms.jina.ai/content/images/size/w1000/2025/03/image-25.png 1000w, https://cms.jina.ai/content/images/size/w1600/2025/03/image-25.png 1600w, https://cms.jina.ai/content/images/2025/03/image-25.png 2048w" sizes="(min-width: 720px) 720px" width="2000" height="2384" alt="Screenshot of a flight comparison website showing options with details on price, travel time, eco-friendliness, and departure" />
<figcaption><span style="white-space: pre-wrap;">Actual Skyscanner search results for Frankfurt-Heraklion flights for May 2025</span></figcaption>
</figure>

We can see the prices are all around the 200 EUR mark, and not the promised 154 EUR for a round-trip! But where does the error come from? Looking at the logs, we find a related memory block was added in round 3:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode json"><code class="sourceCode json"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="fu">{</span><span class="dt">&quot;operation&quot;</span><span class="fu">:</span> <span class="st">&quot;add&quot;</span><span class="fu">,</span> <span class="dt">&quot;content&quot;</span><span class="fu">:</span> <span class="st">&quot;Crete flight options: Eurowings €89.99* one-way ...&quot;</span><span class="fu">}</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Memory block related to Germany-Crete flights</span></p></figcaption>
</figure>

This block seems to be inferred from the attached search result:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>Source 1️: search: Cheapest flights from Germany to Crete May 2025</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>Result:</span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a><span class="in">... other results ...</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a><span class="in">Title: Are you a person or a robot?</span></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="in">URL Source: https://www.skyscanner.com/routes/fran/her/frankfurt-to-crete-heraklion.html</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a><span class="in">Description: Book a one-way ticket from Frankfurt to Heraklion Airport from $78 or travel </span></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a><span class="in">return from just $154. The prices shown are based on availability and could change ...</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Search result for Germany-Crete flights</span></p></figcaption>
</figure>

The model never tried to scrape this web page to confirm the results, but it likely wouldn’t have made a difference. However, it should have at least noticed the search results didn’t include “May” as the period.

### Hotel

The hotels check out, but we identified some improvements that could be made. Firstly, we wish the model had put more effort into finding the prices for Georgioupolis Beach Hotel & FNK Apartments - while it provides other information, prices are sadly lacking. To see what we mean, here’s the raw output of the scraped [URL](https://www.booking.com/region/gr/crete.html) that was used to generate hotel recommendations. It only shows prices for the first and last results, skipping the middle three:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode markdown"><code class="sourceCode markdown"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a>Source 3️: scrape: https://www.booking.com/region/gr/crete.html</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a>Result:</span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-6"><a href="#cb1-6" aria-hidden="true" tabindex="-1"></a><span class="in">Moritz Germany</span></span>
<span id="cb1-7"><a href="#cb1-7" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-8"><a href="#cb1-8" aria-hidden="true" tabindex="-1"></a><span class="in">*   ### [JT Apartments](https://www.booking.com/hotel/gr/jt-apatments.html?label=gen173nr-1FCAYoXEIFY3JldGVIM1gEaJUCiAEBmAExuAEZyAEM2AEB6AEB-AECiAIBqAIDuALSvqC-BsACAdICJDc5ZWE5ZDJkLTI2ZWEtNGNiMS04MzNlLTJhNWIyMGI5Y2M3NdgCBeACAQ&amp;sid=f21cdd5fe9eb08dcac7d3a0304f9ccc9)</span></span>
<span id="cb1-9"><a href="#cb1-9" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-10"><a href="#cb1-10" aria-hidden="true" tabindex="-1"></a><span class="in">Kissamos</span></span>
<span id="cb1-11"><a href="#cb1-11" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-12"><a href="#cb1-12" aria-hidden="true" tabindex="-1"></a><span class="in">From $57 per night</span></span>
<span id="cb1-13"><a href="#cb1-13" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-14"><a href="#cb1-14" aria-hidden="true" tabindex="-1"></a><span class="in">9.5 Exceptional 313 reviews</span></span>
<span id="cb1-15"><a href="#cb1-15" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-16"><a href="#cb1-16" aria-hidden="true" tabindex="-1"></a><span class="in">I highly recommend staying at JT Apartments. When we entered the apartment we were greeted with a pleasant surprise. Everything was well equipped. The neighborhood is peaceful, supermarket nearby. The beach is just a short walk away. It&#39;s a great location if you want to visit the most beautiful beaches in Crete. Thanks to you our stay was exactly as we had dreamed :)</span></span>
<span id="cb1-17"><a href="#cb1-17" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-18"><a href="#cb1-18" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-19"><a href="#cb1-19" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-20"><a href="#cb1-20" aria-hidden="true" tabindex="-1"></a><span class="in">Katarzyna Poland</span></span>
<span id="cb1-21"><a href="#cb1-21" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-22"><a href="#cb1-22" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-23"><a href="#cb1-23" aria-hidden="true" tabindex="-1"></a><span class="in">Aitor Germany</span></span>
<span id="cb1-24"><a href="#cb1-24" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-25"><a href="#cb1-25" aria-hidden="true" tabindex="-1"></a><span class="in">*   ### [FNK Apartments with Sea View](https://www.booking.com/hotel/gr/f-amp-k-apartments.html?label=gen173nr-1FCAYoXEIFY3JldGVIM1gEaJUCiAEBmAExuAEZyAEM2AEB6AEB-AECiAIBqAIDuALSvqC-BsACAdICJDc5ZWE5ZDJkLTI2ZWEtNGNiMS04MzNlLTJhNWIyMGI5Y2M3NdgCBeACAQ&amp;sid=f21cdd5fe9eb08dcac7d3a0304f9ccc9)</span></span>
<span id="cb1-26"><a href="#cb1-26" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-27"><a href="#cb1-27" aria-hidden="true" tabindex="-1"></a><span class="in">Agia Pelagia</span></span>
<span id="cb1-28"><a href="#cb1-28" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-29"><a href="#cb1-29" aria-hidden="true" tabindex="-1"></a><span class="in">9.6 Exceptional 64 reviews</span></span>
<span id="cb1-30"><a href="#cb1-30" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-31"><a href="#cb1-31" aria-hidden="true" tabindex="-1"></a><span class="in">We were in Crete for a week. During this time, we stayed at FnK Apartments. Froso and Konstantinos were super friendly and amazing hosts for us. They were always ready to help if we had questions or needs of any sort. The apartment itself has a beautiful view of Agia Pelagia and the surrounding bays (and even the beautiful sunrise). We can only recommend FnK Apartments!!</span></span>
<span id="cb1-32"><a href="#cb1-32" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-33"><a href="#cb1-33" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-34"><a href="#cb1-34" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-35"><a href="#cb1-35" aria-hidden="true" tabindex="-1"></a><span class="in">Moritz Germany</span></span>
<span id="cb1-36"><a href="#cb1-36" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-37"><a href="#cb1-37" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-38"><a href="#cb1-38" aria-hidden="true" tabindex="-1"></a><span class="in">mary United States</span></span>
<span id="cb1-39"><a href="#cb1-39" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-40"><a href="#cb1-40" aria-hidden="true" tabindex="-1"></a><span class="in">*   ### [Artemis Hotel Apartments](https://www.booking.com/hotel/gr/artemis-hersonisos.html?label=gen173nr-1FCAYoXEIFY3JldGVIM1gEaJUCiAEBmAExuAEZyAEM2AEB6AEB-AECiAIBqAIDuALSvqC-BsACAdICJDc5ZWE5ZDJkLTI2ZWEtNGNiMS04MzNlLTJhNWIyMGI5Y2M3NdgCBeACAQ&amp;sid=f21cdd5fe9eb08dcac7d3a0304f9ccc9)</span></span>
<span id="cb1-41"><a href="#cb1-41" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-42"><a href="#cb1-42" aria-hidden="true" tabindex="-1"></a><span class="in">Limenas Hersonissou, Hersonissos</span></span>
<span id="cb1-43"><a href="#cb1-43" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-44"><a href="#cb1-44" aria-hidden="true" tabindex="-1"></a><span class="in">9.0 Wonderful 419 reviews</span></span>
<span id="cb1-45"><a href="#cb1-45" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-46"><a href="#cb1-46" aria-hidden="true" tabindex="-1"></a><span class="in">If you want to feel welcome, to be treated like friends, to know that you will get help in everything, we highly recommend you to stay at the hotel. Thank you from the bottom of our hearts to Konstantine for the warm and very personal treatment! On our next visit to Crete, we will be happy to stay at Artemis Hotel again!</span></span>
<span id="cb1-47"><a href="#cb1-47" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-48"><a href="#cb1-48" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-49"><a href="#cb1-49" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-50"><a href="#cb1-50" aria-hidden="true" tabindex="-1"></a><span class="in">Irina Israel</span></span>
<span id="cb1-51"><a href="#cb1-51" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-52"><a href="#cb1-52" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-53"><a href="#cb1-53" aria-hidden="true" tabindex="-1"></a><span class="in">Ann Marie Ireland</span></span>
<span id="cb1-54"><a href="#cb1-54" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-55"><a href="#cb1-55" aria-hidden="true" tabindex="-1"></a><span class="in">*   ### [Pinelopi Hotel](https://www.booking.com/hotel/gr/pinelopi.html?label=gen173nr-1FCAYoXEIFY3JldGVIM1gEaJUCiAEBmAExuAEZyAEM2AEB6AEB-AECiAIBqAIDuALSvqC-BsACAdICJDc5ZWE5ZDJkLTI2ZWEtNGNiMS04MzNlLTJhNWIyMGI5Y2M3NdgCBeACAQ&amp;sid=f21cdd5fe9eb08dcac7d3a0304f9ccc9)</span></span>
<span id="cb1-56"><a href="#cb1-56" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-57"><a href="#cb1-57" aria-hidden="true" tabindex="-1"></a><span class="in">Platanes</span></span>
<span id="cb1-58"><a href="#cb1-58" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-59"><a href="#cb1-59" aria-hidden="true" tabindex="-1"></a><span class="in">7.8 Good 198 reviews</span></span>
<span id="cb1-60"><a href="#cb1-60" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-61"><a href="#cb1-61" aria-hidden="true" tabindex="-1"></a><span class="in">Great location close to the beach, great tavernas and also in a good location for traveling around by car. Quiet area, perfect for a wonderful holiday time. Spacious rooms equipped with all you need. Great value for the money. The pool area was excellent and you can relax there anytime during the day. The parking place near the hotel was perfect. I will for sure return to Pinelopi Hotel, when visiting Crete again.</span></span>
<span id="cb1-62"><a href="#cb1-62" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-63"><a href="#cb1-63" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-64"><a href="#cb1-64" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-65"><a href="#cb1-65" aria-hidden="true" tabindex="-1"></a><span class="in">Rita Romania</span></span>
<span id="cb1-66"><a href="#cb1-66" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-67"><a href="#cb1-67" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-68"><a href="#cb1-68" aria-hidden="true" tabindex="-1"></a><span class="in">Katarzyna Poland</span></span>
<span id="cb1-69"><a href="#cb1-69" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-70"><a href="#cb1-70" aria-hidden="true" tabindex="-1"></a><span class="in">*   ### [Elizabeth Suites](https://www.booking.com/hotel/gr/elizabeth-suites.html?label=gen173nr-1FCAYoXEIFY3JldGVIM1gEaJUCiAEBmAExuAEZyAEM2AEB6AEB-AECiAIBqAIDuALSvqC-BsACAdICJDc5ZWE5ZDJkLTI2ZWEtNGNiMS04MzNlLTJhNWIyMGI5Y2M3NdgCBeACAQ&amp;sid=f21cdd5fe9eb08dcac7d3a0304f9ccc9)</span></span>
<span id="cb1-71"><a href="#cb1-71" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-72"><a href="#cb1-72" aria-hidden="true" tabindex="-1"></a><span class="in">Kato Daratso</span></span>
<span id="cb1-73"><a href="#cb1-73" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-74"><a href="#cb1-74" aria-hidden="true" tabindex="-1"></a><span class="in">From $74 per night</span></span>
<span id="cb1-75"><a href="#cb1-75" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-76"><a href="#cb1-76" aria-hidden="true" tabindex="-1"></a><span class="in">9.1 Wonderful 86 reviews</span></span>
<span id="cb1-77"><a href="#cb1-77" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-78"><a href="#cb1-78" aria-hidden="true" tabindex="-1"></a><span class="in">We had a great stay made even more personable by Epas the owner who constantly had a smile and was very helpful and the staff were lovely particularly Anna. We had breakfast a couple of days which were more than plentiful. Apartments were in a perfect position for beaches and restaurants. We highly recommend The Elizabeth Suites made our first holiday in Crete 😊</span></span>
<span id="cb1-79"><a href="#cb1-79" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-80"><a href="#cb1-80" aria-hidden="true" tabindex="-1"></a><span class="in">Show more Show less</span></span>
<span id="cb1-81"><a href="#cb1-81" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-82"><a href="#cb1-82" aria-hidden="true" tabindex="-1"></a><span class="in">Jean United Kingdom</span></span>
<span id="cb1-83"><a href="#cb1-83" aria-hidden="true" tabindex="-1"></a><span class="in">```</span></span></code></pre></div>
<figcaption><p><span style="white-space: pre-wrap;">Raw scraped search results for Crete hotel listings on booking.com</span></p></figcaption>
</figure>

Secondly, we identified an additional problem while using Reranker with its predefined `top_n` of 5 results — it turns out the scraped page contained *more* than five relevant results - we could have addressed this by actually checking the relevancy score of each result, instead of taking just the top five (or however many) results. However, the ideal reranking configuration varies across tasks. A better way to handle this problem would simply be to use the entire scraped page - which sadly isn’t possible due to R1’s limited context length.

### Overall Performance and Potential Improvements

The model started well initially, but we noticed it rarely attempted to switch strategies or develop complex plans unless specifically prompted to do so. While R1 naturally employs these approaches for math and coding problems (areas it was specifically trained on), it doesn't apply the same reasoning to search tasks. While we could further fine-tune the prompt (or even use multiple prompts) to address this limitation, that wasn't our primary goal.

We also observed that R1 didn't adequately address time-sensitive information. In short, if search results don't explicitly mention an incorrect date, the model assumes the information is valid without further verification. For example, when planning a May 1 flight:

- Germany to Crete \$80 May 1: **Correct** - The model can trust this information.
- Germany to Crete \$80 January 1: **Incorrect** - The model properly identifies and discards this.
- Germany to Crete \$80: **False positive** - When no date is specified, the model fails to verify the information and incorrectly assumes validity.

If we were to continue with this project, we might look at implementing several potential improvements:

- Tracking memory block counts and prompting the model to **summarize entries** when the state becomes too large.
- Instructing the model to **exhaust all leads** before finalizing exploration and responding to queries.
- Emphasizing **verification of time-sensitive information**.
- Ensuring the model **double-checks results** by scraping URLs returned by the search tool.
- Testing our system with **future reasoning models supporting larger context windows**, though this would require substantial refactoring and testing to adapt the prompt for a different model.

## Conclusion

Even since R1's quite recent release, the landscape has evolved significantly. Projects have emerged that train reasoning models at remarkably low costs—some for as little as \$5. This democratization means that training specialized models is more accessible than ever before. Our experiments with R1 provide a useful baseline as we continue to explore how reasoning-focused LLMs can be enhanced with tools to tackle complex search tasks.

While our holiday planning example demonstrated promising results (especially for a quick demo project), it also revealed R1’s limits in handling search and memory tasks compared to its strengths in mathematics and coding. While the system successfully produced a travel plan within budget constraints, it fell short in areas like verifying time-sensitive information and thoroughly exploring all available options, highlighting the gap between the model's training focus and its application to different domains.
