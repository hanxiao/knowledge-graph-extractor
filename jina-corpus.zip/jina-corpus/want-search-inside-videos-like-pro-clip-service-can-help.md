---
title: "Want to Search Inside Videos Like a Pro? CLIP-as-service Can Help"
slug: want-search-inside-videos-like-pro-clip-service-can-help
url: https://cms.jina.ai/want-search-inside-videos-like-pro-clip-service-can-help/
published_at: 2022-12-13T10:27:09.000+01:00
updated_at: 2024-01-24T19:03:24.000+01:00
reading_time: 6
authors: "Jie Fu, Scott Martens"
tags: "Tech Blog"
excerpt: "Imagine an AI-powered grep command, one that could process a film and find segments matching a text. With Jina AI's CLIP-as-service, you can do that today. We'll show you how."
---

# Want to Search Inside Videos Like a Pro? CLIP-as-service Can Help

Wouldn’t it be great if you could search through a video the way you search through a text?

Imagine opening a digitized film, just hitting *ctrl-f* and typing “Santa”, then getting all the parts of the video with Santa Claus in it. Or just going to the command line and using the `grep` command:

``` bash
grep "Santa Claus" Santa_Claus_conquers_The_Martians.mp4
```

Normally, this would be impossible, or only possible if you had gone through the film and carefully labeled all the parts with a Santa in them already. But with Jina AI and CLIP-as-service, you can create a **video grep** command for MP4 film with just a few Python functions and a standard computer setup. There is no need for a GPU and no complex AI tech stack to install, just off-the-shelf and open-source Python libraries, with Jina AI Cloud doing all the heavy lifting.

This has immediate applications for anyone who has video data: film archivists, stock image vendors, news photographers, or even regular people who just keep videos from their cellphones around and post them to social media.

## Preliminaries

You need Python 3, and you might want to create a new virtual environment before starting. Then, install a few components at the command line with `pip`:

``` bash
pip install clip_client "docarray[full]>=0.20.0"
```

This installs:

- Jina AI’s [DocArray library](https://docarray.jina.ai/)
- Jina AI’s [CLIP-as-service](https://clip-as-service.jina.ai/) client

You'll also need an account for CLIP-as-service. If you don't already have one, there are [instructions in the Jina AI documentation](https://docs.jina.ai/jina-ai-cloud/login/). Once you have an account, you will need a token. You can get one from <a href="https://cloud.jina.ai/settings/tokens" rel="nofollow">your token settings page at Jina AI Cloud</a>, or at the command line:

``` bash
> jina auth login ⤶

Your browser is going to open the login page.
If this fails please open the following link: https://jina-ai.us.auth0.com/au....
🔐 Successfully logged in to Jina AI as....

> jina auth token create video_search ⤶
╭───────────── 🎉 New token created ─────────────╮
│ 54f0f0ef5d514ca1908698fc6d9555a5               │
│                                                │
│ You can set it as an env var JINA_AUTH_TOKEN   │
╰────── ☝️  This token is only shown once! ───────╯
```

Your token should looks something like: `54f0f0ef5d514ca1908698fc6d9555a5`

Keep your token in an environment variable, or a Python variable if you're using a notebook. You will need it later.

## Getting the Data

Loading MP4 video takes just one line of code with DocArray:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode Python"><code class="sourceCode python"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="im">from</span> docarray <span class="im">import</span> Document</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>video_uri <span class="op">=</span> <span class="st">&quot;https://archive.org/download/santa-clause-conquers-the-martians/Santa%20Clause%20Conquers%20The%20Martians.ia.mp4&quot;</span></span>
<span id="cb1-4"><a href="#cb1-4" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-5"><a href="#cb1-5" aria-hidden="true" tabindex="-1"></a>video_data <span class="op">=</span> Document(uri<span class="op">=</span>video_uri).load_uri_to_video_tensor()</span></code></pre></div>
<figcaption>Loading trailer the to the 1964 film, <em>Santa Claus Conquers the Martians</em></figcaption>
</figure>

This downloads the trailer to the public domain film *[Santa Claus Conquers the Martians](https://www.imdb.com/title/tt0058548/)* from the [Internet Archive](https://archive.org/details/santa-clause-conquers-the-martians). You can substitute another URL or a file path to a local file to use your own video instead.

The video itself is stored as a `numpy` array in the `Document.tensor` attribute of the object:

``` Python
print(video_data.tensor.shape)

(4264, 640, 464, 3)
```

The video itself is has 4,264 frames (the first dimension of the tensor), each measuring 640 pixels by 464 pixels (the second and third dimensions), and each pixel has three color dimensions (conventional RGB in the fourth dimension).

You can play the video in a notebook with the `Document.display()` method:

``` Python
video_data.display()
```

<figure class="kg-card kg-video-card kg-card-hascaption">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration"></span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+" />
</div>
</div>
</div>
<figcaption>Trailer for <em>Santa Claus conquers the Martians</em></figcaption>
</figure>

You can also use DocArray to view individual frames by their frame number. For example, frame \#1400:

<figure class="kg-card kg-code-card">
<div class="sourceCode" id="cb1"><pre class="sourceCode Python"><code class="sourceCode python"><span id="cb1-1"><a href="#cb1-1" aria-hidden="true" tabindex="-1"></a><span class="im">import</span> numpy</span>
<span id="cb1-2"><a href="#cb1-2" aria-hidden="true" tabindex="-1"></a></span>
<span id="cb1-3"><a href="#cb1-3" aria-hidden="true" tabindex="-1"></a>Document(tensor<span class="op">=</span>numpy.rot90(video_data.tensor[<span class="dv">1400</span>], <span class="op">-</span><span class="dv">1</span>)).display()</span></code></pre></div>
<figcaption>Extracting frame #1400 from the video, rotating it -90 degrees to the correct orientation, and then displaying it.</figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/12/frame1400.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/12/frame1400.png 600w, https://cms.jina.ai/content/images/2022/12/frame1400.png 640w" width="640" height="464" />
<figcaption>Frame 1400 of the trailer to <em>Santa Claus conquers the Martians</em></figcaption>
</figure>

And we can extract clips from the video by giving specific start and end frame numbers:

``` Python
clip_data = video_data.tensor[3000:3300]
Document(tensor=clip_data).save_video_tensor_to_file("clip.mp4")
Document(uri="clip.mp4").display()
```

<figure class="kg-card kg-video-card kg-card-hascaption">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration"></span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+" />
</div>
</div>
</div>
<figcaption>Frame #3000 to #3500</figcaption>
</figure>

## Extracting Keyframes

The procedure we’re using to search in videos is to extract *keyframes* and then perform our search on just those still images.

<div class="kg-card kg-callout-card kg-callout-card-blue">

<div class="kg-callout-text">

**What is a keyframe?**  
  
A keyframe is a frame in a video that is the first after a break from smooth frame-to-frame transition. This is the same as a *cut* in film editing. We can identify them by going through the video frame by frame and comparing each frame to the next one. If the difference between the two frames is more than some value, we take that to mean that there was a cut, and the later frame is a keyframe.

</div>

</div>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/11/Keyframe.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/11/Keyframe.png 600w, https://cms.jina.ai/content/images/size/w1000/2022/11/Keyframe.png 1000w, https://cms.jina.ai/content/images/size/w1600/2022/11/Keyframe.png 1600w, https://cms.jina.ai/content/images/2022/11/Keyframe.png 1673w" sizes="(min-width: 720px) 720px" width="1673" height="364" />
<figcaption>A visual illustration of keyframes.</figcaption>
</figure>

DocArray will automatically collect keyframes as it loads the video with the method `Document.load_uri_to_video_tensor()` and store them in the `Document.tags` dictionary under the key `keyframe_indices`:

``` Python
print(video_data.tags['keyframe_indices'])

[0, 25, 196, 261, 325, 395, 478, 534, 695, 728, 840, 1019, 1059, 1131, 1191, 1245, 1340, 1389, 1505, 1573, 1631, 1674, 1750, 1869, 1910, 2010, 2105, 2184, 2248, 2335, 2585, 2618, 2648, 2706, 2756, 2788, 2906, 2950, 3050, 3100, 3128, 3190, 3216, 3314, 3356, 3421, 3514, 3586, 3760, 3828, 4078]
```

The frame numbers of the keyframes are stored in the `Document.tags` dictionary under the key `keyframe_indices`.

## Performing Search

First, extract all the keyframes as images, and put each one into its own `Document`. Then compile all the frames into a `DocumentArray` object:

``` Python
from docarray import Document, DocumentArray
from numpy import rot90

keyframe_indices = video_data.tags['keyframe_indices']
keyframes = DocumentArray()
for idx in range(0, len(keyframe_indices) - 1):
    keyframe_number = keyframe_indices[idx]
    keyframe_tensor = rot90(video_data.tensor[keyframe_number], -1)
    clip_indices = {
        'start': str(keyframe_number),
        'end': str(keyframe_indices[idx + 1]),
    }
    keyframe = Document(tags=clip_indices, tensor=keyframe_tensor)
    keyframes.append(keyframe)
```

The code above uses the `Document.tags` dictionary to store the frame number (as `start`) and the frame number of the next keyframe (as `end`) so that we can extract a video clip corresponding to that keyframe.

Then access CLIP-as-service, passing it the query text – in the example *"Santa Claus"* – and the collection of keyframe images, and it will return the images ranked by how well they match the query text:

``` Python
from docarray import Document, DocumentArray
from clip_client import Client

server_url = "grpcs://api.clip.jina.ai:2096"

# substitute your own token in the line below!
jina_auth_token = "54f0f0ef5d514ca1908698fc6d9555a5"

client = Client(server_url,
                credential={"Authorization": jina_auth_token})
query = Document(text="Santa Claus", matches=keyframes)
ranked_result = client.rank([query])[0]
```

We transmit the query and keyframe images to Jina AI Cloud, and CLIP-as-service calculates an embedding vector for the text query and for each keyframe. Then, we measure the distance between the keyframe vectors and text query vectors. We return a list of keyframes ordered by their proximity to the text query in the embedding space.

You can see this represented in the figure below.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/11/santa-and-martians-1.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/11/santa-and-martians-1.png 600w, https://cms.jina.ai/content/images/2022/11/santa-and-martians-1.png 674w" width="674" height="693" />
<figcaption>CLIP translates texts and images into vectors in a common embedding space where the distance between them reflects their semantic similarity. The embedding vectors of images with Santa Claus are much closer to the vector for the text "Santa Claus" than other images.</figcaption>
</figure>

The query reorders the keyframe images in `Document.matches` in order from the best match to the worst.

``` Python
print(ranked_result.matches[0].tags)

{'start': '2105', 'end': '2184'}
```

You can see in the `Document.tags` section that we've retained the information about this keyframe: It is frame \#2105 and the next keyframe is at \#2184. With this information, we can get the short video clip that this matches:

``` Python
match = ranked_result.matches[0]
start_frame = int(match.tags['start'])
end_frame = int(match.tags['end'])
clip_data = video_data.tensor[start_frame:end_frame] 
Document(tensor=clip_data).save_video_tensor_to_file("match.mp4")
Document(uri="match.mp4").display()
```

<figure class="kg-card kg-video-card kg-card-hascaption">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
</div>
<div class="kg-video-player-container">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+PHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPjwvc3ZnPg==" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration"></span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPjwvc3ZnPg==" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+PC9zdmc+" />
</div>
</div>
</div>
<figcaption>Match #1: Frames 2105 to 2184</figcaption>
</figure>

The top five clips all contain Santa Claus:

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<tbody>
<tr>
<td>Your browser does not support the video tag.
<br />
&#10;Match #2</td>
<td>Your browser does not support the video tag.
<br />
&#10;Match #3</td>
<td>Your browser does not support the video tag.
<br />
&#10;Match #4</td>
<td>Your browser does not support the video tag.
<br />
&#10;Match #5</td>
</tr>
</tbody>
</table>

This quick and simple technique brings very sophisticated multimodal AI to users with only a standard computer setup. CLIP-as-service is a powerful tool for anyone who needs to search through large volumes of digital media to find what they’re looking for. It saves time and helps you get the most out of your digital media collection.

So the next time you need to find Santa Claus, CLIP-as-service is here to help you look!

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2022/11/DALL-E-2022-11-28-18.01.17---Santa-Claus-with-Martians--painted-in-the-style-of-Norman-Rockwell.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2022/11/DALL-E-2022-11-28-18.01.17---Santa-Claus-with-Martians--painted-in-the-style-of-Norman-Rockwell.png 600w, https://cms.jina.ai/content/images/2022/11/DALL-E-2022-11-28-18.01.17---Santa-Claus-with-Martians--painted-in-the-style-of-Norman-Rockwell.png 925w" sizes="(min-width: 720px) 720px" width="925" height="1010" />
<figcaption>“Santa Claus with Martians, painted in the style of Norman Rockwell” according to <a href="https://openai.com/dall-e-2/">DALL-E 2</a>.</figcaption>
</figure>
