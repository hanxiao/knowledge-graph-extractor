---
title: "Watermarking Text with Embedding Models to Protect Against Content Theft"
slug: watermarking-text-with-embedding-models-to-protect-against-content-theft
url: https://cms.jina.ai/watermarking-text-with-embedding-models-to-protect-against-content-theft/
published_at: 2024-11-27T03:21:28.000+01:00
updated_at: 2024-11-27T19:12:11.000+01:00
reading_time: 10
authors: "Han Xiao"
tags: "Tech Blog"
excerpt: "You use our embedding models to do what? This might be the most \"out-of-domain\" applications of embeddings we learned at EMNLP 2024."
---

# Watermarking Text with Embedding Models to Protect Against Content Theft

Sunday evening. You hit "publish" on that article you've poured your heart into all weekend. Every word, every idea - uniquely yours. A few likes trickle in. Not viral, but it's yours.

Three days later, scrolling through your feed, there it is: Your article's soul in someone else's body! They've reshuffled the words, but you know your own creation. The worst part? Their version is everywhere, viral success built on your stolen creativity. That's not the creative economy we signed up for.

The obvious solution is to put your name on your work. But let's be honest - that's also the easiest thing to remove. Can we do better? In this article, we will show you a watermarking technique using embedding models that can both sign and detect original content. This isn't just another search/RAG cliché - it leverages unique features of `jina-embeddings-v3` like long-context and cross-lingual alignment to create a robust authentication system, and allows us to maintain reliable content verification across transformations such as LLM-paraphrasing or even translation.

## Understanding Text Watermarks

Digital watermarks have been a cornerstone of content protection for years. When you found a meme with a semi-transparent logo overlaid on it, you're seeing the most basic form of image watermarking. Modern watermarking techniques have evolved far beyond simple visual overlays – many are now imperceptible to human viewers while remaining machine-readable.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/banner--3-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/11/banner--3-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/11/banner--3-.png 1000w, https://cms.jina.ai/content/images/2024/11/banner--3-.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="630" alt="Flowchart on a dark blue background delineating a document verification process with labels &quot;DOCUMENT,&quot; &quot;VERIFY_ORIGIN,&quot; and " />
<figcaption><span style="white-space: pre-wrap;">Text watermarking preserves the original meaning while embedding a detectable signature. </span></figcaption>
</figure>

Text watermarking follows similar principles but operates **in the semantic space.** Instead of altering pixels, a text watermark subtly modifies the content in ways that preserve the original meaning while embedding a detectable signature. So the key requirements for an effective text watermark are:

- **Semantic preservation**: The watermarked text should maintain its original meaning and readability, just as a visual watermark shouldn't obscure the key elements of an image.
- **Imperceptibility**: The watermark should be unnoticeable to human readers, ensuring they cannot intentionally preserve or remove it during content transformation.
- **Machine-detectable**: While the watermark might be subtle to human readers, it should create clear, measurable patterns that algorithms can reliably identify.
- **Transform-invariant**: Any content transformation (like paraphrasing or translation), whether intentional or unaware of the watermark's existence, should either preserve the watermark or require such substantial changes that it fundamentally alters the original content's structure or meaning.

## Using Embeddings for Text Watermarking

Let's build a text watermarking system using embeddings. First, let's define the key components of this system:

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/banner--7-.png" class="kg-image" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/11/banner--7-.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/11/banner--7-.png 1000w, https://cms.jina.ai/content/images/2024/11/banner--7-.png 1200w" sizes="(min-width: 720px) 720px" width="1200" height="630" alt="Flowchart illustrating a watermark verification process with &quot;Adversary,&quot; &quot;Verifier,&quot; and &quot;Injector&quot; components, including st" />
<figcaption><span style="white-space: pre-wrap;">An embedding-based text watermarking system. Verifier is the party that watermarks the original text and later detects these watermarks to identify plagiarism. Adversary is the party that attempts to modify the watermarked text to avoid detection.</span></figcaption>
</figure>

- **Input:** The original text to be watermarked.
- **Watermark Table:** A secret lexicon containing candidate watermark words. For optimal watermarking effectiveness, the words should be common enough to naturally fit in various contexts. The vocabulary excludes function words, proper nouns, and rare words that might appear out of place, e.g. `delve into`, `embark` are good candidates whereas `good` is just too common. Below, we will build our WatermarkTable using words from advanced English vocabulary.
- **Embedder:** An embedding model that serves two purposes: it selects semantically appropriate words from the `WatermarkTable` based on the `input` text and helps detect watermarks in potentially paraphrased text. We're using `jina-embeddings-v3` because it handles both super long texts and different languages really well. This means we can watermark lengthy documents and still catch copycats even if they translate the text.
- **Watermarks:** Words selected from the WatermarkTable by computing cosine similarity between the input text embedding and the embeddings in the table. The number of words is determined by an insertion ratio, typically 12% of the input word count.
- **Injector:** An instruction-following LLM that integrates the watermark words into the input text while maintaining coherence, factual accuracy, natural flow, and even distribution of watermark words throughout the text.
- **Watermarked Text:** The output after the Injector inserts the watermark words into the `input`.
- **Adversary (Content Theft)**: An entity who attempts to repurpose the watermarked text without attribution, typically through paraphrasing, translation, or minor edits. Today, this simply means using an LLM prompted with `Paraphrase [text]` for automated rewriting.
- **Modified Text:** The result after the adversary's modifications to the watermarked text. This is the text that we need to check for watermarks.

### Algorithm

<figure class="kg-card kg-video-card kg-width-regular" data-kg-thumbnail="https://cms.jina.ai/content/media/2024/11/waermarks_thumb.jpg" data-kg-custom-thumbnail="">
<div class="kg-video-container">
<div class="kg-video-overlay">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjMuMTQgMTAuNjA4IDIuMjUzLjE2NEExLjU1OSAxLjU1OSAwIDAgMCAwIDEuNTU3djIwLjg4N2ExLjU1OCAxLjU1OCAwIDAgMCAyLjI1MyAxLjM5MkwyMy4xNCAxMy4zOTNhMS41NTcgMS41NTcgMCAwIDAgMC0yLjc4NVoiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPg==" />
</div>
<div class="kg-video-player-container kg-video-hide">
<div class="kg-video-player">
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTIzLjE0IDEwLjYwOCAyLjI1My4xNjRBMS41NTkgMS41NTkgMCAwIDAgMCAxLjU1N3YyMC44ODdhMS41NTggMS41NTggMCAwIDAgMi4yNTMgMS4zOTJMMjMuMTQgMTMuMzkzYTEuNTU3IDEuNTU3IDAgMCAwIDAtMi43ODVaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMyIgeT0iMSIgd2lkdGg9IjciIGhlaWdodD0iMjIiIHJ4PSIxLjUiIHJ5PSIxLjUiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD0iMTQiIHk9IjEiIHdpZHRoPSI3IiBoZWlnaHQ9IjIyIiByeD0iMS41IiByeT0iMS41IiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<span class="kg-video-current-time">0:00</span>
<div class="kg-video-time">
/<span class="kg-video-duration">0:08</span>
</div>
1×
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1LjE4OSAyLjAyMWE5LjcyOCA5LjcyOCAwIDAgMC03LjkyNCA0Ljg1LjI0OS4yNDkgMCAwIDEtLjIyMS4xMzNINS4yNWEzIDMgMCAwIDAtMyAzdjJhMyAzIDAgMCAwIDMgM2gxLjc5NGEuMjQ5LjI0OSAwIDAgMSAuMjIxLjEzMyA5LjczIDkuNzMgMCAwIDAgNy45MjQgNC44NWguMDZhMSAxIDAgMCAwIDEtMVYzLjAyYTEgMSAwIDAgMC0xLjA2LS45OThaIiAvPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+" />
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdib3g9IjAgMCAyNCAyNCI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE2LjE3NyA0LjNhLjI0OC4yNDggMCAwIDAgLjA3My0uMTc2di0xLjFhMSAxIDAgMCAwLTEuMDYxLTEgOS43MjggOS43MjggMCAwIDAtNy45MjQgNC44NS4yNDkuMjQ5IDAgMCAxLS4yMjEuMTMzSDUuMjVhMyAzIDAgMCAwLTMgM3YyYTMgMyAwIDAgMCAzIDNoLjExNGEuMjUxLjI1MSAwIDAgMCAuMTc3LS4wNzNaTTIzLjcwNyAxLjcwNkExIDEgMCAwIDAgMjIuMjkzLjI5MmwtMjIgMjJhMSAxIDAgMCAwIDAgMS40MTRsLjAwOS4wMDlhMSAxIDAgMCAwIDEuNDA1LS4wMDlsNi42My02LjYzMUEuMjUxLjI1MSAwIDAgMSA4LjUxNSAxN2EuMjQ1LjI0NSAwIDAgMSAuMTc3LjA3NSAxMC4wODEgMTAuMDgxIDAgMCAwIDYuNSAyLjkyIDEgMSAwIDAgMCAxLjA2MS0xVjkuMjY2YS4yNDcuMjQ3IDAgMCAxIC4wNzMtLjE3NloiIC8+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz4=" />
</div>
</div>
</div>
</figure>

Given an **Input**, we first select watermarks through a selection function that identifies words from our **Watermark Table** that are semantically similar to the input. This selection uses our **Embedder** to compute similarity scores. Once we have our **Watermarks**, we use the **Injector** to seamlessly integrate them into the input text, creating the **Watermarked Text**.

For detection, we follow a similar process: we analyze the potentially **Modified Text** to find words that are semantically similar to those in our **Watermark Table**. We then compare these extracted watermarks with the original watermarks we inserted. If there is substantial overlap between these two sets of watermarks, we can conclude that the text in question was derived from our watermarked original.

Note that the **Input**, **WatermarkTable**, **Embedder**, and **Injector** must remain confidential. The adversary should only have access to the **Watermarked Text**.

### Implementation

<figure class="kg-card kg-bookmark-card kg-card-hascaption">
<a href="https://colab.research.google.com/drive/1sbIdU2tr-18sAtLvVVyhYtrIw2Cgjp8F" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
Google Colab
</div>
<div class="kg-bookmark-description">

</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/favicon-14.ico" class="kg-bookmark-icon" />
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/colab_favicon_256px-3.png" onerror="this.style.display = &#39;none&#39;" />
</div>
<figcaption><p><span style="white-space: pre-wrap;">The full implementation can be found in the link above. This code demonstrates a simplified implementation of text watermarking, serving as a proof-of-concept.</span></p></figcaption>
</figure>

This code provides a proof-of-concept for text watermarking using semantic embeddings. The implementation starts with a small, pre-defined vocabulary of about 60 advanced English words we found from English learning websites as potential watermarks and uses `jina-embeddings-v3` for semantic relations.

<figure class="kg-card kg-gallery-card kg-width-wide">
<div class="kg-gallery-container">
<div class="kg-gallery-row">
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/11/preview-1.webp" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/11/preview-1.webp 600w, https://cms.jina.ai/content/images/size/w1000/2024/11/preview-1.webp 1000w, https://cms.jina.ai/content/images/2024/11/preview-1.webp 1280w" sizes="(min-width: 720px) 720px" width="1280" height="720" />
</div>
<div class="kg-gallery-image">
<img src="https://cms.jina.ai/content/images/2024/11/image-6.png" loading="lazy" srcset="https://cms.jina.ai/content/images/size/w600/2024/11/image-6.png 600w, https://cms.jina.ai/content/images/size/w1000/2024/11/image-6.png 1000w, https://cms.jina.ai/content/images/2024/11/image-6.png 1263w" sizes="(min-width: 720px) 720px" width="1263" height="744" />
</div>
</div>
</div>
</figure>

For the injector, we use `gpt4o` with this prompt:

    Please insert [words] into [section] while maintaining maximum coherence and preserving as much of the original content as possible.

To simulate the adversary's paraphrasing and translation operations, we use `gpt4o` with these respective prompts:

    Paraphrase [section]

    Translate [section] into Chinese

Of course, the attack simulations are simplified versions of what might happen in reality. All three LLM generation services leverage PromptPerfect's "prompt-as-a-service" feature.

The watermark selection process finds words from the watermark table that are semantically similar to the input text using cosine similarity, visualizes this distribution, and picks the top 3 most similar words as watermarks.

## Qualitative Analysis

We use the company introduction as the input:

<figure class="kg-card kg-code-card">
<pre><code>Founded in 2020 in Berlin, Jina AI is a leading search AI company. The future of AI is multimodal,
and we are part of it. We recognize that businesses face challenges in leveraging multimodal data.
In response, we provide the Search Foundation, the core infrastructure for GenAI and multimodal applications.
Our mission is to help businesses and developers unlock the value of multimodal data through better search.</code></pre>
<figcaption><p><span style="white-space: pre-wrap;">The original input</span></p></figcaption>
</figure>

Based on `jina-embeddings-v3` and the watermark table we defined, the three selected watermarks are: `adjoining`, `Open-minded`, `inquisitive`.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/similarity_distribution_20241127_005652.svg" class="kg-image" loading="lazy" width="658" height="660" alt="Bar graph showing distribution of cosine similarities for groups &#39;inquisitive,&#39; &#39;open-minded,&#39; and &#39;adhering.&#39;" />
<figcaption><span style="white-space: pre-wrap;">The histogram shows the cosine similarity between each word in the watermark table and the input text, calculated using </span><span><code spellcheck="false" style="white-space: pre-wrap;">jina-embeddings-v3</code></span><span style="white-space: pre-wrap;">. The vertical dotted and dashed lines indicate the mean and median similarities respectively, while the white dots highlight the top 3 most similar words that were selected as watermarks.</span></figcaption>
</figure>

After the Injector, we get the following watermarked text:

<figure class="kg-card kg-code-card">
<pre><code>Founded in 2020 in Berlin, Jina AI is a leading search AI company. The future of AI is multimodal, and we are part of it. We recognize that businesses face challenges in leveraging multimodal data. In response, we provide the Search Foundation, the core infrastructure for GenAI and multimodal applications. Our mission is to help businesses and developers unlock the value of multimodal data through better search. Adjoining our technical expertise is our open-minded and inquisitive approach, which drives our continuous innovation and commitment to solving complex problems.</code></pre>
<figcaption><p><span style="white-space: pre-wrap;">Injecting watermarks (</span><span><code spellcheck="false" style="white-space: pre-wrap;">adjoining</code></span><span style="white-space: pre-wrap;">, </span><span><code spellcheck="false" style="white-space: pre-wrap;">Open-minded</code></span><span style="white-space: pre-wrap;">, </span><span><code spellcheck="false" style="white-space: pre-wrap;">inquisitive</code></span><span style="white-space: pre-wrap;">) into the original text</span></p></figcaption>
</figure>

After the adversary's paraphrasing, we obtain this modified text:

    Established in Berlin in 2020, Jina AI is a prominent company specializing in search AI. Our team is characterized by our open-mindedness and curiosity, consistently aiming to expand the capabilities of AI. Believing that the future of AI lies in its multimodal potential, we are excited to be at the forefront of this evolution. We understand the interconnected challenges businesses encounter when utilizing multimodal data. To address these, we offer the Search Foundation, essential infrastructure for Generative AI (GenAI) and multimodal applications. Our goal is to assist businesses and developers in unlocking the full potential of multimodal data through enhanced search capabilities.

The top three watermarks extracted from this text are:

    adjoining: 0.300
    Open-minded: 0.287
    inquisitive: 0.278

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/similarity_distribution_20241127_005702.svg" class="kg-image" loading="lazy" width="658" height="660" alt="Bar chart displaying the distribution of cosine similarities for different categories, with statistical markers like mean and" />
<figcaption><span style="white-space: pre-wrap;">Extracted watermarks from the paraphrased text.</span></figcaption>
</figure>

These match our original watermark set perfectly, confirming that this text is derived from the original input.

Similarly, when we analyze the Chinese translation of the watermarked text:

    成立于2020年，Jina AI是一家领先的搜索AI公司。我们是一个开放且好奇心强的团队，始终努力突破AI的界限。AI的未来是多模态的，我们很自豪能够成为其中的一部分。我们意识到企业在利用多模态数据时会面临相邻的挑战。为此，我们提供Search Foundation，这是GenAI和多模态应用的核心基础设施。我们的使命是通过更好的搜索，帮助企业和开发者释放多模态数据的价值。

The top three watermarks extracted from this text are:

    adjoining: 0.413
    forthcoming: 0.380
    Open-minded: 0.379

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/similarity_distribution_20241127_005706.svg" class="kg-image" loading="lazy" width="658" height="660" alt="Bar graph titled &quot;Distribution of Cosine Similarities&quot; showing groups Open-minded, Forthcoming, and Adjoining with their resp" />
<figcaption><span style="white-space: pre-wrap;">Extracted watermarks from the translation.</span></figcaption>
</figure>

Two out of three extracted watermarks are from our original watermark table, showing that this translation is very likely derived from the original input.

Let's try a slightly more challenging example by using Chapter 1, "Down the Rabbit-Hole," from Alice's Adventures in Wonderland, a 2010-token text, as our input text and repeat the watermarking process.

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/similarity_distribution_20241127_011003.svg" class="kg-image" loading="lazy" width="659" height="660" alt="Bar chart presenting cosine similarity distribution with values from 0.00 to 0.30 and key statistics like mean and median ind" />
<figcaption><span style="white-space: pre-wrap;">The three watermarks selected are </span><span><code spellcheck="false" style="white-space: pre-wrap;">inquisitive</code></span><span style="white-space: pre-wrap;">, </span><span><code spellcheck="false" style="white-space: pre-wrap;">Deep-seated</code></span><span style="white-space: pre-wrap;">, </span><span><code spellcheck="false" style="white-space: pre-wrap;">Two-year-old</code></span></figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/similarity_distribution_20241127_011052.svg" class="kg-image" loading="lazy" width="659" height="660" alt="Bar plot showing cosine similarity distributions for deep-seated, two-year-old, and inquisitive data, with frequency on the y" />
<figcaption><span style="white-space: pre-wrap;">Extracted watermarks from paraphrased text. 3/3 matching.</span></figcaption>
</figure>

<figure class="kg-card kg-image-card kg-card-hascaption">
<img src="https://cms.jina.ai/content/images/2024/11/similarity_distribution_20241127_011117.svg" class="kg-image" loading="lazy" width="659" height="660" alt="Graph showing distribution of cosine similarity with &quot;Slow-moving,&quot; &quot;Inquisitive,&quot; and &quot;Two-year-old&quot; clusters, mean of 0.317" />
<figcaption><span style="white-space: pre-wrap;">Extracted watermarks from translated text. 2/3 matching</span></figcaption>
</figure>

## Conclusion

From these examples, we can see our embedding-based watermarking is quite robust even with this basic setup. What's particularly noteworthy is that the watermarks remain detectable even after translation. This robustness across languages is made possible by the powerful multilingual capabilities of the `jina-embeddings-v3` model; without strong multilingual and cross-lingual abilities, such persistence through translation would not be achievable.

There are several ways to improve the accuracy and robustness of this watermarking system. First, the watermark table could be expanded and carefully constructed to ensure diversity. This is important because a larger, more diverse vocabulary provides better coverage of semantic spaces, making it easier to find contextually appropriate watermarks for any given text while reducing the risk of repetitive or obvious patterns.

The Injector component could be improved by implementing more sophisticated insertion strategies. For example, it could be instructed to distribute watermarks uniformly throughout the text to maintain imperceptibility. Additionally, we could employ the [late chunking](https://jina.ai/news/late-chunking-in-long-context-embedding-models/) technique to generate watermarks for individual segments or sentences, allowing the Injector to make more nuanced decisions about watermark placement. This would help maintain both overall imperceptibility and semantic coherence in the final text.

<figure class="kg-card kg-bookmark-card">
<a href="https://arxiv.org/abs/2406.14517" class="kg-bookmark-container"></a>
<div class="kg-bookmark-content">
<div class="kg-bookmark-title">
PostMark: A Robust Blackbox Watermark for Large Language Models
</div>
<div class="kg-bookmark-description">
The most effective techniques to detect LLM-generated text rely on inserting a detectable signature -- or watermark -- during the model’s decoding process. Most existing watermarking methods require access to the underlying LLM’s logits, which LLM API providers are loath to share due to fears of model distillation. As such, these watermarks must be implemented independently by each LLM provider. In this paper, we develop PostMark, a modular post-hoc watermarking procedure in which an input-dependent set of words (determined via a semantic embedding) is inserted into the text after the decoding process has completed. Critically, PostMark does not require logit access, which means it can be implemented by a third party. We also show that PostMark is more robust to paraphrasing attacks than existing watermarking methods: our experiments cover eight baseline algorithms, five base LLMs, and three datasets. Finally, we evaluate the impact of PostMark on text quality using both automated and human assessments, highlighting the trade-off between quality and robustness to paraphrasing. We release our code, outputs, and annotations at https://github.com/lilakk/PostMark.
</div>
<div class="kg-bookmark-metadata">
<img src="https://cms.jina.ai/content/images/icon/apple-touch-icon-5.png" class="kg-bookmark-icon" /><span class="kg-bookmark-author">arXiv.org</span><span class="kg-bookmark-publisher">Yapei Chang</span>
</div>
</div>
<div class="kg-bookmark-thumbnail">
<img src="https://cms.jina.ai/content/images/thumbnail/arxiv-logo-fb-1.png" onerror="this.style.display = &#39;none&#39;" />
</div>
</figure>

For readers interested in a deeper exploration, "POSTMARK: A Robust Blackbox Watermark for Large Language Models" (Chang et al., EMNLP 2024) presents a comprehensive framework including mathematical formulations and extensive experiments. The authors systematically explore watermark vocabulary construction, optimal insertion strategies, and robustness against various attacks. They also thoroughly analyze the trade-off between watermark detection and text quality through both automated and human evaluation.
